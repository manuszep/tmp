import { Subject, ReplaySubject, Subscription, BehaviorSubject } from 'rxjs';
import { Injectable, ɵɵdefineInjectable, Directive, ElementRef, Optional, Self, Renderer2, Input, NgModule, HostBinding, HostListener, Component, ChangeDetectionStrategy, ChangeDetectorRef, ContentChild, ContentChildren, ViewChild, forwardRef, Injector, ViewChildren, EventEmitter, ViewEncapsulation, Output, ComponentFactoryResolver, ViewContainerRef, TemplateRef, SkipSelf, Host, ErrorHandler, Inject, InjectionToken, APP_INITIALIZER, isDevMode } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgControl, NgForm, FormGroupDirective, NG_VALUE_ACCESSOR, FormsModule } from '@angular/forms';
import { trigger, transition, style, animate, state } from '@angular/animations';
import { RouterModule, Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { CdkAccordion, CdkAccordionItem, CdkAccordionModule } from '@angular/cdk/accordion';
import { UniqueSelectionDispatcher as UniqueSelectionDispatcher$1 } from '@angular/cdk/collections';
import { __awaiter } from 'tslib';
import { HttpClientModule } from '@angular/common/http';
import { filter, map } from 'rxjs/operators';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

/**
 * Mixin to augment a directive with updateErrorState method.
 * For component with `errorState` and need to update `errorState`.
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/forms';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/cdk/collections';
import * as ɵngcc4 from '@angular/router';

const _c0 = ["*"];
const _c1 = ["div"];
function AxaFormField_label_2_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "label");
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(ctx_r1.label);
} }
function AxaFormField_6_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0, 3, ["*ngSwitchCase", "true"]);
} }
function AxaFormField_7_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0, 4, ["*ngSwitchDefault", ""]);
} }
const _c2 = [[["axa-prefix"]], "*", [["axa-suffix"]], [["axa-error"]], [["axa-hint"]]];
const _c3 = ["axa-prefix", "*", "axa-suffix", "axa-error", "axa-hint"];
function AxaPhoneInputComponent_option_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 4);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const country_r2 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", country_r2);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate2(" ", country_r2.code, " ", country_r2.dial, " ");
} }
function AxaPhoneInputComponent_option_6_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 4);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const country_r3 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", country_r3);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate2("", country_r3.code, " ", country_r3.dial, "");
} }
function AxaAlertManager_axa_top_content_bar_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "axa-top-content-bar", 1);
    ɵngcc0.ɵɵlistener("buttonClick", function AxaAlertManager_axa_top_content_bar_1_Template_axa_top_content_bar_buttonClick_0_listener() { const alert_r1 = ctx.$implicit; return alert_r1.action && alert_r1.action.handler && alert_r1.action.handler(alert_r1.action, alert_r1); });
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const alert_r1 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("type", alert_r1.type)("buttonLabel", alert_r1.action && alert_r1.action.content);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate1(" ", alert_r1.message, " ");
} }
function AxaTopContentBarComponent_a_3_Template(rf, ctx) { if (rf & 1) {
    const _r2 = ɵngcc0.ɵɵgetCurrentView();
    ɵngcc0.ɵɵelementStart(0, "a", 1);
    ɵngcc0.ɵɵlistener("click", function AxaTopContentBarComponent_a_3_Template_a_click_0_listener($event) { ɵngcc0.ɵɵrestoreView(_r2); const ctx_r1 = ɵngcc0.ɵɵnextContext(); return ctx_r1.handleClick($event); });
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵproperty("href", ctx_r0.href, ɵngcc0.ɵɵsanitizeUrl);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(ctx_r0.buttonLabel);
} }
function AxaCookieMessage_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r2 = ɵngcc0.ɵɵgetCurrentView();
    ɵngcc0.ɵɵelementStart(0, "div", 1);
    ɵngcc0.ɵɵelement(1, "div", 2);
    ɵngcc0.ɵɵelementStart(2, "a", 3);
    ɵngcc0.ɵɵlistener("click", function AxaCookieMessage_div_0_Template_a_click_2_listener() { ɵngcc0.ɵɵrestoreView(_r2); const ctx_r1 = ɵngcc0.ɵɵnextContext(); return ctx_r1.close(); });
    ɵngcc0.ɵɵtext(3);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("innerHTML", ctx_r0.legalMessage, ɵngcc0.ɵɵsanitizeHtml);
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵtextInterpolate1(" ", ctx_r0.closeMessage, " ");
} }
function AxaDateComboPicker_option_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 2);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const day_r3 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", day_r3);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(day_r3);
} }
function AxaDateComboPicker_option_7_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 2);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const month_r4 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", month_r4);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(month_r4);
} }
function AxaDateComboPicker_option_11_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 2);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const year_r5 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", year_r5);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(year_r5);
} }
const _c4 = ["axa-footer-list", ""];
const _c5 = ["axa-footer-social", ""];
function AxaFooterComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 5);
    ɵngcc0.ɵɵprojection(1);
    ɵngcc0.ɵɵprojection(2, 1);
    ɵngcc0.ɵɵelementEnd();
} }
function AxaFooterComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 6);
    ɵngcc0.ɵɵprojection(1, 2);
    ɵngcc0.ɵɵelementEnd();
} }
function AxaFooterComponent_div_4_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 7);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate1(" ", ctx_r2.legalText, " ");
} }
const _c6 = [[["", "axa-footer-list", ""]], [["", "axa-footer-social", ""]], [["", "AxaFooterLanguage", ""]]];
const _c7 = ["[axa-footer-list]", "[axa-footer-social]", "[AxaFooterLanguage]"];
function AxaStepComponent_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0);
} }
function AxaStepHeaderComponent_span_0_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "span", 3);
    ɵngcc0.ɵɵnamespaceSVG();
    ɵngcc0.ɵɵelementStart(1, "svg", 4);
    ɵngcc0.ɵɵelement(2, "path", 5);
    ɵngcc0.ɵɵelement(3, "path", 6);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} }
function AxaStepHeaderComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0);
} }
function AxaStepHeaderComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelement(0, "div");
} if (rf & 2) {
    const ctx_r2 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵclassMap(ctx_r2.getProgressClass());
    ɵngcc0.ɵɵstyleProp("width", ctx_r2.getWidth());
} }
function AxaStepperComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementContainerStart(0);
    ɵngcc0.ɵɵelement(1, "axa-step-header", 1);
    ɵngcc0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const step_r2 = ctx.$implicit;
    const i_r3 = ctx.index;
    const ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("step", step_r2)("label", step_r2.label)("pricing", step_r2.pricing)("active", ctx_r0.getActive(i_r3))("done", ctx_r0.getDone(i_r3));
} }
function AxaStepperComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementContainerStart(0);
    ɵngcc0.ɵɵelementStart(1, "div", 2);
    ɵngcc0.ɵɵelementContainer(2, 3);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const step_r4 = ctx.$implicit;
    const i_r5 = ctx.index;
    const ctx_r1 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵattribute("aria-expanded", ctx_r1.getActive(i_r5));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngTemplateOutlet", step_r4.content);
} }
const _c8 = ["navs"];
function AxaHeaderComponent_div_12_nav_2_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "nav", 26);
    ɵngcc0.ɵɵprojection(1, 2);
    ɵngcc0.ɵɵelementEnd();
} }
function AxaHeaderComponent_div_12_nav_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "nav", 27);
    ɵngcc0.ɵɵprojection(1, 3);
    ɵngcc0.ɵɵelementEnd();
} }
function AxaHeaderComponent_div_12_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 22);
    ɵngcc0.ɵɵelementStart(1, "div", 23);
    ɵngcc0.ɵɵtemplate(2, AxaHeaderComponent_div_12_nav_2_Template, 2, 0, "nav", 24);
    ɵngcc0.ɵɵtemplate(3, AxaHeaderComponent_div_12_nav_3_Template, 2, 0, "nav", 25);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.hasDomains());
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.hasHelpers());
} }
const _c9 = [[["axa-header-nav"], ["axa-header-nav-route"]], [["axa-header-search"]], [["axa-header-meta-domain"]], [["axa-header-meta-helper"]]];
const _c10 = ["axa-header-nav, axa-header-nav-route", "axa-header-search", "axa-header-meta-domain", "axa-header-meta-helper"];
const _c11 = function (a0, a1) { return { "radio1": a0, "radio2": a1 }; };
const _c12 = [[["axa-table-of-contents-title"]], [["axa-table-of-contents-item"]]];
const _c13 = ["axa-table-of-contents-title", "axa-table-of-contents-item"];
function AxaTabItem_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0);
} }
function AxaTab_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    const _r5 = ɵngcc0.ɵɵgetCurrentView();
    ɵngcc0.ɵɵelementContainerStart(0);
    ɵngcc0.ɵɵelementStart(1, "axa-tab-header", 3);
    ɵngcc0.ɵɵlistener("click", function AxaTab_ng_container_3_Template_axa_tab_header_click_1_listener() { ɵngcc0.ɵɵrestoreView(_r5); const i_r3 = ctx.index; const ctx_r4 = ɵngcc0.ɵɵnextContext(); return ctx_r4.onTabClick(i_r3); });
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const tab_r2 = ctx.$implicit;
    const i_r3 = ctx.index;
    const ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngClass", ctx_r0.alt ? "axa-tab-list__tab-alt" : "axa-tab-list__tab")("label", tab_r2.label)("index", i_r3)("active", ctx_r0.getActive(i_r3));
    ɵngcc0.ɵɵattribute("aria-selected", ctx_r0.getActive(i_r3));
} }
function AxaTab_ng_container_5_div_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div");
    ɵngcc0.ɵɵelementContainer(1, 5);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r9 = ɵngcc0.ɵɵnextContext();
    const i_r7 = ctx_r9.index;
    const tab_r6 = ctx_r9.$implicit;
    const ctx_r8 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵattribute("aria-selected", ctx_r8.getActive(i_r7));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngTemplateOutlet", tab_r6.content);
} }
function AxaTab_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementContainerStart(0);
    ɵngcc0.ɵɵtemplate(1, AxaTab_ng_container_5_div_1_Template, 2, 2, "div", 4);
    ɵngcc0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const i_r7 = ctx.index;
    const ctx_r1 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r1.getActive(i_r7));
} }
const _c14 = function (a0) { return { "axa-tab": a0 }; };
const _c15 = [[["axa-expansion-panel-header"]], "*"];
const _c16 = ["axa-expansion-panel-header", "*"];
function mixinErrorState(base) {
    return class extends base {
        constructor(...args) {
            super(...args);
            /** Whether the component is in an error state. */
            this.errorState = false;
            /**
             * Stream that emits whenever the error state of the input changes such that the wrapping
             * `AxaFormField` needs to run change detection.
             */
            this.errorStateChanges = new Subject();
            /**
             * Stream that emits whenever the touched state of the input changes such that the wrapping
             * `AxaFormField` needs to run change detection.
             */
            this.touchedChanges = new Subject();
        }
        /**Updates the errorstate value of a control. */
        updateErrorState() {
            const oldState = this.errorState;
            const parent = this._parentFormGroup || this._parentForm;
            const matcher = this.errorStateMatcher || this._defaultErrorStateMatcher;
            const control = this.ngControl ? this.ngControl.control : null;
            const newState = matcher.isErrorState(control, parent);
            if (newState !== oldState) {
                this.errorState = newState;
                this.errorStateChanges.next();
            }
        }
    };
}

/** Coerces a data-bound value to a boolean. */
function coerceBooleanProperty(value) {
    return value != null && `${value}` !== 'false';
}

/** Mixin to augment a directive with a `disabled` property. */
function mixinDisabled(base) {
    return class extends base {
        constructor(...args) {
            super(...args);
            this._disabled = false;
        }
        /**Wether the control is disabled. */
        get disabled() { return this._disabled; }
        set disabled(value) { this._disabled = coerceBooleanProperty(value); }
    };
}

/**
 * Mixin to augment a directive with updateErrorState method.
 * For component with `errorState` and need to update `errorState`.
 */
function mixinParentErrorState(base) {
    return class extends base {
        constructor(...args) {
            super(...args);
            /** Whether the component is in an error state. */
            this.errorState = false;
            /**
             * Stream that emits whenever the state of the input changes such that the wrapping
             * `AxaFormField` needs to run change detection.
             */
            this.errorStateChanges = new Subject();
            /**The subscriptions used to monitor state. */
            this.subArray = new Array();
            /**Implementation of the value accessor. */
            this.valueAccessorTouch = () => { };
            this.childrenTouchedState = new Array();
            if (this._parentForm != null) {
                this.subArray.push(this._parentForm.ngSubmit.subscribe(() => {
                    this.updateErrorState();
                }));
            }
            if (this._parentFormGroup != null) {
                this.subArray.push(this._parentFormGroup.ngSubmit.subscribe(() => {
                    this.updateErrorState();
                }));
            }
        }
        /**Updates the errorstate value of a control. */
        updateErrorState() {
            const oldState = this.errorState;
            const parent = this._parentFormGroup || this._parentForm;
            const matcher = this.errorStateMatcher || this._defaultErrorStateMatcher;
            const control = this.ngControl ? this.ngControl.control : null;
            const newState = matcher.isErrorState(control, parent);
            if (newState !== oldState) {
                this.errorState = newState;
                this.errorStateChanges.next();
            }
        }
        /**Stops monitoring the states. */
        unMonitorChildrenControls() {
            this.subArray.forEach(sub => sub.unsubscribe());
        }
        /**Monitors the state changes for the form field and children controls. */
        monitorChildrenControls() {
            const parent = this._parentFormGroup || this._parentForm;
            if (parent != null) {
                this.subArray.push(parent.statusChanges.subscribe(test => {
                    this.updateErrorState();
                }));
            }
            this.childrenControls.forEach(s => {
                this.subArray.push(s.errorStateChanges.subscribe(() => {
                    if (this.childrenControls.some(su => su.errorState === true)) {
                        this.errorState = true;
                        this.errorStateChanges.next();
                    }
                    else {
                        this.errorState = false;
                        this.errorStateChanges.next();
                    }
                }));
                this.subArray.push(s.touchedChanges.subscribe(id => {
                    if (this.childrenTouchedState.indexOf(id) === -1) {
                        this.childrenTouchedState.push(id);
                    }
                    if (this.childrenControls.length === this.childrenTouchedState.length) {
                        this.valueAccessorTouch();
                        this.updateErrorState();
                    }
                }));
            });
        }
    };
}

/** Mixin to augment a directive with a `tabIndex` property. */
function mixinTabIndex(base, defaultTabIndex = 0) {
    return class extends base {
        constructor(...args) {
            super(...args);
            this._tabIndex = defaultTabIndex;
        }
        /**The tabIndex value. */
        get tabIndex() { return this.disabled ? -1 : this._tabIndex; }
        set tabIndex(value) {
            // If the specified tabIndex value is null or undefined, fall back to the default value.
            this._tabIndex = value != null ? value : defaultTabIndex;
        }
    };
}

/**
 * Allows a control to work inside an AxaFormField.
 */
class AxaFormFieldControl {
}

/** Error state matcher that matches when a control is invalid and dirty. */
class ShowOnDirtyErrorStateMatcher {
    /**Evaluates the error state. */
    isErrorState(control, form) {
        return !!(control && control.invalid && (control.dirty || (form && form.submitted)));
    }
}
ShowOnDirtyErrorStateMatcher.ɵfac = function ShowOnDirtyErrorStateMatcher_Factory(t) { return new (t || ShowOnDirtyErrorStateMatcher)(); };
ShowOnDirtyErrorStateMatcher.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: ShowOnDirtyErrorStateMatcher, factory: ShowOnDirtyErrorStateMatcher.ɵfac });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(ShowOnDirtyErrorStateMatcher, [{
        type: Injectable
    }], null, null); })();
/** Provider that defines how form controls behave with regards to displaying error messages. */
class ErrorStateMatcher {
    /**Evaluates the error state. */
    isErrorState(control, form) {
        return !!(control && control.invalid && (control.touched || (form && form.submitted)));
    }
}
ErrorStateMatcher.ɵfac = function ErrorStateMatcher_Factory(t) { return new (t || ErrorStateMatcher)(); };
ErrorStateMatcher.ɵprov = ɵɵdefineInjectable({ factory: function ErrorStateMatcher_Factory() { return new ErrorStateMatcher(); }, token: ErrorStateMatcher, providedIn: "root" });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(ErrorStateMatcher, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], null, null); })();

/**Style applied to the axa-input. */
const INPUT_STYLE = 'axa-form-control';
/**Unique ID generated for inputs. */
let nextUniqueId = 0;
/**@ignore */
class AxaInputBase {
    constructor(_defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl) {
        this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
        this._parentForm = _parentForm;
        this._parentFormGroup = _parentFormGroup;
        this.ngControl = ngControl;
    }
}
/**@ignore */
const _AxaInputMixinBase = mixinErrorState(AxaInputBase);
/**
 * Directive to enhance an input html component.
 * @export
 */
class AxaInput extends _AxaInputMixinBase {
    /**
     *Creates an instance of AxaInput.
     * @param el the element ref.
     * @param defaultErrorStateMatcher the error state matcher used.
     * @param ngControl the underlying ngControl
     * @param parentForm the parent form
     * @param parentFormGroup the parent form group
     */
    constructor(el, defaultErrorStateMatcher, ngControl, parentForm, parentFormGroup, renderer) {
        super(defaultErrorStateMatcher, parentForm, parentFormGroup, ngControl);
        this.el = el;
        this.ngControl = ngControl;
        this.renderer = renderer;
        this._uniqueId = `axa-input-${++nextUniqueId}`;
        /**
         * Whether the control is focused.
         */
        this.focused = false;
        this._required = false;
        this._disabled = false;
        this._readonly = false;
        this._clearable = false;
        this._inputValueAccessor = el.nativeElement;
        this.id = this.id;
        this.host = el.nativeElement;
        this.addDefaultStyle();
    }
    /**
   * Implemented as part of AxaFormFieldControl.
   */
    get value() { return this._inputValueAccessor.value; }
    set value(value) {
        if (value !== this.value) {
            this._inputValueAccessor.value = value;
            this.errorStateChanges.next();
        }
    }
    /**
     * Whether the control is required.
     */
    get required() { return this._required; }
    set required(value) { this._required = coerceBooleanProperty(value); }
    /**
     * Whether the control is disabled.
     */
    get disabled() {
        if (this.ngControl && this.ngControl.disabled !== null) {
            return this.ngControl.disabled;
        }
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        if (this.focused) {
            this.focused = false;
        }
    }
    /**
     * Whether the control is readonly.
     */
    get readonly() { return this._readonly; }
    set readonly(value) { this._readonly = coerceBooleanProperty(value); }
    /**
   * Whether the control is readonly.
   */
    get clearable() { return this._clearable; }
    set clearable(value) { this._clearable = coerceBooleanProperty(value); }
    /**
     * Element ID.
     */
    get id() { return this._id; }
    set id(value) { this._id = value || this._uniqueId; }
    ngOnInit() {
        this.createClearButton();
    }
    ngDoCheck() {
        this.updateErrorState();
        this.createClearButton();
    }
    createClearButton() {
        if (this.clearable && !this.clearButton && this.value) {
            this.clearButton = this.renderer.createElement('a');
            this.renderer.setAttribute(this.clearButton, 'clearable', 'true');
            // If have suffix, add another class to rightless
            const hasSuffix = Array
                .from(this.el.nativeElement.parentNode.children)
                .find((e) => e.tagName === 'AXA-SUFFIX');
            if (hasSuffix) {
                this.renderer.addClass(this.clearButton, 'clear');
            }
            else {
                this.renderer.addClass(this.clearButton, 'clear-suffix');
            }
            this.renderer.listen(this.clearButton, 'click', () => { this.removeClearButton(); });
            this.renderer.setStyle(this.el.nativeElement, 'padding-right', '36px');
            this.renderer.appendChild(this.el.nativeElement.parentNode, this.clearButton);
        }
        if (this.clearable && this.clearButton && !this.value) {
            this.removeClearButton();
        }
    }
    removeClearButton() {
        this.value = '';
        this.renderer.removeStyle(this.el.nativeElement, 'padding-right');
        this.renderer.removeChild(this.el.nativeElement.parentNode, this.clearButton);
        this.clearButton = null;
    }
    /**Responds to focus changes events. */
    focusChanged(isFocused) {
        if (isFocused !== this.focused && !this.readonly) {
            this.focused = isFocused;
        }
        if (!isFocused) {
            this.touchedChanges.next(this.id);
        }
    }
    addDefaultStyle() {
        this.host.classList.add(INPUT_STYLE);
    }
    /**
     * Focuses the input.
     */
    focus() {
        this.host.focus();
    }
}
AxaInput.ɵfac = function AxaInput_Factory(t) { return new (t || AxaInput)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef), ɵngcc0.ɵɵdirectiveInject(ErrorStateMatcher), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgControl, 10), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgForm, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.FormGroupDirective, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.Renderer2)); };
AxaInput.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaInput, selectors: [["input", "axaInput", ""], ["textarea", "axaInput", ""]], hostVars: 7, hostBindings: function AxaInput_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("blur", function AxaInput_blur_HostBindingHandler() { return ctx.focusChanged(false); })("focus", function AxaInput_focus_HostBindingHandler() { return ctx.focusChanged(true); });
    } if (rf & 2) {
        ɵngcc0.ɵɵhostProperty("disabled", ctx.disabled)("required", ctx.required)("readonly", ctx.readonly);
        ɵngcc0.ɵɵattribute("id", ctx.id)("aria-invalid", ctx.errorState)("placeholder", ctx.placeholder)("aria-required", ctx.required.toString());
    } }, inputs: { id: "id", value: "value", required: "required", disabled: "disabled", readonly: "readonly", clearable: "clearable", placeholder: "placeholder" }, features: [ɵngcc0.ɵɵProvidersFeature([{ provide: AxaFormFieldControl, useExisting: AxaInput }]), ɵngcc0.ɵɵInheritDefinitionFeature] });
AxaInput.ctorParameters = () => [
    { type: ElementRef },
    { type: ErrorStateMatcher },
    { type: NgControl, decorators: [{ type: Optional }, { type: Self }] },
    { type: NgForm, decorators: [{ type: Optional }] },
    { type: FormGroupDirective, decorators: [{ type: Optional }] },
    { type: Renderer2 }
];
AxaInput.propDecorators = {
    value: [{ type: Input }],
    placeholder: [{ type: Input }],
    required: [{ type: Input }],
    disabled: [{ type: Input }],
    readonly: [{ type: Input }],
    clearable: [{ type: Input }],
    id: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaInput, [{
        type: Directive,
        args: [{
                selector: 'input[axaInput], textarea[axaInput]',
                host: {
                    '[attr.id]': 'id',
                    '[attr.aria-invalid]': 'errorState',
                    '[attr.placeholder]': 'placeholder',
                    '[attr.aria-required]': 'required.toString()',
                    '[disabled]': 'disabled',
                    '[required]': 'required',
                    '[readonly]': 'readonly',
                    '(blur)': 'focusChanged(false)',
                    '(focus)': 'focusChanged(true)'
                },
                providers: [{ provide: AxaFormFieldControl, useExisting: AxaInput }]
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }, { type: ErrorStateMatcher }, { type: ɵngcc1.NgControl, decorators: [{
                type: Optional
            }, {
                type: Self
            }] }, { type: ɵngcc1.NgForm, decorators: [{
                type: Optional
            }] }, { type: ɵngcc1.FormGroupDirective, decorators: [{
                type: Optional
            }] }, { type: ɵngcc0.Renderer2 }]; }, { id: [{
            type: Input
        }], value: [{
            type: Input
        }], required: [{
            type: Input
        }], disabled: [{
            type: Input
        }], readonly: [{
            type: Input
        }], clearable: [{
            type: Input
        }], placeholder: [{
            type: Input
        }] }); })();

class AxaInputModule {
}
AxaInputModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaInputModule });
AxaInputModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaInputModule_Factory(t) { return new (t || AxaInputModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaInputModule, { declarations: function () { return [AxaInput]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaInput]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaInputModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaInput],
                declarations: [AxaInput]
            }]
    }], null, null); })();

/**This dictionary contains all the styles to apply for the different buttons. */
const BUTTON_STYLES = {
    'default': 'axa-btn',
    'ghost': 'axa-btn--ghost',
    'neg': 'axa-btn--neg',
    'split': 'axa-btn--split',
    'alt': 'axa-btn--alt',
    'small': 'axa-btn--sm',
    'large': 'axa-btn--lg'
};

/** Coerces a data-bound value to a boolean. */
function coerceBooleanProperty$1(value) {
    return value != null && `${value}` !== 'false';
}

/**
 * Defines all the buttons available in the toolkit.
 * Takes care of applying the styles to a button.
 */
class AxaButton {
    /**
     * Creates an instance of AxaButton.
     * @param el
     * ElementRef to modify styles.
     */
    constructor(el) {
        this.el = el;
        this.host = el.nativeElement;
        this.addDefaultStyles();
    }
    ngOnChanges(changes) {
        this.addDefaultStyles();
    }
    /**
     * Whether the control is disabled.
     */
    set disabled(value) {
        this._disabled = coerceBooleanProperty$1(value);
        this.host.disabled = this._disabled;
    }
    /**
     * Whether the control is ghost styled.
     */
    set ghost(value) {
        this._ghost = coerceBooleanProperty$1(value);
    }
    /**
     * Whether the control is neg styled.
     */
    set neg(value) {
        this._neg = coerceBooleanProperty$1(value);
    }
    /**
      * Whether the control is split styled.
      */
    set split(value) {
        this._split = coerceBooleanProperty$1(value);
    }
    /**
   * Whether the control is ghost styled.
   */
    set alt(value) {
        this._alt = coerceBooleanProperty$1(value);
    }
    /**
     * Whether the control is ghost styled.
     */
    set small(value) {
        this._small = coerceBooleanProperty$1(value);
    }
    /**
    * Whether the control is ghost styled.
    */
    set large(value) {
        this._large = coerceBooleanProperty$1(value);
    }
    /**
    * Whether the aria-disabled attribute should be set.
    */
    get DisabledAttr() {
        return this._disabled ? 'disabled' : null;
    }
    /**
     * Sets the role attribute.
     */
    get roleAttr() {
        return (this.host.tagName !== 'BUTTON') ? 'button' : null;
    }
    /**
     * Sets the tabIndex.
     */
    get tabIndexAttr() {
        return this._disabled ? -1 : 0;
    }
    /**
     * Disables the click event when the control is disabled.
     */
    _haltDisabledEvents(event) {
        if (this._disabled) {
            event.preventDefault();
            event.stopImmediatePropagation();
        }
    }
    clearStyles() {
        Object.keys(BUTTON_STYLES).forEach(key => {
            const value = BUTTON_STYLES[key];
            this.host.classList.remove(value);
        });
    }
    addDefaultStyles() {
        this.clearStyles();
        Object.keys(BUTTON_STYLES).forEach(key => {
            const value = BUTTON_STYLES[key];
            if (key === 'default' || (this.hasOwnProperty(`_${key}`) && this[`_${key}`])) {
                this.host.classList.add(value);
            }
        });
    }
}
AxaButton.ɵfac = function AxaButton_Factory(t) { return new (t || AxaButton)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaButton.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaButton, selectors: [["button", "axa-button", ""], ["a", "axa-button", ""]], hostVars: 3, hostBindings: function AxaButton_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("click", function AxaButton_click_HostBindingHandler($event) { return ctx._haltDisabledEvents($event); });
    } if (rf & 2) {
        ɵngcc0.ɵɵattribute("aria-disabled", ctx.DisabledAttr)("role", ctx.roleAttr)("tabindex", ctx.tabIndexAttr);
    } }, inputs: { disabled: "disabled", ghost: "ghost", neg: "neg", split: "split", alt: "alt", small: "small", large: "large" }, features: [ɵngcc0.ɵɵNgOnChangesFeature] });
AxaButton.ctorParameters = () => [
    { type: ElementRef }
];
AxaButton.propDecorators = {
    disabled: [{ type: Input, args: ['disabled',] }],
    ghost: [{ type: Input, args: ['ghost',] }],
    neg: [{ type: Input, args: ['neg',] }],
    split: [{ type: Input, args: ['split',] }],
    alt: [{ type: Input, args: ['alt',] }],
    small: [{ type: Input, args: ['small',] }],
    large: [{ type: Input, args: ['large',] }],
    DisabledAttr: [{ type: HostBinding, args: ['attr.aria-disabled',] }],
    roleAttr: [{ type: HostBinding, args: ['attr.role',] }],
    tabIndexAttr: [{ type: HostBinding, args: ['attr.tabindex',] }],
    _haltDisabledEvents: [{ type: HostListener, args: ['click', ['$event'],] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaButton, [{
        type: Directive,
        args: [{
                selector: `button[axa-button], a[axa-button]`
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { disabled: [{
            type: Input,
            args: ['disabled']
        }], ghost: [{
            type: Input,
            args: ['ghost']
        }], neg: [{
            type: Input,
            args: ['neg']
        }], split: [{
            type: Input,
            args: ['split']
        }], alt: [{
            type: Input,
            args: ['alt']
        }], small: [{
            type: Input,
            args: ['small']
        }], large: [{
            type: Input,
            args: ['large']
        }], DisabledAttr: [{
            type: HostBinding,
            args: ['attr.aria-disabled']
        }], roleAttr: [{
            type: HostBinding,
            args: ['attr.role']
        }], tabIndexAttr: [{
            type: HostBinding,
            args: ['attr.tabindex']
        }], _haltDisabledEvents: [{
            type: HostListener,
            args: ['click', ['$event']]
        }] }); })();

class AxaButtonModule {
}
AxaButtonModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaButtonModule });
AxaButtonModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaButtonModule_Factory(t) { return new (t || AxaButtonModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaButtonModule, { declarations: function () { return [AxaButton]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaButton]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaButtonModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                declarations: [AxaButton],
                exports: [AxaButton]
            }]
    }], null, null); })();

/**
 * Generated unique id.
 */
let nextUniqueId$1 = 0;
/**@ignore */
class AxaSelectBase {
    constructor(_defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl) {
        this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
        this._parentForm = _parentForm;
        this._parentFormGroup = _parentFormGroup;
        this.ngControl = ngControl;
    }
}
/**@ignore */
const _AxaSelectMixinBase = mixinTabIndex(mixinDisabled(mixinErrorState(AxaSelectBase)));
/**Style injected in the axaSelect */
const SELECT_STYLE = 'custom-select';
/**
 * Directive to enhance a select html component.
 * @export
 */
class AxaSelect extends _AxaSelectMixinBase {
    /**
     * Creates an instance of AxaSelect.
     * @param el the element ref.
     * @param defaultErrorStateMatcher the error state matcher used.
     * @param ngControl the underlying ngControl
     * @param parentForm the parent form
     * @param parentFormGroup the parent form group
     */
    constructor(el, defaultErrorStateMatcher, ngControl, parentForm, parentFormGroup) {
        super(defaultErrorStateMatcher, parentForm, parentFormGroup, ngControl);
        this.el = el;
        this.ngControl = ngControl;
        this.parentForm = parentForm;
        this.parentFormGroup = parentFormGroup;
        this._uniqueId = `axa-select-${++nextUniqueId$1}`;
        /**
         * Whether the control is focused.
         */
        this.focused = false;
        this._required = false;
        this._disabled = false;
        /**
         * Stream that emits when the errorState of the control changes.
         */
        this.errorStateChanges = new Subject();
        this.host = el.nativeElement;
        this.addDefaultStyle();
        this.id = this.id;
    }
    /**
     * Element ID.
     */
    get id() { return this._id; }
    set id(value) { this._id = value || this._uniqueId; }
    /** Value of the select control. */
    get value() { return this._value; }
    set value(newValue) {
        if (newValue !== this._value) {
            this._value = newValue;
        }
    }
    /**
     * Whether the control is required.
     */
    get required() { return this._required; }
    set required(value) { this._required = coerceBooleanProperty(value); }
    /**
     * Whether the control is disabled.
     */
    get disabled() {
        if (this.ngControl && this.ngControl.disabled !== null) {
            return this.ngControl.disabled;
        }
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        if (this.focused) {
            this.focused = false;
        }
    }
    addDefaultStyle() {
        this.host.classList.add(SELECT_STYLE);
    }
    /**
     * Gives focus to the control.
     */
    focus() {
        this.host.focus();
    }
    /**Reacts to focus changes from the UI. */
    focusChanged(isFocused) {
        if (isFocused !== this.focused) {
            this.focused = isFocused;
        }
        if (!isFocused) {
            this.touchedChanges.next(this.id);
        }
    }
    ngDoCheck() {
        this.updateErrorState();
    }
}
AxaSelect.ɵfac = function AxaSelect_Factory(t) { return new (t || AxaSelect)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef), ɵngcc0.ɵɵdirectiveInject(ErrorStateMatcher), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgControl, 10), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgForm, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.FormGroupDirective, 8)); };
AxaSelect.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaSelect, selectors: [["", "axaSelect", ""]], hostAttrs: ["role", "listbox"], hostVars: 8, hostBindings: function AxaSelect_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("blur", function AxaSelect_blur_HostBindingHandler() { return ctx.focusChanged(false); })("focus", function AxaSelect_focus_HostBindingHandler() { return ctx.focusChanged(true); });
    } if (rf & 2) {
        ɵngcc0.ɵɵhostProperty("disabled", ctx.disabled)("required", ctx.required);
        ɵngcc0.ɵɵattribute("id", ctx.id)("placeholder", ctx.placeholder)("tabindex", ctx.tabIndex)("aria-required", ctx.required.toString())("aria-disabled", ctx.disabled.toString())("aria-invalid", ctx.errorState);
    } }, inputs: { id: "id", value: "value", required: "required", disabled: "disabled", placeholder: "placeholder" }, features: [ɵngcc0.ɵɵProvidersFeature([
            { provide: AxaFormFieldControl, useExisting: AxaSelect }
        ]), ɵngcc0.ɵɵInheritDefinitionFeature] });
AxaSelect.ctorParameters = () => [
    { type: ElementRef },
    { type: ErrorStateMatcher },
    { type: NgControl, decorators: [{ type: Optional }, { type: Self }] },
    { type: NgForm, decorators: [{ type: Optional }] },
    { type: FormGroupDirective, decorators: [{ type: Optional }] }
];
AxaSelect.propDecorators = {
    id: [{ type: Input }],
    value: [{ type: Input }],
    placeholder: [{ type: Input }],
    required: [{ type: Input }],
    disabled: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaSelect, [{
        type: Directive,
        args: [{
                selector: '[axaSelect]',
                host: {
                    'role': 'listbox',
                    '[attr.id]': 'id',
                    '[attr.placeholder]': 'placeholder',
                    '[disabled]': 'disabled',
                    '[required]': 'required',
                    '[attr.tabindex]': 'tabIndex',
                    '[attr.aria-required]': 'required.toString()',
                    '[attr.aria-disabled]': 'disabled.toString()',
                    '[attr.aria-invalid]': 'errorState',
                    '(blur)': 'focusChanged(false)',
                    '(focus)': 'focusChanged(true)'
                },
                providers: [
                    { provide: AxaFormFieldControl, useExisting: AxaSelect }
                ]
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }, { type: ErrorStateMatcher }, { type: ɵngcc1.NgControl, decorators: [{
                type: Optional
            }, {
                type: Self
            }] }, { type: ɵngcc1.NgForm, decorators: [{
                type: Optional
            }] }, { type: ɵngcc1.FormGroupDirective, decorators: [{
                type: Optional
            }] }]; }, { id: [{
            type: Input
        }], value: [{
            type: Input
        }], required: [{
            type: Input
        }], disabled: [{
            type: Input
        }], placeholder: [{
            type: Input
        }] }); })();

class AxaSelectModule {
}
AxaSelectModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaSelectModule });
AxaSelectModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaSelectModule_Factory(t) { return new (t || AxaSelectModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaSelectModule, { declarations: function () { return [AxaSelect]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaSelect]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaSelectModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaSelect],
                declarations: [AxaSelect]
            }]
    }], null, null); })();

/**@ignore */
let nextUniqueId$2 = 0;
/** Error message to be shown underneath the form field. */
class AxaError {
    constructor() {
        /**The id of the control. */
        this.id = `axa-error-${nextUniqueId$2++}`;
    }
}
AxaError.ɵfac = function AxaError_Factory(t) { return new (t || AxaError)(); };
AxaError.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaError, selectors: [["axa-error"]], hostAttrs: ["role", "alert", 1, "axa-form-control-feedback"], hostVars: 1, hostBindings: function AxaError_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
    } }, inputs: { id: "id" } });
AxaError.propDecorators = {
    id: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaError, [{
        type: Directive,
        args: [{
                selector: 'axa-error',
                host: {
                    'class': 'axa-form-control-feedback',
                    'role': 'alert',
                    '[attr.id]': 'id'
                }
            }]
    }], function () { return []; }, { id: [{
            type: Input
        }] }); })();

/**@ignore */
let nextUniqueId$3 = 0;
/** Info message to be shown underneath the form field. */
class AxaHint {
    constructor() {
        /**The id of the control. */
        this.id = `axa-hint-${nextUniqueId$3++}`;
    }
}
AxaHint.ɵfac = function AxaHint_Factory(t) { return new (t || AxaHint)(); };
AxaHint.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaHint, selectors: [["axa-hint"]], hostAttrs: [1, "axa-form-hint"], hostVars: 1, hostBindings: function AxaHint_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
    } }, inputs: { id: "id" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaHint_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2 });
AxaHint.propDecorators = {
    id: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHint, [{
        type: Component,
        args: [{
                selector: 'axa-hint',
                template: "  <ng-content></ng-content>\r\n",
                host: {
                    'class': 'axa-form-hint',
                    '[attr.id]': 'id'
                }
            }]
    }], function () { return []; }, { id: [{
            type: Input
        }] }); })();

/**Form error style. */
const FORM_ERROR_STYLE = 'axa-form-group--has-danger';

/**
 * Container for form inputs that displays errors and hints.
 * @export
 */
class AxaFormField {
    /**
     *Creates an instance of AxaFormField.
     * @param cdr change detector ref
     */
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterContentInit() {
        this.checkChildIsAxaControl();
        this.showErrorOrHint();
        this.control.errorStateChanges.subscribe(() => {
            this.showErrorOrHint();
            this.applyErrorStyle();
        });
    }
    ngAfterContentChecked() {
        this.checkChildIsAxaControl();
    }
    /**Applies the error style to the root div. */
    applyErrorStyle() {
        const element = this.divRef.nativeElement;
        if (this.control.errorState) {
            if (!element.classList.contains(FORM_ERROR_STYLE)) {
                element.classList.add(FORM_ERROR_STYLE);
            }
        }
        else {
            element.classList.remove(FORM_ERROR_STYLE);
        }
    }
    showErrorOrHint() {
        this.showError = this.axaErrors && this.axaErrors.length > 0 &&
            this.control.errorState;
        this.cdr.detectChanges();
    }
    checkChildIsAxaControl() {
        if (!this.control) {
            throw new Error('axa-form-field must contain an axa control');
        }
    }
}
AxaFormField.ɵfac = function AxaFormField_Factory(t) { return new (t || AxaFormField)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef)); };
AxaFormField.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaFormField, selectors: [["axa-form-field"]], contentQueries: function AxaFormField_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaFormFieldControl, true);
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaError, false);
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaHint, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.control = _t.first);
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.axaErrors = _t);
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.axaHints = _t);
    } }, viewQuery: function AxaFormField_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵstaticViewQuery(_c1, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.divRef = _t.first);
    } }, inputs: { label: "label" }, ngContentSelectors: _c3, decls: 8, vars: 3, consts: [[1, "axa-form-group", 3, "ngSwitch"], ["div", ""], [4, "ngIf"], [4, "ngSwitchCase"], [4, "ngSwitchDefault"]], template: function AxaFormField_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c2);
        ɵngcc0.ɵɵelementStart(0, "div", 0, 1);
        ɵngcc0.ɵɵtemplate(2, AxaFormField_label_2_Template, 2, 1, "label", 2);
        ɵngcc0.ɵɵprojection(3);
        ɵngcc0.ɵɵprojection(4, 1);
        ɵngcc0.ɵɵprojection(5, 2);
        ɵngcc0.ɵɵtemplate(6, AxaFormField_6_Template, 1, 0, undefined, 3);
        ɵngcc0.ɵɵtemplate(7, AxaFormField_7_Template, 1, 0, undefined, 4);
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngSwitch", ctx.showError);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngIf", ctx.label);
        ɵngcc0.ɵɵadvance(4);
        ɵngcc0.ɵɵproperty("ngSwitchCase", true);
    } }, directives: [ɵngcc2.NgSwitch, ɵngcc2.NgIf, ɵngcc2.NgSwitchCase, ɵngcc2.NgSwitchDefault], encapsulation: 2, changeDetection: 0 });
AxaFormField.ctorParameters = () => [
    { type: ChangeDetectorRef }
];
AxaFormField.propDecorators = {
    control: [{ type: ContentChild, args: [AxaFormFieldControl,] }],
    axaErrors: [{ type: ContentChildren, args: [AxaError,] }],
    axaHints: [{ type: ContentChildren, args: [AxaHint,] }],
    divRef: [{ type: ViewChild, args: ['div', { static: true },] }],
    label: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFormField, [{
        type: Component,
        args: [{
                selector: 'axa-form-field',
                template: "<div #div class=\"axa-form-group\" [ngSwitch]=\"showError\">\r\n    <label *ngIf=\"label\">{{label}}</label>\r\n    <ng-content select=\"axa-prefix\"></ng-content>\r\n\r\n    <ng-content></ng-content>\r\n\r\n    <ng-content select=\"axa-suffix\"></ng-content>\r\n\r\n    <ng-content *ngSwitchCase=\"true\" select=\"axa-error\"></ng-content>\r\n\r\n    <ng-content *ngSwitchDefault select=\"axa-hint\"></ng-content>\r\n</div>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc0.ChangeDetectorRef }]; }, { control: [{
            type: ContentChild,
            args: [AxaFormFieldControl]
        }], axaErrors: [{
            type: ContentChildren,
            args: [AxaError]
        }], axaHints: [{
            type: ContentChildren,
            args: [AxaHint]
        }], divRef: [{
            type: ViewChild,
            args: ['div', { static: true }]
        }], label: [{
            type: Input
        }] }); })();

/**Directive to attach an HTML element as a prefix in a form field. */
class AxaPrefixDirective {
    constructor() {
        /**Style applied to the prefix element. */
        this.className = 'axa-form-field-prefix';
    }
}
AxaPrefixDirective.ɵfac = function AxaPrefixDirective_Factory(t) { return new (t || AxaPrefixDirective)(); };
AxaPrefixDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaPrefixDirective, selectors: [["axa-prefix"]], hostVars: 2, hostBindings: function AxaPrefixDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.className);
    } } });
AxaPrefixDirective.propDecorators = {
    className: [{ type: HostBinding, args: ['class',] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaPrefixDirective, [{
        type: Directive,
        args: [{ selector: 'axa-prefix' }]
    }], function () { return []; }, { className: [{
            type: HostBinding,
            args: ['class']
        }] }); })();

/**Directive to attach an HTML element as a suffix in a form field. */
class AxaSuffixDirective {
    constructor() {
        /**Style applied to the suffix element. */
        this.className = 'axa-form-field-suffix';
    }
}
AxaSuffixDirective.ɵfac = function AxaSuffixDirective_Factory(t) { return new (t || AxaSuffixDirective)(); };
AxaSuffixDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaSuffixDirective, selectors: [["axa-suffix"]], hostVars: 2, hostBindings: function AxaSuffixDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.className);
    } } });
AxaSuffixDirective.propDecorators = {
    className: [{ type: HostBinding, args: ['class',] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaSuffixDirective, [{
        type: Directive,
        args: [{ selector: 'axa-suffix' }]
    }], function () { return []; }, { className: [{
            type: HostBinding,
            args: ['class']
        }] }); })();

class AxaFormFieldModule {
}
AxaFormFieldModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaFormFieldModule });
AxaFormFieldModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaFormFieldModule_Factory(t) { return new (t || AxaFormFieldModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaFormFieldModule, { declarations: function () { return [AxaFormField, AxaError, AxaHint, AxaPrefixDirective, AxaSuffixDirective]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaFormField, AxaError, AxaHint, AxaPrefixDirective, AxaSuffixDirective]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFormFieldModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaFormField, AxaError, AxaHint, AxaPrefixDirective, AxaSuffixDirective],
                declarations: [AxaFormField, AxaError, AxaHint, AxaPrefixDirective, AxaSuffixDirective]
            }]
    }], null, null); })();

/**Json array of the countries. */
const countries = [
    {
        'name': 'Afghanistan',
        'dial': '+93',
        'code': 'AF'
    },
    {
        'name': 'Åland Islands',
        'dial': '+358',
        'code': 'AX'
    },
    {
        'name': 'Albania',
        'dial': '+355',
        'code': 'AL'
    },
    {
        'name': 'Algeria',
        'dial': '+213',
        'code': 'DZ'
    },
    {
        'name': 'American Samoa',
        'dial': '+1684',
        'code': 'AS'
    },
    {
        'name': 'Andorra',
        'dial': '+376',
        'code': 'AD'
    },
    {
        'name': 'Angola',
        'dial': '+244',
        'code': 'AO'
    },
    {
        'name': 'Anguilla',
        'dial': '+1264',
        'code': 'AI'
    },
    {
        'name': 'Antarctica',
        'dial': '+672',
        'code': 'AQ'
    },
    {
        'name': 'Antigua and Barbuda',
        'dial': '+1268',
        'code': 'AG'
    },
    {
        'name': 'Argentina',
        'dial': '+54',
        'code': 'AR'
    },
    {
        'name': 'Armenia',
        'dial': '+374',
        'code': 'AM'
    },
    {
        'name': 'Aruba',
        'dial': '+297',
        'code': 'AW'
    },
    {
        'name': 'Australia',
        'dial': '+61',
        'code': 'AU'
    },
    {
        'name': 'Austria',
        'dial': '+43',
        'code': 'AT'
    },
    {
        'name': 'Azerbaijan',
        'dial': '+994',
        'code': 'AZ'
    },
    {
        'name': 'Bahamas',
        'dial': '+1242',
        'code': 'BS'
    },
    {
        'name': 'Bahrain',
        'dial': '+973',
        'code': 'BH'
    },
    {
        'name': 'Bangladesh',
        'dial': '+880',
        'code': 'BD'
    },
    {
        'name': 'Barbados',
        'dial': '+1246',
        'code': 'BB'
    },
    {
        'name': 'Belarus',
        'dial': '+375',
        'code': 'BY'
    },
    {
        'name': 'Belgium',
        'dial': '+32',
        'code': 'BE'
    },
    {
        'name': 'Belize',
        'dial': '+501',
        'code': 'BZ'
    },
    {
        'name': 'Benin',
        'dial': '+229',
        'code': 'BJ'
    },
    {
        'name': 'Bermuda',
        'dial': '+1441',
        'code': 'BM'
    },
    {
        'name': 'Bhutan',
        'dial': '+975',
        'code': 'BT'
    },
    {
        'name': 'Bolivia, Plurinational State of bolivia',
        'dial': '+591',
        'code': 'BO'
    },
    {
        'name': 'Bosnia and Herzegovina',
        'dial': '+387',
        'code': 'BA'
    },
    {
        'name': 'Botswana',
        'dial': '+267',
        'code': 'BW'
    },
    {
        'name': 'Bouvet Island',
        'dial': '+47',
        'code': 'BV'
    },
    {
        'name': 'Brazil',
        'dial': '+55',
        'code': 'BR'
    },
    {
        'name': 'British Indian Ocean Territory',
        'dial': '+246',
        'code': 'IO'
    },
    {
        'name': 'Brunei Darussalam',
        'dial': '+673',
        'code': 'BN'
    },
    {
        'name': 'Bulgaria',
        'dial': '+359',
        'code': 'BG'
    },
    {
        'name': 'Burkina Faso',
        'dial': '+226',
        'code': 'BF'
    },
    {
        'name': 'Burundi',
        'dial': '+257',
        'code': 'BI'
    },
    {
        'name': 'Cambodia',
        'dial': '+855',
        'code': 'KH'
    },
    {
        'name': 'Cameroon',
        'dial': '+237',
        'code': 'CM'
    },
    {
        'name': 'Canada',
        'dial': '+1',
        'code': 'CA'
    },
    {
        'name': 'Cape Verde',
        'dial': '+238',
        'code': 'CV'
    },
    {
        'name': 'Cayman Islands',
        'dial': '+ 345',
        'code': 'KY'
    },
    {
        'name': 'Central African Republic',
        'dial': '+236',
        'code': 'CF'
    },
    {
        'name': 'Chad',
        'dial': '+235',
        'code': 'TD'
    },
    {
        'name': 'Chile',
        'dial': '+56',
        'code': 'CL'
    },
    {
        'name': 'China',
        'dial': '+86',
        'code': 'CN'
    },
    {
        'name': 'Christmas Island',
        'dial': '+61',
        'code': 'CX'
    },
    {
        'name': 'Cocos (Keeling) Islands',
        'dial': '+61',
        'code': 'CC'
    },
    {
        'name': 'Colombia',
        'dial': '+57',
        'code': 'CO'
    },
    {
        'name': 'Comoros',
        'dial': '+269',
        'code': 'KM'
    },
    {
        'name': 'Congo',
        'dial': '+242',
        'code': 'CG'
    },
    {
        'name': 'Congo, The Democratic Republic of the Congo',
        'dial': '+243',
        'code': 'CD'
    },
    {
        'name': 'Cook Islands',
        'dial': '+682',
        'code': 'CK'
    },
    {
        'name': 'Costa Rica',
        'dial': '+506',
        'code': 'CR'
    },
    {
        'name': 'Cote d\'Ivoire',
        'dial': '+225',
        'code': 'CI'
    },
    {
        'name': 'Croatia',
        'dial': '+385',
        'code': 'HR'
    },
    {
        'name': 'Cuba',
        'dial': '+53',
        'code': 'CU'
    },
    {
        'name': 'Cyprus',
        'dial': '+357',
        'code': 'CY'
    },
    {
        'name': 'Czech Republic',
        'dial': '+420',
        'code': 'CZ'
    },
    {
        'name': 'Denmark',
        'dial': '+45',
        'code': 'DK'
    },
    {
        'name': 'Djibouti',
        'dial': '+253',
        'code': 'DJ'
    },
    {
        'name': 'Dominica',
        'dial': '+1767',
        'code': 'DM'
    },
    {
        'name': 'Dominican Republic',
        'dial': '+1849',
        'code': 'DO'
    },
    {
        'name': 'Ecuador',
        'dial': '+593',
        'code': 'EC'
    },
    {
        'name': 'Egypt',
        'dial': '+20',
        'code': 'EG'
    },
    {
        'name': 'El Salvador',
        'dial': '+503',
        'code': 'SV'
    },
    {
        'name': 'Equatorial Guinea',
        'dial': '+240',
        'code': 'GQ'
    },
    {
        'name': 'Eritrea',
        'dial': '+291',
        'code': 'ER'
    },
    {
        'name': 'Estonia',
        'dial': '+372',
        'code': 'EE'
    },
    {
        'name': 'Ethiopia',
        'dial': '+251',
        'code': 'ET'
    },
    {
        'name': 'Falkland Islands (Malvinas)',
        'dial': '+500',
        'code': 'FK'
    },
    {
        'name': 'Faroe Islands',
        'dial': '+298',
        'code': 'FO'
    },
    {
        'name': 'Fiji',
        'dial': '+679',
        'code': 'FJ'
    },
    {
        'name': 'Finland',
        'dial': '+358',
        'code': 'FI'
    },
    {
        'name': 'France',
        'dial': '+33',
        'code': 'FR'
    },
    {
        'name': 'French Guiana',
        'dial': '+594',
        'code': 'GF'
    },
    {
        'name': 'French Polynesia',
        'dial': '+689',
        'code': 'PF'
    },
    {
        'name': 'French Southern Territories',
        'dial': '+262',
        'code': 'TF'
    },
    {
        'name': 'Gabon',
        'dial': '+241',
        'code': 'GA'
    },
    {
        'name': 'Gambia',
        'dial': '+220',
        'code': 'GM'
    },
    {
        'name': 'Georgia',
        'dial': '+995',
        'code': 'GE'
    },
    {
        'name': 'Germany',
        'dial': '+49',
        'code': 'DE'
    },
    {
        'name': 'Ghana',
        'dial': '+233',
        'code': 'GH'
    },
    {
        'name': 'Gibraltar',
        'dial': '+350',
        'code': 'GI'
    },
    {
        'name': 'Greece',
        'dial': '+30',
        'code': 'GR'
    },
    {
        'name': 'Greenland',
        'dial': '+299',
        'code': 'GL'
    },
    {
        'name': 'Grenada',
        'dial': '+1473',
        'code': 'GD'
    },
    {
        'name': 'Guadeloupe',
        'dial': '+590',
        'code': 'GP'
    },
    {
        'name': 'Guam',
        'dial': '+1671',
        'code': 'GU'
    },
    {
        'name': 'Guatemala',
        'dial': '+502',
        'code': 'GT'
    },
    {
        'name': 'Guernsey',
        'dial': '+44',
        'code': 'GG'
    },
    {
        'name': 'Guinea',
        'dial': '+224',
        'code': 'GN'
    },
    {
        'name': 'Guinea-Bissau',
        'dial': '+245',
        'code': 'GW'
    },
    {
        'name': 'Guyana',
        'dial': '+592',
        'code': 'GY'
    },
    {
        'name': 'Haiti',
        'dial': '+509',
        'code': 'HT'
    },
    {
        'name': 'Heard Island and Mcdonald Islands',
        'dial': '+0',
        'code': 'HM'
    },
    {
        'name': 'Holy See (Vatican City State)',
        'dial': '+379',
        'code': 'VA'
    },
    {
        'name': 'Honduras',
        'dial': '+504',
        'code': 'HN'
    },
    {
        'name': 'Hong Kong',
        'dial': '+852',
        'code': 'HK'
    },
    {
        'name': 'Hungary',
        'dial': '+36',
        'code': 'HU'
    },
    {
        'name': 'Iceland',
        'dial': '+354',
        'code': 'IS'
    },
    {
        'name': 'India',
        'dial': '+91',
        'code': 'IN'
    },
    {
        'name': 'Indonesia',
        'dial': '+62',
        'code': 'ID'
    },
    {
        'name': 'Iran, Islamic Republic of Persian Gulf',
        'dial': '+98',
        'code': 'IR'
    },
    {
        'name': 'Iraq',
        'dial': '+964',
        'code': 'IQ'
    },
    {
        'name': 'Ireland',
        'dial': '+353',
        'code': 'IE'
    },
    {
        'name': 'Isle of Man',
        'dial': '+44',
        'code': 'IM'
    },
    {
        'name': 'Israel',
        'dial': '+972',
        'code': 'IL'
    },
    {
        'name': 'Italy',
        'dial': '+39',
        'code': 'IT'
    },
    {
        'name': 'Jamaica',
        'dial': '+1876',
        'code': 'JM'
    },
    {
        'name': 'Japan',
        'dial': '+81',
        'code': 'JP'
    },
    {
        'name': 'Jersey',
        'dial': '+44',
        'code': 'JE'
    },
    {
        'name': 'Jordan',
        'dial': '+962',
        'code': 'JO'
    },
    {
        'name': 'Kazakhstan',
        'dial': '+7',
        'code': 'KZ'
    },
    {
        'name': 'Kenya',
        'dial': '+254',
        'code': 'KE'
    },
    {
        'name': 'Kiribati',
        'dial': '+686',
        'code': 'KI'
    },
    {
        'name': 'Korea, Democratic People\'s Republic of Korea',
        'dial': '+850',
        'code': 'KP'
    },
    {
        'name': 'Korea, Republic of South Korea',
        'dial': '+82',
        'code': 'KR'
    },
    {
        'name': 'Kosovo',
        'dial': '+383',
        'code': 'XK'
    },
    {
        'name': 'Kuwait',
        'dial': '+965',
        'code': 'KW'
    },
    {
        'name': 'Kyrgyzstan',
        'dial': '+996',
        'code': 'KG'
    },
    {
        'name': 'Laos',
        'dial': '+856',
        'code': 'LA'
    },
    {
        'name': 'Latvia',
        'dial': '+371',
        'code': 'LV'
    },
    {
        'name': 'Lebanon',
        'dial': '+961',
        'code': 'LB'
    },
    {
        'name': 'Lesotho',
        'dial': '+266',
        'code': 'LS'
    },
    {
        'name': 'Liberia',
        'dial': '+231',
        'code': 'LR'
    },
    {
        'name': 'Libyan Arab Jamahiriya',
        'dial': '+218',
        'code': 'LY'
    },
    {
        'name': 'Liechtenstein',
        'dial': '+423',
        'code': 'LI'
    },
    {
        'name': 'Lithuania',
        'dial': '+370',
        'code': 'LT'
    },
    {
        'name': 'Luxembourg',
        'dial': '+352',
        'code': 'LU'
    },
    {
        'name': 'Macao',
        'dial': '+853',
        'code': 'MO'
    },
    {
        'name': 'Macedonia',
        'dial': '+389',
        'code': 'MK'
    },
    {
        'name': 'Madagascar',
        'dial': '+261',
        'code': 'MG'
    },
    {
        'name': 'Malawi',
        'dial': '+265',
        'code': 'MW'
    },
    {
        'name': 'Malaysia',
        'dial': '+60',
        'code': 'MY'
    },
    {
        'name': 'Maldives',
        'dial': '+960',
        'code': 'MV'
    },
    {
        'name': 'Mali',
        'dial': '+223',
        'code': 'ML'
    },
    {
        'name': 'Malta',
        'dial': '+356',
        'code': 'MT'
    },
    {
        'name': 'Marshall Islands',
        'dial': '+692',
        'code': 'MH'
    },
    {
        'name': 'Martinique',
        'dial': '+596',
        'code': 'MQ'
    },
    {
        'name': 'Mauritania',
        'dial': '+222',
        'code': 'MR'
    },
    {
        'name': 'Mauritius',
        'dial': '+230',
        'code': 'MU'
    },
    {
        'name': 'Mayotte',
        'dial': '+262',
        'code': 'YT'
    },
    {
        'name': 'Mexico',
        'dial': '+52',
        'code': 'MX'
    },
    {
        'name': 'Micronesia, Federated States of Micronesia',
        'dial': '+691',
        'code': 'FM'
    },
    {
        'name': 'Moldova',
        'dial': '+373',
        'code': 'MD'
    },
    {
        'name': 'Monaco',
        'dial': '+377',
        'code': 'MC'
    },
    {
        'name': 'Mongolia',
        'dial': '+976',
        'code': 'MN'
    },
    {
        'name': 'Montenegro',
        'dial': '+382',
        'code': 'ME'
    },
    {
        'name': 'Montserrat',
        'dial': '+1664',
        'code': 'MS'
    },
    {
        'name': 'Morocco',
        'dial': '+212',
        'code': 'MA'
    },
    {
        'name': 'Mozambique',
        'dial': '+258',
        'code': 'MZ'
    },
    {
        'name': 'Myanmar',
        'dial': '+95',
        'code': 'MM'
    },
    {
        'name': 'Namibia',
        'dial': '+264',
        'code': 'NA'
    },
    {
        'name': 'Nauru',
        'dial': '+674',
        'code': 'NR'
    },
    {
        'name': 'Nepal',
        'dial': '+977',
        'code': 'NP'
    },
    {
        'name': 'Netherlands',
        'dial': '+31',
        'code': 'NL'
    },
    {
        'name': 'Netherlands Antilles',
        'dial': '+599',
        'code': 'AN'
    },
    {
        'name': 'New Caledonia',
        'dial': '+687',
        'code': 'NC'
    },
    {
        'name': 'New Zealand',
        'dial': '+64',
        'code': 'NZ'
    },
    {
        'name': 'Nicaragua',
        'dial': '+505',
        'code': 'NI'
    },
    {
        'name': 'Niger',
        'dial': '+227',
        'code': 'NE'
    },
    {
        'name': 'Nigeria',
        'dial': '+234',
        'code': 'NG'
    },
    {
        'name': 'Niue',
        'dial': '+683',
        'code': 'NU'
    },
    {
        'name': 'Norfolk Island',
        'dial': '+672',
        'code': 'NF'
    },
    {
        'name': 'Northern Mariana Islands',
        'dial': '+1670',
        'code': 'MP'
    },
    {
        'name': 'Norway',
        'dial': '+47',
        'code': 'NO'
    },
    {
        'name': 'Oman',
        'dial': '+968',
        'code': 'OM'
    },
    {
        'name': 'Pakistan',
        'dial': '+92',
        'code': 'PK'
    },
    {
        'name': 'Palau',
        'dial': '+680',
        'code': 'PW'
    },
    {
        'name': 'Palestinian Territory, Occupied',
        'dial': '+970',
        'code': 'PS'
    },
    {
        'name': 'Panama',
        'dial': '+507',
        'code': 'PA'
    },
    {
        'name': 'Papua New Guinea',
        'dial': '+675',
        'code': 'PG'
    },
    {
        'name': 'Paraguay',
        'dial': '+595',
        'code': 'PY'
    },
    {
        'name': 'Peru',
        'dial': '+51',
        'code': 'PE'
    },
    {
        'name': 'Philippines',
        'dial': '+63',
        'code': 'PH'
    },
    {
        'name': 'Pitcairn',
        'dial': '+64',
        'code': 'PN'
    },
    {
        'name': 'Poland',
        'dial': '+48',
        'code': 'PL'
    },
    {
        'name': 'Portugal',
        'dial': '+351',
        'code': 'PT'
    },
    {
        'name': 'Puerto Rico',
        'dial': '+1939',
        'code': 'PR'
    },
    {
        'name': 'Qatar',
        'dial': '+974',
        'code': 'QA'
    },
    {
        'name': 'Romania',
        'dial': '+40',
        'code': 'RO'
    },
    {
        'name': 'Russia',
        'dial': '+7',
        'code': 'RU'
    },
    {
        'name': 'Rwanda',
        'dial': '+250',
        'code': 'RW'
    },
    {
        'name': 'Reunion',
        'dial': '+262',
        'code': 'RE'
    },
    {
        'name': 'Saint Barthelemy',
        'dial': '+590',
        'code': 'BL'
    },
    {
        'name': 'Saint Helena, Ascension and Tristan Da Cunha',
        'dial': '+290',
        'code': 'SH'
    },
    {
        'name': 'Saint Kitts and Nevis',
        'dial': '+1869',
        'code': 'KN'
    },
    {
        'name': 'Saint Lucia',
        'dial': '+1758',
        'code': 'LC'
    },
    {
        'name': 'Saint Martin',
        'dial': '+590',
        'code': 'MF'
    },
    {
        'name': 'Saint Pierre and Miquelon',
        'dial': '+508',
        'code': 'PM'
    },
    {
        'name': 'Saint Vincent and the Grenadines',
        'dial': '+1784',
        'code': 'VC'
    },
    {
        'name': 'Samoa',
        'dial': '+685',
        'code': 'WS'
    },
    {
        'name': 'San Marino',
        'dial': '+378',
        'code': 'SM'
    },
    {
        'name': 'Sao Tome and Principe',
        'dial': '+239',
        'code': 'ST'
    },
    {
        'name': 'Saudi Arabia',
        'dial': '+966',
        'code': 'SA'
    },
    {
        'name': 'Senegal',
        'dial': '+221',
        'code': 'SN'
    },
    {
        'name': 'Serbia',
        'dial': '+381',
        'code': 'RS'
    },
    {
        'name': 'Seychelles',
        'dial': '+248',
        'code': 'SC'
    },
    {
        'name': 'Sierra Leone',
        'dial': '+232',
        'code': 'SL'
    },
    {
        'name': 'Singapore',
        'dial': '+65',
        'code': 'SG'
    },
    {
        'name': 'Slovakia',
        'dial': '+421',
        'code': 'SK'
    },
    {
        'name': 'Slovenia',
        'dial': '+386',
        'code': 'SI'
    },
    {
        'name': 'Solomon Islands',
        'dial': '+677',
        'code': 'SB'
    },
    {
        'name': 'Somalia',
        'dial': '+252',
        'code': 'SO'
    },
    {
        'name': 'South Africa',
        'dial': '+27',
        'code': 'ZA'
    },
    {
        'name': 'South Sudan',
        'dial': '+211',
        'code': 'SS'
    },
    {
        'name': 'South Georgia and the South Sandwich Islands',
        'dial': '+500',
        'code': 'GS'
    },
    {
        'name': 'Spain',
        'dial': '+34',
        'code': 'ES'
    },
    {
        'name': 'Sri Lanka',
        'dial': '+94',
        'code': 'LK'
    },
    {
        'name': 'Sudan',
        'dial': '+249',
        'code': 'SD'
    },
    {
        'name': 'Suriname',
        'dial': '+597',
        'code': 'SR'
    },
    {
        'name': 'Svalbard and Jan Mayen',
        'dial': '+47',
        'code': 'SJ'
    },
    {
        'name': 'Swaziland',
        'dial': '+268',
        'code': 'SZ'
    },
    {
        'name': 'Sweden',
        'dial': '+46',
        'code': 'SE'
    },
    {
        'name': 'Switzerland',
        'dial': '+41',
        'code': 'CH'
    },
    {
        'name': 'Syrian Arab Republic',
        'dial': '+963',
        'code': 'SY'
    },
    {
        'name': 'Taiwan',
        'dial': '+886',
        'code': 'TW'
    },
    {
        'name': 'Tajikistan',
        'dial': '+992',
        'code': 'TJ'
    },
    {
        'name': 'Tanzania, United Republic of Tanzania',
        'dial': '+255',
        'code': 'TZ'
    },
    {
        'name': 'Thailand',
        'dial': '+66',
        'code': 'TH'
    },
    {
        'name': 'Timor-Leste',
        'dial': '+670',
        'code': 'TL'
    },
    {
        'name': 'Togo',
        'dial': '+228',
        'code': 'TG'
    },
    {
        'name': 'Tokelau',
        'dial': '+690',
        'code': 'TK'
    },
    {
        'name': 'Tonga',
        'dial': '+676',
        'code': 'TO'
    },
    {
        'name': 'Trinidad and Tobago',
        'dial': '+1868',
        'code': 'TT'
    },
    {
        'name': 'Tunisia',
        'dial': '+216',
        'code': 'TN'
    },
    {
        'name': 'Turkey',
        'dial': '+90',
        'code': 'TR'
    },
    {
        'name': 'Turkmenistan',
        'dial': '+993',
        'code': 'TM'
    },
    {
        'name': 'Turks and Caicos Islands',
        'dial': '+1649',
        'code': 'TC'
    },
    {
        'name': 'Tuvalu',
        'dial': '+688',
        'code': 'TV'
    },
    {
        'name': 'Uganda',
        'dial': '+256',
        'code': 'UG'
    },
    {
        'name': 'Ukraine',
        'dial': '+380',
        'code': 'UA'
    },
    {
        'name': 'United Arab Emirates',
        'dial': '+971',
        'code': 'AE'
    },
    {
        'name': 'United Kingdom',
        'dial': '+44',
        'code': 'GB'
    },
    {
        'name': 'United States',
        'dial': '+1',
        'code': 'US'
    },
    {
        'name': 'Uruguay',
        'dial': '+598',
        'code': 'UY'
    },
    {
        'name': 'Uzbekistan',
        'dial': '+998',
        'code': 'UZ'
    },
    {
        'name': 'Vanuatu',
        'dial': '+678',
        'code': 'VU'
    },
    {
        'name': 'Venezuela, Bolivarian Republic of Venezuela',
        'dial': '+58',
        'code': 'VE'
    },
    {
        'name': 'Vietnam',
        'dial': '+84',
        'code': 'VN'
    },
    {
        'name': 'Virgin Islands, British',
        'dial': '+1284',
        'code': 'VG'
    },
    {
        'name': 'Virgin Islands, U.S.',
        'dial': '+1340',
        'code': 'VI'
    },
    {
        'name': 'Wallis and Futuna',
        'dial': '+681',
        'code': 'WF'
    },
    {
        'name': 'Yemen',
        'dial': '+967',
        'code': 'YE'
    },
    {
        'name': 'Zambia',
        'dial': '+260',
        'code': 'ZM'
    },
    {
        'name': 'Zimbabwe',
        'dial': '+263',
        'code': 'ZW'
    }
];

/**Service that returns a list of countries. */
class AxaCountryService {
    /**Returns an array of all the countries. */
    getCountries() {
        return countries;
    }
}
AxaCountryService.ɵfac = function AxaCountryService_Factory(t) { return new (t || AxaCountryService)(); };
AxaCountryService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaCountryService, factory: AxaCountryService.ɵfac });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCountryService, [{
        type: Injectable
    }], null, null); })();

/**Unique ID generated for phone inputs. */
let nextUniqueId$4 = 0;
/**Value Accessor provider to enable ngModel. */
const AXA_PHONE_INPUT_CONTROL_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AxaPhoneInputComponent),
    multi: true
};
/**@ignore */
class AxaPhoneInputBase {
    constructor(_defaultErrorStateMatcher, cdr, _parentForm, _parentFormGroup, ngControl) {
        this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
        this.cdr = cdr;
        this._parentForm = _parentForm;
        this._parentFormGroup = _parentFormGroup;
        this.ngControl = ngControl;
    }
}
/**@ignore */
const _AxaPhoneInputMixinBase = mixinParentErrorState(AxaPhoneInputBase);
/**Input to enter international phone number. */
class AxaPhoneInputComponent extends _AxaPhoneInputMixinBase {
    /**
     *Creates an instance of AxaPhoneInputComponent.
     * @param ngControl the underlying control
     * @param parentForm the parent form
     * @param parentFormGroup the parent formgroup
     * @param defaultErrorStateMatcher the errorstatematcher that will be used
     * @param cdr changedetectorref
     * @param _injector dependency injector
     * @param countrySvc the country service
     */
    constructor(ngControl, parentForm, parentFormGroup, defaultErrorStateMatcher, cdr, _injector, countrySvc) {
        super(defaultErrorStateMatcher, cdr, parentForm, parentFormGroup, ngControl);
        this.ngControl = ngControl;
        this.cdr = cdr;
        this._injector = _injector;
        this.countrySvc = countrySvc;
        this._uniqueId = `axa-phone-input-${++nextUniqueId$4}`;
        /**Default style of the step. */
        this.cls = true;
        /**
         * Stream that emits when the errorState of the control changes.
         */
        this.errorStateChanges = new Subject();
        /**
         * Whether the control is focused.
         */
        this.focused = false;
        this._required = false;
        this._disabled = false;
        this._readonly = false;
        this._selectedCountry = null;
        /**Input associated with the internal input control. */
        this.inputValue = '';
        /**
         * Implementation of the value accessor.
         */
        this.valueAccessorChange = () => { };
        this.id = this.id;
        // Setting the value accessor directly (instead of using
        // the providers) to avoid running into a circular import.
        if (this.ngControl != null) {
            this.ngControl.valueAccessor = this;
        }
        this.countries = this.countrySvc.getCountries();
    }
    /**
     * Whether the control is required.
     */
    get required() { return this._required; }
    set required(value) { this._required = coerceBooleanProperty(value); }
    /**
     * Whether the control is disabled.
     */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        if (this.focused) {
            this.focused = false;
        }
    }
    /**
     * Whether the control is readonly.
     */
    get readonly() { return this._readonly; }
    set readonly(value) { this._readonly = coerceBooleanProperty(value); }
    /**
     * Element ID.
     */
    get id() { return this._id; }
    set id(value) { this._id = value || this._uniqueId; }
    /**The selected dial country. */
    get selectedCountry() {
        return this._selectedCountry;
    }
    set selectedCountry(v) {
        this._selectedCountry = v;
        this.evaluateInput();
    }
    /**The phone number. */
    get value() { return this._value; }
    set value(value) {
        this._value = value;
        this.valueAccessorChange(this._value);
    }
    ngOnInit() {
        this.favoriteCountries = this.countries.filter(c => this.favorites.indexOf(c.code) !== -1);
        setTimeout(() => {
            if (this.default) {
                this.selectedCountry = this.countries.find((country => country.code === this.default));
            }
            this.cdr.markForCheck();
        }, 0);
        this.ngControl = this._injector.get(NgControl);
    }
    ngOnDestroy() {
        this.unMonitorChildrenControls();
    }
    ngAfterViewInit() {
        this.childrenControls = this.axaControls;
        this.monitorChildrenControls();
    }
    /**Reacts to changes in the inner input control. */
    onInputChange() {
        this.evaluateInput();
    }
    /**Evaluates the input to read the dial code. */
    evaluateInput() {
        const input = this.inputValue;
        if (input && input.length > 1) {
            const result = this.countries.filter(count => count.dial === input.substring(0, count.dial.length));
            if (result && result.length > 0 && this._selectedCountry === null) {
                this._selectedCountry = result[0];
                if (input && input.indexOf(this._selectedCountry.dial) !== -1) {
                    this.inputValue = input.substring(this._selectedCountry.dial.length, input.length);
                }
            }
        }
        this._value = this._selectedCountry && this.inputValue ? this._selectedCountry.dial + this.inputValue : '';
        this.valueAccessorChange(this._value);
    }
    /**
     * Implementation of the value accessor.
     */
    writeValue(value) {
        if (value && value.length > 1) {
            const result = this.countries.filter(count => count.dial === value.substring(0, count.dial.length));
            if (result.length > 0 && this._selectedCountry === null) {
                this._selectedCountry = result[0];
                if (value.indexOf(this._selectedCountry.dial) !== -1) {
                    this.inputValue = value.substring(this._selectedCountry.dial.length, value.length);
                }
            }
        }
        else if (value === null) {
            this._selectedCountry = null;
            this.inputValue = null;
            this.cdr.markForCheck();
        }
    }
    /**
     * Implementation of the value accessor.
     */
    registerOnChange(fn) {
        this.valueAccessorChange = fn;
    }
    /**
     * Implementation of the value accessor.
     */
    registerOnTouched(fn) {
        this.valueAccessorTouch = fn;
    }
    /**
     * Implementation of the value accessor.
     */
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this.cdr.markForCheck();
    }
}
AxaPhoneInputComponent.ɵfac = function AxaPhoneInputComponent_Factory(t) { return new (t || AxaPhoneInputComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgControl, 10), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgForm, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.FormGroupDirective, 8), ɵngcc0.ɵɵdirectiveInject(ErrorStateMatcher), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.Injector), ɵngcc0.ɵɵdirectiveInject(AxaCountryService)); };
AxaPhoneInputComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaPhoneInputComponent, selectors: [["axa-phone-input"]], viewQuery: function AxaPhoneInputComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵviewQuery(AxaFormFieldControl, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.axaControls = _t);
    } }, hostVars: 3, hostBindings: function AxaPhoneInputComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
        ɵngcc0.ɵɵclassProp("axa-phone-input", ctx.cls);
    } }, inputs: { id: "id", required: "required", disabled: "disabled", readonly: "readonly", value: "value", name: "name", placeholder: "placeholder", favorites: "favorites", default: "default" }, features: [ɵngcc0.ɵɵProvidersFeature([
            { provide: AxaFormFieldControl, useExisting: AxaPhoneInputComponent },
            AxaCountryService
        ]), ɵngcc0.ɵɵInheritDefinitionFeature], decls: 8, vars: 12, consts: [["axaSelect", "", "id", "flags", "name", "flags", 3, "ngModel", "required", "disabled", "ngModelChange"], [3, "ngValue", 4, "ngFor", "ngForOf"], ["disabled", ""], ["axaInput", "", "axaNumbersOnly", "", 3, "id", "name", "placeholder", "required", "disabled", "readonly", "ngModel", "ngModelChange"], [3, "ngValue"]], template: function AxaPhoneInputComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "axa-prefix");
        ɵngcc0.ɵɵelementStart(1, "select", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaPhoneInputComponent_Template_select_ngModelChange_1_listener($event) { return ctx.selectedCountry = $event; });
        ɵngcc0.ɵɵelementStart(2, "optgroup");
        ɵngcc0.ɵɵtemplate(3, AxaPhoneInputComponent_option_3_Template, 2, 3, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(4, "option", 2);
        ɵngcc0.ɵɵtext(5, "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtemplate(6, AxaPhoneInputComponent_option_6_Template, 2, 3, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(7, "input", 3);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaPhoneInputComponent_Template_input_ngModelChange_7_listener($event) { return ctx.inputValue = $event; })("ngModelChange", function AxaPhoneInputComponent_Template_input_ngModelChange_7_listener() { return ctx.onInputChange(); });
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngModel", ctx.selectedCountry)("required", ctx.required)("disabled", ctx.disabled);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.favoriteCountries);
        ɵngcc0.ɵɵadvance(3);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.countries);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("id", ctx.id)("name", ctx.name)("placeholder", ctx.placeholder)("required", ctx.required)("disabled", ctx.disabled)("readonly", ctx.readonly)("ngModel", ctx.inputValue);
    } }, directives: function () { return [AxaPrefixDirective, ɵngcc1.SelectControlValueAccessor, AxaSelect, ɵngcc1.NgControlStatus, ɵngcc1.NgModel, ɵngcc1.RequiredValidator, ɵngcc2.NgForOf, ɵngcc1.NgSelectOption, ɵngcc1.ɵangular_packages_forms_forms_x, AxaInput, ɵngcc1.DefaultValueAccessor, AxaNumbersOnlyDirective]; }, encapsulation: 2, changeDetection: 0 });
AxaPhoneInputComponent.ctorParameters = () => [
    { type: NgControl, decorators: [{ type: Optional }, { type: Self }] },
    { type: NgForm, decorators: [{ type: Optional }] },
    { type: FormGroupDirective, decorators: [{ type: Optional }] },
    { type: ErrorStateMatcher },
    { type: ChangeDetectorRef },
    { type: Injector },
    { type: AxaCountryService }
];
AxaPhoneInputComponent.propDecorators = {
    cls: [{ type: HostBinding, args: [`class.axa-phone-input`,] }],
    name: [{ type: Input }],
    required: [{ type: Input }],
    disabled: [{ type: Input }],
    readonly: [{ type: Input }],
    placeholder: [{ type: Input }],
    id: [{ type: Input }],
    value: [{ type: Input }],
    favorites: [{ type: Input }],
    default: [{ type: Input }],
    axaControls: [{ type: ViewChildren, args: [AxaFormFieldControl,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaPhoneInputComponent, [{
        type: Component,
        args: [{
                selector: 'axa-phone-input',
                host: {
                    '[attr.id]': 'id'
                },
                template: "<axa-prefix>\r\n  <select axaSelect id=\"flags\" name=\"flags\" [(ngModel)]=\"selectedCountry\" [required]=\"required\" [disabled]=\"disabled\">\r\n    <optgroup>\r\n      <option *ngFor=\"let country of favoriteCountries\" [ngValue]=\"country\">\r\n        {{country.code}} {{country.dial}}\r\n      </option>\r\n    </optgroup>\r\n    <option disabled>\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500</option>\r\n    <option *ngFor=\"let country of countries\" [ngValue]=\"country\">{{country.code}} {{country.dial}}</option>\r\n  </select>\r\n</axa-prefix>\r\n<input axaInput axaNumbersOnly [id]=\"id\" [name]=\"name\" [placeholder]=\"placeholder\" [required]=\"required\"\r\n  [disabled]=\"disabled\" [readonly]=\"readonly\" [(ngModel)]=\"inputValue\" (ngModelChange)=\"onInputChange()\">",
                providers: [
                    { provide: AxaFormFieldControl, useExisting: AxaPhoneInputComponent },
                    AxaCountryService
                ],
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc1.NgControl, decorators: [{
                type: Optional
            }, {
                type: Self
            }] }, { type: ɵngcc1.NgForm, decorators: [{
                type: Optional
            }] }, { type: ɵngcc1.FormGroupDirective, decorators: [{
                type: Optional
            }] }, { type: ErrorStateMatcher }, { type: ɵngcc0.ChangeDetectorRef }, { type: ɵngcc0.Injector }, { type: AxaCountryService }]; }, { cls: [{
            type: HostBinding,
            args: [`class.axa-phone-input`]
        }], id: [{
            type: Input
        }], required: [{
            type: Input
        }], disabled: [{
            type: Input
        }], readonly: [{
            type: Input
        }], value: [{
            type: Input
        }], name: [{
            type: Input
        }], placeholder: [{
            type: Input
        }], favorites: [{
            type: Input
        }], default: [{
            type: Input
        }], axaControls: [{
            type: ViewChildren,
            args: [AxaFormFieldControl]
        }] }); })();

/**Directive to only allow numeric input. */
class AxaNumbersOnlyDirective {
    constructor() {
        this.regexStr = '^[0-9+]*$';
    }
    /**Handles the key down event. */
    onKeyDown(event) {
        const allowKeys = {
            'Delete': 0,
            'Del': 0,
            'Tab': 0,
            'Escape': 0,
            'Esc': 0,
            'Backspace': 0,
            'Enter': 0,
            'Home': 0,
            'End': 0,
            'ArrowLeft': 0,
            'ArrowRight': 0
        };
        if (allowKeys[event.key] === 0) {
            return;
        }
        if (event.ctrlKey && ['a', 'c', 'v', 'x'].find(key => event.key.toLowerCase() === key)) {
            return;
        }
        if (new RegExp(this.regexStr).test(event.key)) {
            return;
        }
        event.preventDefault();
    }
}
AxaNumbersOnlyDirective.ɵfac = function AxaNumbersOnlyDirective_Factory(t) { return new (t || AxaNumbersOnlyDirective)(); };
AxaNumbersOnlyDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaNumbersOnlyDirective, selectors: [["", "axaNumbersOnly", ""]], hostBindings: function AxaNumbersOnlyDirective_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("keydown", function AxaNumbersOnlyDirective_keydown_HostBindingHandler($event) { return ctx.onKeyDown($event); });
    } } });
AxaNumbersOnlyDirective.propDecorators = {
    onKeyDown: [{ type: HostListener, args: ['keydown', ['$event'],] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaNumbersOnlyDirective, [{
        type: Directive,
        args: [{ selector: '[axaNumbersOnly]' }]
    }], function () { return []; }, { onKeyDown: [{
            type: HostListener,
            args: ['keydown', ['$event']]
        }] }); })();

class AxaPhoneInputModule {
    static forRoot() {
        return {
            ngModule: AxaPhoneInputModule,
            providers: [AxaCountryService]
        };
    }
}
AxaPhoneInputModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaPhoneInputModule });
AxaPhoneInputModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaPhoneInputModule_Factory(t) { return new (t || AxaPhoneInputModule)(); }, providers: [], imports: [[CommonModule, FormsModule, AxaSelectModule, AxaInputModule, AxaFormFieldModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaPhoneInputModule, { declarations: function () { return [AxaPhoneInputComponent, AxaNumbersOnlyDirective]; }, imports: function () { return [CommonModule, FormsModule, AxaSelectModule, AxaInputModule, AxaFormFieldModule]; }, exports: function () { return [AxaPhoneInputComponent, AxaNumbersOnlyDirective]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaPhoneInputModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, FormsModule, AxaSelectModule, AxaInputModule, AxaFormFieldModule],
                exports: [AxaPhoneInputComponent, AxaNumbersOnlyDirective],
                declarations: [AxaPhoneInputComponent, AxaNumbersOnlyDirective],
                providers: []
            }]
    }], null, null); })();

/**
 * Service used to communicate with the alert manager.
 * @export
 */
class AxaAlertService {
    constructor() {
        this.newAlerts = new ReplaySubject(10);
        this.removedAlerts = new ReplaySubject(10);
    }
    /**
     * Add an alert.
     */
    addAlert(alert) {
        this.newAlerts.next(alert);
        if (alert.ttl) {
            setTimeout(() => {
                this.removeAlert(alert);
            }, alert.ttl);
        }
    }
    /**
     * Remove an alert.
     */
    removeAlert(alert) {
        this.removedAlerts.next(alert);
    }
    /**
     * Gets the stream of added alerts.
     */
    getNewAlerts() {
        return this.newAlerts;
    }
    /**
     * Gets the stream of removed alerts.
     */
    getRemovedAlerts() {
        return this.removedAlerts;
    }
}
AxaAlertService.ɵfac = function AxaAlertService_Factory(t) { return new (t || AxaAlertService)(); };
AxaAlertService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaAlertService, factory: AxaAlertService.ɵfac });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAlertService, [{
        type: Injectable
    }], function () { return []; }, null); })();

/**
 * The alert manager displays the alerts submitted to the alert service.
 * @export
 */
class AxaAlertManager {
    /**
     * Creates an instance of AxaAlertManager.
     */
    constructor(alertSvc, cdr) {
        this.alertSvc = alertSvc;
        this.cdr = cdr;
        /** List of alerts received from the alert service. */
        this.alerts = new Array();
    }
    ngOnInit() {
        this.newAlertSub = this.alertSvc.getNewAlerts().subscribe(alert => {
            this.alerts = [...this.alerts, alert];
            this.cdr.markForCheck();
        });
        this.removeAlertSub = this.alertSvc.getRemovedAlerts().subscribe(alert => {
            this.alerts = this.alerts.filter(currentAlert => currentAlert !== alert);
            this.cdr.markForCheck();
        });
    }
    ngOnDestroy() {
        this.newAlertSub.unsubscribe();
        this.removeAlertSub.unsubscribe();
    }
}
AxaAlertManager.ɵfac = function AxaAlertManager_Factory(t) { return new (t || AxaAlertManager)(ɵngcc0.ɵɵdirectiveInject(AxaAlertService), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef)); };
AxaAlertManager.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaAlertManager, selectors: [["axa-alert-manager"]], decls: 2, vars: 2, consts: [[3, "type", "buttonLabel", "buttonClick", 4, "ngFor", "ngForOf"], [3, "type", "buttonLabel", "buttonClick"]], template: function AxaAlertManager_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div");
        ɵngcc0.ɵɵtemplate(1, AxaAlertManager_axa_top_content_bar_1_Template, 2, 3, "axa-top-content-bar", 0);
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("@simpleFadeAnimation", undefined);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.alerts);
    } }, directives: function () { return [ɵngcc2.NgForOf, AxaTopContentBarComponent]; }, encapsulation: 2, data: { animation: [
            trigger('simpleFadeAnimation', [
                transition('void => *', [
                    style({ opacity: '0' }),
                    animate(1000)
                ]),
                transition('* => void', [
                    animate(1000, style({ opacity: '1' }))
                ])
            ])
        ] }, changeDetection: 0 });
AxaAlertManager.ctorParameters = () => [
    { type: AxaAlertService },
    { type: ChangeDetectorRef }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAlertManager, [{
        type: Component,
        args: [{
                selector: 'axa-alert-manager',
                template: `
    <div [@simpleFadeAnimation]>
      <axa-top-content-bar *ngFor="let alert of alerts"
      [type]="alert.type" [buttonLabel]="alert.action && alert.action.content"
      (buttonClick)="alert.action && alert.action.handler  && alert.action.handler(alert.action, alert)">
        {{alert.message}}
      </axa-top-content-bar>
    </div>`,
                changeDetection: ChangeDetectionStrategy.OnPush,
                animations: [
                    trigger('simpleFadeAnimation', [
                        transition('void => *', [
                            style({ opacity: '0' }),
                            animate(1000)
                        ]),
                        transition('* => void', [
                            animate(1000, style({ opacity: '1' }))
                        ])
                    ])
                ]
            }]
    }], function () { return [{ type: AxaAlertService }, { type: ɵngcc0.ChangeDetectorRef }]; }, null); })();

/** Base css class. */
const AXA_BAR_CLASS_BASE = 'axa-top-content-bar';
/** Corporate css class. */
const AXA_BAR_CLASS_CORPORATE = 'corporate';
/** Commercial css class. */
const AXA_BAR_CLASS_COMMERCIAL = 'commercial';
/** Warning css class. */
const AXA_BAR_CLASS_WARNING = 'warning';
/** Base content css class. */
const AXA_BAR_CLASS_CONTENT = 'content';

/**
 * Alert component message displayed by the `AxaAlertManager`
 * @export
 * ### Example
 * ```
 * <axa-alert-manager></axa-alert-manager>
 * ```
 */
class AxaTopContentBarComponent {
    /**
     * Creates an instance of AxaTopContentBarComponent.
     */
    constructor() {
        /**
         * Occurs when the button is clicked.
         */
        this.buttonClick = new EventEmitter();
    }
    /**
     * Handles the click on the button.
     */
    handleClick(e) {
        e.preventDefault();
        this.buttonClick.emit(e);
    }
    /**
     * Sets the css class depending on type.
     */
    getTypeClass() {
        switch (this.type) {
            case 'corporate':
                return `${AXA_BAR_CLASS_BASE}--${AXA_BAR_CLASS_CORPORATE}`;
            case 'warning':
                return `${AXA_BAR_CLASS_BASE}--${AXA_BAR_CLASS_WARNING}`;
        }
        return `${AXA_BAR_CLASS_BASE}--${AXA_BAR_CLASS_COMMERCIAL}`;
    }
    /**
     * Sets the base css class.
     */
    getClass() {
        return `${AXA_BAR_CLASS_BASE} ${this.getTypeClass()}`;
    }
    /**
     * Sets the base css content class.
     */
    getContentClass() {
        return `${AXA_BAR_CLASS_BASE}__${AXA_BAR_CLASS_CONTENT}`;
    }
}
AxaTopContentBarComponent.ɵfac = function AxaTopContentBarComponent_Factory(t) { return new (t || AxaTopContentBarComponent)(); };
AxaTopContentBarComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTopContentBarComponent, selectors: [["axa-top-content-bar"]], inputs: { type: "type", href: "href", buttonLabel: "buttonLabel" }, outputs: { buttonClick: "buttonClick" }, ngContentSelectors: _c0, decls: 4, vars: 5, consts: [["axa-button", "", "neg", "", "small", "", 3, "href", "click", 4, "ngIf"], ["axa-button", "", "neg", "", "small", "", 3, "href", "click"]], template: function AxaTopContentBarComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "div");
        ɵngcc0.ɵɵelementStart(1, "div");
        ɵngcc0.ɵɵprojection(2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtemplate(3, AxaTopContentBarComponent_a_3_Template, 2, 2, "a", 0);
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.getClass());
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵclassMap(ctx.getContentClass());
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngIf", ctx.buttonLabel);
    } }, directives: [ɵngcc2.NgIf, AxaButton], encapsulation: 2, changeDetection: 0 });
AxaTopContentBarComponent.ctorParameters = () => [];
AxaTopContentBarComponent.propDecorators = {
    type: [{ type: Input }],
    href: [{ type: Input }],
    buttonLabel: [{ type: Input }],
    buttonClick: [{ type: Output }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTopContentBarComponent, [{
        type: Component,
        args: [{
                selector: 'axa-top-content-bar',
                template: "<div [class]=\"getClass()\">\r\n  <div [class]=\"getContentClass()\">\r\n      <ng-content></ng-content>\r\n  </div>\r\n  <a *ngIf=\"buttonLabel\" [href]=\"href\" (click)=\"handleClick($event)\" axa-button neg small>{{buttonLabel}}</a>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { buttonClick: [{
            type: Output
        }], type: [{
            type: Input
        }], href: [{
            type: Input
        }], buttonLabel: [{
            type: Input
        }] }); })();

class AxaTopContentBarModule {
}
AxaTopContentBarModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaTopContentBarModule });
AxaTopContentBarModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaTopContentBarModule_Factory(t) { return new (t || AxaTopContentBarModule)(); }, imports: [[CommonModule, AxaButtonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaTopContentBarModule, { declarations: function () { return [AxaTopContentBarComponent]; }, imports: function () { return [CommonModule, AxaButtonModule]; }, exports: function () { return [AxaTopContentBarComponent]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTopContentBarModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, AxaButtonModule],
                declarations: [AxaTopContentBarComponent],
                exports: [AxaTopContentBarComponent]
            }]
    }], null, null); })();

class AxaAlertModule {
    static forRoot() {
        return {
            ngModule: AxaAlertModule,
            providers: [AxaAlertService]
        };
    }
}
AxaAlertModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaAlertModule });
AxaAlertModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaAlertModule_Factory(t) { return new (t || AxaAlertModule)(); }, imports: [[CommonModule, AxaTopContentBarModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaAlertModule, { declarations: function () { return [AxaAlertManager]; }, imports: function () { return [CommonModule, AxaTopContentBarModule]; }, exports: function () { return [AxaAlertManager]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAlertModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, AxaTopContentBarModule],
                exports: [AxaAlertManager],
                declarations: [AxaAlertManager]
            }]
    }], null, null); })();

/**
 * The busy component displayed by the busy directive
 * @export
 */
class AxaBusyComponent {
    constructor() {
        /**
         * The busy message displayed, defaults to 'loading'.
         */
        this.message = '';
    }
}
AxaBusyComponent.ɵfac = function AxaBusyComponent_Factory(t) { return new (t || AxaBusyComponent)(); };
AxaBusyComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaBusyComponent, selectors: [["axa-busy-component"]], inputs: { message: "message" }, decls: 4, vars: 1, consts: [[1, "axa-busy-indicator", "axa-busy-indicator--active"], [1, "axa-busy-indicator__animation"], [1, "axa-busy-indicator__caption"]], template: function AxaBusyComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelement(1, "div", 1);
        ɵngcc0.ɵɵelementStart(2, "div", 2);
        ɵngcc0.ɵɵtext(3);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(3);
        ɵngcc0.ɵɵtextInterpolate1(" ", ctx.message, " ");
    } }, encapsulation: 2 });
AxaBusyComponent.propDecorators = {
    message: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyComponent, [{
        type: Component,
        args: [{
                selector: 'axa-busy-component',
                template: `
    <div class="axa-busy-indicator axa-busy-indicator--active">
        <div class="axa-busy-indicator__animation"></div>
        <div class="axa-busy-indicator__caption">
        {{ message }}
        </div>
    </div>`
            }]
    }], function () { return []; }, { message: [{
            type: Input
        }] }); })();

/**
 * The backdrop displayed with the busy component.
 * @export
 */
class AxaBusyBackdropComponent {
}
AxaBusyBackdropComponent.ɵfac = function AxaBusyBackdropComponent_Factory(t) { return new (t || AxaBusyBackdropComponent)(); };
AxaBusyBackdropComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaBusyBackdropComponent, selectors: [["axa-busy-backdrop"]], decls: 1, vars: 0, consts: [[1, "axa-busy-indicator__backdrop", "axa-busy-indicator__backdrop--active"]], template: function AxaBusyBackdropComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelement(0, "div", 0);
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyBackdropComponent, [{
        type: Component,
        args: [{
                selector: 'axa-busy-backdrop',
                template: `
    <div class="axa-busy-indicator__backdrop axa-busy-indicator__backdrop--active">
    </div>`
            }]
    }], null, null); })();

/**Axa busy container style. */
const BUSY_CONTAINER = 'axa-busy-indicator-wrapper';
/**Axa busy container full screen style. */
const BUSY_CONTAINER_FULL_SCREEN = 'axa-busy-indicator-wrapper--fixed';

/**Busy directive for local busy. */
class AxaBusyContainerDirective {
    /**
     *Creates an instance of AxaBusyContainerDirective.
     * @param  el The element ref.
     */
    constructor(el) {
        this.el = el;
        this.host = el.nativeElement;
        this.addDefaultStyles();
    }
    /**Adds the default style. */
    addDefaultStyles() {
        this.host.classList.add(BUSY_CONTAINER);
    }
}
AxaBusyContainerDirective.ɵfac = function AxaBusyContainerDirective_Factory(t) { return new (t || AxaBusyContainerDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaBusyContainerDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaBusyContainerDirective, selectors: [["", "AxaBusyContainer", ""]] });
AxaBusyContainerDirective.ctorParameters = () => [
    { type: ElementRef }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyContainerDirective, [{
        type: Directive,
        args: [{ selector: '[AxaBusyContainer]' }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, null); })();
/**Busy directive for fullscreen busy. */
class AxaBusyContainerFullScreenDirective {
    /**
     *Creates an instance of AxaBusyContainerFullScreenDirective.
     * @param  el The element ref
     */
    constructor(el) {
        this.el = el;
        this.host = el.nativeElement;
        this.addDefaultStyles();
    }
    /**Adds the default style. */
    addDefaultStyles() {
        this.host.classList.add(BUSY_CONTAINER_FULL_SCREEN);
    }
}
AxaBusyContainerFullScreenDirective.ɵfac = function AxaBusyContainerFullScreenDirective_Factory(t) { return new (t || AxaBusyContainerFullScreenDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaBusyContainerFullScreenDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaBusyContainerFullScreenDirective, selectors: [["", "AxaBusyContainerFullScreen", ""]] });
AxaBusyContainerFullScreenDirective.ctorParameters = () => [
    { type: ElementRef }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyContainerFullScreenDirective, [{
        type: Directive,
        args: [{ selector: '[AxaBusyContainerFullScreen]' }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, null); })();

/**
 * The busy component displayed by the busy raw directive
 * @export
 */
class AxaBusyRawComponent {
}
AxaBusyRawComponent.ɵfac = function AxaBusyRawComponent_Factory(t) { return new (t || AxaBusyRawComponent)(); };
AxaBusyRawComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaBusyRawComponent, selectors: [["axa-busy-raw-component"]], decls: 2, vars: 0, consts: [[1, "axa-busy-indicator", "axa-busy-indicator--active"], [1, "axa-busy-indicator__animation"]], template: function AxaBusyRawComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelement(1, "div", 1);
        ɵngcc0.ɵɵelementEnd();
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyRawComponent, [{
        type: Component,
        args: [{
                selector: 'axa-busy-raw-component',
                template: `
    <div class="axa-busy-indicator axa-busy-indicator--active">
        <div class="axa-busy-indicator__animation"></div>
    </div>`
            }]
    }], null, null); })();

/**
 * Directive used to connect an observable or promise to the busy indicator.
 * You can optionnally add a message too.
 * @export
 */
class AxaBusyRawDirective {
    /**
     * Creates an instance of AxaBusyDirective.
     */
    constructor(componentFactory, viewContainer, template) {
        this.componentFactory = componentFactory;
        this.viewContainer = viewContainer;
        this.template = template;
    }
    /**
     * Busy promise or observable input
     */
    set axaBusyRaw(busy) {
        this.processBusy(busy);
    }
    processBusy(busy) {
        if (busy == null || this.asyncOperation === busy) {
            return;
        }
        if (typeof busy === 'boolean') {
            if (busy) {
                this.createBusy();
            }
            else {
                this.busyFinished();
            }
        }
        else {
            this.asyncOperation = busy;
            if (this.asyncOperation instanceof Promise) {
                this.createBusy();
                this.asyncOperation.then(() => this.busyFinished(), () => this.busyFinished());
            }
            else if (this.asyncOperation instanceof Subscription) {
                this.createBusy();
                this.asyncOperation.add(() => this.busyFinished());
            }
        }
    }
    ngOnInit() {
        this.createViews();
    }
    ngOnDestroy() {
        this.deleteViews();
    }
    createViews() {
        if (this.parentElement == null) {
            const ref = this.viewContainer.createEmbeddedView(this.template);
            this.parentElement = ref.rootNodes[0];
        }
    }
    createBusy() {
        this.createViews();
        const busyFactory = this.componentFactory.resolveComponentFactory(AxaBusyRawComponent);
        const busyBackdropFactory = this.componentFactory.resolveComponentFactory(AxaBusyBackdropComponent);
        this.backdropRef = this.viewContainer.createComponent(busyBackdropFactory);
        this.busyRef = this.viewContainer.createComponent(busyFactory);
        this.backdropElement = this.parentElement.appendChild(this.backdropRef.location.nativeElement);
        this.busyElement = this.parentElement.appendChild(this.busyRef.location.nativeElement);
    }
    busyFinished() {
        if (this.backdropElement && this.backdropElement.parentNode) {
            this.backdropElement.parentNode.removeChild(this.backdropElement);
        }
        if (this.busyElement && this.busyElement.parentNode) {
            this.busyElement.parentNode.removeChild(this.busyElement);
        }
    }
    deleteViews() {
        if (this.busyRef) {
            this.busyRef.destroy();
        }
        if (this.backdropRef) {
            this.backdropRef.destroy();
        }
    }
}
AxaBusyRawDirective.ɵfac = function AxaBusyRawDirective_Factory(t) { return new (t || AxaBusyRawDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ComponentFactoryResolver), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ViewContainerRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.TemplateRef)); };
AxaBusyRawDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaBusyRawDirective, selectors: [["", "axaBusyRaw", ""]], inputs: { axaBusyRaw: "axaBusyRaw" } });
AxaBusyRawDirective.ctorParameters = () => [
    { type: ComponentFactoryResolver },
    { type: ViewContainerRef },
    { type: TemplateRef }
];
AxaBusyRawDirective.propDecorators = {
    axaBusyRaw: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyRawDirective, [{
        type: Directive,
        args: [{ selector: '[axaBusyRaw]' }]
    }], function () { return [{ type: ɵngcc0.ComponentFactoryResolver }, { type: ɵngcc0.ViewContainerRef }, { type: ɵngcc0.TemplateRef }]; }, { axaBusyRaw: [{
            type: Input
        }] }); })();

/**
 * Directive used to connect an observable or promise to the busy indicator.
 * You can optionnally add a message too.
 * @export
 */
class AxaBusyDirective {
    /**
     * Creates an instance of AxaBusyDirective.
     */
    constructor(componentFactory, viewContainer, template) {
        this.componentFactory = componentFactory;
        this.viewContainer = viewContainer;
        this.template = template;
    }
    /**
     * Busy promise or observable input
     */
    set axaBusy(busy) {
        this.processBusy(busy);
    }
    processBusy(busy) {
        if (busy == null || this.asyncOperation === busy) {
            return;
        }
        if (typeof busy === 'boolean') {
            if (busy) {
                this.createBusy();
            }
            else {
                this.busyFinished();
            }
        }
        else {
            this.asyncOperation = busy;
            if (this.asyncOperation instanceof Promise) {
                this.createBusy();
                this.asyncOperation.then(() => this.busyFinished(), () => this.busyFinished());
            }
            else if (this.asyncOperation instanceof Subscription) {
                this.createBusy();
                this.asyncOperation.add(() => this.busyFinished());
            }
        }
    }
    ngOnInit() {
        this.createViews();
    }
    ngOnDestroy() {
        this.deleteViews();
    }
    createViews() {
        if (this.parentElement == null) {
            const ref = this.viewContainer.createEmbeddedView(this.template);
            this.parentElement = ref.rootNodes[0];
        }
    }
    createBusy() {
        this.createViews();
        const busyFactory = this.componentFactory.resolveComponentFactory(AxaBusyComponent);
        const busyBackdropFactory = this.componentFactory.resolveComponentFactory(AxaBusyBackdropComponent);
        this.backdropRef = this.viewContainer.createComponent(busyBackdropFactory);
        this.busyRef = this.viewContainer.createComponent(busyFactory);
        this.backdropElement = this.parentElement.appendChild(this.backdropRef.location.nativeElement);
        this.busyElement = this.parentElement.appendChild(this.busyRef.location.nativeElement);
        if (this.axaBusyMessage) {
            this.busyRef.instance.message = this.axaBusyMessage;
        }
    }
    busyFinished() {
        if (this.backdropElement && this.backdropElement.parentNode) {
            this.backdropElement.parentNode.removeChild(this.backdropElement);
        }
        if (this.busyElement && this.busyElement.parentNode) {
            this.busyElement.parentNode.removeChild(this.busyElement);
        }
    }
    deleteViews() {
        if (this.busyRef) {
            this.busyRef.destroy();
        }
        if (this.backdropRef) {
            this.backdropRef.destroy();
        }
    }
}
AxaBusyDirective.ɵfac = function AxaBusyDirective_Factory(t) { return new (t || AxaBusyDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ComponentFactoryResolver), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ViewContainerRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.TemplateRef)); };
AxaBusyDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaBusyDirective, selectors: [["", "axaBusy", ""]], inputs: { axaBusy: "axaBusy", axaBusyMessage: "axaBusyMessage" } });
AxaBusyDirective.ctorParameters = () => [
    { type: ComponentFactoryResolver },
    { type: ViewContainerRef },
    { type: TemplateRef }
];
AxaBusyDirective.propDecorators = {
    axaBusy: [{ type: Input }],
    axaBusyMessage: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyDirective, [{
        type: Directive,
        args: [{ selector: '[axaBusy]' }]
    }], function () { return [{ type: ɵngcc0.ComponentFactoryResolver }, { type: ɵngcc0.ViewContainerRef }, { type: ɵngcc0.TemplateRef }]; }, { axaBusy: [{
            type: Input
        }], axaBusyMessage: [{
            type: Input
        }] }); })();

class AxaBusyModule {
}
AxaBusyModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaBusyModule });
AxaBusyModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaBusyModule_Factory(t) { return new (t || AxaBusyModule)(); }, imports: [[]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaBusyModule, { declarations: [AxaBusyComponent, AxaBusyBackdropComponent, AxaBusyDirective, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective, AxaBusyRawComponent, AxaBusyRawDirective], exports: [AxaBusyDirective, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective, AxaBusyRawDirective] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyModule, [{
        type: NgModule,
        args: [{
                imports: [],
                exports: [AxaBusyDirective, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective, AxaBusyRawDirective],
                declarations: [
                    AxaBusyComponent, AxaBusyBackdropComponent,
                    AxaBusyDirective, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective,
                    AxaBusyRawComponent, AxaBusyRawDirective
                ]
            }]
    }], null, null); })();

/**Default style. */
const CLASS_BASE = 'axa-card';
/**Active style. */
const CLASS_ACTIVE = `${CLASS_BASE}--active`;
/**Wide style. */
const CLASS_WIDE = `${CLASS_BASE}--wide`;
/**Block style. */
const CLASS_BLOCK = `${CLASS_BASE}__block`;
/**Title style. */
const CLASS_TITLE = `${CLASS_BASE}__title`;
/**Info style. */
const CLASS_INFO = `${CLASS_BASE}--info`;
/**Content style. */
const CLASS_CONTENT = `${CLASS_BASE}--content`;
/**Compact style. */
const CLASS_BLOCK_COMPACT = `${CLASS_BLOCK}--compact`;

/**
 * The card component used to display information in a formatted way.
 */
class AxaCardComponent {
    constructor() {
        /**Base styling binding. */
        this.baseCls = true;
    }
    /**Weither the card is active. */
    set active(value) {
        this._active = coerceBooleanProperty$1(value);
    }
    /**Weither the card is of type wide. */
    set wide(value) {
        this._wide = coerceBooleanProperty$1(value);
    }
    /**Weither the card is of type info. */
    set info(value) {
        this._info = coerceBooleanProperty$1(value);
    }
    /**Weither the card is of type content. */
    set content(value) {
        this._content = coerceBooleanProperty$1(value);
    }
    /**Weither the card is active. */
    get hasActiveClass() {
        return this._active;
    }
    /**Weither the card is wide. */
    get hasWideClass() {
        return this._wide;
    }
    /**Weither the card is info. */
    get hasInfoClass() {
        return this._info;
    }
    /**Weither the card is content. */
    get hasContentClass() {
        return this._content;
    }
}
AxaCardComponent.ɵfac = function AxaCardComponent_Factory(t) { return new (t || AxaCardComponent)(); };
AxaCardComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaCardComponent, selectors: [["axa-card"]], hostVars: 10, hostBindings: function AxaCardComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-card", ctx.baseCls)("axa-card--active", ctx.hasActiveClass)("axa-card--wide", ctx.hasWideClass)("axa-card--info", ctx.hasInfoClass)("axa-card--content", ctx.hasContentClass);
    } }, inputs: { active: "active", wide: "wide", info: "info", content: "content" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaCardComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2, changeDetection: 0 });
AxaCardComponent.propDecorators = {
    baseCls: [{ type: HostBinding, args: [`class.${CLASS_BASE}`,] }],
    active: [{ type: Input, args: ['active',] }],
    wide: [{ type: Input, args: ['wide',] }],
    info: [{ type: Input, args: ['info',] }],
    content: [{ type: Input, args: ['content',] }],
    hasActiveClass: [{ type: HostBinding, args: [`class.${CLASS_ACTIVE}`,] }],
    hasWideClass: [{ type: HostBinding, args: [`class.${CLASS_WIDE}`,] }],
    hasInfoClass: [{ type: HostBinding, args: [`class.${CLASS_INFO}`,] }],
    hasContentClass: [{ type: HostBinding, args: [`class.${CLASS_CONTENT}`,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCardComponent, [{
        type: Component,
        args: [{
                selector: 'axa-card',
                template: "<ng-content></ng-content>",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { baseCls: [{
            type: HostBinding,
            args: [`class.${CLASS_BASE}`]
        }], active: [{
            type: Input,
            args: ['active']
        }], wide: [{
            type: Input,
            args: ['wide']
        }], info: [{
            type: Input,
            args: ['info']
        }], content: [{
            type: Input,
            args: ['content']
        }], hasActiveClass: [{
            type: HostBinding,
            args: [`class.${CLASS_ACTIVE}`]
        }], hasWideClass: [{
            type: HostBinding,
            args: [`class.${CLASS_WIDE}`]
        }], hasInfoClass: [{
            type: HostBinding,
            args: [`class.${CLASS_INFO}`]
        }], hasContentClass: [{
            type: HostBinding,
            args: [`class.${CLASS_CONTENT}`]
        }] }); })();
/**Directive of the card title. */
class AxaCardTitleDirective {
    constructor() {
        /**Base styling binding. */
        this.baseCls = true;
    }
    /**Weither the card is compact. */
    set compact(value) {
        this._compact = coerceBooleanProperty$1(value);
    }
    /**Weither the card is compact. */
    get hasCompactClass() {
        return this._compact;
    }
}
AxaCardTitleDirective.ɵfac = function AxaCardTitleDirective_Factory(t) { return new (t || AxaCardTitleDirective)(); };
AxaCardTitleDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaCardTitleDirective, selectors: [["axa-card-title"]], hostVars: 4, hostBindings: function AxaCardTitleDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-card__title", ctx.baseCls)("axa-card__block--compact", ctx.hasCompactClass);
    } }, inputs: { compact: "compact" } });
AxaCardTitleDirective.propDecorators = {
    baseCls: [{ type: HostBinding, args: [`class.${CLASS_TITLE}`,] }],
    compact: [{ type: Input, args: ['compact',] }],
    hasCompactClass: [{ type: HostBinding, args: [`class.${CLASS_BLOCK_COMPACT}`,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCardTitleDirective, [{
        type: Directive,
        args: [{
                selector: 'axa-card-title'
            }]
    }], function () { return []; }, { baseCls: [{
            type: HostBinding,
            args: [`class.${CLASS_TITLE}`]
        }], compact: [{
            type: Input,
            args: ['compact']
        }], hasCompactClass: [{
            type: HostBinding,
            args: [`class.${CLASS_BLOCK_COMPACT}`]
        }] }); })();
/**Directive for the card content. */
class AxaCardContentDirective {
    constructor() {
        /**Base styling binding. */
        this.baseCls = true;
    }
    /**Weither the card is compact. */
    set compact(value) {
        this._compact = coerceBooleanProperty$1(value);
    }
    /**Weither the card is compact. */
    get hasCompactClass() {
        return this._compact;
    }
}
AxaCardContentDirective.ɵfac = function AxaCardContentDirective_Factory(t) { return new (t || AxaCardContentDirective)(); };
AxaCardContentDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaCardContentDirective, selectors: [["axa-card-content"]], hostVars: 4, hostBindings: function AxaCardContentDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-card__block", ctx.baseCls)("axa-card__block--compact", ctx.hasCompactClass);
    } }, inputs: { compact: "compact" } });
AxaCardContentDirective.propDecorators = {
    baseCls: [{ type: HostBinding, args: [`class.${CLASS_BLOCK}`,] }],
    compact: [{ type: Input, args: ['compact',] }],
    hasCompactClass: [{ type: HostBinding, args: [`class.${CLASS_BLOCK_COMPACT}`,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCardContentDirective, [{
        type: Directive,
        args: [{
                selector: 'axa-card-content'
            }]
    }], function () { return []; }, { baseCls: [{
            type: HostBinding,
            args: [`class.${CLASS_BLOCK}`]
        }], compact: [{
            type: Input,
            args: ['compact']
        }], hasCompactClass: [{
            type: HostBinding,
            args: [`class.${CLASS_BLOCK_COMPACT}`]
        }] }); })();

class AxaCardModule {
}
AxaCardModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaCardModule });
AxaCardModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaCardModule_Factory(t) { return new (t || AxaCardModule)(); }, imports: [[
            CommonModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaCardModule, { declarations: function () { return [AxaCardComponent, AxaCardTitleDirective, AxaCardContentDirective]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaCardComponent, AxaCardTitleDirective, AxaCardContentDirective]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCardModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule
                ],
                declarations: [
                    AxaCardComponent,
                    AxaCardTitleDirective,
                    AxaCardContentDirective
                ],
                exports: [
                    AxaCardComponent,
                    AxaCardTitleDirective,
                    AxaCardContentDirective
                ]
            }]
    }], null, null); })();

/**
 * Generated unique id.
 */
let nextUniqueId$5 = 0;
/**Value Accessor provider to enable ngModel. */
const AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AxaCheckbox),
    multi: true
};
/**
 * Change event emitted by the AxaCheckbox.
 * @export
 */
class AxaCheckboxChange {
}
/**
 * An AXA styled checkbox.
 * @export
 */
class AxaCheckbox {
    constructor() {
        this._uniqueId = `axa-checkbox-${++nextUniqueId$5}`;
        /**
         * Element ID.
         */
        this.id = this._uniqueId;
        /**
         * Name of the control.
         */
        this.name = null;
        /** Used to set the 'aria-label' attribute on the underlying input element. */
        this.ariaLabel = '';
        /** The 'aria-labelledby' attribute takes precedence as the element's text alternative. */
        this.ariaLabelledby = null;
        this._checked = false;
        /**
         *Event emitted when the checked state changes.
         */
        this.change = new EventEmitter();
        /**
         * Implementation of the value accessor.
         */
        this.valueAccessorChange = () => { };
        /**
         * Implementation of the value accessor.
         */
        this.valueAccessorTouch = () => { };
    }
    /**
     * Returns the element id
     */
    get inputId() {
        return this.id;
    }
    /**
     * Whether the control is required.
     */
    get required() {
        return this._required;
    }
    set required(value) {
        this._required = coerceBooleanProperty$1(value);
    }
    /**
     *Whether the control is checked.
     */
    get checked() {
        return this._checked;
    }
    set checked(value) {
        this._checked = coerceBooleanProperty$1(value);
        this.valueAccessorChange(this._checked);
    }
    /**
     * Gets the aria value of the checked state.
     */
    getAriaChecked() {
        return this.checked ? 'true' : this.indeterminate ? 'mixed' : 'false';
    }
    /** Toggles the `checked` state of the checkbox. */
    toggle() {
        this.checked = !this.checked;
    }
    fireChangeEvent() {
        const event = new AxaCheckboxChange();
        event.source = this;
        event.checked = this.checked;
        this.valueAccessorChange(this.checked);
        this.change.emit(event);
    }
    /**
     * Handles the change event of the checkbox.
     */
    onInteractionEvent(event) {
        event.stopPropagation();
    }
    /**
     * Handles the click event of the checkbox.
     */
    onInputClick(event) {
        event.stopPropagation();
        this.toggle();
        this.fireChangeEvent();
    }
    /**
     * Implementation of the value accessor.
     */
    writeValue(value) {
        if (this._checked !== value) {
            this.checked = value;
        }
    }
    /**
     * Implementation of the value accessor.
     */
    registerOnChange(fn) {
        this.valueAccessorChange = fn;
    }
    /**
     * Implementation of the value accessor.
     */
    registerOnTouched(fn) {
        this.valueAccessorTouch = fn;
    }
    /**
     * Implementation of the value accessor.
     */
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
}
AxaCheckbox.ɵfac = function AxaCheckbox_Factory(t) { return new (t || AxaCheckbox)(); };
AxaCheckbox.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaCheckbox, selectors: [["axa-checkbox"]], inputs: { id: "id", name: "name", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], required: "required", checked: "checked", disabled: "disabled", value: "value", tabIndex: "tabIndex", indeterminate: "indeterminate" }, outputs: { change: "change" }, features: [ɵngcc0.ɵɵProvidersFeature([AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR])], ngContentSelectors: _c0, decls: 5, vars: 11, consts: [[1, "custom-control", "custom-checkbox"], ["type", "checkbox", 1, "custom-control-input", 3, "id", "required", "checked", "disabled", "tabIndex", "indeterminate", "change", "click"], [1, "custom-control-indicator"], [1, "custom-control-description"]], template: function AxaCheckbox_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "label", 0);
        ɵngcc0.ɵɵelementStart(1, "input", 1);
        ɵngcc0.ɵɵlistener("change", function AxaCheckbox_Template_input_change_1_listener($event) { return ctx.onInteractionEvent($event); })("click", function AxaCheckbox_Template_input_click_1_listener($event) { return ctx.onInputClick($event); });
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelement(2, "span", 2);
        ɵngcc0.ɵɵelementStart(3, "span", 3);
        ɵngcc0.ɵɵprojection(4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("id", ctx.inputId)("required", ctx.required)("checked", ctx.checked)("disabled", ctx.disabled)("tabIndex", ctx.tabIndex)("indeterminate", ctx.indeterminate);
        ɵngcc0.ɵɵattribute("value", ctx.value)("name", ctx.name)("aria-label", ctx.ariaLabel || null)("aria-labelledby", ctx.ariaLabelledby)("aria-checked", ctx.getAriaChecked());
    } }, encapsulation: 2 });
AxaCheckbox.propDecorators = {
    id: [{ type: Input }],
    required: [{ type: Input }],
    value: [{ type: Input }],
    disabled: [{ type: Input }],
    tabIndex: [{ type: Input }],
    name: [{ type: Input }],
    indeterminate: [{ type: Input }],
    ariaLabel: [{ type: Input, args: ['aria-label',] }],
    ariaLabelledby: [{ type: Input, args: ['aria-labelledby',] }],
    checked: [{ type: Input }],
    change: [{ type: Output }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCheckbox, [{
        type: Component,
        args: [{
                selector: 'axa-checkbox',
                template: "<label class=\"custom-control custom-checkbox\">\r\n    <input type=\"checkbox\"  class=\"custom-control-input\" \r\n    [id]=\"inputId\"\r\n    [required]=\"required\"\r\n    [checked]=\"checked\"\r\n    [attr.value]=\"value\"\r\n    [disabled]=\"disabled\"\r\n    [attr.name]=\"name\"\r\n    [tabIndex]=\"tabIndex\"\r\n    [indeterminate]=\"indeterminate\"\r\n    [attr.aria-label]=\"ariaLabel || null\"\r\n    [attr.aria-labelledby]=\"ariaLabelledby\"\r\n    [attr.aria-checked]=\"getAriaChecked()\"\r\n    (change)=\"onInteractionEvent($event)\"\r\n    (click)=\"onInputClick($event)\">\r\n    <span class=\"custom-control-indicator\"></span>\r\n    <span class=\"custom-control-description\">\r\n        <ng-content></ng-content>\r\n    </span>\r\n</label>",
                providers: [AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR]
            }]
    }], function () { return []; }, { id: [{
            type: Input
        }], name: [{
            type: Input
        }], ariaLabel: [{
            type: Input,
            args: ['aria-label']
        }], ariaLabelledby: [{
            type: Input,
            args: ['aria-labelledby']
        }], change: [{
            type: Output
        }], required: [{
            type: Input
        }], checked: [{
            type: Input
        }], disabled: [{
            type: Input
        }], value: [{
            type: Input
        }], tabIndex: [{
            type: Input
        }], indeterminate: [{
            type: Input
        }] }); })();

class AxaCheckboxModule {
}
AxaCheckboxModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaCheckboxModule });
AxaCheckboxModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaCheckboxModule_Factory(t) { return new (t || AxaCheckboxModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaCheckboxModule, { declarations: function () { return [AxaCheckbox]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaCheckbox]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCheckboxModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaCheckbox],
                declarations: [AxaCheckbox]
            }]
    }], null, null); })();

/**
 * Cookie message warning, that stores it's state in the local storage.
 * @export
 */
class AxaCookieMessage {
    constructor() {
        /**
         * Whether the cookie message was already closed.
         */
        this.closed = localStorage.getItem(COOKIE_STORAGE) === 'true';
    }
    /**
     * The close action.
     */
    close() {
        this.closed = true;
        localStorage.setItem(COOKIE_STORAGE, 'true');
    }
}
AxaCookieMessage.ɵfac = function AxaCookieMessage_Factory(t) { return new (t || AxaCookieMessage)(); };
AxaCookieMessage.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaCookieMessage, selectors: [["axa-cookie-message"]], inputs: { legalMessage: "legalMessage", closeMessage: "closeMessage" }, decls: 1, vars: 1, consts: [["class", "alert axa-top-content-bar axa-top-content-bar--corporate cookie-message", "role", "alert", 4, "ngIf"], ["role", "alert", 1, "alert", "axa-top-content-bar", "axa-top-content-bar--corporate", "cookie-message"], [1, "axa-top-content-bar__content", 3, "innerHTML"], ["axa-button", "", "neg", "", "small", "", 3, "click"]], template: function AxaCookieMessage_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵtemplate(0, AxaCookieMessage_div_0_Template, 4, 2, "div", 0);
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngIf", !ctx.closed);
    } }, directives: [ɵngcc2.NgIf, AxaButton], styles: [".cookie-message[_ngcontent-%COMP%] {\n        z-index: 1000000;\n        position: fixed;\n        width: 100%;\n        left: 0;\n        bottom: 0;\n        margin: 0;\n      }"] });
AxaCookieMessage.propDecorators = {
    legalMessage: [{ type: Input }],
    closeMessage: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCookieMessage, [{
        type: Component,
        args: [{
                selector: 'axa-cookie-message',
                template: `
    <div *ngIf="!closed" class="alert axa-top-content-bar axa-top-content-bar--corporate cookie-message" role="alert">
        <div class="axa-top-content-bar__content" [innerHTML]="legalMessage"></div>
        <a axa-button neg small (click)="close()" >
            {{ closeMessage }}
        </a>
    </div>
`,
                styles: [`
    .cookie-message {
        z-index: 1000000;
        position: fixed;
        width: 100%;
        left: 0;
        bottom: 0;
        margin: 0;
      }
    `]
            }]
    }], function () { return []; }, { legalMessage: [{
            type: Input
        }], closeMessage: [{
            type: Input
        }] }); })();
/**Key for the stored cookie state. */
const COOKIE_STORAGE = 'axa-cookie.closed';

class AxaCookieMessageModule {
}
AxaCookieMessageModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaCookieMessageModule });
AxaCookieMessageModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaCookieMessageModule_Factory(t) { return new (t || AxaCookieMessageModule)(); }, imports: [[CommonModule, AxaButtonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaCookieMessageModule, { declarations: function () { return [AxaCookieMessage]; }, imports: function () { return [CommonModule, AxaButtonModule]; }, exports: function () { return [AxaCookieMessage]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCookieMessageModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, AxaButtonModule],
                exports: [AxaCookieMessage],
                declarations: [AxaCookieMessage]
            }]
    }], null, null); })();

/**Unique ID generated for phone inputs. */
let nextUniqueId$6 = 0;
/**Value Accessor provider to enable ngModel. */
const AXA_DATECOMBOPICKER_CONTROL_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AxaDateComboPicker),
    multi: true
};
/**@ignore */
class AxaDateComboBase {
    constructor(_defaultErrorStateMatcher, cdr, _parentForm, _parentFormGroup, ngControl) {
        this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
        this.cdr = cdr;
        this._parentForm = _parentForm;
        this._parentFormGroup = _parentFormGroup;
        this.ngControl = ngControl;
    }
}
/**@ignore */
const _AxaDateComboBase = mixinParentErrorState(AxaDateComboBase);
/**Date picker control. */
class AxaDateComboPicker extends _AxaDateComboBase {
    /**
     *Creates an instance of AxaDateComboPicker.
     * @param ngControl The underlying ngControl.
     * @param parentForm the parent form
     * @param parentFormGroup the parent formgroup
     * @param defaultErrorStateMatcher the errorstatematcher that will be used
     * @param cdr The change detector.
     * @param el The element ref.
     */
    constructor(ngControl, parentForm, parentFormGroup, defaultErrorStateMatcher, cdr, el) {
        super(defaultErrorStateMatcher, cdr, parentForm, parentFormGroup, ngControl);
        this.ngControl = ngControl;
        this.parentForm = parentForm;
        this.parentFormGroup = parentFormGroup;
        this.cdr = cdr;
        this._uniqueId = `axa-datecombopicker-${++nextUniqueId$6}`;
        /**
         * Stream that emits when the errorState of the control changes.
         */
        this.errorStateChanges = new Subject();
        /**
         * Whether the control is focused.
         */
        this.focused = false;
        this._required = false;
        this._disabled = false;
        this._readonly = false;
        this.generateRange = (start, end) => {
            const array = new Array();
            for (let i = start; i <= end; i++) {
                array.push(i);
            }
            return array;
        };
        /**
          * Implementation of the value accessor.
          */
        this.valueAccessorChange = () => { };
        this.id = this.id;
        this.host = el.nativeElement;
        // Setting the value accessor directly (instead of using
        // the providers) to avoid running into a circular import.
        if (this.ngControl != null) {
            this.ngControl.valueAccessor = this;
        }
    }
    /**
     * Element ID.
     */
    get id() { return this._id; }
    set id(value) { this._id = value || this._uniqueId; }
    /**
     * Whether the control is required.
     */
    get required() { return this._required; }
    set required(value) { this._required = coerceBooleanProperty$1(value); }
    /**
     * Whether the control is disabled.
     */
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty$1(value);
        if (this.focused) {
            this.focused = false;
        }
    }
    /**
     * Whether the control is readonly.
     */
    get readonly() { return this._readonly; }
    set readonly(value) { this._readonly = coerceBooleanProperty$1(value); }
    /**The selected day. */
    get selectedDay() {
        return this._selectedDay;
    }
    set selectedDay(value) {
        this._selectedDay = value;
        this.updateSelectedDate();
    }
    /**The selected month. */
    get selectedMonth() {
        return this._selectedMonth;
    }
    set selectedMonth(value) {
        this._selectedMonth = value;
        this.adaptDayList();
        this.updateSelectedDate();
    }
    /**The selected year. */
    get selectedYear() {
        return this._selectedYear;
    }
    set selectedYear(value) {
        if ((this._minDate && value < this._minDate.getFullYear())
            || (this._maxDate && value > this._maxDate.getFullYear())) {
            value = null;
        }
        this._selectedYear = value;
        this.adaptDayList();
        this.adaptMonthList();
        this.updateSelectedDate();
    }
    /**The selected Date. */
    get value() {
        return this._value;
    }
    set value(value) {
        this._value = value;
    }
    get minDate() {
        return this._minDate;
    }
    set minDate(minDate) {
        this._minDate = minDate;
        this.validateSelectedDate();
    }
    /**The latest date that is selectable. */
    get maxDate() {
        return this._maxDate;
    }
    set maxDate(maxDate) {
        this._maxDate = maxDate;
        this.validateSelectedDate();
    }
    validateSelectedDate() {
        if (this.value < this._minDate || this.value > this._maxDate) {
            this._selectedYear = null;
            this._selectedMonth = null;
            this._selectedDay = null;
        }
        this.adaptDayList();
        this.adaptMonthList();
        this.adaptYearList();
        this.updateSelectedDate();
    }
    ngOnInit() {
        // this.ngControl = this._injector.get(NgControl);
        this.adaptDayList();
        this.adaptMonthList();
        this.adaptYearList();
    }
    ngOnDestroy() {
        this.unMonitorChildrenControls();
    }
    ngAfterViewInit() {
        this.childrenControls = this.axaSelects;
        this.monitorChildrenControls();
    }
    /**Returns the number of days in current month. */
    daysInMonth(month, year) {
        return new Date(year, month, 0).getDate();
    }
    /**Adapts the day list depending on the month and year. */
    adaptDayList() {
        let maxRange = 31;
        let minRange = 1;
        if (Number(this._selectedMonth) > 0 && Number(this._selectedYear) > 0) {
            // calulate max range of days if current selected month and year are the same or earlier than the maxDate
            if (this._maxDate
                && Number(this._selectedYear) === this._maxDate.getFullYear()
                && Number(this._selectedMonth) >= this._maxDate.getMonth() + 1) {
                // clear day if it is earlier than the maxDate
                if (this._selectedDay > this.maxDate.getDate()) {
                    this.selectedDay = null;
                }
                maxRange = this._maxDate.getDate();
            }
            else {
                maxRange = this.daysInMonth(this._selectedMonth, this._selectedYear);
            }
            // calulate min range of days if current selected month and year are the same or earlier than the minDate
            if (this._minDate
                && Number(this._selectedYear) === this._minDate.getFullYear()
                && Number(this._selectedMonth) <= this._minDate.getMonth() + 1) {
                // clear day if it is earlier than the minDate
                if (this._selectedDay < this.minDate.getDate()) {
                    this.selectedDay = null;
                }
                minRange = this._minDate.getDate();
            }
        }
        // clear day if it is greater than the number of days that exist on the month
        if (maxRange < this._selectedDay) {
            this.selectedDay = null;
        }
        this.days = this.generateRange(minRange, maxRange);
    }
    /**Adapts the month list depending on the year. */
    adaptMonthList() {
        let maxRange = 12;
        let minRange = 1;
        if (Number(this._selectedYear) > 0) {
            // calulate max range of months if current selected year is the same as of the maxDate
            if (this._maxDate
                && Number(this._selectedYear) === this._maxDate.getFullYear()) {
                // clear month and day if month is later than the maxDate
                if (this._selectedMonth > this.maxDate.getMonth() + 1) {
                    this.selectedMonth = null;
                    this.selectedDay = null;
                }
                maxRange = this._maxDate.getMonth() + 1;
            }
            // calulate min range of months if current selected year is the same as of the minDate
            if (this._minDate
                && Number(this._selectedYear) === this._minDate.getFullYear()) {
                // clear month and day if month is earlier than the maxDate
                if (this._selectedMonth < this._minDate.getMonth() + 1) {
                    this.selectedMonth = null;
                    this.selectedDay = null;
                }
                minRange = this.minDate.getMonth() + 1;
            }
        }
        this.months = this.generateRange(minRange, maxRange);
    }
    /**Adapts the year list depending on the allowed range. */
    adaptYearList() {
        this.years = this.generateRange(this._minDate ? this._minDate.getFullYear() : 1900, this._maxDate ? this._maxDate.getFullYear() : 2050);
    }
    /**
     * Focuses the input.
     */
    focus() {
        this.host.focus();
    }
    updateSelectedDate() {
        const previousValue = this._value;
        if (Number(this._selectedDay) > 0 && Number(this._selectedMonth) > 0 && Number(this._selectedYear) > 0 &&
            Number.isInteger(+this._selectedDay) && Number.isInteger(+this._selectedMonth) && Number.isInteger(+this._selectedYear)) {
            this.value = new Date(this._selectedYear, this._selectedMonth - 1, this._selectedDay);
        }
        else {
            this.value = null;
        }
        if (previousValue !== this._value) {
            this.valueAccessorChange(this.value);
        }
    }
    /**
     * Implementation of the value accessor.
     */
    writeValue(newValue) {
        this.value = newValue;
        if (newValue) {
            this.selectedDay = newValue.getDate();
            this.selectedMonth = newValue.getMonth() + 1;
            this.selectedYear = newValue.getFullYear();
        }
        else {
            this.selectedYear = null;
            this.selectedMonth = null;
            this.selectedDay = null;
            this.cdr.markForCheck();
        }
    }
    /**
     * Implementation of the value accessor.
     */
    registerOnChange(fn) {
        this.valueAccessorChange = (value) => { Promise.resolve(null).then(() => fn(value)); };
    }
    /**
     * Implementation of the value accessor.
     */
    registerOnTouched(fn) {
        this.valueAccessorTouch = fn;
    }
    /**
     * Implementation of the value accessor.
     */
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
}
AxaDateComboPicker.ɵfac = function AxaDateComboPicker_Factory(t) { return new (t || AxaDateComboPicker)(ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgControl, 10), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgForm, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.FormGroupDirective, 8), ɵngcc0.ɵɵdirectiveInject(ErrorStateMatcher), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaDateComboPicker.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaDateComboPicker, selectors: [["axa-datecombopicker"]], viewQuery: function AxaDateComboPicker_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵviewQuery(AxaSelect, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.axaSelects = _t);
    } }, hostVars: 1, hostBindings: function AxaDateComboPicker_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
    } }, inputs: { id: "id", required: "required", disabled: "disabled", readonly: "readonly", minDate: "minDate", maxDate: "maxDate", days: "days", months: "months", years: "years", placeholder: "placeholder", name: "name" }, features: [ɵngcc0.ɵɵProvidersFeature([{ provide: AxaFormFieldControl, useExisting: AxaDateComboPicker }]), ɵngcc0.ɵɵInheritDefinitionFeature], decls: 12, vars: 12, consts: [["axaSelect", "", 1, "datepicker", 3, "ngModel", "required", "disabled", "ngModelChange"], [3, "ngValue", 4, "ngFor", "ngForOf"], [3, "ngValue"]], template: function AxaDateComboPicker_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div");
        ɵngcc0.ɵɵelementStart(1, "select", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaDateComboPicker_Template_select_ngModelChange_1_listener($event) { return ctx.selectedDay = $event; });
        ɵngcc0.ɵɵelement(2, "option");
        ɵngcc0.ɵɵtemplate(3, AxaDateComboPicker_option_3_Template, 2, 2, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtext(4, " / ");
        ɵngcc0.ɵɵelementStart(5, "select", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaDateComboPicker_Template_select_ngModelChange_5_listener($event) { return ctx.selectedMonth = $event; });
        ɵngcc0.ɵɵelement(6, "option");
        ɵngcc0.ɵɵtemplate(7, AxaDateComboPicker_option_7_Template, 2, 2, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtext(8, " / ");
        ɵngcc0.ɵɵelementStart(9, "select", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaDateComboPicker_Template_select_ngModelChange_9_listener($event) { return ctx.selectedYear = $event; });
        ɵngcc0.ɵɵelement(10, "option");
        ɵngcc0.ɵɵtemplate(11, AxaDateComboPicker_option_11_Template, 2, 2, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngModel", ctx.selectedDay)("required", ctx.required)("disabled", ctx.disabled);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.days);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngModel", ctx.selectedMonth)("required", ctx.required)("disabled", ctx.disabled);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.months);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngModel", ctx.selectedYear)("required", ctx.required)("disabled", ctx.disabled);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.years);
    } }, directives: [ɵngcc1.SelectControlValueAccessor, AxaSelect, ɵngcc1.NgControlStatus, ɵngcc1.NgModel, ɵngcc1.RequiredValidator, ɵngcc1.NgSelectOption, ɵngcc1.ɵangular_packages_forms_forms_x, ɵngcc2.NgForOf], styles: [".datepicker[_ngcontent-%COMP%]{display:inline;width:108px}"], changeDetection: 0 });
AxaDateComboPicker.ctorParameters = () => [
    { type: NgControl, decorators: [{ type: Optional }, { type: Self }] },
    { type: NgForm, decorators: [{ type: Optional }] },
    { type: FormGroupDirective, decorators: [{ type: Optional }] },
    { type: ErrorStateMatcher },
    { type: ChangeDetectorRef },
    { type: ElementRef }
];
AxaDateComboPicker.propDecorators = {
    id: [{ type: Input }],
    placeholder: [{ type: Input }],
    name: [{ type: Input }],
    required: [{ type: Input }],
    disabled: [{ type: Input }],
    readonly: [{ type: Input }],
    days: [{ type: Input }],
    months: [{ type: Input }],
    years: [{ type: Input }],
    axaSelects: [{ type: ViewChildren, args: [AxaSelect,] }],
    minDate: [{ type: Input }],
    maxDate: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaDateComboPicker, [{
        type: Component,
        args: [{
                selector: 'axa-datecombopicker',
                host: {
                    '[attr.id]': 'id'
                },
                template: "<div>\r\n  <select class=\"datepicker\" axaSelect [(ngModel)]=\"selectedDay\" [required]=\"required\" [disabled]=\"disabled\">\r\n    <option></option>\r\n    <option *ngFor=\"let day of days\"  [ngValue]=\"day\">{{day}}</option>\r\n  </select> / <select class=\"datepicker\" axaSelect [(ngModel)]=\"selectedMonth\" [required]=\"required\" [disabled]=\"disabled\">\r\n    <option></option>\r\n    <option *ngFor=\"let month of months\"  [ngValue]=\"month\">{{month}}</option>\r\n  </select> / <select class=\"datepicker\" axaSelect [(ngModel)]=\"selectedYear\" [required]=\"required\" [disabled]=\"disabled\">\r\n    <option></option>\r\n    <option *ngFor=\"let year of years\"  [ngValue]=\"year\">{{year}}</option>\r\n  </select>\r\n</div>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush,
                providers: [{ provide: AxaFormFieldControl, useExisting: AxaDateComboPicker }],
                styles: [".datepicker{display:inline;width:108px}"]
            }]
    }], function () { return [{ type: ɵngcc1.NgControl, decorators: [{
                type: Optional
            }, {
                type: Self
            }] }, { type: ɵngcc1.NgForm, decorators: [{
                type: Optional
            }] }, { type: ɵngcc1.FormGroupDirective, decorators: [{
                type: Optional
            }] }, { type: ErrorStateMatcher }, { type: ɵngcc0.ChangeDetectorRef }, { type: ɵngcc0.ElementRef }]; }, { id: [{
            type: Input
        }], required: [{
            type: Input
        }], disabled: [{
            type: Input
        }], readonly: [{
            type: Input
        }], minDate: [{
            type: Input
        }], maxDate: [{
            type: Input
        }], days: [{
            type: Input
        }], months: [{
            type: Input
        }], years: [{
            type: Input
        }], placeholder: [{
            type: Input
        }], name: [{
            type: Input
        }], axaSelects: [{
            type: ViewChildren,
            args: [AxaSelect]
        }] }); })();

class AxaDateComboPickerModule {
}
AxaDateComboPickerModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaDateComboPickerModule });
AxaDateComboPickerModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaDateComboPickerModule_Factory(t) { return new (t || AxaDateComboPickerModule)(); }, providers: [], imports: [[CommonModule, FormsModule, AxaSelectModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaDateComboPickerModule, { declarations: function () { return [AxaDateComboPicker]; }, imports: function () { return [CommonModule, FormsModule, AxaSelectModule]; }, exports: function () { return [AxaDateComboPicker]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaDateComboPickerModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, FormsModule, AxaSelectModule],
                exports: [AxaDateComboPicker],
                declarations: [AxaDateComboPicker],
                providers: []
            }]
    }], null, null); })();

/**
 * Defines all the flags icons available in the toolkit.
 * Takes care of applying the styles to a button.
 */
class AxaFlagIcon {
    /**
     * Creates an instance of AxaFlagIcon.
     * @param el
     * ElementRef to modify styles.
     */
    constructor(el) {
        this.el = el;
        this._country = 'be';
        this.host = el.nativeElement;
        this.addDefaultStyles('be');
    }
    /**Applies country styling. */
    set country(country) {
        this.addDefaultStyles(country || 'be');
    }
    addDefaultStyles(country) {
        this.host.className = `axa-flag axa-flag--${country}`;
    }
}
AxaFlagIcon.ɵfac = function AxaFlagIcon_Factory(t) { return new (t || AxaFlagIcon)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaFlagIcon.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaFlagIcon, selectors: [["", "axa-flag-icon", ""]], inputs: { country: "country" } });
AxaFlagIcon.ctorParameters = () => [
    { type: ElementRef }
];
AxaFlagIcon.propDecorators = {
    country: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFlagIcon, [{
        type: Directive,
        args: [{
                selector: `[axa-flag-icon]`
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { country: [{
            type: Input
        }] }); })();

class AxaFlagIconModule {
}
AxaFlagIconModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaFlagIconModule });
AxaFlagIconModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaFlagIconModule_Factory(t) { return new (t || AxaFlagIconModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaFlagIconModule, { declarations: function () { return [AxaFlagIcon]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaFlagIcon]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFlagIconModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                declarations: [AxaFlagIcon],
                exports: [AxaFlagIcon]
            }]
    }], null, null); })();

/**Component to display icons. */
class IconComponent {
    /**
     * Creates an instance of IconComponent.
     * @param el
     * ElementRef to modify styles.
     */
    constructor(el) {
        this.el = el;
        this.host = el.nativeElement;
        this.host.classList.add('axa-icon');
    }
    /**Gets the path of the icon. */
    getPath() {
        return `./assets/icons.svg#${this.name}`;
    }
}
IconComponent.ɵfac = function IconComponent_Factory(t) { return new (t || IconComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
IconComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: IconComponent, selectors: [["axa-icon"]], inputs: { name: "name" }, decls: 2, vars: 1, consts: [["focusable", "false"]], template: function IconComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵnamespaceSVG();
        ɵngcc0.ɵɵelementStart(0, "svg", 0);
        ɵngcc0.ɵɵelement(1, "use");
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵattribute("href", ctx.getPath(), null, "xlink");
    } }, encapsulation: 2, changeDetection: 0 });
IconComponent.ctorParameters = () => [
    { type: ElementRef }
];
IconComponent.propDecorators = {
    name: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(IconComponent, [{
        type: Component,
        args: [{
                selector: 'axa-icon',
                template: "<svg focusable=\"false\">\r\n    <use [attr.xlink:href]=\"getPath()\"></use>\r\n</svg>",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { name: [{
            type: Input
        }] }); })();

class AxaIconModule {
}
AxaIconModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaIconModule });
AxaIconModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaIconModule_Factory(t) { return new (t || AxaIconModule)(); }, imports: [[]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaIconModule, { declarations: [IconComponent], exports: [IconComponent] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaIconModule, [{
        type: NgModule,
        args: [{
                exports: [
                    IconComponent
                ],
                imports: [],
                declarations: [
                    IconComponent
                ]
            }]
    }], null, null); })();

/**Component to display list items in the footer. */
class AxaFooterListComponent {
    constructor() {
        /**Default style of the step. */
        this.cls = true;
    }
}
AxaFooterListComponent.ɵfac = function AxaFooterListComponent_Factory(t) { return new (t || AxaFooterListComponent)(); };
AxaFooterListComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaFooterListComponent, selectors: [["", "axa-footer-list", ""]], hostVars: 2, hostBindings: function AxaFooterListComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-footer__main__quarter", ctx.cls);
    } }, inputs: { title: "title" }, attrs: _c4, ngContentSelectors: _c0, decls: 5, vars: 1, consts: [[1, "axa-footer__main__quarter"], [1, "axa-footer__main__title"], [1, "axa-footer__main__links"]], template: function AxaFooterListComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelementStart(1, "h1", 1);
        ɵngcc0.ɵɵtext(2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "ul", 2);
        ɵngcc0.ɵɵprojection(4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵtextInterpolate(ctx.title);
    } }, encapsulation: 2, changeDetection: 0 });
AxaFooterListComponent.propDecorators = {
    title: [{ type: Input }],
    cls: [{ type: HostBinding, args: [`class.axa-footer__main__quarter`,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterListComponent, [{
        type: Component,
        args: [{
                selector: '[axa-footer-list]',
                template: "<div class=\"axa-footer__main__quarter\">\r\n  <h1 class=\"axa-footer__main__title\">{{title}}</h1>\r\n  <ul class=\"axa-footer__main__links\">\r\n    <ng-content></ng-content>\r\n  </ul>\r\n</div>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: [`class.axa-footer__main__quarter`]
        }], title: [{
            type: Input
        }] }); })();

/**Component to display social items in the footer. */
class AxaFooterSocialComponent {
    constructor() {
        /**Default style of the step. */
        this.cls = true;
    }
}
AxaFooterSocialComponent.ɵfac = function AxaFooterSocialComponent_Factory(t) { return new (t || AxaFooterSocialComponent)(); };
AxaFooterSocialComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaFooterSocialComponent, selectors: [["", "axa-footer-social", ""]], hostVars: 2, hostBindings: function AxaFooterSocialComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-footer__main__quarter", ctx.cls);
    } }, inputs: { title: "title" }, attrs: _c5, ngContentSelectors: _c0, decls: 5, vars: 1, consts: [[1, "axa-footer__main__quarter"], [1, "axa-footer__main__title"], [1, "axa-footer__main__social"]], template: function AxaFooterSocialComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelementStart(1, "h1", 1);
        ɵngcc0.ɵɵtext(2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "ul", 2);
        ɵngcc0.ɵɵprojection(4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵtextInterpolate(ctx.title);
    } }, encapsulation: 2, changeDetection: 0 });
AxaFooterSocialComponent.propDecorators = {
    title: [{ type: Input }],
    cls: [{ type: HostBinding, args: [`class.axa-footer__main__quarter`,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterSocialComponent, [{
        type: Component,
        args: [{
                selector: '[axa-footer-social]',
                template: "<div class=\"axa-footer__main__quarter\">\r\n  <h1 class=\"axa-footer__main__title\">{{title}}</h1>\r\n  <ul class=\"axa-footer__main__social\">\r\n    <ng-content></ng-content>\r\n  </ul>\r\n</div>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: [`class.axa-footer__main__quarter`]
        }], title: [{
            type: Input
        }] }); })();

/**Default style. */
const FOOTER_CLASS_BASE = 'axa-footer';

/**Component to generate the footer. */
class AxaFooterComponent {
    constructor() {
        /**Whether the legal is shown. */
        this.showLegal = true;
        /**Text used for the legal information. */
        this.legalText = `Policy privacy © ${new Date().getFullYear()} AXA all rights reserved`;
        /**Whether the languages are shown */
        this.showLanguages = true;
        /**Default style for the footer. */
        this.cls = FOOTER_CLASS_BASE;
    }
}
AxaFooterComponent.ɵfac = function AxaFooterComponent_Factory(t) { return new (t || AxaFooterComponent)(); };
AxaFooterComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaFooterComponent, selectors: [["axa-footer"]], contentQueries: function AxaFooterComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaFooterListComponent, false);
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaFooterSocialComponent, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.lists = _t);
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.social = _t);
    } }, hostVars: 2, hostBindings: function AxaFooterComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, inputs: { showLegal: "showLegal", legalText: "legalText", showLanguages: "showLanguages" }, ngContentSelectors: _c7, decls: 5, vars: 3, consts: [["axa-footer", "", 1, "content-wrapper"], ["class", "axa-footer__main", 4, "ngIf"], [1, "axa-footer__bottom"], ["class", "axa-footer__bottom__language", 4, "ngIf"], ["class", "axa-footer__bottom__legal", 4, "ngIf"], [1, "axa-footer__main"], [1, "axa-footer__bottom__language"], [1, "axa-footer__bottom__legal"]], template: function AxaFooterComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c6);
        ɵngcc0.ɵɵelementStart(0, "footer", 0);
        ɵngcc0.ɵɵtemplate(1, AxaFooterComponent_div_1_Template, 3, 0, "div", 1);
        ɵngcc0.ɵɵelementStart(2, "div", 2);
        ɵngcc0.ɵɵtemplate(3, AxaFooterComponent_div_3_Template, 2, 0, "div", 3);
        ɵngcc0.ɵɵtemplate(4, AxaFooterComponent_div_4_Template, 2, 1, "div", 4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngIf", ctx.lists && ctx.lists.length > 0 || ctx.social && ctx.social.length > 0);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngIf", ctx.showLanguages);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngIf", ctx.showLegal);
    } }, directives: [ɵngcc2.NgIf], encapsulation: 2, changeDetection: 0 });
AxaFooterComponent.propDecorators = {
    showLegal: [{ type: Input }],
    legalText: [{ type: Input }],
    showLanguages: [{ type: Input }],
    cls: [{ type: HostBinding, args: ['class',] }],
    lists: [{ type: ContentChildren, args: [AxaFooterListComponent,] }],
    social: [{ type: ContentChildren, args: [AxaFooterSocialComponent,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterComponent, [{
        type: Component,
        args: [{
                selector: 'axa-footer',
                template: "<footer axa-footer class=\"content-wrapper\">\r\n  <div *ngIf=\"(lists && lists.length > 0) || (social && social.length > 0)\" class=\"axa-footer__main\">\r\n    <ng-content select=\"[axa-footer-list]\">\r\n    </ng-content>\r\n\r\n    <ng-content select=\"[axa-footer-social]\">\r\n    </ng-content>\r\n  </div>\r\n  <div class=\"axa-footer__bottom\">\r\n    <div *ngIf=\"showLanguages\" class=\"axa-footer__bottom__language\">\r\n      <ng-content select=\"[AxaFooterLanguage]\"></ng-content>\r\n    </div>\r\n    <div *ngIf=\"showLegal\" class=\"axa-footer__bottom__legal\">\r\n      {{legalText}}\r\n    </div>\r\n  </div>\r\n</footer>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { showLegal: [{
            type: Input
        }], legalText: [{
            type: Input
        }], showLanguages: [{
            type: Input
        }], cls: [{
            type: HostBinding,
            args: ['class']
        }], lists: [{
            type: ContentChildren,
            args: [AxaFooterListComponent]
        }], social: [{
            type: ContentChildren,
            args: [AxaFooterSocialComponent]
        }] }); })();

/**Directive to mark the links associated with languages. */
class AxaFooterLanguage {
}
AxaFooterLanguage.ɵfac = function AxaFooterLanguage_Factory(t) { return new (t || AxaFooterLanguage)(); };
AxaFooterLanguage.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaFooterLanguage, selectors: [["a", "AxaFooterLanguage", ""]] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterLanguage, [{
        type: Directive,
        args: [{ selector: 'a[AxaFooterLanguage]' }]
    }], null, null); })();

class AxaFooterModule {
}
AxaFooterModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaFooterModule });
AxaFooterModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaFooterModule_Factory(t) { return new (t || AxaFooterModule)(); }, providers: [], imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaFooterModule, { declarations: function () { return [AxaFooterComponent, AxaFooterListComponent, AxaFooterSocialComponent, AxaFooterLanguage]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaFooterComponent, AxaFooterListComponent, AxaFooterSocialComponent, AxaFooterLanguage]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaFooterComponent, AxaFooterListComponent, AxaFooterSocialComponent, AxaFooterLanguage],
                declarations: [AxaFooterComponent, AxaFooterListComponent, AxaFooterSocialComponent, AxaFooterLanguage],
                providers: []
            }]
    }], null, null); })();

/**The step provided by the user. */
class AxaStepComponent {
    constructor() {
        this.labelChange = new EventEmitter();
    }
    /**The label of the step. */
    set label(value) {
        if (this._label !== value) {
            this._label = value;
            this.labelChange.emit(this._label);
        }
    }
    get label() {
        return this._label;
    }
    /**Weither this is a pricing step. */
    set pricing(value) {
        this._pricing = coerceBooleanProperty$1(value);
    }
    get pricing() {
        return this._pricing;
    }
}
AxaStepComponent.ɵfac = function AxaStepComponent_Factory(t) { return new (t || AxaStepComponent)(); };
AxaStepComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaStepComponent, selectors: [["axa-step"]], viewQuery: function AxaStepComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵstaticViewQuery(TemplateRef, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.content = _t.first);
    } }, inputs: { label: "label", pricing: "pricing", type: "type" }, outputs: { labelChange: "labelChange" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaStepComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵtemplate(0, AxaStepComponent_ng_template_0_Template, 1, 0, "ng-template");
    } }, encapsulation: 2, changeDetection: 0 });
AxaStepComponent.propDecorators = {
    content: [{ type: ViewChild, args: [TemplateRef, { static: true },] }],
    type: [{ type: Input }],
    label: [{ type: Input }],
    labelChange: [{ type: Output }],
    pricing: [{ type: Input, args: ['pricing',] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaStepComponent, [{
        type: Component,
        args: [{
                selector: 'axa-step',
                template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { labelChange: [{
            type: Output
        }], label: [{
            type: Input
        }], pricing: [{
            type: Input,
            args: ['pricing']
        }], content: [{
            type: ViewChild,
            args: [TemplateRef, { static: true }]
        }], type: [{
            type: Input
        }] }); })();

/**Default stepper style. */
const CLASS_BASE$1 = 'axa-form-steps';
/**Wrapper style. */
const CLASS_WRAPPER = `${CLASS_BASE$1}__wrapper`;
/**Step style. */
const CLASS_STEP = `${CLASS_BASE$1}__step`;
/**Pricing step style. */
const CLASS_STEP_PRICING = `${CLASS_BASE$1}--pricing`;
/**progress bar style. */
const CLASS_PROGRESS = `${CLASS_STEP}__progress`;
/**Active step style. */
const CLASS_STEP_ACTIVE = `${CLASS_STEP}--active`;
/**Done step style. */
const CLASS_STEP_DONE = `${CLASS_STEP}--done`;

/**
 *Step generated at runtime to display progress.
 */
class AxaStepHeaderComponent {
    constructor(cdr) {
        this.cdr = cdr;
        /**Default style of the step. */
        this.cls = true;
        /**Active style of the step. */
        this.active = false;
        /**Done style of the step. */
        this.done = false;
    }
    /**The step. */
    get step() {
        return this._step;
    }
    set step(step) {
        this._step = step;
        this.subToLabelChange();
    }
    /**Pricing style of the step. */
    get pricingClass() {
        return this._pricing;
    }
    /**Weither this is a pricing step. */
    get pricing() {
        return this._pricing;
    }
    set pricing(value) {
        this._pricing = coerceBooleanProperty$1(value);
    }
    ngOnDestroy() {
        this._labelSub.unsubscribe();
    }
    subToLabelChange() {
        this._labelSub = this._step.labelChange.subscribe((newLabel) => {
            this.label = newLabel;
            this.cdr.markForCheck();
        });
    }
    /**Gets the progress of the step. */
    getWidth() {
        let pc = 0;
        if (this.done) {
            pc = 100;
        }
        else if (this.active) {
            pc = 30;
        }
        return `${pc}%`;
    }
    /**Gets the label of the step. */
    getLabel() {
        if (this.label !== undefined) {
            return this.label;
        }
        return null;
    }
    /**Gets the progress class of the step. */
    getProgressClass() {
        return `${CLASS_PROGRESS}`;
    }
}
AxaStepHeaderComponent.ɵfac = function AxaStepHeaderComponent_Factory(t) { return new (t || AxaStepHeaderComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef)); };
AxaStepHeaderComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaStepHeaderComponent, selectors: [["axa-step-header"]], hostVars: 8, hostBindings: function AxaStepHeaderComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-form-steps__step", ctx.cls)("axa-form-steps__step--active", ctx.active)("axa-form-steps__step--done", ctx.done)("axa-form-steps--pricing", ctx.pricingClass);
    } }, inputs: { active: "active", done: "done", step: "step", pricing: "pricing", label: "label", type: "type" }, ngContentSelectors: _c0, decls: 6, vars: 3, consts: [["class", "axa-form-steps--pricing__icon", 4, "ngIf"], [1, "axa-form-steps__step__content"], [3, "class", "width", 4, "ngIf"], [1, "axa-form-steps--pricing__icon"], ["viewBox", "0 0 24 24", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M15 18.5c-2.51 0-4.68-1.42-5.76-3.5H15v-2H8.58c-.05-.33-.08-.66-.08-1s.03-.67.08-1H15V9H9.24C10.32 6.92 12.5 5.5 15 5.5c1.61 0 3.09.59 4.23 1.57L21 5.3C19.41 3.87 17.3 3 15 3c-3.92 0-7.24 2.51-8.48 6H3v2h3.06c-.04.33-.06.66-.06 1 0 .34.02.67.06 1H3v2h3.52c1.24 3.49 4.56 6 8.48 6 2.31 0 4.41-.87 6-2.3l-1.78-1.77c-1.13.98-2.6 1.57-4.22 1.57z"], ["d", "M0 0h24v24H0z", "fill", "none"]], template: function AxaStepHeaderComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵtemplate(0, AxaStepHeaderComponent_span_0_Template, 4, 0, "span", 0);
        ɵngcc0.ɵɵelementStart(1, "span", 1);
        ɵngcc0.ɵɵtext(2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "span", 1);
        ɵngcc0.ɵɵtemplate(4, AxaStepHeaderComponent_ng_template_4_Template, 1, 0, "ng-template");
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtemplate(5, AxaStepHeaderComponent_div_5_Template, 1, 4, "div", 2);
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngIf", ctx.pricing);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵtextInterpolate(ctx.getLabel());
        ɵngcc0.ɵɵadvance(3);
        ɵngcc0.ɵɵproperty("ngIf", !ctx.pricing);
    } }, directives: [ɵngcc2.NgIf], encapsulation: 2, changeDetection: 0 });
AxaStepHeaderComponent.ctorParameters = () => [
    { type: ChangeDetectorRef }
];
AxaStepHeaderComponent.propDecorators = {
    type: [{ type: Input }],
    step: [{ type: Input }],
    label: [{ type: Input }],
    cls: [{ type: HostBinding, args: [`class.${CLASS_STEP}`,] }],
    active: [{ type: Input }, { type: HostBinding, args: [`class.${CLASS_STEP_ACTIVE}`,] }],
    done: [{ type: Input }, { type: HostBinding, args: [`class.${CLASS_STEP_DONE}`,] }],
    pricingClass: [{ type: HostBinding, args: [`class.${CLASS_STEP_PRICING}`,] }],
    pricing: [{ type: Input, args: ['pricing',] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaStepHeaderComponent, [{
        type: Component,
        args: [{
                selector: 'axa-step-header',
                template: "<span class=\"axa-form-steps--pricing__icon\" *ngIf=\"pricing\">\r\n  <svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\r\n      <path d=\"M15 18.5c-2.51 0-4.68-1.42-5.76-3.5H15v-2H8.58c-.05-.33-.08-.66-.08-1s.03-.67.08-1H15V9H9.24C10.32 6.92 12.5 5.5 15 5.5c1.61 0 3.09.59 4.23 1.57L21 5.3C19.41 3.87 17.3 3 15 3c-3.92 0-7.24 2.51-8.48 6H3v2h3.06c-.04.33-.06.66-.06 1 0 .34.02.67.06 1H3v2h3.52c1.24 3.49 4.56 6 8.48 6 2.31 0 4.41-.87 6-2.3l-1.78-1.77c-1.13.98-2.6 1.57-4.22 1.57z\"\r\n      />\r\n      <path d=\"M0 0h24v24H0z\" fill=\"none\" />\r\n  </svg>\r\n</span>\r\n<span class=\"axa-form-steps__step__content\">{{ getLabel() }}</span>\r\n<span class=\"axa-form-steps__step__content\">\r\n  <ng-template>\r\n      <ng-content></ng-content>\r\n  </ng-template>\r\n</span>\r\n\r\n<div [class]=\"getProgressClass()\" [style.width]=\"getWidth()\" *ngIf=\"!pricing\"></div>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc0.ChangeDetectorRef }]; }, { cls: [{
            type: HostBinding,
            args: [`class.${CLASS_STEP}`]
        }], active: [{
            type: Input
        }, {
            type: HostBinding,
            args: [`class.${CLASS_STEP_ACTIVE}`]
        }], done: [{
            type: Input
        }, {
            type: HostBinding,
            args: [`class.${CLASS_STEP_DONE}`]
        }], step: [{
            type: Input
        }], pricingClass: [{
            type: HostBinding,
            args: [`class.${CLASS_STEP_PRICING}`]
        }], pricing: [{
            type: Input,
            args: ['pricing']
        }], label: [{
            type: Input
        }], type: [{
            type: Input
        }] }); })();

/**
 *Stepper control to display forms in a workflow format.
 */
class AxaStepperComponent {
    /**The current step. */
    get current() {
        return this._current;
    }
    set current(value) {
        this._current = value;
    }
    /**Gets the wrapper class. */
    getWrapperClass() {
        return `${CLASS_WRAPPER}`;
    }
    /**Gets the active step. */
    getActive(index) {
        return index === this.current - 1;
    }
    /**Gets the done steps. */
    getDone(index) {
        return index < this.current - 1;
    }
    /**Gets the default style. */
    getClass() {
        return `${CLASS_BASE$1}`;
    }
    /**Gets the transform of the view. */
    getTransform() {
        const translate = -100 * this._current - 1;
        return `translate3d(${translate}%, 0, 0)`;
    }
}
AxaStepperComponent.ɵfac = function AxaStepperComponent_Factory(t) { return new (t || AxaStepperComponent)(); };
AxaStepperComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaStepperComponent, selectors: [["axa-stepper"]], contentQueries: function AxaStepperComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaStepComponent, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.steps = _t);
    } }, viewQuery: function AxaStepperComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵviewQuery(AxaStepHeaderComponent, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.stepHeaders = _t);
    } }, inputs: { current: "current" }, decls: 5, vars: 8, consts: [[4, "ngFor", "ngForOf"], [3, "step", "label", "pricing", "active", "done"], [1, "axa-form-steps-content"], [3, "ngTemplateOutlet"]], template: function AxaStepperComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div");
        ɵngcc0.ɵɵelementStart(1, "div");
        ɵngcc0.ɵɵtemplate(2, AxaStepperComponent_ng_container_2_Template, 2, 5, "ng-container", 0);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "div");
        ɵngcc0.ɵɵtemplate(4, AxaStepperComponent_ng_container_4_Template, 3, 2, "ng-container", 0);
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.getClass());
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵclassMap(ctx.getWrapperClass());
        ɵngcc0.ɵɵstyleProp("transform", ctx.getTransform());
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.steps);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.steps);
    } }, directives: [ɵngcc2.NgForOf, AxaStepHeaderComponent, ɵngcc2.NgTemplateOutlet], encapsulation: 2, changeDetection: 0 });
AxaStepperComponent.propDecorators = {
    current: [{ type: Input }],
    steps: [{ type: ContentChildren, args: [AxaStepComponent,] }],
    stepHeaders: [{ type: ViewChildren, args: [AxaStepHeaderComponent,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaStepperComponent, [{
        type: Component,
        args: [{
                selector: 'axa-stepper',
                template: "<div [class]=\"getClass()\">\r\n  <div [class]=\"getWrapperClass()\" [style.transform]=\"getTransform()\">\r\n      <ng-container *ngFor=\"let step of steps; let i = index;\">\r\n          <axa-step-header [step]=\"step\" [label]=\"step.label\" [pricing]=\"step.pricing\" [active]=\"getActive(i)\" [done]=\"getDone(i)\">\r\n          </axa-step-header>\r\n      </ng-container>\r\n  </div>\r\n</div>\r\n<div>\r\n  <ng-container *ngFor=\"let step of steps; let i = index;\">\r\n      <div class=\"axa-form-steps-content\" [attr.aria-expanded]=\"getActive(i)\">\r\n          <ng-container [ngTemplateOutlet]=\"step.content\"></ng-container>\r\n      </div>\r\n  </ng-container>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], null, { current: [{
            type: Input
        }], steps: [{
            type: ContentChildren,
            args: [AxaStepComponent]
        }], stepHeaders: [{
            type: ViewChildren,
            args: [AxaStepHeaderComponent]
        }] }); })();

class AxaStepperModule {
}
AxaStepperModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaStepperModule });
AxaStepperModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaStepperModule_Factory(t) { return new (t || AxaStepperModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaStepperModule, { declarations: function () { return [AxaStepperComponent, AxaStepComponent, AxaStepHeaderComponent]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaStepperComponent, AxaStepComponent]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaStepperModule, [{
        type: NgModule,
        args: [{
                exports: [
                    AxaStepperComponent,
                    AxaStepComponent
                ],
                declarations: [
                    AxaStepperComponent,
                    AxaStepComponent,
                    AxaStepHeaderComponent
                ],
                imports: [CommonModule]
            }]
    }], null, null); })();

/**Default style. */
const HEADER_CLASS_BASE = 'axa-header';
/**Meta domain style. */
const HEADER_CLASS_META_DOMAIN = `${HEADER_CLASS_BASE}__meta__domain__link`;
/**Meta helper style. */
const HEADER_CLASS_META_HELPER = `${HEADER_CLASS_BASE}__meta__helper__link`;
/**search button style. */
const HEADER_CLASS_SEARCH = `${HEADER_CLASS_BASE}__search`;
/**Navigation link style. */
const HEADER_CLASS_NAV_LINK = `${HEADER_CLASS_BASE}__nav__link`;
/**Active navigation link style. */
const HEADER_CLASS_NAV_LINK_ACTIVE = `${HEADER_CLASS_NAV_LINK}--active`;
/**Button navigation link style. */
const HEADER_CLASS_NAV_LINK_BUTTON = `${HEADER_CLASS_NAV_LINK}--button`;

/**The meta domain link in the header. */
class AxaHeaderMetaDomainDirective {
    constructor() {
        /**Default styling of domain link. */
        this.cls = HEADER_CLASS_META_DOMAIN;
    }
}
AxaHeaderMetaDomainDirective.ɵfac = function AxaHeaderMetaDomainDirective_Factory(t) { return new (t || AxaHeaderMetaDomainDirective)(); };
AxaHeaderMetaDomainDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaHeaderMetaDomainDirective, selectors: [["axa-header-meta-domain"]], hostVars: 2, hostBindings: function AxaHeaderMetaDomainDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } } });
AxaHeaderMetaDomainDirective.propDecorators = {
    cls: [{ type: HostBinding, args: [`class`,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderMetaDomainDirective, [{
        type: Directive,
        args: [{
                selector: 'axa-header-meta-domain'
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: [`class`]
        }] }); })();
/**The meta helper link in the header. */
class AxaHeaderMetaHelperDirective {
    constructor() {
        /**Default styling of helper link. */
        this.cls = HEADER_CLASS_META_HELPER;
    }
}
AxaHeaderMetaHelperDirective.ɵfac = function AxaHeaderMetaHelperDirective_Factory(t) { return new (t || AxaHeaderMetaHelperDirective)(); };
AxaHeaderMetaHelperDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaHeaderMetaHelperDirective, selectors: [["axa-header-meta-helper"]], hostVars: 2, hostBindings: function AxaHeaderMetaHelperDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } } });
AxaHeaderMetaHelperDirective.propDecorators = {
    cls: [{ type: HostBinding, args: [`class`,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderMetaHelperDirective, [{
        type: Directive,
        args: [{
                selector: 'axa-header-meta-helper'
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: [`class`]
        }] }); })();

/**Component to generate the navigation bar */
class AxaHeaderComponent {
    constructor(headerEl) {
        this.headerEl = headerEl;
        /**Default style for the header. */
        this.cls = HEADER_CLASS_BASE;
        this.navToggleValue = false;
        /**Unique id for the header. */
        this.uuid = this.guid();
    }
    /**Whether any domain is provided. */
    hasDomains() {
        return this._domains.length > 0;
    }
    /**Whether any helper is provided. */
    hasHelpers() {
        return this._helpers.length > 0;
    }
    /**Whether any meta is provided. */
    hasMeta() {
        return this._domains.length > 0 || this._helpers.length > 0;
    }
    guid() {
        const s4 = () => {
            return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        };
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
    }
    ngOnInit() {
        const navs = this._navigateEl.nativeElement.children;
        for (let navIdx = 0; navIdx < navs.length; navIdx++) {
            navs[navIdx].onclick = () => {
                this.navToggleValue = false;
            };
        }
    }
    clickout(event) {
        if (!this.headerEl.nativeElement.contains(event.target)) {
            this.navToggleValue = false;
        }
    }
}
AxaHeaderComponent.ɵfac = function AxaHeaderComponent_Factory(t) { return new (t || AxaHeaderComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaHeaderComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaHeaderComponent, selectors: [["axa-header"]], contentQueries: function AxaHeaderComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaHeaderMetaDomainDirective, false);
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaHeaderMetaHelperDirective, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx._domains = _t);
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx._helpers = _t);
    } }, viewQuery: function AxaHeaderComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵstaticViewQuery(_c8, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx._navigateEl = _t.first);
    } }, hostVars: 2, hostBindings: function AxaHeaderComponent_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("click", function AxaHeaderComponent_click_HostBindingHandler($event) { return ctx.clickout($event); }, false, ɵngcc0.ɵɵresolveDocument);
    } if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, ngContentSelectors: _c10, decls: 24, vars: 5, consts: [["type", "checkbox", 1, "axa-header__toggle__input", 3, "id", "ngModel", "ngModelChange"], [1, "axa-header__toggle", 3, "for"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 0 24 24", 1, "axa-header__toggle__close"], ["d", "M0,0H24V24H0Z", "fill", "none"], ["d", "M4.31,21a1.25,1.25,0,0,1-.92-.38,1.3,1.3,0,0,1,0-1.84L18.77,3.39a1.3,1.3,0,0,1,1.84,1.84L5.23,20.61A1.29,1.29,0,0,1,4.31,21Z"], ["d", "M9.63,10.93a1.29,1.29,0,0,1-.92-.38L3.39,5.23A1.3,1.3,0,0,1,5.23,3.39l5.32,5.32a1.3,1.3,0,0,1,0,1.84A1.33,1.33,0,0,1,9.63,10.93Z"], ["d", "M19.69,21a1.29,1.29,0,0,1-.92-.38l-5.28-5.28a1.3,1.3,0,0,1,1.84-1.84l5.28,5.28a1.3,1.3,0,0,1,0,1.84A1.25,1.25,0,0,1,19.69,21Z"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 0 24 24", 1, "axa-header__toggle__open"], ["d", "M0 0h24v24H0z", "fill", "none"], ["d", "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"], [1, "axa-header__toggle--bg", 3, "for"], [1, "axa-header__wrapper"], ["class", "axa-header__meta", 4, "ngIf"], [1, "axa-header__main"], [1, "axa-header__main__logo"], ["preserveAspectRatio", "xMinYMin meet", "viewBox", "0 0 512 512", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M320.667 253.814l-37.712-.1L480.678.008 511.425 0 320.667 253.814z", "fill", "#ff1721"], ["d", "M298.442 354.484c15.66-19.294 28.628-36.51 33.912-45.023l2.087-3.36.163 4.485c.09 2.466.373 5.445.63 6.62.628 2.86 3.673 12.924 7.843 25.92 1.883 5.87 3.49 10.98 3.57 11.358l.146.686h-48.907l.556-.686zM210.752 409.708c-2.757-8.54-3.97-12.712-3.797-13.057.435-.866 12.09-15.865 12.328-15.865.124 0 .67 1.338 1.21 2.973 1.885 5.698 5.696 16.41 6.62 18.61l.93 2.214-1.69 2.358c-5.074 7.083-11.175 15.317-11.35 15.317-.108 0-2.02-5.647-4.25-12.55zM101.462 354.79c.162-.21 3.035-3.813 6.384-8.006 8.2-10.27 16.55-21.16 21.075-27.5 3.84-5.374 8.305-12.172 8.305-12.64 0-.146.137-.265.304-.265.185 0 .304 1.358.304 3.466 0 1.906.21 4.685.466 6.175.515 2.992 3.335 12.51 8.404 28.365 1.83 5.725 3.328 10.494 3.328 10.597 0 .103-10.995.188-24.433.188-19.5 0-24.374-.077-24.138-.38z", "fill", "#00008f"], ["d", "M511.695 511.91S.315 511.82.203 511.708C.09 511.597 0 459.46 0 459.46h10.978c10.07 0 11.017-.044 11.453-.533.263-.294 1.6-2.35 2.975-4.572 3.387-5.476 9.006-13.483 12.564-17.904 2.948-3.664 15.66-20.205 34.223-44.535l10.004-13.112h75.58l3.746 12.96 4.34 15.022.59 2.062L160.17 417c-19.426 25.198-22.406 28.796-29.935 36.147-3.44 3.36-5.21 5.3-5.145 5.64.092.482 1.41.527 17.88.6 9.78.043 17.964-.026 18.185-.153.222-.127 1.458-2.324 2.75-4.882 2.455-4.866 4.923-8.578 10.05-15.117 1.687-2.15 3.22-4.106 3.406-4.345.185-.24.42-.435.52-.435.187 0 2.267 6.425 3.663 11.31.412 1.442 1.13 4.92 1.596 7.73.484 2.93 1.028 5.294 1.273 5.538.356.357 3.418.427 18.542.427h18.116l.42-.686c.233-.377 1.436-2.603 2.676-4.947 1.24-2.343 3.304-5.667 4.586-7.386 3.32-4.45 9.142-11.155 9.434-10.86.694.698 3.738 12.02 4.69 17.445.624 3.56 1.198 6.017 1.44 6.17.454.29 45.677.366 46.423.08.264-.102.482-.35.482-.55 0-.198-1.18-2.482-2.624-5.074-5.554-9.973-5.155-8.908-15.953-42.562-2.697-8.407-4.904-15.448-4.904-15.646 0-.198 2.62-4.058 5.82-8.578l5.818-8.216 38.01.077 38.01.078 5.578 17.99c8.252 26.62 13.137 42.647 13.954 45.784.92 3.537 1.638 8.354 1.884 12.658.13 2.274.333 3.502.624 3.794.364.363 4.12.43 24.17.43 13.056 0 23.956-.083 24.22-.185.703-.27.61-.603-.615-2.197-2.235-2.91-5.89-11.374-10.44-24.19-2.66-7.483-8.313-24.683-15.914-48.417-2.71-8.454-5.33-16.476-5.83-17.827-1.722-4.673-24.928-85.657-25.394-88.624-.25-1.595-.605-4.34-.788-6.1-.184-1.76-.405-3.442-.492-3.735-.15-.5-1.33-.534-19.178-.534h-19.02l-1.336 2.822c-1.76 3.71-6.486 11.835-9.002 15.476-6.745 9.757-59.662 79.577-60.024 79.196-.265-.28-5.607-19.293-5.5-19.574.126-.327 11.45-14.763 37.675-48.035 12.288-15.59 18.12-22.302 23.18-26.682 1.357-1.174 2.467-2.374 2.467-2.668 0-.503-1.127-.534-19.51-.534h-19.51l-.152.687c-.084.377-.296 1.535-.473 2.574-.716 4.192-2.022 6.913-5.536 11.53-5.666 7.447-29.763 37.773-30.114 37.9-.132.048-.822-2.01-1.533-4.574-2.1-7.568-7.45-26.462-9.276-32.76-1.615-5.568-2.128-8.51-2.41-13.83l-.072-1.373-23.16-.078c-14.18-.048-23.27.033-23.444.21-.18.178.23 1.294 1.094 2.974 3.646 7.09 5.36 11.892 16.697 46.766 6.228 19.162 11.264 35.07 11.19 35.354-.22.836-11.903 15.582-12.148 15.33-.608-.625-25.192-81.055-25.746-84.23-.248-1.42-.73-5.4-1.073-8.845-.343-3.444-.686-6.57-.764-6.948l-.142-.686H129.403l-4.147 8.31c-2.28 4.57-5.182 10.044-6.446 12.164-2.886 4.837-21.25 29.448-47.754 63.996-5.468 7.128-13.017 17.008-16.776 21.956-14.306 18.833-27.67 35.965-42.676 54.712-5.627 7.03-10.535 13.136-10.907 13.57l-.675.788L0 0h481.946S429.63 68.322 324.52 204.315c-20.327 26.298-36.958 48.067-36.958 48.374 0 .32.29.636.686.74.9.243 27.924.24 28.825 0 .734-.197 1.177-.765 42.004-53.78 12.723-16.522 26.304-34.155 30.182-39.186C405.642 139.204 511.276.16 511.424 0l.27 511.91z", "fill", "#00008f"], [1, "axa-header__nav"], ["navs", ""], [1, "axa-header__tools"], [1, "axa-header__meta"], [1, "axa-header__meta__container"], ["class", "axa-header__meta__domain", 4, "ngIf"], ["class", "axa-header__meta__helper", 4, "ngIf"], [1, "axa-header__meta__domain"], [1, "axa-header__meta__helper"]], template: function AxaHeaderComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c9);
        ɵngcc0.ɵɵelementStart(0, "input", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaHeaderComponent_Template_input_ngModelChange_0_listener($event) { return ctx.navToggleValue = $event; });
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(1, "label", 1);
        ɵngcc0.ɵɵnamespaceSVG();
        ɵngcc0.ɵɵelementStart(2, "svg", 2);
        ɵngcc0.ɵɵelement(3, "path", 3);
        ɵngcc0.ɵɵelement(4, "path", 4);
        ɵngcc0.ɵɵelement(5, "path", 5);
        ɵngcc0.ɵɵelement(6, "path", 6);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(7, "svg", 7);
        ɵngcc0.ɵɵelement(8, "path", 8);
        ɵngcc0.ɵɵelement(9, "path", 9);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵnamespaceHTML();
        ɵngcc0.ɵɵelement(10, "label", 10);
        ɵngcc0.ɵɵelementStart(11, "div", 11);
        ɵngcc0.ɵɵtemplate(12, AxaHeaderComponent_div_12_Template, 4, 2, "div", 12);
        ɵngcc0.ɵɵelementStart(13, "div", 13);
        ɵngcc0.ɵɵelementStart(14, "div", 14);
        ɵngcc0.ɵɵnamespaceSVG();
        ɵngcc0.ɵɵelementStart(15, "svg", 15);
        ɵngcc0.ɵɵelement(16, "path", 16);
        ɵngcc0.ɵɵelement(17, "path", 17);
        ɵngcc0.ɵɵelement(18, "path", 18);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵnamespaceHTML();
        ɵngcc0.ɵɵelementStart(19, "nav", 19, 20);
        ɵngcc0.ɵɵprojection(21);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(22, "div", 21);
        ɵngcc0.ɵɵprojection(23, 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵpropertyInterpolate1("id", "axa-header__toggle", ctx.uuid, "");
        ɵngcc0.ɵɵproperty("ngModel", ctx.navToggleValue);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵpropertyInterpolate1("for", "axa-header__toggle", ctx.uuid, "");
        ɵngcc0.ɵɵadvance(9);
        ɵngcc0.ɵɵpropertyInterpolate1("for", "axa-header__toggle", ctx.uuid, "");
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngIf", ctx.hasMeta());
    } }, directives: [ɵngcc1.CheckboxControlValueAccessor, ɵngcc1.NgControlStatus, ɵngcc1.NgModel, ɵngcc2.NgIf], encapsulation: 2, changeDetection: 0 });
AxaHeaderComponent.ctorParameters = () => [
    { type: ElementRef }
];
AxaHeaderComponent.propDecorators = {
    cls: [{ type: HostBinding, args: ['class',] }],
    _domains: [{ type: ContentChildren, args: [AxaHeaderMetaDomainDirective,] }],
    _helpers: [{ type: ContentChildren, args: [AxaHeaderMetaHelperDirective,] }],
    _navigateEl: [{ type: ViewChild, args: ['navs', { static: true },] }],
    clickout: [{ type: HostListener, args: ['document:click', ['$event'],] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderComponent, [{
        type: Component,
        args: [{
                selector: 'axa-header',
                template: "<input class=\"axa-header__toggle__input\" type=\"checkbox\" id=\"axa-header__toggle{{uuid}}\" [(ngModel)]=\"navToggleValue\" />\r\n<label class=\"axa-header__toggle\" for=\"axa-header__toggle{{uuid}}\">\r\n  <svg class=\"axa-header__toggle__close\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\r\n    <path d=\"M0,0H24V24H0Z\" fill=\"none\" />\r\n    <path d=\"M4.31,21a1.25,1.25,0,0,1-.92-.38,1.3,1.3,0,0,1,0-1.84L18.77,3.39a1.3,1.3,0,0,1,1.84,1.84L5.23,20.61A1.29,1.29,0,0,1,4.31,21Z\"\r\n    />\r\n    <path d=\"M9.63,10.93a1.29,1.29,0,0,1-.92-.38L3.39,5.23A1.3,1.3,0,0,1,5.23,3.39l5.32,5.32a1.3,1.3,0,0,1,0,1.84A1.33,1.33,0,0,1,9.63,10.93Z\"\r\n    />\r\n    <path d=\"M19.69,21a1.29,1.29,0,0,1-.92-.38l-5.28-5.28a1.3,1.3,0,0,1,1.84-1.84l5.28,5.28a1.3,1.3,0,0,1,0,1.84A1.25,1.25,0,0,1,19.69,21Z\"\r\n    />\r\n  </svg>\r\n\r\n  <svg class=\"axa-header__toggle__open\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\r\n    <path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\r\n    <path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path>\r\n  </svg>\r\n</label>\r\n<label class=\"axa-header__toggle--bg\" for=\"axa-header__toggle{{uuid}}\"></label>\r\n<div class=\"axa-header__wrapper\">\r\n  <div class=\"axa-header__meta\" *ngIf=\"hasMeta()\">\r\n    <div class=\"axa-header__meta__container\">\r\n      <nav class=\"axa-header__meta__domain\" *ngIf=\"hasDomains()\">\r\n        <ng-content select=\"axa-header-meta-domain\"></ng-content>\r\n      </nav>\r\n      <nav class=\"axa-header__meta__helper\" *ngIf=\"hasHelpers()\">\r\n        <ng-content select=\"axa-header-meta-helper\"></ng-content>\r\n      </nav>\r\n    </div>\r\n  </div>\r\n  <div class=\"axa-header__main\">\r\n    <div class=\"axa-header__main__logo\">\r\n      <svg preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 512 512\" xmlns=\"http://www.w3.org/2000/svg\">\r\n        <path d=\"M320.667 253.814l-37.712-.1L480.678.008 511.425 0 320.667 253.814z\" fill=\"#ff1721\"></path>\r\n        <path d=\"M298.442 354.484c15.66-19.294 28.628-36.51 33.912-45.023l2.087-3.36.163 4.485c.09 2.466.373 5.445.63 6.62.628 2.86 3.673 12.924 7.843 25.92 1.883 5.87 3.49 10.98 3.57 11.358l.146.686h-48.907l.556-.686zM210.752 409.708c-2.757-8.54-3.97-12.712-3.797-13.057.435-.866 12.09-15.865 12.328-15.865.124 0 .67 1.338 1.21 2.973 1.885 5.698 5.696 16.41 6.62 18.61l.93 2.214-1.69 2.358c-5.074 7.083-11.175 15.317-11.35 15.317-.108 0-2.02-5.647-4.25-12.55zM101.462 354.79c.162-.21 3.035-3.813 6.384-8.006 8.2-10.27 16.55-21.16 21.075-27.5 3.84-5.374 8.305-12.172 8.305-12.64 0-.146.137-.265.304-.265.185 0 .304 1.358.304 3.466 0 1.906.21 4.685.466 6.175.515 2.992 3.335 12.51 8.404 28.365 1.83 5.725 3.328 10.494 3.328 10.597 0 .103-10.995.188-24.433.188-19.5 0-24.374-.077-24.138-.38z\"\r\n          fill=\"#00008f\"></path>\r\n        <path d=\"M511.695 511.91S.315 511.82.203 511.708C.09 511.597 0 459.46 0 459.46h10.978c10.07 0 11.017-.044 11.453-.533.263-.294 1.6-2.35 2.975-4.572 3.387-5.476 9.006-13.483 12.564-17.904 2.948-3.664 15.66-20.205 34.223-44.535l10.004-13.112h75.58l3.746 12.96 4.34 15.022.59 2.062L160.17 417c-19.426 25.198-22.406 28.796-29.935 36.147-3.44 3.36-5.21 5.3-5.145 5.64.092.482 1.41.527 17.88.6 9.78.043 17.964-.026 18.185-.153.222-.127 1.458-2.324 2.75-4.882 2.455-4.866 4.923-8.578 10.05-15.117 1.687-2.15 3.22-4.106 3.406-4.345.185-.24.42-.435.52-.435.187 0 2.267 6.425 3.663 11.31.412 1.442 1.13 4.92 1.596 7.73.484 2.93 1.028 5.294 1.273 5.538.356.357 3.418.427 18.542.427h18.116l.42-.686c.233-.377 1.436-2.603 2.676-4.947 1.24-2.343 3.304-5.667 4.586-7.386 3.32-4.45 9.142-11.155 9.434-10.86.694.698 3.738 12.02 4.69 17.445.624 3.56 1.198 6.017 1.44 6.17.454.29 45.677.366 46.423.08.264-.102.482-.35.482-.55 0-.198-1.18-2.482-2.624-5.074-5.554-9.973-5.155-8.908-15.953-42.562-2.697-8.407-4.904-15.448-4.904-15.646 0-.198 2.62-4.058 5.82-8.578l5.818-8.216 38.01.077 38.01.078 5.578 17.99c8.252 26.62 13.137 42.647 13.954 45.784.92 3.537 1.638 8.354 1.884 12.658.13 2.274.333 3.502.624 3.794.364.363 4.12.43 24.17.43 13.056 0 23.956-.083 24.22-.185.703-.27.61-.603-.615-2.197-2.235-2.91-5.89-11.374-10.44-24.19-2.66-7.483-8.313-24.683-15.914-48.417-2.71-8.454-5.33-16.476-5.83-17.827-1.722-4.673-24.928-85.657-25.394-88.624-.25-1.595-.605-4.34-.788-6.1-.184-1.76-.405-3.442-.492-3.735-.15-.5-1.33-.534-19.178-.534h-19.02l-1.336 2.822c-1.76 3.71-6.486 11.835-9.002 15.476-6.745 9.757-59.662 79.577-60.024 79.196-.265-.28-5.607-19.293-5.5-19.574.126-.327 11.45-14.763 37.675-48.035 12.288-15.59 18.12-22.302 23.18-26.682 1.357-1.174 2.467-2.374 2.467-2.668 0-.503-1.127-.534-19.51-.534h-19.51l-.152.687c-.084.377-.296 1.535-.473 2.574-.716 4.192-2.022 6.913-5.536 11.53-5.666 7.447-29.763 37.773-30.114 37.9-.132.048-.822-2.01-1.533-4.574-2.1-7.568-7.45-26.462-9.276-32.76-1.615-5.568-2.128-8.51-2.41-13.83l-.072-1.373-23.16-.078c-14.18-.048-23.27.033-23.444.21-.18.178.23 1.294 1.094 2.974 3.646 7.09 5.36 11.892 16.697 46.766 6.228 19.162 11.264 35.07 11.19 35.354-.22.836-11.903 15.582-12.148 15.33-.608-.625-25.192-81.055-25.746-84.23-.248-1.42-.73-5.4-1.073-8.845-.343-3.444-.686-6.57-.764-6.948l-.142-.686H129.403l-4.147 8.31c-2.28 4.57-5.182 10.044-6.446 12.164-2.886 4.837-21.25 29.448-47.754 63.996-5.468 7.128-13.017 17.008-16.776 21.956-14.306 18.833-27.67 35.965-42.676 54.712-5.627 7.03-10.535 13.136-10.907 13.57l-.675.788L0 0h481.946S429.63 68.322 324.52 204.315c-20.327 26.298-36.958 48.067-36.958 48.374 0 .32.29.636.686.74.9.243 27.924.24 28.825 0 .734-.197 1.177-.765 42.004-53.78 12.723-16.522 26.304-34.155 30.182-39.186C405.642 139.204 511.276.16 511.424 0l.27 511.91z\"\r\n          fill=\"#00008f\"></path>\r\n      </svg>\r\n    </div>\r\n\r\n    <nav class=\"axa-header__nav\" #navs>\r\n      <ng-content select=\"axa-header-nav, axa-header-nav-route\"></ng-content>\r\n    </nav>\r\n\r\n    <div class=\"axa-header__tools\">\r\n      <ng-content select=\"axa-header-search\"></ng-content>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { cls: [{
            type: HostBinding,
            args: ['class']
        }], clickout: [{
            type: HostListener,
            args: ['document:click', ['$event']]
        }], _domains: [{
            type: ContentChildren,
            args: [AxaHeaderMetaDomainDirective]
        }], _helpers: [{
            type: ContentChildren,
            args: [AxaHeaderMetaHelperDirective]
        }], _navigateEl: [{
            type: ViewChild,
            args: ['navs', { static: true }]
        }] }); })();

/**Navigation element of the header. */
class AxaHeaderNavComponent {
    constructor() {
        /**Default style for the the header nav. */
        this.cls = true;
    }
    /**Active state of the navigation element. */
    set active(value) {
        this._active = coerceBooleanProperty$1(value);
    }
    /**Styling for the active state. */
    get activeClass() {
        return (this._active) ? 'disabled' : null;
    }
    /**Styling for the button state. */
    get buttonClass() {
        return typeof this.button !== 'undefined';
    }
}
AxaHeaderNavComponent.ɵfac = function AxaHeaderNavComponent_Factory(t) { return new (t || AxaHeaderNavComponent)(); };
AxaHeaderNavComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaHeaderNavComponent, selectors: [["axa-header-nav"]], hostVars: 6, hostBindings: function AxaHeaderNavComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-header__nav__link", ctx.cls)("axa-header__nav__link--active", ctx.activeClass)("axa-header__nav__link--button", ctx.buttonClass);
    } }, inputs: { active: "active", link: "link", button: "button" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaHeaderNavComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2, changeDetection: 0 });
AxaHeaderNavComponent.propDecorators = {
    cls: [{ type: HostBinding, args: [`class.${HEADER_CLASS_NAV_LINK}`,] }],
    link: [{ type: Input }],
    button: [{ type: Input }],
    active: [{ type: Input, args: ['active',] }],
    activeClass: [{ type: HostBinding, args: [`class.${HEADER_CLASS_NAV_LINK_ACTIVE}`,] }],
    buttonClass: [{ type: HostBinding, args: [`class.${HEADER_CLASS_NAV_LINK_BUTTON}`,] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderNavComponent, [{
        type: Component,
        args: [{
                selector: 'axa-header-nav',
                template: "<ng-content></ng-content>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: [`class.${HEADER_CLASS_NAV_LINK}`]
        }], active: [{
            type: Input,
            args: ['active']
        }], activeClass: [{
            type: HostBinding,
            args: [`class.${HEADER_CLASS_NAV_LINK_ACTIVE}`]
        }], buttonClass: [{
            type: HostBinding,
            args: [`class.${HEADER_CLASS_NAV_LINK_BUTTON}`]
        }], link: [{
            type: Input
        }], button: [{
            type: Input
        }] }); })();

/**
 *The search element of the header.
 * @export
 */
class AxaHeaderSearchComponent {
    constructor() {
        /**Default styling of the search element. */
        this.cls = true;
        /**Event that happens when the search is triggered. */
        this.search = new EventEmitter();
    }
    /**Emits the search event. */
    onSubmit() {
        this.search.emit(this.headerSearchValue);
    }
}
AxaHeaderSearchComponent.ɵfac = function AxaHeaderSearchComponent_Factory(t) { return new (t || AxaHeaderSearchComponent)(); };
AxaHeaderSearchComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaHeaderSearchComponent, selectors: [["axa-header-search"]], hostVars: 2, hostBindings: function AxaHeaderSearchComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-header__search", ctx.cls);
    } }, inputs: { placeholder: "placeholder" }, outputs: { search: "search" }, decls: 7, vars: 3, consts: [[1, "axa-header__search__wrapper", 3, "ngSubmit"], ["headerSearchForm", "ngForm"], ["type", "text", "name", "fld_header_search", 1, "axa-header__search__input", 3, "placeholder", "ngModel", "ngModelChange"], ["type", "submit", 1, "axa-header__search__btn", 3, "disabled"], ["title", "search", "viewBox", "0 0 24 24", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"], ["d", "M0 0h24v24H0z", "fill", "none"]], template: function AxaHeaderSearchComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "form", 0, 1);
        ɵngcc0.ɵɵlistener("ngSubmit", function AxaHeaderSearchComponent_Template_form_ngSubmit_0_listener() { return ctx.onSubmit(); });
        ɵngcc0.ɵɵelementStart(2, "input", 2);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaHeaderSearchComponent_Template_input_ngModelChange_2_listener($event) { return ctx.headerSearchValue = $event; });
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "button", 3);
        ɵngcc0.ɵɵnamespaceSVG();
        ɵngcc0.ɵɵelementStart(4, "svg", 4);
        ɵngcc0.ɵɵelement(5, "path", 5);
        ɵngcc0.ɵɵelement(6, "path", 6);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        const _r0 = ɵngcc0.ɵɵreference(1);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵpropertyInterpolate("placeholder", ctx.placeholder);
        ɵngcc0.ɵɵproperty("ngModel", ctx.headerSearchValue);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("disabled", !_r0.form.valid);
    } }, directives: [ɵngcc1.ɵangular_packages_forms_forms_y, ɵngcc1.NgControlStatusGroup, ɵngcc1.NgForm, ɵngcc1.DefaultValueAccessor, ɵngcc1.NgControlStatus, ɵngcc1.NgModel], encapsulation: 2, changeDetection: 0 });
AxaHeaderSearchComponent.propDecorators = {
    cls: [{ type: HostBinding, args: [`class.${HEADER_CLASS_SEARCH}`,] }],
    search: [{ type: Output }],
    placeholder: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderSearchComponent, [{
        type: Component,
        args: [{
                selector: 'axa-header-search',
                template: "<form class=\"axa-header__search__wrapper\" #headerSearchForm=\"ngForm\" (ngSubmit)=\"onSubmit()\">\r\n  <input class=\"axa-header__search__input\" type=\"text\" name=\"fld_header_search\" placeholder=\"{{placeholder}}\" [(ngModel)]=\"headerSearchValue\"\r\n  />\r\n  <button type=\"submit\" class=\"axa-header__search__btn\" [disabled]=\"!headerSearchForm.form.valid\">\r\n    <svg title=\"search\" viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\r\n      <path d=\"M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z\"\r\n      />\r\n      <path d=\"M0 0h24v24H0z\" fill=\"none\" />\r\n    </svg>\r\n  </button>\r\n</form>\r\n",
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: [`class.${HEADER_CLASS_SEARCH}`]
        }], search: [{
            type: Output
        }], placeholder: [{
            type: Input
        }] }); })();

class AxaHeaderModule {
}
AxaHeaderModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaHeaderModule });
AxaHeaderModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaHeaderModule_Factory(t) { return new (t || AxaHeaderModule)(); }, imports: [[
            CommonModule,
            RouterModule,
            FormsModule,
            AxaButtonModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaHeaderModule, { declarations: function () { return [AxaHeaderComponent, AxaHeaderMetaDomainDirective, AxaHeaderMetaHelperDirective, AxaHeaderNavComponent, AxaHeaderSearchComponent]; }, imports: function () { return [CommonModule,
        RouterModule,
        FormsModule, AxaButtonModule]; }, exports: function () { return [AxaHeaderComponent, AxaHeaderMetaDomainDirective, AxaHeaderMetaHelperDirective, AxaHeaderNavComponent, AxaHeaderSearchComponent]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderModule, [{
        type: NgModule,
        args: [{
                exports: [
                    AxaHeaderComponent,
                    AxaHeaderMetaDomainDirective,
                    AxaHeaderMetaHelperDirective,
                    AxaHeaderNavComponent,
                    AxaHeaderSearchComponent
                ],
                imports: [
                    CommonModule,
                    RouterModule,
                    FormsModule,
                    AxaButtonModule
                ],
                declarations: [
                    AxaHeaderComponent,
                    AxaHeaderMetaDomainDirective,
                    AxaHeaderMetaHelperDirective,
                    AxaHeaderNavComponent,
                    AxaHeaderSearchComponent
                ]
            }]
    }], null, null); })();

/**This dictionary contains all the styles to apply for the different links. */
const LINK_STYLES = {
    'axa-arrow-link': ['axa-link-blue-arrow'],
    'axa-icon-link': ['axa-link-blue-icon']
};

/**
 * Defines all the links available in the toolkit.
 * Takes care of applying the styles to a button.
 * @export
 */
class AxaLink {
    /**
     * Creates an instance of AxaLink.
     */
    constructor(el) {
        this.el = el;
        this.host = el.nativeElement;
        this.host.classList.add('axa-link');
        this.addDefaultStyle();
    }
    clearStyles() {
        Object.keys(LINK_STYLES).forEach(key => {
            const value = LINK_STYLES[key];
            value.forEach(style => {
                this.host.classList.remove(style);
            });
        });
    }
    hasHostAttributes(...attributes) {
        return attributes.some(attribute => this.host.hasAttribute(attribute));
    }
    addDefaultStyle() {
        this.clearStyles();
        Object.keys(LINK_STYLES).forEach(key => {
            const value = LINK_STYLES[key];
            if (this.hasHostAttributes(key)) {
                value.forEach(style => {
                    this.host.classList.add(style);
                });
            }
        });
    }
}
AxaLink.ɵfac = function AxaLink_Factory(t) { return new (t || AxaLink)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaLink.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaLink, selectors: [["a", "axa-link", ""], ["a", "axa-arrow-link", ""], ["a", "axa-icon-link", ""]] });
AxaLink.ctorParameters = () => [
    { type: ElementRef }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaLink, [{
        type: Directive,
        args: [{ selector: 'a[axa-link], a[axa-arrow-link], a[axa-icon-link]' }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, null); })();

class AxaLinkModule {
}
AxaLinkModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaLinkModule });
AxaLinkModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaLinkModule_Factory(t) { return new (t || AxaLinkModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaLinkModule, { declarations: function () { return [AxaLink]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaLink]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaLinkModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaLink],
                declarations: [AxaLink]
            }]
    }], null, null); })();

/**
 * Class to coordinate unique selection based on name.
 */
class UniqueSelectionDispatcher {
    constructor() {
        this._listeners = [];
    }
    /**
     * Notify other items that selection for the given name has been set.
     * @param id ID of the item.
     * @param name Name of the item.
     */
    notify(id, name) {
        for (const listener of this._listeners) {
            listener(id, name);
        }
    }
    /**
     * Listen for future changes to item selection.
     * @return Function used to deregister listener
     */
    listen(listener) {
        this._listeners.push(listener);
        return () => {
            this._listeners = this._listeners.filter((registered) => {
                return listener !== registered;
            });
        };
    }
    /**
     * @ignore
     */
    ngOnDestroy() {
        this._listeners = [];
    }
}
UniqueSelectionDispatcher.ɵfac = function UniqueSelectionDispatcher_Factory(t) { return new (t || UniqueSelectionDispatcher)(); };
UniqueSelectionDispatcher.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: UniqueSelectionDispatcher, factory: UniqueSelectionDispatcher.ɵfac });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(UniqueSelectionDispatcher, [{
        type: Injectable
    }], function () { return []; }, null); })();
/**Factory for the unique selection dispatcher */
function UNIQUE_SELECTION_DISPATCHER_PROVIDER_FACTORY(parentDispatcher) {
    return parentDispatcher || new UniqueSelectionDispatcher();
}
/**Unique selection dispatcher provider */
const UNIQUE_SELECTION_DISPATCHER_PROVIDER = {
    provide: UniqueSelectionDispatcher,
    deps: [[new Optional(), new SkipSelf(), UniqueSelectionDispatcher]],
    useFactory: UNIQUE_SELECTION_DISPATCHER_PROVIDER_FACTORY
};

/**
 * Generated unique id.
 */
let nextUniqueId$7 = 0;
/**Value Accessor provider to enable ngModel. */
const AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AxaRadioGroup),
    multi: true
};
/**
 * Group of radiobuttons
 * @export
 */
class AxaRadioGroup {
    constructor() {
        this._value = null;
        /** The HTML name attribute applied to radio buttons in this group. */
        this._name = `axa-radio-group-${nextUniqueId$7++}`;
        /** The currently selected radio button. Should match value. */
        this._selected = null;
        /** Whether the `value` has been set to its initial value. */
        this._isInitialized = false;
        /** Whether the labels should appear after or before the radio-buttons. Defaults to 'after' */
        this._labelPosition = 'after';
        /** Whether the radio group is disabled. */
        this._disabled = false;
        /** Whether the radio group is required. */
        this._required = false;
        /**
         * Event emitted when the group value changes.
         * Change events are only emitted when the value changes due to user interaction with
         * a radio button (the same behavior as `<input type-"radio">`).
         */
        this.change = new EventEmitter();
        /** The method to be called in order to update ngModel */
        this.valueAccessorChange = () => { };
        /**
         * The method called to update the blur status of ngModel
         */
        this.valueAccessorTouch = () => { };
    }
    /** Name of the radio button group. All radio buttons inside this group will use this name. */
    get name() { return this._name; }
    set name(value) {
        this._name = value;
        this._updateRadioButtonNames();
    }
    /** Value of the radio button. */
    get value() { return this._value; }
    set value(newValue) {
        if (this._value !== newValue) {
            // Set this before proceeding to ensure no circular loop occurs with selection.
            this._value = newValue;
            this.updateSelectedRadioFromValue();
            this.checkSelectedRadioButton();
        }
    }
    checkSelectedRadioButton() {
        if (this._selected && !this._selected.checked) {
            this._selected.checked = true;
        }
    }
    /** Whether the radio button is selected. */
    get selected() { return this._selected; }
    set selected(selected) {
        this._selected = selected;
        this.value = selected ? selected.value : null;
        this.checkSelectedRadioButton();
    }
    /** Whether the radio group is disabled */
    get disabled() { return this._disabled; }
    set disabled(value) {
        this._disabled = coerceBooleanProperty$1(value);
    }
    /** Whether the radio group is required */
    get required() { return this._required; }
    set required(value) {
        this._required = coerceBooleanProperty$1(value);
    }
    ngAfterContentInit() {
        this._isInitialized = true;
    }
    /**
     * @ignore
     */
    touch() {
        if (this.valueAccessorTouch) {
            this.valueAccessorTouch();
        }
    }
    _updateRadioButtonNames() {
        if (this._radios) {
            this._radios.forEach(radio => {
                radio.name = this.name;
            });
        }
    }
    /** Updates the `selected` radio button from the internal _value state. */
    updateSelectedRadioFromValue() {
        // If the value already matches the selected radio, do nothing.
        const isAlreadySelected = this._selected != null && this._selected.value === this._value;
        if (this._radios != null && !isAlreadySelected) {
            this._selected = null;
            this._radios.forEach(radio => {
                radio.checked = this.value === radio.value;
                if (radio.checked) {
                    this._selected = radio;
                }
            });
        }
    }
    /** Dispatch change event with current selection and group value. */
    fireChangeEvent() {
        if (this._isInitialized) {
            this.change.emit(new AxaRadioChange(this._selected, this._value));
        }
    }
    /**
     * Sets the model value. Implemented as part of ControlValueAccessor.
     */
    writeValue(value) {
        this.value = value;
    }
    /**
     * Registers a callback to be triggered when the model value changes.
     * Implemented as part of ControlValueAccessor.
     * @param fn Callback to be registered.
     */
    registerOnChange(fn) {
        this.valueAccessorChange = fn;
    }
    /**
     * Registers a callback to be triggered when the control is touched.
     * Implemented as part of ControlValueAccessor.
     * @param fn Callback to be registered.
     */
    registerOnTouched(fn) {
        this.valueAccessorTouch = fn;
    }
    /**
     * Sets the disabled state of the control. Implemented as a part of ControlValueAccessor.
     * @param isDisabled Whether the control should be disabled.
     */
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
}
AxaRadioGroup.ɵfac = function AxaRadioGroup_Factory(t) { return new (t || AxaRadioGroup)(); };
AxaRadioGroup.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaRadioGroup, selectors: [["axa-radio-group"]], contentQueries: function AxaRadioGroup_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaRadioButton, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx._radios = _t);
    } }, inputs: { disabled: "disabled", name: "name", value: "value", selected: "selected", required: "required" }, outputs: { change: "change" }, exportAs: ["axaRadioGroup"], features: [ɵngcc0.ɵɵProvidersFeature([AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR])] });
AxaRadioGroup.propDecorators = {
    change: [{ type: Output }],
    _radios: [{ type: ContentChildren, args: [forwardRef(() => AxaRadioButton), { descendants: true },] }],
    name: [{ type: Input }],
    value: [{ type: Input }],
    selected: [{ type: Input }],
    disabled: [{ type: Input }],
    required: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaRadioGroup, [{
        type: Directive,
        args: [{
                selector: 'axa-radio-group',
                exportAs: 'axaRadioGroup',
                providers: [AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR],
                inputs: ['disabled']
            }]
    }], function () { return []; }, { change: [{
            type: Output
        }], name: [{
            type: Input
        }], value: [{
            type: Input
        }], selected: [{
            type: Input
        }], disabled: [{
            type: Input
        }], required: [{
            type: Input
        }], _radios: [{
            type: ContentChildren,
            args: [forwardRef(() => AxaRadioButton), { descendants: true }]
        }] }); })();
/**Directive to use images for the content of axa-radio-button. */
class AxaRadioImage {
    constructor() {
        /**Base style. */
        this.elementClass = 'custom-radio--image';
    }
}
AxaRadioImage.ɵfac = function AxaRadioImage_Factory(t) { return new (t || AxaRadioImage)(); };
AxaRadioImage.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaRadioImage, selectors: [["axa-radio-button", "axa-radio-image", ""]], hostVars: 2, hostBindings: function AxaRadioImage_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.elementClass);
    } } });
AxaRadioImage.propDecorators = {
    elementClass: [{ type: HostBinding, args: ['class',] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaRadioImage, [{
        type: Directive,
        args: [{
                selector: `axa-radio-button[axa-radio-image]`
            }]
    }], function () { return []; }, { elementClass: [{
            type: HostBinding,
            args: ['class']
        }] }); })();
/**
 * Change event emitted by the AxaRadioButton.
 * @export
 */
class AxaRadioChange {
    /**
     * Creates an instance of AxaRadioChange.
     * @param source The AxaRadioButton that emits the change event.
     * @param value The value of the AxaRadioButton.
     */
    constructor(source, value) {
        this.source = source;
        this.value = value;
    }
}
/**
 * An AXA styled radio-button, used with the AxaRadioGroup.
 * @export
 */
class AxaRadioButton {
    /**
     * Creates an instance of AxaRadioButton.
     */
    constructor(radioGroup, _radioDispatcher) {
        this._radioDispatcher = _radioDispatcher;
        this._uniqueId = `axa-radio-${++nextUniqueId$7}`;
        this._checked = false;
        this._value = null;
        /**
         * Element ID.
         */
        this.id = this._uniqueId;
        /**
         * The style applied to the radio button, can be '1' or '2'.
         */
        this.style = '1';
        /**
         * Event emitted when the checked state changes.
         */
        this.change = new EventEmitter();
        this.removeUniqueSelectionListener = () => { };
        /**
         * Implementation of the value accessor.
         */
        this.onTouched = () => { };
        this.radioGroup = radioGroup;
        this.removeUniqueSelectionListener =
            _radioDispatcher.listen((id, name) => {
                if (id !== this.id && name === this.name) {
                    this.checked = false;
                }
            });
    }
    /**
     * Whether the control is checked.
     */
    get checked() { return this._checked; }
    set checked(value) {
        const newCheckedState = coerceBooleanProperty$1(value);
        if (this._checked !== newCheckedState) {
            this._checked = newCheckedState;
            if (newCheckedState && this.radioGroup && this.radioGroup.value !== this.value) {
                this.radioGroup.selected = this;
            }
            else if (!newCheckedState && this.radioGroup && this.radioGroup.value === this.value) {
                // When unchecking the selected radio button, update the selected radio
                // property on the group.
                this.radioGroup.selected = null;
            }
            if (newCheckedState) {
                // Notify all radio buttons with the same name to un-check.
                this._radioDispatcher.notify(this.id, this.name);
            }
        }
    }
    /**
     * The value of the control.
     */
    get value() { return this._value; }
    set value(value) {
        if (this._value !== value) {
            this._value = value;
        }
    }
    /**
     * Whether the control is disabled.
     */
    get disabled() {
        return this._disabled || (this.radioGroup != null && this.radioGroup.disabled);
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty$1(value);
    }
    /**
     * Whether the control is required.
     */
    get required() {
        return this._required || (this.radioGroup && this.radioGroup.required);
    }
    set required(value) {
        this._required = coerceBooleanProperty$1(value);
    }
    /**
     *Gets the ID of the element.
     */
    get inputId() { return `${this.id || this._uniqueId}-input`; }
    /**Handles the click on the input. */
    onInputClick(event) {
        event.stopPropagation();
    }
    /**Handles value change on the input. */
    onInputChange(event) {
        event.stopPropagation();
        const groupValueChanged = this.radioGroup && this.value !== this.radioGroup.value;
        this.checked = true;
        this.fireChangeEvent();
        if (this.radioGroup) {
            this.radioGroup.valueAccessorChange(this.value);
            this.radioGroup.touch();
            if (groupValueChanged) {
                this.radioGroup.fireChangeEvent();
            }
        }
    }
    fireChangeEvent() {
        this.change.emit(new AxaRadioChange(this, this._value));
    }
    ngOnInit() {
        if (this.radioGroup) {
            // If the radio is inside a radio group, determine if it should be checked
            this.checked = this.radioGroup.value === this._value;
            // Copy name from parent radio group
            this.name = this.radioGroup.name;
        }
    }
    ngOnDestroy() {
        this.removeUniqueSelectionListener();
    }
}
AxaRadioButton.ɵfac = function AxaRadioButton_Factory(t) { return new (t || AxaRadioButton)(ɵngcc0.ɵɵdirectiveInject(AxaRadioGroup, 8), ɵngcc0.ɵɵdirectiveInject(UniqueSelectionDispatcher)); };
AxaRadioButton.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaRadioButton, selectors: [["axa-radio-button"]], hostVars: 1, hostBindings: function AxaRadioButton_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
    } }, inputs: { id: "id", style: "style", checked: "checked", value: "value", disabled: "disabled", required: "required", name: "name", tabIndex: "tabIndex", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"] }, outputs: { change: "change" }, ngContentSelectors: _c0, decls: 5, vars: 13, consts: [[1, "custom-control", "custom-radio", 3, "ngClass"], ["type", "radio", 1, "custom-control-input", 3, "id", "checked", "disabled", "tabIndex", "required", "change", "click"], [1, "custom-control-indicator"], [1, "custom-control-description"]], template: function AxaRadioButton_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "label", 0);
        ɵngcc0.ɵɵelementStart(1, "input", 1);
        ɵngcc0.ɵɵlistener("change", function AxaRadioButton_Template_input_change_1_listener($event) { return ctx.onInputChange($event); })("click", function AxaRadioButton_Template_input_click_1_listener($event) { return ctx.onInputClick($event); });
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelement(2, "span", 2);
        ɵngcc0.ɵɵelementStart(3, "span", 3);
        ɵngcc0.ɵɵprojection(4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(10, _c11, ctx.style === "1", ctx.style === "2"));
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("id", ctx.inputId)("checked", ctx.checked)("disabled", ctx.disabled)("tabIndex", ctx.tabIndex)("required", ctx.required);
        ɵngcc0.ɵɵattribute("name", ctx.name)("aria-label", ctx.ariaLabel)("aria-labelledby", ctx.ariaLabelledby)("aria-describedby", ctx.ariaDescribedby);
    } }, directives: [ɵngcc2.NgClass], encapsulation: 2 });
AxaRadioButton.ctorParameters = () => [
    { type: AxaRadioGroup, decorators: [{ type: Optional }] },
    { type: UniqueSelectionDispatcher }
];
AxaRadioButton.propDecorators = {
    id: [{ type: Input }],
    tabIndex: [{ type: Input }],
    name: [{ type: Input }],
    style: [{ type: Input }],
    ariaLabel: [{ type: Input, args: ['aria-label',] }],
    ariaLabelledby: [{ type: Input, args: ['aria-labelledby',] }],
    ariaDescribedby: [{ type: Input, args: ['aria-describedby',] }],
    checked: [{ type: Input }],
    value: [{ type: Input }],
    disabled: [{ type: Input }],
    required: [{ type: Input }],
    change: [{ type: Output }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaRadioButton, [{
        type: Component,
        args: [{
                selector: 'axa-radio-button',
                template: "<label class=\"custom-control custom-radio\" [ngClass]=\"{'radio1': style==='1','radio2': style==='2'}\">\r\n    <input type=\"radio\" class=\"custom-control-input\"\r\n    [id]=\"inputId\"\r\n    [checked]=\"checked\"\r\n    [disabled]=\"disabled\"\r\n    [tabIndex]=\"tabIndex\"\r\n    [attr.name]=\"name\"\r\n    [required]=\"required\"\r\n    [attr.aria-label]=\"ariaLabel\"\r\n    [attr.aria-labelledby]=\"ariaLabelledby\"\r\n    [attr.aria-describedby]=\"ariaDescribedby\"\r\n    (change)=\"onInputChange($event)\"\r\n    (click)=\"onInputClick($event)\">\r\n    <span class=\"custom-control-indicator\"></span>\r\n    <span class=\"custom-control-description\">\r\n        <ng-content></ng-content>\r\n    </span>\r\n</label>\r\n",
                host: { '[attr.id]': 'id' }
            }]
    }], function () { return [{ type: AxaRadioGroup, decorators: [{
                type: Optional
            }] }, { type: UniqueSelectionDispatcher }]; }, { id: [{
            type: Input
        }], style: [{
            type: Input
        }], change: [{
            type: Output
        }], checked: [{
            type: Input
        }], value: [{
            type: Input
        }], disabled: [{
            type: Input
        }], required: [{
            type: Input
        }], name: [{
            type: Input
        }], tabIndex: [{
            type: Input
        }], ariaLabel: [{
            type: Input,
            args: ['aria-label']
        }], ariaLabelledby: [{
            type: Input,
            args: ['aria-labelledby']
        }], ariaDescribedby: [{
            type: Input,
            args: ['aria-describedby']
        }] }); })();

class AxaRadioButtonModule {
}
AxaRadioButtonModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaRadioButtonModule });
AxaRadioButtonModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaRadioButtonModule_Factory(t) { return new (t || AxaRadioButtonModule)(); }, providers: [UNIQUE_SELECTION_DISPATCHER_PROVIDER], imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaRadioButtonModule, { declarations: function () { return [AxaRadioButton, AxaRadioGroup, AxaRadioImage]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaRadioButton, AxaRadioGroup, AxaRadioImage]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaRadioButtonModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaRadioButton, AxaRadioGroup, AxaRadioImage],
                providers: [UNIQUE_SELECTION_DISPATCHER_PROVIDER],
                declarations: [AxaRadioButton, AxaRadioGroup, AxaRadioImage]
            }]
    }], null, null); })();

/**Wrapper class for the axa table. */
const TABLE_CLASS_WRAPPER = 'axa-table-wrapper';
/**Different flex values for the axa table. */
const TABLE_CLASS_FLEX = {
    xs: 'axa-table--flex-xs',
    sm: 'axa-table--flex-sm',
    md: 'axa-table--flex-md',
    lg: 'axa-table--flex-lg',
    xl: 'axa-table--flex-xl'
};
/**This dictionary contains all the styles to apply for the table. */
const TABLE_STYLES = {};

/**
 * Takes care of applying the styles to a table.
 * @export
 */
class AxaTable {
    /**Creates an instance of AxaTable. */
    constructor(el) {
        this._host = el.nativeElement;
        this.applyStyles();
    }
    /** Weither the card is active. */
    set flexDown(value) {
        this._flexDown = value;
        this.applyStyles();
    }
    get flexDown() {
        return this._flexDown;
    }
    applyStyles() {
        this.getClass().forEach(style => {
            if (this._host && !this._host.classList.contains(style)) {
                this._host.classList.add(style);
            }
        });
    }
    /**Returns the css classes. */
    getClass() {
        const classes = [TABLE_CLASS_WRAPPER];
        if (typeof TABLE_CLASS_FLEX[this.flexDown] !== 'undefined') {
            classes.push(TABLE_CLASS_FLEX[this.flexDown]);
        }
        return classes;
    }
}
AxaTable.ɵfac = function AxaTable_Factory(t) { return new (t || AxaTable)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaTable.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTable, selectors: [["axa-table"]], inputs: { flexDown: ["flex-down", "flexDown"] }, ngContentSelectors: _c0, decls: 2, vars: 0, consts: [[1, "axa-table"]], template: function AxaTable_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "table", 0);
        ɵngcc0.ɵɵprojection(1);
        ɵngcc0.ɵɵelementEnd();
    } }, encapsulation: 2 });
AxaTable.ctorParameters = () => [
    { type: ElementRef }
];
AxaTable.propDecorators = {
    flexDown: [{ type: Input, args: ['flex-down',] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTable, [{
        type: Component,
        args: [{
                selector: 'axa-table',
                template: "<table class=\"axa-table\">\r\n  <ng-content></ng-content>\r\n</table>\r\n"
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { flexDown: [{
            type: Input,
            args: ['flex-down']
        }] }); })();

class AxaTableModule {
}
AxaTableModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaTableModule });
AxaTableModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaTableModule_Factory(t) { return new (t || AxaTableModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaTableModule, { declarations: function () { return [AxaTable]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaTable]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaTable],
                declarations: [AxaTable]
            }]
    }], null, null); })();

/**Default style. */
const TOC_CLASS_BASE = 'table-of-contents';
/**Title style. */
const TOC_CLASS_TITLE = `${TOC_CLASS_BASE}__heading`;
/**Title style. */
const TOC_CLASS_ITEM = `${TOC_CLASS_BASE}__item`;

/**Table of contents components to display a summary. */
class AxaTableOfContentsComponent {
    constructor() {
        /**Default style */
        this.cls = TOC_CLASS_BASE;
    }
}
AxaTableOfContentsComponent.ɵfac = function AxaTableOfContentsComponent_Factory(t) { return new (t || AxaTableOfContentsComponent)(); };
AxaTableOfContentsComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTableOfContentsComponent, selectors: [["axa-table-of-contents"]], hostVars: 2, hostBindings: function AxaTableOfContentsComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, ngContentSelectors: _c13, decls: 4, vars: 0, consts: [[1, "table-of-contents__nav"], [1, "table-of-contents__menu"]], template: function AxaTableOfContentsComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c12);
        ɵngcc0.ɵɵprojection(0);
        ɵngcc0.ɵɵelementStart(1, "nav", 0);
        ɵngcc0.ɵɵelementStart(2, "div", 1);
        ɵngcc0.ɵɵprojection(3, 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } }, encapsulation: 2, changeDetection: 0 });
AxaTableOfContentsComponent.propDecorators = {
    cls: [{ type: HostBinding, args: ['class',] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableOfContentsComponent, [{
        type: Component,
        args: [{
                selector: 'axa-table-of-contents',
                template: "<ng-content select=\"axa-table-of-contents-title\"></ng-content>\r\n<nav class=\"table-of-contents__nav\">\r\n  <div class=\"table-of-contents__menu\">\r\n    <ng-content select=\"axa-table-of-contents-item\"></ng-content>\r\n  </div>\r\n</nav>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: ['class']
        }] }); })();

/**Table of contents title component */
class AxaTableOfContentsTitleComponent {
    constructor() {
        /**Default style */
        this.cls = TOC_CLASS_TITLE;
    }
}
AxaTableOfContentsTitleComponent.ɵfac = function AxaTableOfContentsTitleComponent_Factory(t) { return new (t || AxaTableOfContentsTitleComponent)(); };
AxaTableOfContentsTitleComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTableOfContentsTitleComponent, selectors: [["axa-table-of-contents-title"]], hostVars: 2, hostBindings: function AxaTableOfContentsTitleComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaTableOfContentsTitleComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2, changeDetection: 0 });
AxaTableOfContentsTitleComponent.propDecorators = {
    cls: [{ type: HostBinding, args: ['class',] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableOfContentsTitleComponent, [{
        type: Component,
        args: [{
                selector: 'axa-table-of-contents-title',
                template: "<ng-content></ng-content>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: ['class']
        }] }); })();

/**Table of contents item component. */
class AxaTableOfContentsItemComponent {
    constructor() {
        /**Default style */
        this.cls = TOC_CLASS_ITEM;
    }
}
AxaTableOfContentsItemComponent.ɵfac = function AxaTableOfContentsItemComponent_Factory(t) { return new (t || AxaTableOfContentsItemComponent)(); };
AxaTableOfContentsItemComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTableOfContentsItemComponent, selectors: [["axa-table-of-contents-item"]], hostVars: 2, hostBindings: function AxaTableOfContentsItemComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, inputs: { link: "link" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaTableOfContentsItemComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2, changeDetection: 0 });
AxaTableOfContentsItemComponent.propDecorators = {
    cls: [{ type: HostBinding, args: ['class',] }],
    link: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableOfContentsItemComponent, [{
        type: Component,
        args: [{
                selector: 'axa-table-of-contents-item',
                template: "<ng-content></ng-content>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: HostBinding,
            args: ['class']
        }], link: [{
            type: Input
        }] }); })();

class AxaTableOfContentsModule {
}
AxaTableOfContentsModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaTableOfContentsModule });
AxaTableOfContentsModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaTableOfContentsModule_Factory(t) { return new (t || AxaTableOfContentsModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaTableOfContentsModule, { declarations: function () { return [AxaTableOfContentsComponent, AxaTableOfContentsTitleComponent, AxaTableOfContentsItemComponent]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaTableOfContentsComponent, AxaTableOfContentsTitleComponent, AxaTableOfContentsItemComponent]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableOfContentsModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaTableOfContentsComponent, AxaTableOfContentsTitleComponent, AxaTableOfContentsItemComponent],
                declarations: [AxaTableOfContentsComponent, AxaTableOfContentsTitleComponent, AxaTableOfContentsItemComponent]
            }]
    }], null, null); })();

/** TabItem displayed in the tab control. */
class AxaTabItem {
}
AxaTabItem.ɵfac = function AxaTabItem_Factory(t) { return new (t || AxaTabItem)(); };
AxaTabItem.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTabItem, selectors: [["axa-tab-item"]], viewQuery: function AxaTabItem_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵstaticViewQuery(TemplateRef, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.content = _t.first);
    } }, inputs: { label: "label" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaTabItem_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵtemplate(0, AxaTabItem_ng_template_0_Template, 1, 0, "ng-template");
    } }, encapsulation: 2, changeDetection: 0 });
AxaTabItem.propDecorators = {
    label: [{ type: Input }],
    content: [{ type: ViewChild, args: [TemplateRef, { static: true },] }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTabItem, [{
        type: Component,
        args: [{
                selector: 'axa-tab-item',
                template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], null, { label: [{
            type: Input
        }], content: [{
            type: ViewChild,
            args: [TemplateRef, { static: true }]
        }] }); })();

/** Tab control to display sub organized content. */
class AxaTab {
    constructor() {
        this._current = 1;
        this._alt = false;
        /**The change event for the current property. */
        this.currentChange = new EventEmitter();
    }
    /** The currently selected tab item. */
    get current() { return this._current; }
    set current(value) {
        this._current = value;
        this.currentChange.emit(this.current);
    }
    /** Weither the alternate style should be used.
     *
     * Example 1: <axa-tab alt>
     *
     * Example 2: <axa-tab [alt]="showAltStyle">
    */
    get alt() { return this._alt; }
    set alt(value) {
        this._alt = coerceBooleanProperty(value);
    }
    /**Returns the current active tab. */
    getActive(index) {
        return index === this.current - 1;
    }
    /**Sets the curent active item. */
    onTabClick(index) {
        this.current = index + 1;
    }
}
AxaTab.ɵfac = function AxaTab_Factory(t) { return new (t || AxaTab)(); };
AxaTab.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTab, selectors: [["axa-tab"]], contentQueries: function AxaTab_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaTabItem, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.tabs = _t);
    } }, inputs: { current: "current", alt: "alt" }, outputs: { currentChange: "currentChange" }, decls: 6, vars: 6, consts: [[3, "ngClass"], [1, "axa-tab-list"], [4, "ngFor", "ngForOf"], [3, "ngClass", "label", "index", "active", "click"], [4, "ngIf"], [3, "ngTemplateOutlet"]], template: function AxaTab_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelementStart(1, "div");
        ɵngcc0.ɵɵelementStart(2, "div", 1);
        ɵngcc0.ɵɵtemplate(3, AxaTab_ng_container_3_Template, 2, 5, "ng-container", 2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(4, "div", 0);
        ɵngcc0.ɵɵtemplate(5, AxaTab_ng_container_5_Template, 2, 1, "ng-container", 2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction1(4, _c14, !ctx.alt));
        ɵngcc0.ɵɵadvance(3);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.tabs);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngClass", ctx.alt ? "axa-tab-panel-alt" : "axa-tab-panel");
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.tabs);
    } }, directives: function () { return [ɵngcc2.NgClass, ɵngcc2.NgForOf, AxaTabHeader, ɵngcc2.NgIf, ɵngcc2.NgTemplateOutlet]; }, encapsulation: 2 });
AxaTab.propDecorators = {
    tabs: [{ type: ContentChildren, args: [AxaTabItem,] }],
    current: [{ type: Input }],
    alt: [{ type: Input }],
    currentChange: [{ type: Output }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTab, [{
        type: Component,
        args: [{
                selector: 'axa-tab',
                template: "<div [ngClass]=\"{'axa-tab': !alt}\">\r\n  <div>\r\n    <div class=\"axa-tab-list\">\r\n      <ng-container *ngFor=\"let tab of tabs; let i = index;\">\r\n        <axa-tab-header [ngClass]=\"alt ? 'axa-tab-list__tab-alt' : 'axa-tab-list__tab'\" [label]=\"tab.label\" [index]=\"i\"\r\n                        [active]=\"getActive(i)\" [attr.aria-selected]=\"getActive(i)\" (click)=\"onTabClick(i)\">\r\n        </axa-tab-header>\r\n      </ng-container>\r\n    </div>\r\n  </div>\r\n  <div [ngClass]=\"alt ? 'axa-tab-panel-alt' : 'axa-tab-panel'\">\r\n    <ng-container *ngFor=\"let tab of tabs; let i = index;\">\r\n      <div [attr.aria-selected]=\"getActive(i)\" *ngIf=\"getActive(i)\">\r\n        <ng-container [ngTemplateOutlet]=\"tab.content\"></ng-container>\r\n      </div>\r\n    </ng-container>\r\n  </div>\r\n</div>\r\n",
                changeDetection: ChangeDetectionStrategy.Default
            }]
    }], function () { return []; }, { currentChange: [{
            type: Output
        }], current: [{
            type: Input
        }], alt: [{
            type: Input
        }], tabs: [{
            type: ContentChildren,
            args: [AxaTabItem]
        }] }); })();

/** Header control generated to display the tab list. */
class AxaTabHeader {
}
AxaTabHeader.ɵfac = function AxaTabHeader_Factory(t) { return new (t || AxaTabHeader)(); };
AxaTabHeader.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTabHeader, selectors: [["axa-tab-header"]], inputs: { active: "active", label: "label", index: "index" }, decls: 1, vars: 1, template: function AxaTabHeader_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵtext(0);
    } if (rf & 2) {
        ɵngcc0.ɵɵtextInterpolate1("", ctx.label, "\n");
    } }, encapsulation: 2, changeDetection: 0 });
AxaTabHeader.propDecorators = {
    active: [{ type: Input }],
    label: [{ type: Input }],
    index: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTabHeader, [{
        type: Component,
        args: [{
                selector: 'axa-tab-header',
                template: "{{label}}\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush
            }]
    }], null, { active: [{
            type: Input
        }], label: [{
            type: Input
        }], index: [{
            type: Input
        }] }); })();

class AxaTabModule {
}
AxaTabModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaTabModule });
AxaTabModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaTabModule_Factory(t) { return new (t || AxaTabModule)(); }, imports: [[CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaTabModule, { declarations: function () { return [AxaTab, AxaTabItem, AxaTabHeader]; }, imports: function () { return [CommonModule]; }, exports: function () { return [AxaTab, AxaTabItem]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTabModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule],
                exports: [AxaTab, AxaTabItem],
                declarations: [AxaTab, AxaTabItem, AxaTabHeader]
            }]
    }], null, null); })();

/**Accordion control to display collapsible steps. */
class AxaAccordion extends CdkAccordion {
    constructor() {
        super(...arguments);
        /**Current display mode, defaults to default. */
        this.displayMode = 'default';
    }
}
AxaAccordion.ɵfac = function AxaAccordion_Factory(t) { return ɵAxaAccordion_BaseFactory(t || AxaAccordion); };
AxaAccordion.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaAccordion, selectors: [["axa-accordion"]], hostAttrs: [1, "axa-accordion"], inputs: { displayMode: "displayMode" }, features: [ɵngcc0.ɵɵInheritDefinitionFeature] });
AxaAccordion.propDecorators = {
    displayMode: [{ type: Input }]
};
const ɵAxaAccordion_BaseFactory = ɵngcc0.ɵɵgetInheritedFactory(AxaAccordion);
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAccordion, [{
        type: Directive,
        args: [{
                selector: 'axa-accordion',
                host: {
                    class: 'axa-accordion'
                }
            }]
    }], null, { displayMode: [{
            type: Input
        }] }); })();

/** Time and timing curve for expansion panel animations. */
const EXPANSION_PANEL_ANIMATION_TIMING = '225ms cubic-bezier(0.4,0.0,0.2,1)';
/** Animations for the expansion panel. */
const axaExpansionAnimations = {
    /** Animation that expands and collapses the panel content. */
    bodyExpansion: trigger('bodyExpansion', [
        state('collapsed', style({ height: '0px', visibility: 'hidden' })),
        state('expanded', style({ height: '*', visibility: 'visible' })),
        transition('expanded <=> collapsed', animate(EXPANSION_PANEL_ANIMATION_TIMING)),
    ])
};
/** Counter for generating unique element ids. */
let uniqueId = 0;
const ɵ0 = undefined;
/**Expansion panel found inside the axa accordion. */
class AxaExpansionPanel extends CdkAccordionItem {
    /**
     *Creates an instance of AxaExpansionPanel.
     * @param accordion parent accordion.
     * @param cdr ChangeDetectorRef.
     * @param uniqueSelectionDispatcher selection dispatcher to sync panels.
     */
    constructor(accordion, cdr, uniqueSelectionDispatcher) {
        super(accordion, cdr, uniqueSelectionDispatcher);
        /** ID for the associated header element. Used for a11y labelling. */
        this.headerId = `axa-expansion-panel-header-${uniqueId++}`;
        this.accordion = accordion;
    }
    /** Gets the expanded state string. */
    getExpandedState() {
        return this.expanded ? 'expanded' : 'collapsed';
    }
    /** Determines whether the expansion panel should have spacing between it and its siblings. */
    hasSpacing() {
        if (this.accordion) {
            return (this.expanded ? this.accordion.displayMode : this.getExpandedState()) === 'default';
        }
        return false;
    }
    /** Handles animation events */
    bodyAnimation(event) {
        const classList = event.element.classList;
        const cssClass = 'axa-expanded';
        const { phaseName, toState } = event;
        if (phaseName === 'done' && toState === 'expanded') {
            classList.add(cssClass);
        }
        else if (phaseName === 'start' && toState === 'collapsed') {
            classList.remove(cssClass);
        }
    }
}
AxaExpansionPanel.ɵfac = function AxaExpansionPanel_Factory(t) { return new (t || AxaExpansionPanel)(ɵngcc0.ɵɵdirectiveInject(AxaAccordion, 12), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc3.UniqueSelectionDispatcher)); };
AxaExpansionPanel.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaExpansionPanel, selectors: [["axa-expansion-panel"]], hostAttrs: [1, "axa-expansion-panel"], hostVars: 4, hostBindings: function AxaExpansionPanel_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-expanded", ctx.expanded)("axa-expansion-panel-spacing", ctx.hasSpacing());
    } }, inputs: { disabled: "disabled", expanded: "expanded" }, outputs: { opened: "opened", closed: "closed", expandedChange: "expandedChange" }, exportAs: ["axaExpansionPanel"], features: [ɵngcc0.ɵɵProvidersFeature([
            { provide: AxaAccordion, useValue: ɵ0 },
        ]), ɵngcc0.ɵɵInheritDefinitionFeature], ngContentSelectors: _c16, decls: 4, vars: 2, consts: [["role", "region", 1, "axa-expansion-panel-content"], [1, "axa-expansion-panel-body"]], template: function AxaExpansionPanel_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c15);
        ɵngcc0.ɵɵprojection(0);
        ɵngcc0.ɵɵelementStart(1, "div", 0);
        ɵngcc0.ɵɵlistener("@bodyExpansion.done", function AxaExpansionPanel_Template_div_animation_bodyExpansion_done_1_listener($event) { return ctx.bodyAnimation($event); })("@bodyExpansion.start", function AxaExpansionPanel_Template_div_animation_bodyExpansion_start_1_listener($event) { return ctx.bodyAnimation($event); });
        ɵngcc0.ɵɵelementStart(2, "div", 1);
        ɵngcc0.ɵɵprojection(3, 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("@bodyExpansion", ctx.getExpandedState());
        ɵngcc0.ɵɵattribute("aria-labelledby", ctx.headerId);
    } }, encapsulation: 2, data: { animation: [axaExpansionAnimations.bodyExpansion] } });
AxaExpansionPanel.ctorParameters = () => [
    { type: AxaAccordion, decorators: [{ type: Optional }, { type: SkipSelf }] },
    { type: ChangeDetectorRef },
    { type: UniqueSelectionDispatcher$1 }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaExpansionPanel, [{
        type: Component,
        args: [{
                selector: 'axa-expansion-panel',
                template: "<ng-content select=\"axa-expansion-panel-header\"></ng-content>\r\n<div class=\"axa-expansion-panel-content\" [@bodyExpansion]=\"getExpandedState()\"\r\n     (@bodyExpansion.done)=\"bodyAnimation($event)\" (@bodyExpansion.start)=\"bodyAnimation($event)\" role=\"region\"\r\n     [attr.aria-labelledby]=\"headerId\">\r\n  <div class=\"axa-expansion-panel-body\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n</div>\r\n",
                exportAs: 'axaExpansionPanel',
                encapsulation: ViewEncapsulation.None,
                providers: [
                    { provide: AxaAccordion, useValue: ɵ0 },
                ],
                animations: [axaExpansionAnimations.bodyExpansion],
                inputs: ['disabled', 'expanded'],
                outputs: ['opened', 'closed', 'expandedChange'],
                host: {
                    'class': 'axa-expansion-panel',
                    '[class.axa-expanded]': 'expanded',
                    '[class.axa-expansion-panel-spacing]': 'hasSpacing()'
                }
            }]
    }], function () { return [{ type: AxaAccordion, decorators: [{
                type: Optional
            }, {
                type: SkipSelf
            }] }, { type: ɵngcc0.ChangeDetectorRef }, { type: ɵngcc3.UniqueSelectionDispatcher }]; }, null); })();

/**Header of the panel ment for the accordion. */
class AxaExpansionPanelHeader {
    /**
     *Creates an instance of AxaExpansionPanelHeader.
     * @param panel parent expansion panel.
     */
    constructor(panel) {
        this.panel = panel;
    }
    /** Gets the panel id. */
    getPanelId() {
        return this.panel.id;
    }
    /** Gets whether the panel is expanded. */
    isExpanded() {
        return this.panel.expanded;
    }
    /** Toggles the expanded state of the panel. */
    toggle() {
        this.panel.toggle();
    }
}
AxaExpansionPanelHeader.ɵfac = function AxaExpansionPanelHeader_Factory(t) { return new (t || AxaExpansionPanelHeader)(ɵngcc0.ɵɵdirectiveInject(AxaExpansionPanel, 1)); };
AxaExpansionPanelHeader.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaExpansionPanelHeader, selectors: [["axa-expansion-panel-header"]], hostAttrs: ["role", "button", 1, "axa-expansion-panel-header"], hostVars: 5, hostBindings: function AxaExpansionPanelHeader_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("click", function AxaExpansionPanelHeader_click_HostBindingHandler() { return ctx.toggle(); });
    } if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.panel.headerId)("tabindex", ctx.panel.disabled ? 0 - 1 : 0)("aria-controls", ctx.getPanelId())("aria-expanded", ctx.isExpanded())("aria-disabled", ctx.panel.disabled);
    } }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaExpansionPanelHeader_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2 });
AxaExpansionPanelHeader.ctorParameters = () => [
    { type: AxaExpansionPanel, decorators: [{ type: Host }] }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaExpansionPanelHeader, [{
        type: Component,
        args: [{
                template: "<ng-content></ng-content>\r\n",
                selector: 'axa-expansion-panel-header',
                encapsulation: ViewEncapsulation.None,
                host: {
                    'class': 'axa-expansion-panel-header',
                    '(click)': 'toggle()',
                    'role': 'button',
                    '[attr.id]': 'panel.headerId',
                    '[attr.tabindex]': 'panel.disabled ? -1 : 0',
                    '[attr.aria-controls]': 'getPanelId()',
                    '[attr.aria-expanded]': 'isExpanded()',
                    '[attr.aria-disabled]': 'panel.disabled'
                }
            }]
    }], function () { return [{ type: AxaExpansionPanel, decorators: [{
                type: Host
            }] }]; }, null); })();

class AxaExpansionModule {
}
AxaExpansionModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaExpansionModule });
AxaExpansionModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaExpansionModule_Factory(t) { return new (t || AxaExpansionModule)(); }, imports: [[CommonModule, CdkAccordionModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaExpansionModule, { declarations: function () { return [AxaAccordion, AxaExpansionPanel, AxaExpansionPanelHeader]; }, imports: function () { return [CommonModule, CdkAccordionModule]; }, exports: function () { return [AxaAccordion, AxaExpansionPanel, AxaExpansionPanelHeader]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaExpansionModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, CdkAccordionModule],
                exports: [AxaAccordion, AxaExpansionPanel, AxaExpansionPanelHeader],
                declarations: [AxaAccordion, AxaExpansionPanel, AxaExpansionPanelHeader]
            }]
    }], null, null); })();

/**Class representing the config.base.json. */
class EnvSpecific {
}

/**The configuration injectable class. */
class AxaAppConfig {
    /**
     *Creates an instance of AxaAppConfig.
     */
    constructor() {
        /**Contains the environment from config.base.config. */
        this.base = new EnvSpecific();
    }
    /**Loads the configuration. */
    load() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const baseFile = `assets/config/config.base.json`;
                const baseResponse = yield fetch(baseFile, { credentials: 'include' });
                this.base = yield baseResponse.json();
                if (this.base.environment.includes('#{token')) {
                    this.base.environment = 'dev';
                }
                const env = this.base.environment.toLowerCase();
                const envFile = `assets/config/config.${env}.json`;
                const envResponse = yield fetch(envFile, { credentials: 'include' });
                this.settings = (yield envResponse.json());
            }
            catch (e) {
                console.error('Configuration file could not be loaded', e);
            }
        });
    }
}
AxaAppConfig.ɵfac = function AxaAppConfig_Factory(t) { return new (t || AxaAppConfig)(); };
AxaAppConfig.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaAppConfig, factory: AxaAppConfig.ɵfac });
AxaAppConfig.ctorParameters = () => [];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAppConfig, [{
        type: Injectable
    }], function () { return []; }, null); })();
/**Factory function to load the configuration. */
function initializeAxaConfig(appConfig) {
    return () => appConfig.load();
}

class AxaConfigModule {
    static forRoot() {
        return {
            ngModule: AxaConfigModule,
            providers: [AxaAppConfig]
        };
    }
}
AxaConfigModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaConfigModule });
AxaConfigModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaConfigModule_Factory(t) { return new (t || AxaConfigModule)(); }, imports: [[CommonModule, HttpClientModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaConfigModule, { imports: function () { return [CommonModule, HttpClientModule]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaConfigModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, HttpClientModule]
            }]
    }], null, null); })();

/**Key for the error close button string. */
const AXA_ERROR_CLOSE_STRING = 'AXA_ERROR_CLOSE_STRING';
/**Key for the error title string. */
const AXA_ERROR_TITLE_STRING = 'AXA_ERROR_TITLE_STRING';

/**
 * Implementation of a global error handler.
 * The axa implementation pushes alerts to {AxaAlertService}.
 */
class AxaGlobalErrorHandler extends ErrorHandler {
    /**
     * Creates an instance of AxaGlobalErrorHandler.
     */
    constructor(injector) {
        super();
        this.injector = injector;
    }
    /**
     * Handles an uncaught error in the appliation.
     */
    handleError(error) {
        const closeString = this.injector.get(AXA_ERROR_CLOSE_STRING, null);
        const titleString = this.injector.get(AXA_ERROR_TITLE_STRING, null);
        console.error(titleString || 'DEFAULT GLOBAL ERROR HANDLER', error);
        const alertService = this.injector.get(AxaAlertService, null);
        if (alertService) {
            const alertCloseAction = {
                content: closeString || 'Close',
                handler: (action, parent) => {
                    alertService.removeAlert(parent);
                }
            };
            const alert = {
                message: error.message,
                type: 'warning',
                ttl: 0,
                action: alertCloseAction
            };
            alertService.addAlert(alert);
        }
    }
}
AxaGlobalErrorHandler.ɵfac = function AxaGlobalErrorHandler_Factory(t) { return new (t || AxaGlobalErrorHandler)(ɵngcc0.ɵɵinject(ɵngcc0.Injector)); };
AxaGlobalErrorHandler.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaGlobalErrorHandler, factory: AxaGlobalErrorHandler.ɵfac });
AxaGlobalErrorHandler.ctorParameters = () => [
    { type: Injector }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaGlobalErrorHandler, [{
        type: Injectable
    }], function () { return [{ type: ɵngcc0.Injector }]; }, null); })();

class AxaErrorHandlingModule {
    static forRoot() {
        return {
            ngModule: AxaErrorHandlingModule,
            providers: [AxaGlobalErrorHandler]
        };
    }
}
AxaErrorHandlingModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaErrorHandlingModule });
AxaErrorHandlingModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaErrorHandlingModule_Factory(t) { return new (t || AxaErrorHandlingModule)(); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaErrorHandlingModule, [{
        type: NgModule,
        args: [{}]
    }], null, null); })();

/**Key for the auth endpoint. */
const AXA_OAUTH_ENDPOINT_KEY = 'OAUTH2_AUTHENTICATION_ENDPOINT';
/**Key for the scope. */
const AXA_OAUTH_SCOPE_KEY = 'OAUTH2_SCOPE';
/**Key for the client id. */
const AXA_OAUTH_CLIENTID_KEY = 'OAUTH2_CLIENT_ID';
/**Key for the callback URL. */
const AXA_OAUTH_CALLBACK_KEY = 'OAUTH2_CALLBACK_URL';
/**Key for the token. */
const AXA_OAUTH_TOKEN_KEY = 'OAUTH2_TOKEN_STORAGE_KEY';
/**Key for the response type. Set to token by default. */
const AXA_OAUTH_RESPONSE_TYPE = 'OAUTH2_RESPONSE_TYPE';
/**Key for the redirect URI.  */
const AXA_OAUTH_REDIRECT_URI = 'redirect_uri';
/**Error for missing token key. */
const AXA_TOKEN_KEY_MISSING_ERROR = new Error('OAUTH2_TOKEN_STORAGE_KEY should be provided in the root module. ' +
    'It is the key to be used for the storage of the token in the sessionStorage.');
/**Error for missing endpoint. */
const AXA_ENDPOINT_MISSING_ERROR = new Error('OAUTH2_AUTHENTICATION_ENDPOINT should be provided in the root module. ' +
    'It is the url of the popup to the Authentication Server');
/**Error for missing client id. */
const AXA_CLIENTID_MISSING_ERROR = new Error('OAUTH2_CLIENT_ID should be provided in the root module. ' +
    'It is the registered ID of the application in the Authentication Server');
/**Error for missing scope. */
const AXA_SCOPE_MISSING_ERROR = new Error('OAUTH2_SCOPE should be provided in the root module. ' +
    'It is the scope of the application.');
/**Error for failed retrieval of the token. */
const AXA_TOKEN_RETRIEVE_FAILED_ERROR = new Error('Unable to retrieve access token from request');

/**
 * Service to do oauth authentification with the MAAM.
 * @export
 */
class AxaOAuthService {
    /**
     * Creates an instance of AxaOAuthService.
     * @param authenticationUrl The auth URL (AXA_OAUTH_ENDPOINT_KEY).
     * @param scope The scope (AXA_OAUTH_SCOPE_KEY).
     * @param clientId The client id (AXA_OAUTH_CLIENTID_KEY).
     * @param callbackUrl The callback URL (AXA_OAUTH_CALLBACK_KEY).
     * @param tokenStorageKey The token key in the storage (AXA_OAUTH_TOKEN_KEY).
     */
    constructor(authenticationUrl, scope, clientId, callbackUrl, tokenStorageKey, responseType, router) {
        this.authenticationUrl = authenticationUrl;
        this.scope = scope;
        this.clientId = clientId;
        this.callbackUrl = callbackUrl;
        this.tokenStorageKey = tokenStorageKey;
        this.responseType = responseType;
        this.token = new BehaviorSubject(null);
        this.currentUrl = '';
        this.authenticating = false;
        router.events.subscribe((r) => {
            this.currentUrl = r.url;
        });
        if (!authenticationUrl) {
            throw AXA_ENDPOINT_MISSING_ERROR;
        }
        if (!scope) {
            throw AXA_SCOPE_MISSING_ERROR;
        }
        if (!clientId) {
            throw AXA_CLIENTID_MISSING_ERROR;
        }
        if (!tokenStorageKey) {
            throw AXA_TOKEN_KEY_MISSING_ERROR;
        }
        if (!this.responseType) {
            this.responseType = 'token';
        }
        const token = sessionStorage.getItem(tokenStorageKey);
        if (token) {
            this.token.next(token);
        }
    }
    /**
     * Gets a stream of the current token.
     */
    getToken() {
        const token = sessionStorage.getItem(this.tokenStorageKey);
        if (token) {
            this.token.next(token);
        }
        return this.token;
    }
    /**
     * Gets the token if it's there or authenticates and then returns the token.
     */
    getTokenOrAuthenticate() {
        const token = sessionStorage.getItem(this.tokenStorageKey);
        if (token) {
            this.token.next(token);
        }
        if (!this.token.getValue() && !this.authenticating) {
            this.authenticate();
        }
        return this.token;
    }
    /**
     * Requires a new token from the MAAM.
     */
    authenticate() {
        // console.log('response type: ' + this.responseType);
        this.authenticating = true;
        this.saveDataForAutenticationCallback({
            redirect_uri: this.currentUrl
        });
        const url = this.authenticationUrl + '?' +
            'client_id=' + this.clientId + '&' +
            'redirect_uri=' + encodeURI(window.location.origin + this.callbackUrl) + '&' +
            'response_type=' + this.responseType + '&' +
            'scope=' + this.scope;
        window.open(url, '_self');
        return this.token;
    }
    saveDataForAutenticationCallback(data) {
        Object.keys(data).forEach(key => {
            if (data[key]) {
                sessionStorage.setItem(key, data[key]);
            }
        });
    }
    /**
     * Removes the token from sessionstorage, this is not a disconnect function.
     */
    forgetToken() {
        sessionStorage.removeItem(this.tokenStorageKey);
        this.token.next(null);
    }
}
AxaOAuthService.ɵfac = function AxaOAuthService_Factory(t) { return new (t || AxaOAuthService)(ɵngcc0.ɵɵinject(AXA_OAUTH_ENDPOINT_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_SCOPE_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_CLIENTID_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_CALLBACK_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_TOKEN_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_RESPONSE_TYPE, 8), ɵngcc0.ɵɵinject(ɵngcc4.Router)); };
AxaOAuthService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaOAuthService, factory: AxaOAuthService.ɵfac });
AxaOAuthService.ctorParameters = () => [
    { type: String, decorators: [{ type: Optional }, { type: Inject, args: [AXA_OAUTH_ENDPOINT_KEY,] }] },
    { type: String, decorators: [{ type: Optional }, { type: Inject, args: [AXA_OAUTH_SCOPE_KEY,] }] },
    { type: String, decorators: [{ type: Optional }, { type: Inject, args: [AXA_OAUTH_CLIENTID_KEY,] }] },
    { type: String, decorators: [{ type: Optional }, { type: Inject, args: [AXA_OAUTH_CALLBACK_KEY,] }] },
    { type: String, decorators: [{ type: Optional }, { type: Inject, args: [AXA_OAUTH_TOKEN_KEY,] }] },
    { type: String, decorators: [{ type: Optional }, { type: Inject, args: [AXA_OAUTH_RESPONSE_TYPE,] }] },
    { type: Router }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaOAuthService, [{
        type: Injectable
    }], function () { return [{ type: String, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [AXA_OAUTH_ENDPOINT_KEY]
            }] }, { type: String, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [AXA_OAUTH_SCOPE_KEY]
            }] }, { type: String, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [AXA_OAUTH_CLIENTID_KEY]
            }] }, { type: String, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [AXA_OAUTH_CALLBACK_KEY]
            }] }, { type: String, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [AXA_OAUTH_TOKEN_KEY]
            }] }, { type: String, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [AXA_OAUTH_RESPONSE_TYPE]
            }] }, { type: ɵngcc4.Router }]; }, null); })();

/**
 * This directive takes care of parsing the token and redirecting to the AXA_OAUTH_REDIRECT_URI.
 * @export
 */
class AxaOAuthCallbackComponent {
    /**
     * Creates an instance of AxaOAuthCallbackComponent.
     * @param route
     * The route used to parse the fragment of the url.
     * @param router
     * The router used for the redirection.
     * @param tokenStorageKey
     * The key where the token needs to be stored.
     */
    constructor(route, router, tokenStorageKey) {
        this.route = route;
        this.router = router;
        this.tokenStorageKey = tokenStorageKey;
        const dict = {};
        this.route.fragment.subscribe(fragment => {
            if (fragment) {
                fragment.split('&').forEach(item => {
                    const parts = item.split('=');
                    dict[parts[0]] = parts[1];
                });
            }
            if (dict && dict.access_token != null) {
                if (!tokenStorageKey) {
                    throw AXA_TOKEN_KEY_MISSING_ERROR;
                }
                sessionStorage.setItem(tokenStorageKey, dict.access_token);
            }
            else {
                throw AXA_TOKEN_RETRIEVE_FAILED_ERROR;
            }
            const redirectUri = sessionStorage.getItem(AXA_OAUTH_REDIRECT_URI);
            router.navigateByUrl(redirectUri);
        });
    }
}
AxaOAuthCallbackComponent.ɵfac = function AxaOAuthCallbackComponent_Factory(t) { return new (t || AxaOAuthCallbackComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc4.ActivatedRoute), ɵngcc0.ɵɵdirectiveInject(ɵngcc4.Router), ɵngcc0.ɵɵdirectiveInject(AXA_OAUTH_TOKEN_KEY, 8)); };
AxaOAuthCallbackComponent.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaOAuthCallbackComponent, selectors: [["axa-oauth-callback"]] });
AxaOAuthCallbackComponent.ctorParameters = () => [
    { type: ActivatedRoute },
    { type: Router },
    { type: String, decorators: [{ type: Optional }, { type: Inject, args: [AXA_OAUTH_TOKEN_KEY,] }] }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaOAuthCallbackComponent, [{
        type: Directive,
        args: [{
                selector: 'axa-oauth-callback'
            }]
    }], function () { return [{ type: ɵngcc4.ActivatedRoute }, { type: ɵngcc4.Router }, { type: String, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [AXA_OAUTH_TOKEN_KEY]
            }] }]; }, null); })();

class AxaOAuthModule {
    static forRoot() {
        return {
            ngModule: AxaOAuthModule,
            providers: [AxaOAuthService]
        };
    }
}
AxaOAuthModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaOAuthModule });
AxaOAuthModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaOAuthModule_Factory(t) { return new (t || AxaOAuthModule)(); }, imports: [[RouterModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaOAuthModule, { declarations: function () { return [AxaOAuthCallbackComponent]; }, imports: function () { return [RouterModule]; }, exports: function () { return [AxaOAuthCallbackComponent]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaOAuthModule, [{
        type: NgModule,
        args: [{
                imports: [RouterModule],
                exports: [AxaOAuthCallbackComponent],
                declarations: [AxaOAuthCallbackComponent]
            }]
    }], null, null); })();

/** Service to provide access to google analytics. */
class AxaGoogleAnalyticsService {
    /**
     *Creates an instance of AxaGoogleAnalyticsService.
     * @param router The router to report page views.
     */
    constructor(router) {
        this.router = router;
    }
    /** Will start tracking page views and reporting them to google analytics.
     * Only needs to be called once in the boostrap component for example (app.component.ts)
     */
    trackPageViews() {
        if (typeof ga === 'function') {
            this.router.events.pipe(filter(e => e instanceof NavigationEnd), map((e) => {
                ga('set', 'page', e.urlAfterRedirects);
                ga('send', 'pageview');
            })).subscribe();
        }
    }
    /** Emits a custom event to google analytics. */
    emitEvent(eventCategory, eventAction, eventLabel = null, eventValue = null) {
        if (typeof ga === 'function') {
            ga('send', 'event', { eventCategory, eventLabel, eventAction, eventValue });
        }
    }
}
AxaGoogleAnalyticsService.ɵfac = function AxaGoogleAnalyticsService_Factory(t) { return new (t || AxaGoogleAnalyticsService)(ɵngcc0.ɵɵinject(ɵngcc4.Router)); };
AxaGoogleAnalyticsService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaGoogleAnalyticsService, factory: AxaGoogleAnalyticsService.ɵfac });
AxaGoogleAnalyticsService.ctorParameters = () => [
    { type: Router }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaGoogleAnalyticsService, [{
        type: Injectable
    }], function () { return [{ type: ɵngcc4.Router }]; }, null); })();

const AXA_GA_SETTINGS_TOKEN = new InjectionToken('axa-ga-settings', {
    factory: () => ({ trackingCode: '' })
});
const AXA_GA_INIT_PROVIDER = {
    provide: APP_INITIALIZER,
    multi: true,
    useFactory: GoogleAnalyticsInitializer,
    deps: [
        AXA_GA_SETTINGS_TOKEN
    ]
};
function GoogleAnalyticsInitializer(settings) {
    return () => __awaiter(this, void 0, void 0, function* () {
        if (isDevMode()) {
            return;
        }
        if (!settings.trackingCode) {
            console.error('Empty tracking code for Google Analytics. Make sure to provide one when initializing google analytics.');
            return;
        }
        // Set default ga.js uri
        settings.uri = settings.uri || `https://www.googletagmanager.com/gtag/js?id=${settings.trackingCode}`;
        // these commands should run first!
        const initialCommands = [
            { command: 'js', values: [new Date()] },
            { command: 'config', values: [settings.trackingCode] }
        ];
        settings.initCommands = [...initialCommands, ...(settings.initCommands || [])];
        window['dataLayer'] = window['dataLayer'] || [];
        window['gtag'] = window['gtag'] || function () {
            window['dataLayer'].push(arguments);
        };
        for (const command of settings.initCommands) {
            window['gtag'](command.command, ...command.values);
        }
        const s = document.createElement('script');
        s.async = true;
        s.src = settings.uri;
        const head = document.getElementsByTagName('head')[0];
        head.appendChild(s);
    });
}

class AxaAnalyticsModule {
    static forRoot(gaCode, commands = [], uri) {
        return {
            ngModule: AxaAnalyticsModule,
            providers: [
                AxaGoogleAnalyticsService,
                {
                    provide: AXA_GA_SETTINGS_TOKEN,
                    useValue: {
                        trackingCode: gaCode,
                        commands: commands,
                        uri: uri
                    }
                },
                AXA_GA_INIT_PROVIDER
            ]
        };
    }
}
AxaAnalyticsModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaAnalyticsModule });
AxaAnalyticsModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaAnalyticsModule_Factory(t) { return new (t || AxaAnalyticsModule)(); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAnalyticsModule, [{
        type: NgModule,
        args: [{}]
    }], null, null); })();

class PDFService {
    generateLandscape(content, fileName, format = 'a4', heightPage = 800, widthPage = 1750) {
        html2canvas(content).then((canvas) => {
            const pdf = new jsPDF('l', 'pt', format);
            this.generatePDF(content, fileName, heightPage, canvas, widthPage, pdf);
        });
    }
    generatePortrait(content, fileName, format = 'a4', heightPage = 1100, widthPage = 1300) {
        html2canvas(content).then((canvas) => {
            const pdf = new jsPDF('p', 'pt', format);
            this.generatePDF(content, fileName, heightPage, canvas, widthPage, pdf);
        });
    }
    generatePDF(content, fileName, heightPage, canvas, widthPage, pdf) {
        for (let index = 0, len = content.clientHeight / heightPage; index <= len; index++) {
            const { url, width, height } = this.getCanvas({ index, canvas, heightPage, widthPage });
            // If we're on anything other than the first page, add another page
            if (index > 0) {
                pdf.addPage();
            }
            pdf.setPage(index + 1);
            pdf.addImage(url, 'PNG', 20, 40, (width * 0.62), (height * 0.62));
        }
        pdf.save(`${fileName}.pdf`);
    }
    getCanvas({ index, canvas, heightPage, widthPage }) {
        const srcImg = canvas;
        const sX = 0;
        const sY = heightPage * index;
        const sWidth = 1575;
        const sHeight = heightPage;
        const dX = 0;
        const dY = 0;
        const dWidth = widthPage;
        const dHeight = heightPage;
        const onePageCanvas = document.createElement('canvas');
        onePageCanvas.setAttribute('width', '' + widthPage);
        onePageCanvas.setAttribute('height', '' + heightPage);
        const ctx = onePageCanvas.getContext('2d');
        // Details on this usage of this function:
        // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Using_images#Slicing
        ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);
        const url = onePageCanvas.toDataURL('image/png', 1.0);
        const width = onePageCanvas.width;
        const height = onePageCanvas.clientHeight;
        return { url, width, height };
    }
}
PDFService.ɵfac = function PDFService_Factory(t) { return new (t || PDFService)(); };
PDFService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: PDFService, factory: PDFService.ɵfac });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(PDFService, [{
        type: Injectable
    }], null, null); })();

class PDFModule {
}
PDFModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: PDFModule });
PDFModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function PDFModule_Factory(t) { return new (t || PDFModule)(); }, providers: [PDFService] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(PDFModule, [{
        type: NgModule,
        args: [{
                providers: [PDFService]
            }]
    }], null, null); })();

const GTM_ID = 'GTM_ID';

// Based on lib https://github.com/mzuccaroli/angular-google-tag-manager
class AxaGtmService {
    constructor(gtmId) {
        this.gtmId = gtmId;
        this.isLoaded = false;
        this.browserGlobals = {
            windowRef() {
                return window;
            },
            documentRef() {
                return document;
            }
        };
    }
    init() {
        if (this.isLoaded) {
            return;
        }
        const doc = this.browserGlobals.documentRef();
        this.pushOnDataLayer({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        const gtmScript = doc.createElement('script');
        gtmScript.id = 'GTMscript';
        gtmScript.async = true;
        gtmScript.src = this.appendId('//www.googletagmanager.com/gtm.js');
        doc.head.insertBefore(gtmScript, doc.head.firstChild);
        const ifrm = doc.createElement('iframe');
        ifrm.setAttribute('src', this.appendId('//www.googletagmanager.com/ns.html'));
        ifrm.style.width = '0';
        ifrm.style.height = '0';
        ifrm.style.display = 'none';
        ifrm.style.visibility = 'hidden';
        const noscript = doc.createElement('noscript');
        noscript.id = 'GTMiframe';
        noscript.appendChild(ifrm);
        doc.body.insertBefore(noscript, doc.body.firstChild);
        this.isLoaded = true;
    }
    pushTag(item) {
        if (!this.isLoaded) {
            this.init();
        }
        this.pushOnDataLayer(item);
    }
    appendId(url) {
        return `${url}?id=${this.gtmId}`;
    }
    getDataLayer() {
        const window = this.browserGlobals.windowRef();
        window['dataLayer'] = window['dataLayer'] || [];
        return window['dataLayer'];
    }
    pushOnDataLayer(obj) {
        const dataLayer = this.getDataLayer();
        dataLayer.push(obj);
    }
}
AxaGtmService.ɵfac = function AxaGtmService_Factory(t) { return new (t || AxaGtmService)(ɵngcc0.ɵɵinject(GTM_ID, 8)); };
AxaGtmService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaGtmService, factory: AxaGtmService.ɵfac });
AxaGtmService.ctorParameters = () => [
    { type: String, decorators: [{ type: Optional }, { type: Inject, args: [GTM_ID,] }] }
];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaGtmService, [{
        type: Injectable
    }], function () { return [{ type: String, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [GTM_ID]
            }] }]; }, null); })();

class AxaGtmModule {
}
AxaGtmModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaGtmModule });
AxaGtmModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaGtmModule_Factory(t) { return new (t || AxaGtmModule)(); }, providers: [AxaGtmService] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaGtmModule, [{
        type: NgModule,
        args: [{
                providers: [AxaGtmService]
            }]
    }], null, null); })();

/**Public API Surface of ng-toolkit */

/**
 * Generated bundle index. Do not edit.
 */

export { AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR, AXA_CLIENTID_MISSING_ERROR, AXA_DATECOMBOPICKER_CONTROL_VALUE_ACCESSOR, AXA_ENDPOINT_MISSING_ERROR, AXA_ERROR_CLOSE_STRING, AXA_ERROR_TITLE_STRING, AXA_OAUTH_CALLBACK_KEY, AXA_OAUTH_CLIENTID_KEY, AXA_OAUTH_ENDPOINT_KEY, AXA_OAUTH_REDIRECT_URI, AXA_OAUTH_RESPONSE_TYPE, AXA_OAUTH_SCOPE_KEY, AXA_OAUTH_TOKEN_KEY, AXA_PHONE_INPUT_CONTROL_VALUE_ACCESSOR, AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR, AXA_SCOPE_MISSING_ERROR, AXA_TOKEN_KEY_MISSING_ERROR, AXA_TOKEN_RETRIEVE_FAILED_ERROR, AxaAccordion, AxaAlertManager, AxaAlertModule, AxaAlertService, AxaAnalyticsModule, AxaAppConfig, AxaBusyComponent, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective, AxaBusyDirective, AxaBusyModule, AxaBusyRawComponent, AxaBusyRawDirective, AxaButton, AxaButtonModule, AxaCardComponent, AxaCardContentDirective, AxaCardModule, AxaCardTitleDirective, AxaCheckbox, AxaCheckboxChange, AxaCheckboxModule, AxaConfigModule, AxaCookieMessage, AxaCookieMessageModule, AxaDateComboBase, AxaDateComboPicker, AxaDateComboPickerModule, AxaError, AxaErrorHandlingModule, AxaExpansionModule, AxaExpansionPanel, AxaExpansionPanelHeader, AxaFlagIcon, AxaFlagIconModule, AxaFooterComponent, AxaFooterLanguage, AxaFooterListComponent, AxaFooterModule, AxaFooterSocialComponent, AxaFormField, AxaFormFieldModule, AxaGlobalErrorHandler, AxaGoogleAnalyticsService, AxaGtmModule, AxaGtmService, AxaHeaderComponent, AxaHeaderMetaDomainDirective, AxaHeaderMetaHelperDirective, AxaHeaderModule, AxaHeaderNavComponent, AxaHeaderSearchComponent, AxaHint, AxaIconModule, AxaInput, AxaInputBase, AxaInputModule, AxaLink, AxaLinkModule, AxaNumbersOnlyDirective, AxaOAuthCallbackComponent, AxaOAuthModule, AxaOAuthService, AxaPhoneInputBase, AxaPhoneInputComponent, AxaPhoneInputModule, AxaPrefixDirective, AxaRadioButton, AxaRadioButtonModule, AxaRadioChange, AxaRadioGroup, AxaRadioImage, AxaSelect, AxaSelectBase, AxaSelectModule, AxaStepComponent, AxaStepperComponent, AxaStepperModule, AxaSuffixDirective, AxaTab, AxaTabItem, AxaTabModule, AxaTable, AxaTableModule, AxaTableOfContentsComponent, AxaTableOfContentsItemComponent, AxaTableOfContentsModule, AxaTableOfContentsTitleComponent, AxaTopContentBarComponent, AxaTopContentBarModule, COOKIE_STORAGE, EXPANSION_PANEL_ANIMATION_TIMING, GTM_ID, INPUT_STYLE, IconComponent, PDFModule, PDFService, SELECT_STYLE, _AxaDateComboBase, _AxaInputMixinBase, _AxaPhoneInputMixinBase, _AxaSelectMixinBase, axaExpansionAnimations, initializeAxaConfig, mixinDisabled, mixinErrorState, mixinParentErrorState, mixinTabIndex, ɵ0, ErrorStateMatcher as ɵa, AxaFormFieldControl as ɵb, AXA_GA_INIT_PROVIDER as ɵba, GoogleAnalyticsInitializer as ɵbb, AxaCountryService as ɵc, AxaBusyBackdropComponent as ɵd, CLASS_BASE as ɵe, CLASS_ACTIVE as ɵf, CLASS_WIDE as ɵg, CLASS_BLOCK as ɵh, CLASS_TITLE as ɵi, CLASS_INFO as ɵj, CLASS_CONTENT as ɵk, CLASS_BLOCK_COMPACT as ɵl, AxaStepHeaderComponent as ɵm, CLASS_STEP as ɵn, CLASS_STEP_PRICING as ɵo, CLASS_STEP_ACTIVE as ɵp, CLASS_STEP_DONE as ɵq, HEADER_CLASS_SEARCH as ɵr, HEADER_CLASS_NAV_LINK as ɵs, HEADER_CLASS_NAV_LINK_ACTIVE as ɵt, HEADER_CLASS_NAV_LINK_BUTTON as ɵu, UniqueSelectionDispatcher as ɵv, UNIQUE_SELECTION_DISPATCHER_PROVIDER_FACTORY as ɵw, UNIQUE_SELECTION_DISPATCHER_PROVIDER as ɵx, AxaTabHeader as ɵy, AXA_GA_SETTINGS_TOKEN as ɵz };

//# sourceMappingURL=axa-ng-toolkit.js.map