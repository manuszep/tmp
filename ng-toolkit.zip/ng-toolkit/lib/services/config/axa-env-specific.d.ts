/**Class representing the config.base.json. */
export declare class EnvSpecific {
    /**The current environment. */
    environment: string;
}
