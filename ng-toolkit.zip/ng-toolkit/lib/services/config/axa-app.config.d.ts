import { EnvSpecific } from './axa-env-specific';
/**The configuration injectable class. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaAppConfig<T> {
    /**Contains the environment from config.base.config. */
    base: EnvSpecific;
    /**Contains the generic configuration. */
    settings: T;
    /**
     *Creates an instance of AxaAppConfig.
     */
    constructor();
    /**Loads the configuration. */
    load(): Promise<void>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaAppConfig<any>, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<AxaAppConfig<any>>;
}
/**Factory function to load the configuration. */
export declare function initializeAxaConfig<T>(appConfig: AxaAppConfig<T>): () => Promise<void>;

//# sourceMappingURL=axa-app.config.d.ts.map