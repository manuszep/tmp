import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/common';
import * as ɵngcc2 from '@angular/common/http';
export declare class AxaConfigModule {
    static forRoot(): ModuleWithProviders<AxaConfigModule>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaConfigModule, never, [typeof ɵngcc1.CommonModule, typeof ɵngcc2.HttpClientModule], never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaConfigModule>;
}

//# sourceMappingURL=axa-config.module.d.ts.map