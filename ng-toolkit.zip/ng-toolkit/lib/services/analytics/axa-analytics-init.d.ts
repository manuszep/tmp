import { InjectionToken, Provider } from '@angular/core';
export interface IAxaGaSettings {
    trackingCode: string;
    uri?: string;
    initCommands?: Array<IAxaGaCommand>;
}
export interface IAxaGaCommand {
    command: string;
    values: any[];
}
export declare const AXA_GA_SETTINGS_TOKEN: InjectionToken<IAxaGaSettings>;
export declare const AXA_GA_INIT_PROVIDER: Provider;
export declare function GoogleAnalyticsInitializer(settings: IAxaGaSettings): () => Promise<void>;
