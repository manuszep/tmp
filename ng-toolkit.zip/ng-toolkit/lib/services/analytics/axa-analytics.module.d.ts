import { ModuleWithProviders } from '@angular/core';
import { IAxaGaCommand } from './axa-analytics-init';
import * as ɵngcc0 from '@angular/core';
export declare class AxaAnalyticsModule {
    static forRoot(gaCode: string, commands?: IAxaGaCommand[], uri?: string): ModuleWithProviders<AxaAnalyticsModule>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaAnalyticsModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaAnalyticsModule>;
}

//# sourceMappingURL=axa-analytics.module.d.ts.map