import { Router } from '@angular/router';
/** Service to provide access to google analytics. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaGoogleAnalyticsService {
    private router;
    /**
     *Creates an instance of AxaGoogleAnalyticsService.
     * @param router The router to report page views.
     */
    constructor(router: Router);
    /** Will start tracking page views and reporting them to google analytics.
     * Only needs to be called once in the boostrap component for example (app.component.ts)
     */
    trackPageViews(): void;
    /** Emits a custom event to google analytics. */
    emitEvent(eventCategory: string, eventAction: string, eventLabel?: string, eventValue?: number): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaGoogleAnalyticsService, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<AxaGoogleAnalyticsService>;
}

//# sourceMappingURL=axa-google-analytics.d.ts.map