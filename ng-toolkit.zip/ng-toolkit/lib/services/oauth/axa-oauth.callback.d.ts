import { ActivatedRoute, Router } from '@angular/router';
/**
 * This directive takes care of parsing the token and redirecting to the AXA_OAUTH_REDIRECT_URI.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaOAuthCallbackComponent {
    private route;
    private router;
    private tokenStorageKey;
    /**
     * Creates an instance of AxaOAuthCallbackComponent.
     * @param route
     * The route used to parse the fragment of the url.
     * @param router
     * The router used for the redirection.
     * @param tokenStorageKey
     * The key where the token needs to be stored.
     */
    constructor(route: ActivatedRoute, router: Router, tokenStorageKey: string);
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaOAuthCallbackComponent, [null, null, { optional: true; }]>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaOAuthCallbackComponent, "axa-oauth-callback", never, {}, {}, never>;
}

//# sourceMappingURL=axa-oauth.callback.d.ts.map