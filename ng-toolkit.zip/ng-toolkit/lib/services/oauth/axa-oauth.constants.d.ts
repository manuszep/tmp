/**Key for the auth endpoint. */
export declare const AXA_OAUTH_ENDPOINT_KEY = "OAUTH2_AUTHENTICATION_ENDPOINT";
/**Key for the scope. */
export declare const AXA_OAUTH_SCOPE_KEY = "OAUTH2_SCOPE";
/**Key for the client id. */
export declare const AXA_OAUTH_CLIENTID_KEY = "OAUTH2_CLIENT_ID";
/**Key for the callback URL. */
export declare const AXA_OAUTH_CALLBACK_KEY = "OAUTH2_CALLBACK_URL";
/**Key for the token. */
export declare const AXA_OAUTH_TOKEN_KEY = "OAUTH2_TOKEN_STORAGE_KEY";
/**Key for the response type. Set to token by default. */
export declare const AXA_OAUTH_RESPONSE_TYPE = "OAUTH2_RESPONSE_TYPE";
/**Key for the redirect URI.  */
export declare const AXA_OAUTH_REDIRECT_URI = "redirect_uri";
/**Error for missing token key. */
export declare const AXA_TOKEN_KEY_MISSING_ERROR: Error;
/**Error for missing endpoint. */
export declare const AXA_ENDPOINT_MISSING_ERROR: Error;
/**Error for missing client id. */
export declare const AXA_CLIENTID_MISSING_ERROR: Error;
/**Error for missing scope. */
export declare const AXA_SCOPE_MISSING_ERROR: Error;
/**Error for failed retrieval of the token. */
export declare const AXA_TOKEN_RETRIEVE_FAILED_ERROR: Error;
