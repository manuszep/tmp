import { Router } from '@angular/router';
import { Observable } from 'rxjs';
/**
 * Service to do oauth authentification with the MAAM.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaOAuthService {
    private authenticationUrl;
    private scope;
    private clientId;
    private callbackUrl;
    private tokenStorageKey;
    private responseType;
    private token;
    private currentUrl;
    private authenticating;
    /**
     * Creates an instance of AxaOAuthService.
     * @param authenticationUrl The auth URL (AXA_OAUTH_ENDPOINT_KEY).
     * @param scope The scope (AXA_OAUTH_SCOPE_KEY).
     * @param clientId The client id (AXA_OAUTH_CLIENTID_KEY).
     * @param callbackUrl The callback URL (AXA_OAUTH_CALLBACK_KEY).
     * @param tokenStorageKey The token key in the storage (AXA_OAUTH_TOKEN_KEY).
     */
    constructor(authenticationUrl: string, scope: string, clientId: string, callbackUrl: string, tokenStorageKey: string, responseType: string, router: Router);
    /**
     * Gets a stream of the current token.
     */
    getToken(): Observable<string>;
    /**
     * Gets the token if it's there or authenticates and then returns the token.
     */
    getTokenOrAuthenticate(): Observable<string>;
    /**
     * Requires a new token from the MAAM.
     */
    authenticate(): Observable<string>;
    private saveDataForAutenticationCallback;
    /**
     * Removes the token from sessionstorage, this is not a disconnect function.
     */
    forgetToken(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaOAuthService, [{ optional: true; }, { optional: true; }, { optional: true; }, { optional: true; }, { optional: true; }, { optional: true; }, null]>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<AxaOAuthService>;
}

//# sourceMappingURL=axa-oauth.service.d.ts.map