import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-oauth.callback';
import * as ɵngcc2 from '@angular/router';
export declare class AxaOAuthModule {
    static forRoot(): ModuleWithProviders<AxaOAuthModule>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaOAuthModule, [typeof ɵngcc1.AxaOAuthCallbackComponent], [typeof ɵngcc2.RouterModule], [typeof ɵngcc1.AxaOAuthCallbackComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaOAuthModule>;
}

//# sourceMappingURL=axa-oauth.module.d.ts.map