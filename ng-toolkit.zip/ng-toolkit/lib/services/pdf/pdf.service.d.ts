import * as ɵngcc0 from '@angular/core';
export declare class PDFService {
    generateLandscape(content: HTMLElement, fileName: string, format?: string, heightPage?: number, widthPage?: number): void;
    generatePortrait(content: HTMLElement, fileName: string, format?: string, heightPage?: number, widthPage?: number): void;
    private generatePDF;
    private getCanvas;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<PDFService, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<PDFService>;
}

//# sourceMappingURL=pdf.service.d.ts.map