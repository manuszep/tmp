import * as ɵngcc0 from '@angular/core';
export declare class PDFModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<PDFModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<PDFModule>;
}

//# sourceMappingURL=pdf.module.d.ts.map