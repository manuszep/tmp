import { ErrorHandler, Injector } from '@angular/core';
/**
 * Implementation of a global error handler.
 * The axa implementation pushes alerts to {AxaAlertService}.
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaGlobalErrorHandler extends ErrorHandler {
    private injector;
    /**
     * Creates an instance of AxaGlobalErrorHandler.
     */
    constructor(injector: Injector);
    /**
     * Handles an uncaught error in the appliation.
     */
    handleError(error: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaGlobalErrorHandler, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<AxaGlobalErrorHandler>;
}

//# sourceMappingURL=axa-globalerrorhandler.d.ts.map