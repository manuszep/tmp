/**Key for the error close button string. */
export declare const AXA_ERROR_CLOSE_STRING = "AXA_ERROR_CLOSE_STRING";
/**Key for the error title string. */
export declare const AXA_ERROR_TITLE_STRING = "AXA_ERROR_TITLE_STRING";
