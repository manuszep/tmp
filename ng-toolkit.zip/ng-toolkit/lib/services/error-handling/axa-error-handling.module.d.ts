import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class AxaErrorHandlingModule {
    static forRoot(): ModuleWithProviders<AxaErrorHandlingModule>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaErrorHandlingModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaErrorHandlingModule>;
}

//# sourceMappingURL=axa-error-handling.module.d.ts.map