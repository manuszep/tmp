import * as ɵngcc0 from '@angular/core';
export declare class AxaGtmModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaGtmModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaGtmModule>;
}

//# sourceMappingURL=axa-gtm.module.d.ts.map