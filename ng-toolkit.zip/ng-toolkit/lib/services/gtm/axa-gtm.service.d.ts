import * as ɵngcc0 from '@angular/core';
export declare class AxaGtmService {
    private gtmId;
    private isLoaded;
    private readonly browserGlobals;
    constructor(gtmId: string);
    init(): void;
    pushTag(item: object): void;
    private appendId;
    private getDataLayer;
    private pushOnDataLayer;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaGtmService, [{ optional: true; }]>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<AxaGtmService>;
}

//# sourceMappingURL=axa-gtm.service.d.ts.map