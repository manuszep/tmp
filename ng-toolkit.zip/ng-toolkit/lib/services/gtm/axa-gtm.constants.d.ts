export declare const GTM_ID = "GTM_ID";
