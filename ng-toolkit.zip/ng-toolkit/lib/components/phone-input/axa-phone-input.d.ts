import { AfterViewInit, ChangeDetectorRef, Injector, OnDestroy, OnInit, QueryList } from '@angular/core';
import { ControlValueAccessor, FormGroupDirective, NgControl, NgForm } from '@angular/forms';
import { Subject } from 'rxjs';
import { AxaFormFieldControl } from '../form-field/axa-form-field.control';
import { CanUpdateParentErrorState } from '../mixins/parent-control.validation';
import { ErrorStateMatcher } from '../validation/validation';
import { AxaCountryService } from './axa-country.service';
import { Country } from './country.model';
/**Value Accessor provider to enable ngModel. */
import * as ɵngcc0 from '@angular/core';
export declare const AXA_PHONE_INPUT_CONTROL_VALUE_ACCESSOR: any;
/**@ignore */
export declare class AxaPhoneInputBase {
    _defaultErrorStateMatcher: ErrorStateMatcher;
    cdr: ChangeDetectorRef;
    _parentForm: NgForm;
    _parentFormGroup: FormGroupDirective;
    ngControl: NgControl;
    constructor(_defaultErrorStateMatcher: ErrorStateMatcher, cdr: ChangeDetectorRef, _parentForm: NgForm, _parentFormGroup: FormGroupDirective, ngControl: NgControl);
}
/**@ignore */
export declare const _AxaPhoneInputMixinBase: (new (...args: any[]) => CanUpdateParentErrorState) & typeof AxaPhoneInputBase;
/**Input to enter international phone number. */
export declare class AxaPhoneInputComponent extends _AxaPhoneInputMixinBase implements CanUpdateParentErrorState, AxaFormFieldControl<string>, ControlValueAccessor, OnInit, AfterViewInit, OnDestroy {
    ngControl: NgControl;
    cdr: ChangeDetectorRef;
    private _injector;
    private countrySvc;
    private _uniqueId;
    /**Default style of the step. */
    cls: boolean;
    /**
     * Stream that emits when the errorState of the control changes.
     */
    readonly errorStateChanges: Subject<void>;
    /**
     * Whether the control is in an error state.
     */
    errorState: boolean;
    /**
     * The name for this control.
     */
    name: string;
    /**
     * Whether the control is focused.
     */
    focused: boolean;
    /**
     * Whether the control is required.
     */
    get required(): boolean;
    set required(value: boolean);
    protected _required: boolean;
    /**
     * Whether the control is disabled.
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    protected _disabled: boolean;
    /**
     * Whether the control is readonly.
     */
    get readonly(): boolean;
    set readonly(value: boolean);
    private _readonly;
    /**
     * The placeholder for this control.
     */
    placeholder: string;
    /**
     * Element ID.
     */
    get id(): string;
    set id(value: string);
    protected _id: string;
    /**Translated favorite list of countries. */
    favoriteCountries: Country[];
    /**List of countries displayed. */
    countries: Country[];
    /**The selected dial country. */
    get selectedCountry(): Country;
    set selectedCountry(v: Country);
    protected _selectedCountry: any;
    /**The phone number. */
    get value(): string;
    set value(value: string);
    protected _value: string;
    /**Input associated with the internal input control. */
    inputValue: string;
    /**List of countries to display at the top, format: [favorites]="['NL','BE','FR']" */
    favorites: string[];
    /** Deafult country to be displayed, format default="NL" */
    default: string;
    /**The select controls used by the datepicker. */
    axaControls: QueryList<AxaFormFieldControl<any>>;
    /**
     *Creates an instance of AxaPhoneInputComponent.
     * @param ngControl the underlying control
     * @param parentForm the parent form
     * @param parentFormGroup the parent formgroup
     * @param defaultErrorStateMatcher the errorstatematcher that will be used
     * @param cdr changedetectorref
     * @param _injector dependency injector
     * @param countrySvc the country service
     */
    constructor(ngControl: NgControl, parentForm: NgForm, parentFormGroup: FormGroupDirective, defaultErrorStateMatcher: ErrorStateMatcher, cdr: ChangeDetectorRef, _injector: Injector, countrySvc: AxaCountryService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    /**Reacts to changes in the inner input control. */
    onInputChange(): void;
    /**Evaluates the input to read the dial code. */
    evaluateInput(): void;
    /**
     * Implementation of the value accessor.
     */
    valueAccessorChange: (value: string) => void;
    /**
     * Implementation of the value accessor.
     */
    writeValue(value: string): void;
    /**
     * Implementation of the value accessor.
     */
    registerOnChange(fn: any): void;
    /**
     * Implementation of the value accessor.
     */
    registerOnTouched(fn: any): void;
    /**
     * Implementation of the value accessor.
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaPhoneInputComponent, [{ optional: true; self: true; }, { optional: true; }, { optional: true; }, null, null, null, null]>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaPhoneInputComponent, "axa-phone-input", never, { "id": "id"; "required": "required"; "disabled": "disabled"; "readonly": "readonly"; "value": "value"; "name": "name"; "placeholder": "placeholder"; "favorites": "favorites"; "default": "default"; }, {}, never, never>;
}

//# sourceMappingURL=axa-phone-input.d.ts.map