/**Directive to only allow numeric input. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaNumbersOnlyDirective {
    private regexStr;
    /**Handles the key down event. */
    onKeyDown(event: KeyboardEvent): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaNumbersOnlyDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaNumbersOnlyDirective, "[axaNumbersOnly]", never, {}, {}, never>;
}

//# sourceMappingURL=axa-mask.directive.d.ts.map