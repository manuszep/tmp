import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-phone-input';
import * as ɵngcc2 from './axa-mask.directive';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from '@angular/forms';
import * as ɵngcc5 from '../select/axa-select.module';
import * as ɵngcc6 from '../input/axa-input.module';
import * as ɵngcc7 from '../form-field/axa-form-field.module';
export declare class AxaPhoneInputModule {
    static forRoot(): ModuleWithProviders<AxaPhoneInputModule>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaPhoneInputModule, [typeof ɵngcc1.AxaPhoneInputComponent, typeof ɵngcc2.AxaNumbersOnlyDirective], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.FormsModule, typeof ɵngcc5.AxaSelectModule, typeof ɵngcc6.AxaInputModule, typeof ɵngcc7.AxaFormFieldModule], [typeof ɵngcc1.AxaPhoneInputComponent, typeof ɵngcc2.AxaNumbersOnlyDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaPhoneInputModule>;
}

//# sourceMappingURL=axa-phone-input.module.d.ts.map