import { Country } from './country.model';
/**Service that returns a list of countries. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaCountryService {
    /**Returns an array of all the countries. */
    getCountries(): Country[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaCountryService, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<AxaCountryService>;
}

//# sourceMappingURL=axa-country.service.d.ts.map