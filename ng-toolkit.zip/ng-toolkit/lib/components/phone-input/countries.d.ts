/**Json array of the countries. */
export declare const countries: {
    name: string;
    dial: string;
    code: string;
}[];
