/**Country representation with dial prefix. */
export interface Country {
    /**Name of the country. */
    name: string;
    /**Country code. */
    code: string;
    /**International dial prefix. */
    dial: string;
}
