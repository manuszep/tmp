/**Axa busy container style. */
export declare const BUSY_CONTAINER = "axa-busy-indicator-wrapper";
/**Axa busy container full screen style. */
export declare const BUSY_CONTAINER_FULL_SCREEN = "axa-busy-indicator-wrapper--fixed";
