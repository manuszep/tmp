/**
 * The busy component displayed by the busy raw directive
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaBusyRawComponent {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaBusyRawComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaBusyRawComponent, "axa-busy-raw-component", never, {}, {}, never, never>;
}

//# sourceMappingURL=axa-busy-raw.d.ts.map