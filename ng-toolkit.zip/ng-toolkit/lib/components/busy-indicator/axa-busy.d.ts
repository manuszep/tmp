/**
 * The busy component displayed by the busy directive
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaBusyComponent {
    /**
     * The busy message displayed, defaults to 'loading'.
     */
    message: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaBusyComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaBusyComponent, "axa-busy-component", never, { "message": "message"; }, {}, never, never>;
}

//# sourceMappingURL=axa-busy.d.ts.map