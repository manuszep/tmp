import { ComponentFactoryResolver, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Subscription } from 'rxjs';
/**
 * Directive used to connect an observable or promise to the busy indicator.
 * You can optionnally add a message too.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaBusyRawDirective implements OnInit, OnDestroy {
    private componentFactory;
    private viewContainer;
    private template;
    private busyRef;
    private backdropRef;
    private backdropElement;
    private busyElement;
    private parentElement;
    private asyncOperation;
    /**
     * Busy promise or observable input
     */
    set axaBusyRaw(busy: Promise<any> | Subscription | boolean);
    /**
     * Creates an instance of AxaBusyDirective.
     */
    constructor(componentFactory: ComponentFactoryResolver, viewContainer: ViewContainerRef, template: TemplateRef<any>);
    private processBusy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    private createViews;
    private createBusy;
    private busyFinished;
    private deleteViews;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaBusyRawDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaBusyRawDirective, "[axaBusyRaw]", never, { "axaBusyRaw": "axaBusyRaw"; }, {}, never>;
}

//# sourceMappingURL=axa-busy-raw.directive.d.ts.map