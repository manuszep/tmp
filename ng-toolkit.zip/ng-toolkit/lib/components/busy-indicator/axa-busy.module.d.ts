import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-busy';
import * as ɵngcc2 from './axa-busy-backdrop';
import * as ɵngcc3 from './axa-busy.directive';
import * as ɵngcc4 from './axa-busy-container.directive';
import * as ɵngcc5 from './axa-busy-raw';
import * as ɵngcc6 from './axa-busy-raw.directive';
export declare class AxaBusyModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaBusyModule, [typeof ɵngcc1.AxaBusyComponent, typeof ɵngcc2.AxaBusyBackdropComponent, typeof ɵngcc3.AxaBusyDirective, typeof ɵngcc4.AxaBusyContainerDirective, typeof ɵngcc4.AxaBusyContainerFullScreenDirective, typeof ɵngcc5.AxaBusyRawComponent, typeof ɵngcc6.AxaBusyRawDirective], never, [typeof ɵngcc3.AxaBusyDirective, typeof ɵngcc4.AxaBusyContainerDirective, typeof ɵngcc4.AxaBusyContainerFullScreenDirective, typeof ɵngcc6.AxaBusyRawDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaBusyModule>;
}

//# sourceMappingURL=axa-busy.module.d.ts.map