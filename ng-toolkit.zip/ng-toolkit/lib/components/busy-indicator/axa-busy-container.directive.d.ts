import { ElementRef } from '@angular/core';
/**Busy directive for local busy. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaBusyContainerDirective {
    private el;
    /**The native element decorated. */
    host: HTMLElement;
    /**
     *Creates an instance of AxaBusyContainerDirective.
     * @param  el The element ref.
     */
    constructor(el: ElementRef);
    /**Adds the default style. */
    addDefaultStyles(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaBusyContainerDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaBusyContainerDirective, "[AxaBusyContainer]", never, {}, {}, never>;
}
/**Busy directive for fullscreen busy. */
export declare class AxaBusyContainerFullScreenDirective {
    private el;
    /**The native element decorated. */
    host: HTMLElement;
    /**
     *Creates an instance of AxaBusyContainerFullScreenDirective.
     * @param  el The element ref
     */
    constructor(el: ElementRef);
    /**Adds the default style. */
    addDefaultStyles(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaBusyContainerFullScreenDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaBusyContainerFullScreenDirective, "[AxaBusyContainerFullScreen]", never, {}, {}, never>;
}

//# sourceMappingURL=axa-busy-container.directive.d.ts.map