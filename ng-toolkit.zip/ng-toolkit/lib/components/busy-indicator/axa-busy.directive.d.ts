import { ComponentFactoryResolver, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Subscription } from 'rxjs';
/**
 * Directive used to connect an observable or promise to the busy indicator.
 * You can optionnally add a message too.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaBusyDirective implements OnInit, OnDestroy {
    private componentFactory;
    private viewContainer;
    private template;
    private busyRef;
    private backdropRef;
    private backdropElement;
    private busyElement;
    private parentElement;
    private asyncOperation;
    /**
     * Busy promise or observable input
     */
    set axaBusy(busy: Promise<any> | Subscription | boolean);
    /**
     * Busy message to display with the animation.
     */
    axaBusyMessage: string;
    /**
     * Creates an instance of AxaBusyDirective.
     */
    constructor(componentFactory: ComponentFactoryResolver, viewContainer: ViewContainerRef, template: TemplateRef<any>);
    private processBusy;
    ngOnInit(): void;
    ngOnDestroy(): void;
    private createViews;
    private createBusy;
    private busyFinished;
    private deleteViews;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaBusyDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaBusyDirective, "[axaBusy]", never, { "axaBusy": "axaBusy"; "axaBusyMessage": "axaBusyMessage"; }, {}, never>;
}

//# sourceMappingURL=axa-busy.directive.d.ts.map