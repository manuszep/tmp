/**
 * The backdrop displayed with the busy component.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaBusyBackdropComponent {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaBusyBackdropComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaBusyBackdropComponent, "axa-busy-backdrop", never, {}, {}, never, never>;
}

//# sourceMappingURL=axa-busy-backdrop.d.ts.map