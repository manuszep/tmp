import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-form-field';
import * as ɵngcc2 from './axa-error';
import * as ɵngcc3 from './axa-hint';
import * as ɵngcc4 from './axa-prefix';
import * as ɵngcc5 from './axa-suffix';
import * as ɵngcc6 from '@angular/common';
export declare class AxaFormFieldModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaFormFieldModule, [typeof ɵngcc1.AxaFormField, typeof ɵngcc2.AxaError, typeof ɵngcc3.AxaHint, typeof ɵngcc4.AxaPrefixDirective, typeof ɵngcc5.AxaSuffixDirective], [typeof ɵngcc6.CommonModule], [typeof ɵngcc1.AxaFormField, typeof ɵngcc2.AxaError, typeof ɵngcc3.AxaHint, typeof ɵngcc4.AxaPrefixDirective, typeof ɵngcc5.AxaSuffixDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaFormFieldModule>;
}

//# sourceMappingURL=axa-form-field.module.d.ts.map