/** Info message to be shown underneath the form field. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaHint {
    /**The id of the control. */
    id: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaHint, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaHint, "axa-hint", never, { "id": "id"; }, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-hint.d.ts.map