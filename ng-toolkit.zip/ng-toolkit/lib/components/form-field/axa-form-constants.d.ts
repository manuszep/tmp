/**Form error style. */
export declare const FORM_ERROR_STYLE = "axa-form-group--has-danger";
