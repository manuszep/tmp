/**Directive to attach an HTML element as a suffix in a form field. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaSuffixDirective {
    /**Style applied to the suffix element. */
    className: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaSuffixDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaSuffixDirective, "axa-suffix", never, {}, {}, never>;
}

//# sourceMappingURL=axa-suffix.d.ts.map