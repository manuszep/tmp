/** Error message to be shown underneath the form field. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaError {
    /**The id of the control. */
    id: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaError, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaError, "axa-error", never, { "id": "id"; }, {}, never>;
}

//# sourceMappingURL=axa-error.d.ts.map