import { NgControl } from '@angular/forms';
import { Observable } from 'rxjs';
/**
 * Allows a control to work inside an AxaFormField.
 */
export declare abstract class AxaFormFieldControl<T> {
    /** The value of the control. */
    value: T | null;
    /**
     * Element ID.
     */
    readonly id: string;
    /**
     * Whether the control is in an error state.
     */
    readonly errorState: boolean;
    /**
     * The angular control attached to this element.
     */
    readonly ngControl: NgControl | null;
    /**
    * Whether the control is focused.
    */
    readonly focused: boolean;
    /**
     * Whether the control is required.
     */
    readonly required: boolean;
    /**
     * Whether the control is disabled.
     */
    readonly disabled: boolean;
    /**
     * Stream that emits when the errorState of the control changes.
     */
    readonly errorStateChanges: Observable<void>;
    /**Streams that emits when the control is touched. */
    readonly touchedChanges?: Observable<string>;
}
