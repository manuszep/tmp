import { AfterContentInit, QueryList, AfterContentChecked, ChangeDetectorRef, ElementRef } from '@angular/core';
import { AxaFormFieldControl } from './axa-form-field.control';
import { AxaError } from './axa-error';
import { AxaHint } from './axa-hint';
/**
 * Container for form inputs that displays errors and hints.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaFormField implements AfterContentInit, AfterContentChecked {
    private cdr;
    /**
     * The control contained in the form field.
     */
    control: AxaFormFieldControl<any>;
    /**
     * The list of errors to be displayed.
     */
    axaErrors: QueryList<AxaError>;
    /**
     * The list of hints to be displayed.
     */
    axaHints: QueryList<AxaHint>;
    /**The base div of the component. */
    divRef: ElementRef;
    /**
     * Label field of the form field
     */
    label: string;
    /**
     * Whether to display the error state.
     */
    showError: boolean;
    /**
     *Creates an instance of AxaFormField.
     * @param cdr change detector ref
     */
    constructor(cdr: ChangeDetectorRef);
    ngAfterContentInit(): void;
    ngAfterContentChecked(): void;
    /**Applies the error style to the root div. */
    applyErrorStyle(): any;
    private showErrorOrHint;
    protected checkChildIsAxaControl(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaFormField, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaFormField, "axa-form-field", never, { "label": "label"; }, {}, ["control", "axaErrors", "axaHints"], ["axa-prefix", "*", "axa-suffix", "axa-error", "axa-hint"]>;
}

//# sourceMappingURL=axa-form-field.d.ts.map