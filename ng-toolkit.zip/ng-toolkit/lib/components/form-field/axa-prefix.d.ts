/**Directive to attach an HTML element as a prefix in a form field. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaPrefixDirective {
    /**Style applied to the prefix element. */
    className: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaPrefixDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaPrefixDirective, "axa-prefix", never, {}, {}, never>;
}

//# sourceMappingURL=axa-prefix.d.ts.map