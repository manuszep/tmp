import { ElementRef } from '@angular/core';
/**
 * Defines all the flags icons available in the toolkit.
 * Takes care of applying the styles to a button.
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaFlagIcon {
    private el;
    private host;
    private _country;
    /**
     * Creates an instance of AxaFlagIcon.
     * @param el
     * ElementRef to modify styles.
     */
    constructor(el: ElementRef);
    /**Applies country styling. */
    set country(country: any);
    private addDefaultStyles;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaFlagIcon, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaFlagIcon, "[axa-flag-icon]", never, { "country": "country"; }, {}, never>;
}

//# sourceMappingURL=flag-icon.d.ts.map