import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './flag-icon';
import * as ɵngcc2 from '@angular/common';
export declare class AxaFlagIconModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaFlagIconModule, [typeof ɵngcc1.AxaFlagIcon], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaFlagIcon]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaFlagIconModule>;
}

//# sourceMappingURL=flag-icon.module.d.ts.map