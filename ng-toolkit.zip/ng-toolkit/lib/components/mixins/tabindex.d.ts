declare type Constructor<T> = new (...args: any[]) => T;
import { CanDisable } from './disabled';
/**@ignore */
export interface HasTabIndex {
    tabIndex: number;
}
/** Mixin to augment a directive with a `tabIndex` property. */
export declare function mixinTabIndex<T extends Constructor<CanDisable>>(base: T, defaultTabIndex?: number): Constructor<HasTabIndex> & T;
export {};
