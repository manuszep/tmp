import { FormGroupDirective, NgControl, NgForm } from '@angular/forms';
import { Subject } from 'rxjs';
import { ErrorStateMatcher } from '../validation/validation';
declare type Constructor<T> = new (...args: any[]) => T;
/** @ignore */
export interface CanUpdateErrorState {
    readonly errorStateChanges: Subject<void>;
    readonly touchedChanges: Subject<string>;
    errorState: boolean;
    errorStateMatcher: ErrorStateMatcher;
    updateErrorState(): any;
}
/** @ignore */
export interface HasErrorState {
    _parentFormGroup: FormGroupDirective;
    _parentForm: NgForm;
    _defaultErrorStateMatcher: ErrorStateMatcher;
    ngControl: NgControl;
}
/**
 * Mixin to augment a directive with updateErrorState method.
 * For component with `errorState` and need to update `errorState`.
 */
export declare function mixinErrorState<T extends Constructor<HasErrorState>>(base: T): Constructor<CanUpdateErrorState> & T;
export {};
