import { QueryList, ChangeDetectorRef } from '@angular/core';
import { FormGroupDirective, NgForm, NgControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { ErrorStateMatcher } from '../validation/validation';
import { AxaFormFieldControl } from '../form-field/axa-form-field.control';
declare type Constructor<T> = new (...args: any[]) => T;
/** @ignore */
export interface CanUpdateParentErrorState {
    readonly errorStateChanges: Subject<void>;
    errorState: boolean;
    errorStateMatcher: ErrorStateMatcher;
    childrenControls: QueryList<AxaFormFieldControl<any>>;
    updateErrorState(): any;
    valueAccessorTouch(): any;
    monitorChildrenControls(): any;
    unMonitorChildrenControls(): any;
}
/** @ignore */
export interface HasParentErrorState {
    _parentFormGroup: FormGroupDirective;
    _parentForm: NgForm;
    _defaultErrorStateMatcher: ErrorStateMatcher;
    ngControl: NgControl;
    cdr: ChangeDetectorRef;
}
/**
 * Mixin to augment a directive with updateErrorState method.
 * For component with `errorState` and need to update `errorState`.
 */
export declare function mixinParentErrorState<T extends Constructor<HasParentErrorState>>(base: T): Constructor<CanUpdateParentErrorState> & T;
export {};
