/**The meta domain link in the header. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaHeaderMetaDomainDirective {
    /**Default styling of domain link. */
    cls: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaHeaderMetaDomainDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaHeaderMetaDomainDirective, "axa-header-meta-domain", never, {}, {}, never>;
}
/**The meta helper link in the header. */
export declare class AxaHeaderMetaHelperDirective {
    /**Default styling of helper link. */
    cls: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaHeaderMetaHelperDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaHeaderMetaHelperDirective, "axa-header-meta-helper", never, {}, {}, never>;
}

//# sourceMappingURL=axa-header-meta.directive.d.ts.map