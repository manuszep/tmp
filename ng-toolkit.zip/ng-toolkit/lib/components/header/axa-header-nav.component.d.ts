/**Navigation element of the header. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaHeaderNavComponent {
    /**Default style for the the header nav. */
    cls: boolean;
    /**The link associated with this navigation element. */
    link: string;
    /**Whether to apply the button styling. */
    button: boolean;
    private _active;
    /**Active state of the navigation element. */
    set active(value: boolean);
    /**Styling for the active state. */
    get activeClass(): string | boolean;
    /**Styling for the button state. */
    get buttonClass(): string | boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaHeaderNavComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaHeaderNavComponent, "axa-header-nav", never, { "active": "active"; "link": "link"; "button": "button"; }, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-header-nav.component.d.ts.map