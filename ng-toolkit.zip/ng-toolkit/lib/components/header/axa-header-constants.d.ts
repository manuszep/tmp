/**Default style. */
export declare const HEADER_CLASS_BASE = "axa-header";
/**Meta domain style. */
export declare const HEADER_CLASS_META_DOMAIN: string;
/**Meta helper style. */
export declare const HEADER_CLASS_META_HELPER: string;
/**search button style. */
export declare const HEADER_CLASS_SEARCH: string;
/**Navigation link style. */
export declare const HEADER_CLASS_NAV_LINK: string;
/**Active navigation link style. */
export declare const HEADER_CLASS_NAV_LINK_ACTIVE: string;
/**Button navigation link style. */
export declare const HEADER_CLASS_NAV_LINK_BUTTON: string;
