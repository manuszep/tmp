import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-header.component';
import * as ɵngcc2 from './axa-header-meta.directive';
import * as ɵngcc3 from './axa-header-nav.component';
import * as ɵngcc4 from './axa-header-search.component';
import * as ɵngcc5 from '@angular/common';
import * as ɵngcc6 from '@angular/router';
import * as ɵngcc7 from '@angular/forms';
import * as ɵngcc8 from '../button/axa-button.module';
export declare class AxaHeaderModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaHeaderModule, [typeof ɵngcc1.AxaHeaderComponent, typeof ɵngcc2.AxaHeaderMetaDomainDirective, typeof ɵngcc2.AxaHeaderMetaHelperDirective, typeof ɵngcc3.AxaHeaderNavComponent, typeof ɵngcc4.AxaHeaderSearchComponent], [typeof ɵngcc5.CommonModule, typeof ɵngcc6.RouterModule, typeof ɵngcc7.FormsModule, typeof ɵngcc8.AxaButtonModule], [typeof ɵngcc1.AxaHeaderComponent, typeof ɵngcc2.AxaHeaderMetaDomainDirective, typeof ɵngcc2.AxaHeaderMetaHelperDirective, typeof ɵngcc3.AxaHeaderNavComponent, typeof ɵngcc4.AxaHeaderSearchComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaHeaderModule>;
}

//# sourceMappingURL=axa-header.module.d.ts.map