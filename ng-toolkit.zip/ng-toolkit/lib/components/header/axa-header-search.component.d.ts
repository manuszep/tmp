import { EventEmitter } from '@angular/core';
/**
 *The search element of the header.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaHeaderSearchComponent {
    /**Default styling of the search element. */
    cls: boolean;
    /**Event that happens when the search is triggered. */
    search: EventEmitter<string>;
    /**Placeholder in the search input. */
    placeholder: string;
    /**Value entered in the search input. */
    headerSearchValue: string;
    /**Emits the search event. */
    onSubmit(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaHeaderSearchComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaHeaderSearchComponent, "axa-header-search", never, { "placeholder": "placeholder"; }, { "search": "search"; }, never, never>;
}

//# sourceMappingURL=axa-header-search.component.d.ts.map