import { ElementRef, OnInit } from '@angular/core';
/**Component to generate the navigation bar */
import * as ɵngcc0 from '@angular/core';
export declare class AxaHeaderComponent implements OnInit {
    private headerEl;
    /**Default style for the header. */
    cls: string;
    private _domains;
    private _helpers;
    private _navigateEl;
    navToggleValue: boolean;
    /**Unique id for the header. */
    uuid: string;
    /**Whether any domain is provided. */
    hasDomains(): boolean;
    /**Whether any helper is provided. */
    hasHelpers(): boolean;
    /**Whether any meta is provided. */
    hasMeta(): boolean;
    private guid;
    constructor(headerEl: ElementRef);
    ngOnInit(): void;
    clickout(event: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaHeaderComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaHeaderComponent, "axa-header", never, {}, {}, ["_domains", "_helpers"], ["axa-header-meta-domain", "axa-header-meta-helper", "axa-header-nav, axa-header-nav-route", "axa-header-search"]>;
}

//# sourceMappingURL=axa-header.component.d.ts.map