import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-icon.component';
export declare class AxaIconModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaIconModule, [typeof ɵngcc1.IconComponent], never, [typeof ɵngcc1.IconComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaIconModule>;
}

//# sourceMappingURL=axa-icon.module.d.ts.map