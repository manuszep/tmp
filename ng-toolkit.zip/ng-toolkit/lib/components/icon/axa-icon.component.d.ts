import { ElementRef } from '@angular/core';
/**Component to display icons. */
import * as ɵngcc0 from '@angular/core';
export declare class IconComponent {
    private el;
    /**Name of the icon to display. */
    name: string;
    private host;
    /**
     * Creates an instance of IconComponent.
     * @param el
     * ElementRef to modify styles.
     */
    constructor(el: ElementRef);
    /**Gets the path of the icon. */
    getPath(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<IconComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<IconComponent, "axa-icon", never, { "name": "name"; }, {}, never, never>;
}

//# sourceMappingURL=axa-icon.component.d.ts.map