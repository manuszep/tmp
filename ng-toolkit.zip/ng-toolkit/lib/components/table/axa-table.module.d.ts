import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-table';
import * as ɵngcc2 from '@angular/common';
export declare class AxaTableModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaTableModule, [typeof ɵngcc1.AxaTable], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaTable]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaTableModule>;
}

//# sourceMappingURL=axa-table.module.d.ts.map