import { ElementRef } from '@angular/core';
/**
 * Takes care of applying the styles to a table.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaTable {
    private _flexDown;
    private _host;
    /** Weither the card is active. */
    set flexDown(value: string);
    get flexDown(): string;
    /**Creates an instance of AxaTable. */
    constructor(el: ElementRef);
    private applyStyles;
    /**Returns the css classes. */
    getClass(): string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaTable, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaTable, "axa-table", never, { "flexDown": "flex-down"; }, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-table.d.ts.map