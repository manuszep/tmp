/**Wrapper class for the axa table. */
export declare const TABLE_CLASS_WRAPPER = "axa-table-wrapper";
/**Different flex values for the axa table. */
export declare const TABLE_CLASS_FLEX: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
};
/**This dictionary contains all the styles to apply for the table. */
export declare const TABLE_STYLES: {
    [name: string]: string[];
};
