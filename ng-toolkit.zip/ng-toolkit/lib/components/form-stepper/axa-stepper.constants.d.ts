/**Default stepper style. */
export declare const CLASS_BASE = "axa-form-steps";
/**Wrapper style. */
export declare const CLASS_WRAPPER: string;
/**Step style. */
export declare const CLASS_STEP: string;
/**Pricing step style. */
export declare const CLASS_STEP_PRICING: string;
/**progress bar style. */
export declare const CLASS_PROGRESS: string;
/**Active step style. */
export declare const CLASS_STEP_ACTIVE: string;
/**Done step style. */
export declare const CLASS_STEP_DONE: string;
