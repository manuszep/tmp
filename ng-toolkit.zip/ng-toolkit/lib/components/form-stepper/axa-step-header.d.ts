import { ChangeDetectorRef, OnDestroy } from '@angular/core';
import { AxaStepComponent } from './axa-step.component';
/**
 *Step generated at runtime to display progress.
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaStepHeaderComponent implements OnDestroy {
    private cdr;
    private _labelSub;
    private _pricing;
    private _step;
    constructor(cdr: ChangeDetectorRef);
    /**Type of the step. */
    type: string;
    /**The step. */
    get step(): AxaStepComponent;
    set step(step: AxaStepComponent);
    /**Label of the step. */
    label: string;
    /**Default style of the step. */
    cls: boolean;
    /**Active style of the step. */
    active: boolean;
    /**Done style of the step. */
    done: boolean;
    /**Pricing style of the step. */
    get pricingClass(): boolean;
    /**Weither this is a pricing step. */
    get pricing(): boolean;
    set pricing(value: boolean);
    ngOnDestroy(): void;
    private subToLabelChange;
    /**Gets the progress of the step. */
    getWidth(): string | null;
    /**Gets the label of the step. */
    getLabel(): string | null;
    /**Gets the progress class of the step. */
    getProgressClass(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaStepHeaderComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaStepHeaderComponent, "axa-step-header", never, { "active": "active"; "done": "done"; "step": "step"; "pricing": "pricing"; "label": "label"; "type": "type"; }, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-step-header.d.ts.map