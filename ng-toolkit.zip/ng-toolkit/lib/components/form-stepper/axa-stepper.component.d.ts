import { QueryList } from '@angular/core';
import { AxaStepComponent } from './axa-step.component';
import { AxaStepHeaderComponent } from './axa-step-header';
/**
 *Stepper control to display forms in a workflow format.
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaStepperComponent {
    private _current;
    /**The current step. */
    get current(): number;
    set current(value: number);
    /**The steps entered by the user step. */
    steps: QueryList<AxaStepComponent>;
    /**The headers generated from the steps. */
    stepHeaders: QueryList<AxaStepHeaderComponent>;
    /**Gets the wrapper class. */
    getWrapperClass(): string;
    /**Gets the active step. */
    getActive(index: number): boolean;
    /**Gets the done steps. */
    getDone(index: number): boolean;
    /**Gets the default style. */
    getClass(): string;
    /**Gets the transform of the view. */
    getTransform(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaStepperComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaStepperComponent, "axa-stepper", never, { "current": "current"; }, {}, ["steps"], never>;
}

//# sourceMappingURL=axa-stepper.component.d.ts.map