import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-stepper.component';
import * as ɵngcc2 from './axa-step.component';
import * as ɵngcc3 from './axa-step-header';
import * as ɵngcc4 from '@angular/common';
export declare class AxaStepperModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaStepperModule, [typeof ɵngcc1.AxaStepperComponent, typeof ɵngcc2.AxaStepComponent, typeof ɵngcc3.AxaStepHeaderComponent], [typeof ɵngcc4.CommonModule], [typeof ɵngcc1.AxaStepperComponent, typeof ɵngcc2.AxaStepComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaStepperModule>;
}

//# sourceMappingURL=axa-stepper.module.d.ts.map