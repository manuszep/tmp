import { TemplateRef, EventEmitter } from '@angular/core';
/**The step provided by the user. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaStepComponent {
    private _pricing;
    private _label;
    /**The content of the step. */
    content: TemplateRef<any>;
    /**The type of the step. */
    type: string;
    /**The label of the step. */
    set label(value: string);
    get label(): string;
    labelChange: EventEmitter<string>;
    /**Weither this is a pricing step. */
    set pricing(value: boolean);
    get pricing(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaStepComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaStepComponent, "axa-step", never, { "label": "label"; "pricing": "pricing"; "type": "type"; }, { "labelChange": "labelChange"; }, never, ["*"]>;
}

//# sourceMappingURL=axa-step.component.d.ts.map