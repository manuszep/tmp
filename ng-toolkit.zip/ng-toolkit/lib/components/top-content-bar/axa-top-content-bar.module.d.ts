import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-top-content-bar.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '../button/axa-button.module';
export declare class AxaTopContentBarModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaTopContentBarModule, [typeof ɵngcc1.AxaTopContentBarComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.AxaButtonModule], [typeof ɵngcc1.AxaTopContentBarComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaTopContentBarModule>;
}

//# sourceMappingURL=axa-top-content-bar.module.d.ts.map