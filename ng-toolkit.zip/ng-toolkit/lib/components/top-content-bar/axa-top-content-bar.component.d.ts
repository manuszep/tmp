import { EventEmitter } from '@angular/core';
/**
 * Alert component message displayed by the `AxaAlertManager`
 * @export
 * ### Example
 * ```
 * <axa-alert-manager></axa-alert-manager>
 * ```
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaTopContentBarComponent {
    /**
     * The type of content.
     * Can be corporate, commercial or warning.
     */
    type: string;
    /**
     * The ref the button links too.
     */
    href: string;
    /**
     * The text displayed on the button.
     */
    buttonLabel: string;
    /**
     * Occurs when the button is clicked.
     */
    buttonClick: EventEmitter<any>;
    /**
     * Creates an instance of AxaTopContentBarComponent.
     */
    constructor();
    /**
     * Handles the click on the button.
     */
    handleClick(e: MouseEvent): void;
    /**
     * Sets the css class depending on type.
     */
    getTypeClass(): string;
    /**
     * Sets the base css class.
     */
    getClass(): string;
    /**
     * Sets the base css content class.
     */
    getContentClass(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaTopContentBarComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaTopContentBarComponent, "axa-top-content-bar", never, { "type": "type"; "href": "href"; "buttonLabel": "buttonLabel"; }, { "buttonClick": "buttonClick"; }, never, ["*"]>;
}

//# sourceMappingURL=axa-top-content-bar.component.d.ts.map