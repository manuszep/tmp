/** Base css class. */
export declare const AXA_BAR_CLASS_BASE = "axa-top-content-bar";
/** Corporate css class. */
export declare const AXA_BAR_CLASS_CORPORATE = "corporate";
/** Commercial css class. */
export declare const AXA_BAR_CLASS_COMMERCIAL = "commercial";
/** Warning css class. */
export declare const AXA_BAR_CLASS_WARNING = "warning";
/** Base content css class. */
export declare const AXA_BAR_CLASS_CONTENT = "content";
