/** Coerces a data-bound value to a boolean. */
export declare function coerceBooleanProperty(value: any): boolean;
