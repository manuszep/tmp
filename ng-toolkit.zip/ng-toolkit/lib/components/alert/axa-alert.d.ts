/**
 * Alert message displayed by the `AxaAlertManager`
 * @export
 */
export interface AxaAlert {
    /**
     * the message displayed
     */
    message: string;
    /**
     * The type of the alert.
     */
    type?: string;
    /**
     * The associated handlers to the alert.
     */
    action?: AxaAlertAction;
    /**
     * The time in ms to keep the alert open.
     */
    ttl?: number;
}
/**
 * The handler for the alert.
 */
export interface AxaAlertAction {
    /**
     * The content of the action button.
     */
    content: (() => string) | string;
    /**
     * The method called by the handler.
     */
    handler: (action: AxaAlertAction, alert?: AxaAlert) => void;
}
