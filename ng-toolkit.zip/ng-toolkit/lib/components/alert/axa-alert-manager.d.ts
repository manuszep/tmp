import { OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { AxaAlertService } from './axa-alert.service';
import { AxaAlert } from './axa-alert';
/**
 * The alert manager displays the alerts submitted to the alert service.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaAlertManager implements OnInit, OnDestroy {
    private alertSvc;
    private cdr;
    private removeAlertSub;
    private newAlertSub;
    /** List of alerts received from the alert service. */
    alerts: AxaAlert[];
    /**
     * Creates an instance of AxaAlertManager.
     */
    constructor(alertSvc: AxaAlertService, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaAlertManager, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaAlertManager, "axa-alert-manager", never, {}, {}, never, never>;
}

//# sourceMappingURL=axa-alert-manager.d.ts.map