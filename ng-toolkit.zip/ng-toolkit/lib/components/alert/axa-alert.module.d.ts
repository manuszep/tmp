import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-alert-manager';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '../top-content-bar/axa-top-content-bar.module';
export declare class AxaAlertModule {
    static forRoot(): ModuleWithProviders<AxaAlertModule>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaAlertModule, [typeof ɵngcc1.AxaAlertManager], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.AxaTopContentBarModule], [typeof ɵngcc1.AxaAlertManager]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaAlertModule>;
}

//# sourceMappingURL=axa-alert.module.d.ts.map