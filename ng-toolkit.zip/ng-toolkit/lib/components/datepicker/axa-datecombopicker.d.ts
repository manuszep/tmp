import { OnInit, QueryList, AfterViewInit, ElementRef, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { NgControl, ControlValueAccessor, NgForm, FormGroupDirective } from '@angular/forms';
import { AxaFormFieldControl } from '../form-field/axa-form-field.control';
import { AxaSelect } from '../select/axa-select';
import { Subject } from 'rxjs';
import { ErrorStateMatcher } from '../validation/validation';
import { CanUpdateParentErrorState } from '../mixins/parent-control.validation';
/**Value Accessor provider to enable ngModel. */
import * as ɵngcc0 from '@angular/core';
export declare const AXA_DATECOMBOPICKER_CONTROL_VALUE_ACCESSOR: any;
/**@ignore */
export declare class AxaDateComboBase {
    _defaultErrorStateMatcher: ErrorStateMatcher;
    cdr: ChangeDetectorRef;
    _parentForm: NgForm;
    _parentFormGroup: FormGroupDirective;
    ngControl: NgControl;
    constructor(_defaultErrorStateMatcher: ErrorStateMatcher, cdr: ChangeDetectorRef, _parentForm: NgForm, _parentFormGroup: FormGroupDirective, ngControl: NgControl);
}
/**@ignore */
export declare const _AxaDateComboBase: (new (...args: any[]) => CanUpdateParentErrorState) & typeof AxaDateComboBase;
/**Date picker control. */
export declare class AxaDateComboPicker extends _AxaDateComboBase implements CanUpdateParentErrorState, AxaFormFieldControl<Date>, ControlValueAccessor, OnInit, OnDestroy, AfterViewInit {
    ngControl: NgControl;
    private parentForm;
    private parentFormGroup;
    cdr: ChangeDetectorRef;
    private _uniqueId;
    /**
     * Element ID.
     */
    get id(): string;
    set id(value: string);
    protected _id: string;
    /**
     * Stream that emits when the errorState of the control changes.
     */
    readonly errorStateChanges: Subject<void>;
    /**
     * Whether the control is in an error state.
     */
    errorState: boolean;
    /**
     * The placeholder for this control.
     */
    placeholder: string;
    /**
     * The name for this control.
     */
    name: string;
    /**
     * Whether the control is focused.
     */
    focused: boolean;
    /**
     * Whether the control is required.
     */
    get required(): boolean;
    set required(value: boolean);
    protected _required: boolean;
    /**
     * Whether the control is disabled.
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    protected _disabled: boolean;
    /**
     * Whether the control is readonly.
     */
    get readonly(): boolean;
    set readonly(value: boolean);
    private _readonly;
    /**List of days. */
    days: number[];
    /**List of months. */
    months: number[];
    /**List of years. */
    years: number[];
    private _selectedDay;
    /**The selected day. */
    get selectedDay(): number;
    set selectedDay(value: number);
    private _selectedMonth;
    /**The selected month. */
    get selectedMonth(): number;
    set selectedMonth(value: number);
    private _selectedYear;
    /**The selected year. */
    get selectedYear(): number;
    set selectedYear(value: number);
    private _value;
    /**The selected Date. */
    get value(): Date;
    set value(value: Date);
    /**The underlying ngControl. */
    private host;
    /**The select controls used by the datepicker. */
    axaSelects: QueryList<AxaSelect>;
    _minDate: Date;
    get minDate(): Date;
    set minDate(minDate: Date);
    _maxDate: Date;
    /**The latest date that is selectable. */
    get maxDate(): Date;
    set maxDate(maxDate: Date);
    /**
     *Creates an instance of AxaDateComboPicker.
     * @param ngControl The underlying ngControl.
     * @param parentForm the parent form
     * @param parentFormGroup the parent formgroup
     * @param defaultErrorStateMatcher the errorstatematcher that will be used
     * @param cdr The change detector.
     * @param el The element ref.
     */
    constructor(ngControl: NgControl, parentForm: NgForm, parentFormGroup: FormGroupDirective, defaultErrorStateMatcher: ErrorStateMatcher, cdr: ChangeDetectorRef, el: ElementRef);
    private validateSelectedDate;
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    /**Returns the number of days in current month. */
    daysInMonth(month: number, year: number): number;
    /**Adapts the day list depending on the month and year. */
    adaptDayList(): void;
    /**Adapts the month list depending on the year. */
    adaptMonthList(): void;
    /**Adapts the year list depending on the allowed range. */
    private adaptYearList;
    /**
     * Focuses the input.
     */
    focus(): void;
    private updateSelectedDate;
    private generateRange;
    /**
      * Implementation of the value accessor.
      */
    valueAccessorChange: (value: Date) => void;
    /**
     * Implementation of the value accessor.
     */
    writeValue(newValue: Date): void;
    /**
     * Implementation of the value accessor.
     */
    registerOnChange(fn: any): void;
    /**
     * Implementation of the value accessor.
     */
    registerOnTouched(fn: any): void;
    /**
     * Implementation of the value accessor.
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaDateComboPicker, [{ optional: true; self: true; }, { optional: true; }, { optional: true; }, null, null, null]>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaDateComboPicker, "axa-datecombopicker", never, { "id": "id"; "required": "required"; "disabled": "disabled"; "readonly": "readonly"; "minDate": "minDate"; "maxDate": "maxDate"; "days": "days"; "months": "months"; "years": "years"; "placeholder": "placeholder"; "name": "name"; }, {}, never, never>;
}

//# sourceMappingURL=axa-datecombopicker.d.ts.map