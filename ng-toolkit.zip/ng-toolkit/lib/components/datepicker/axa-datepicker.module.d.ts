import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-datecombopicker';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '../select/axa-select.module';
export declare class AxaDateComboPickerModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaDateComboPickerModule, [typeof ɵngcc1.AxaDateComboPicker], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule, typeof ɵngcc4.AxaSelectModule], [typeof ɵngcc1.AxaDateComboPicker]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaDateComboPickerModule>;
}

//# sourceMappingURL=axa-datepicker.module.d.ts.map