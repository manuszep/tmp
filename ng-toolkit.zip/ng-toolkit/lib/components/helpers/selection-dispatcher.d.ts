import { Optional, OnDestroy } from '@angular/core';
/**Export of the listener. */
import * as ɵngcc0 from '@angular/core';
export declare type UniqueSelectionDispatcherListener = (id: string, name: string) => void;
/**
 * Class to coordinate unique selection based on name.
 */
export declare class UniqueSelectionDispatcher implements OnDestroy {
    private _listeners;
    /**
     * Notify other items that selection for the given name has been set.
     * @param id ID of the item.
     * @param name Name of the item.
     */
    notify(id: string, name: string): void;
    /**
     * Listen for future changes to item selection.
     * @return Function used to deregister listener
     */
    listen(listener: UniqueSelectionDispatcherListener): () => void;
    /**
     * @ignore
     */
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<UniqueSelectionDispatcher, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<UniqueSelectionDispatcher>;
}
/**Factory for the unique selection dispatcher */
export declare function UNIQUE_SELECTION_DISPATCHER_PROVIDER_FACTORY(parentDispatcher: UniqueSelectionDispatcher): UniqueSelectionDispatcher;
/**Unique selection dispatcher provider */
export declare const UNIQUE_SELECTION_DISPATCHER_PROVIDER: {
    provide: typeof UniqueSelectionDispatcher;
    deps: Optional[][];
    useFactory: typeof UNIQUE_SELECTION_DISPATCHER_PROVIDER_FACTORY;
};

//# sourceMappingURL=selection-dispatcher.d.ts.map