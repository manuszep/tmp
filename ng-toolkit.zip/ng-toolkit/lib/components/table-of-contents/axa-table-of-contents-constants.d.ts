/**Default style. */
export declare const TOC_CLASS_BASE = "table-of-contents";
/**Title style. */
export declare const TOC_CLASS_TITLE: string;
/**Title style. */
export declare const TOC_CLASS_ITEM: string;
