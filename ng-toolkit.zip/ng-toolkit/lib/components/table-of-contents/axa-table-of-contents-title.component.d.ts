/**Table of contents title component */
import * as ɵngcc0 from '@angular/core';
export declare class AxaTableOfContentsTitleComponent {
    /**Default style */
    cls: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaTableOfContentsTitleComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaTableOfContentsTitleComponent, "axa-table-of-contents-title", never, {}, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-table-of-contents-title.component.d.ts.map