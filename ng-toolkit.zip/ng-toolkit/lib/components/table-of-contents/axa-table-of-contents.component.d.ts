/**Table of contents components to display a summary. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaTableOfContentsComponent {
    /**Default style */
    cls: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaTableOfContentsComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaTableOfContentsComponent, "axa-table-of-contents", never, {}, {}, never, ["axa-table-of-contents-title", "axa-table-of-contents-item"]>;
}

//# sourceMappingURL=axa-table-of-contents.component.d.ts.map