/**Table of contents item component. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaTableOfContentsItemComponent {
    /**Default style */
    cls: string;
    /**The link associated with this navigation element. */
    link: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaTableOfContentsItemComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaTableOfContentsItemComponent, "axa-table-of-contents-item", never, { "link": "link"; }, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-table-of-contents-item.component.d.ts.map