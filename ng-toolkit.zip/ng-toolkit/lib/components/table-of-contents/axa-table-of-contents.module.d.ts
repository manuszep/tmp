import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-table-of-contents.component';
import * as ɵngcc2 from './axa-table-of-contents-title.component';
import * as ɵngcc3 from './axa-table-of-contents-item.component';
import * as ɵngcc4 from '@angular/common';
export declare class AxaTableOfContentsModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaTableOfContentsModule, [typeof ɵngcc1.AxaTableOfContentsComponent, typeof ɵngcc2.AxaTableOfContentsTitleComponent, typeof ɵngcc3.AxaTableOfContentsItemComponent], [typeof ɵngcc4.CommonModule], [typeof ɵngcc1.AxaTableOfContentsComponent, typeof ɵngcc2.AxaTableOfContentsTitleComponent, typeof ɵngcc3.AxaTableOfContentsItemComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaTableOfContentsModule>;
}

//# sourceMappingURL=axa-table-of-contents.module.d.ts.map