import { EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
/**Value Accessor provider to enable ngModel. */
import * as ɵngcc0 from '@angular/core';
export declare const AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR: any;
/**
 * Change event emitted by the AxaCheckbox.
 * @export
 */
export declare class AxaCheckboxChange {
    /**
     * The AxaCheckbox that emits the change event.
     */
    source: AxaCheckbox;
    /**
     * The value of the AxaCheckbox
     */
    checked: boolean;
}
/**
 * An AXA styled checkbox.
 * @export
 */
export declare class AxaCheckbox implements ControlValueAccessor {
    private _uniqueId;
    /**
     * Element ID.
     */
    id: string;
    /**
     * Returns the element id
     */
    get inputId(): string;
    /**
     * Whether the control is required.
     */
    get required(): boolean;
    set required(value: boolean);
    private _required;
    /**
     * The value of the control.
     */
    value: string;
    /**
     * Whether the control is disabled.
     */
    disabled: boolean;
    /**
     * tabIndex of the control.
     */
    tabIndex: string;
    /**
     * Name of the control.
     */
    name: string | null;
    /**
     * Whether the control has an indeterminate state.
     */
    indeterminate: boolean;
    /** Used to set the 'aria-label' attribute on the underlying input element. */
    ariaLabel: string;
    /** The 'aria-labelledby' attribute takes precedence as the element's text alternative. */
    ariaLabelledby: string | null;
    /**
     *Whether the control is checked.
     */
    get checked(): boolean;
    set checked(value: boolean);
    private _checked;
    /**
     *Event emitted when the checked state changes.
     */
    readonly change: EventEmitter<AxaCheckboxChange>;
    /**
     * Implementation of the value accessor.
     */
    valueAccessorChange: (value: any) => void;
    /**
     * Implementation of the value accessor.
     */
    valueAccessorTouch: () => any;
    /**
     * Gets the aria value of the checked state.
     */
    getAriaChecked(): 'true' | 'false' | 'mixed';
    /** Toggles the `checked` state of the checkbox. */
    toggle(): void;
    private fireChangeEvent;
    /**
     * Handles the change event of the checkbox.
     */
    onInteractionEvent(event: Event): void;
    /**
     * Handles the click event of the checkbox.
     */
    onInputClick(event: Event): void;
    /**
     * Implementation of the value accessor.
     */
    writeValue(value: any): void;
    /**
     * Implementation of the value accessor.
     */
    registerOnChange(fn: any): void;
    /**
     * Implementation of the value accessor.
     */
    registerOnTouched(fn: any): void;
    /**
     * Implementation of the value accessor.
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaCheckbox, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaCheckbox, "axa-checkbox", never, { "id": "id"; "name": "name"; "ariaLabel": "aria-label"; "ariaLabelledby": "aria-labelledby"; "required": "required"; "checked": "checked"; "disabled": "disabled"; "value": "value"; "tabIndex": "tabIndex"; "indeterminate": "indeterminate"; }, { "change": "change"; }, never, ["*"]>;
}

//# sourceMappingURL=axa-checkbox.d.ts.map