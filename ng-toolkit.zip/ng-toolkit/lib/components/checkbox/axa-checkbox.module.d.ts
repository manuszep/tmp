import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-checkbox';
import * as ɵngcc2 from '@angular/common';
export declare class AxaCheckboxModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaCheckboxModule, [typeof ɵngcc1.AxaCheckbox], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaCheckbox]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaCheckboxModule>;
}

//# sourceMappingURL=axa-checkbox.module.d.ts.map