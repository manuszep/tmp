import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-input';
import * as ɵngcc2 from '@angular/common';
export declare class AxaInputModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaInputModule, [typeof ɵngcc1.AxaInput], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaInput]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaInputModule>;
}

//# sourceMappingURL=axa-input.module.d.ts.map