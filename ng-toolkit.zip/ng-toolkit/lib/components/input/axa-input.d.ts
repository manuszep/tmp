import { DoCheck, ElementRef, Renderer2, OnInit } from '@angular/core';
import { FormGroupDirective, NgControl, NgForm } from '@angular/forms';
import { AxaFormFieldControl } from '../form-field/axa-form-field.control';
import { CanUpdateErrorState } from '../mixins/control-validation';
import { ErrorStateMatcher } from '../validation/validation';
/**Style applied to the axa-input. */
import * as ɵngcc0 from '@angular/core';
export declare const INPUT_STYLE = "axa-form-control";
/**@ignore */
export declare class AxaInputBase {
    _defaultErrorStateMatcher: ErrorStateMatcher;
    _parentForm: NgForm;
    _parentFormGroup: FormGroupDirective;
    ngControl: NgControl;
    constructor(_defaultErrorStateMatcher: ErrorStateMatcher, _parentForm: NgForm, _parentFormGroup: FormGroupDirective, ngControl: NgControl);
}
/**@ignore */
export declare const _AxaInputMixinBase: (new (...args: any[]) => CanUpdateErrorState) & typeof AxaInputBase;
/**
 * Directive to enhance an input html component.
 * @export
 */
export declare class AxaInput extends _AxaInputMixinBase implements OnInit, CanUpdateErrorState, AxaFormFieldControl<any>, DoCheck {
    private el;
    ngControl: NgControl;
    private renderer;
    private _uniqueId;
    private _inputValueAccessor;
    /**
   * Implemented as part of AxaFormFieldControl.
   */
    get value(): string;
    set value(value: string);
    /**
     * The placeholder for this control.
     */
    placeholder: string;
    /**
     * Whether the control is focused.
     */
    focused: boolean;
    /**
     * Whether the control is required.
     */
    get required(): boolean;
    set required(value: boolean);
    protected _required: boolean;
    /**
     * Whether the control is disabled.
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    protected _disabled: boolean;
    /**
     * Whether the control is readonly.
     */
    get readonly(): boolean;
    set readonly(value: boolean);
    private _readonly;
    /**
   * Whether the control is readonly.
   */
    get clearable(): boolean;
    set clearable(value: boolean);
    private _clearable;
    /**
     * Element ID.
     */
    get id(): string;
    set id(value: string);
    protected _id: string;
    private host;
    private clearButton;
    /**
     *Creates an instance of AxaInput.
     * @param el the element ref.
     * @param defaultErrorStateMatcher the error state matcher used.
     * @param ngControl the underlying ngControl
     * @param parentForm the parent form
     * @param parentFormGroup the parent form group
     */
    constructor(el: ElementRef, defaultErrorStateMatcher: ErrorStateMatcher, ngControl: NgControl, parentForm: NgForm, parentFormGroup: FormGroupDirective, renderer: Renderer2);
    ngOnInit(): void;
    ngDoCheck(): void;
    private createClearButton;
    private removeClearButton;
    /**Responds to focus changes events. */
    focusChanged(isFocused: boolean): void;
    private addDefaultStyle;
    /**
     * Focuses the input.
     */
    focus(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaInput, [null, null, { optional: true; self: true; }, { optional: true; }, { optional: true; }, null]>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaInput, "input[axaInput], textarea[axaInput]", never, { "id": "id"; "value": "value"; "required": "required"; "disabled": "disabled"; "readonly": "readonly"; "clearable": "clearable"; "placeholder": "placeholder"; }, {}, never>;
}

//# sourceMappingURL=axa-input.d.ts.map