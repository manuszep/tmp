import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-select';
import * as ɵngcc2 from '@angular/common';
export declare class AxaSelectModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaSelectModule, [typeof ɵngcc1.AxaSelect], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaSelect]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaSelectModule>;
}

//# sourceMappingURL=axa-select.module.d.ts.map