import { ElementRef, DoCheck } from '@angular/core';
import { NgControl, NgForm, FormGroupDirective } from '@angular/forms';
import { AxaFormFieldControl } from '../form-field/axa-form-field.control';
import { Subject } from 'rxjs';
import { ErrorStateMatcher } from '../validation/validation';
import { CanUpdateErrorState } from '../mixins/control-validation';
import { HasTabIndex } from '../mixins/tabindex';
import { CanDisable } from '../mixins/disabled';
/**@ignore */
import * as ɵngcc0 from '@angular/core';
export declare class AxaSelectBase {
    _defaultErrorStateMatcher: ErrorStateMatcher;
    _parentForm: NgForm;
    _parentFormGroup: FormGroupDirective;
    ngControl: NgControl;
    constructor(_defaultErrorStateMatcher: ErrorStateMatcher, _parentForm: NgForm, _parentFormGroup: FormGroupDirective, ngControl: NgControl);
}
/**@ignore */
export declare const _AxaSelectMixinBase: (new (...args: any[]) => HasTabIndex) & (new (...args: any[]) => CanDisable) & (new (...args: any[]) => CanUpdateErrorState) & typeof AxaSelectBase;
/**Style injected in the axaSelect */
export declare const SELECT_STYLE = "custom-select";
/**
 * Directive to enhance a select html component.
 * @export
 */
export declare class AxaSelect extends _AxaSelectMixinBase implements AxaFormFieldControl<any>, CanUpdateErrorState, HasTabIndex, CanDisable, DoCheck {
    private el;
    ngControl: NgControl;
    private parentForm;
    private parentFormGroup;
    private _uniqueId;
    /**
     * Element ID.
     */
    get id(): string;
    set id(value: string);
    protected _id: string;
    /** Value of the select control. */
    get value(): any;
    set value(newValue: any);
    private _value;
    /**
     * Whether the control is in an error state.
     */
    errorState: boolean;
    /**
     * The placeholder for this control.
     */
    placeholder: string;
    /**
     * Whether the control is focused.
     */
    focused: boolean;
    /**
     * Whether the control is required.
     */
    get required(): boolean;
    set required(value: boolean);
    protected _required: boolean;
    /**
     * Whether the control is disabled.
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    protected _disabled: boolean;
    /**
     * Stream that emits when the errorState of the control changes.
     */
    readonly errorStateChanges: Subject<void>;
    private host;
    /**
     * Creates an instance of AxaSelect.
     * @param el the element ref.
     * @param defaultErrorStateMatcher the error state matcher used.
     * @param ngControl the underlying ngControl
     * @param parentForm the parent form
     * @param parentFormGroup the parent form group
     */
    constructor(el: ElementRef, defaultErrorStateMatcher: ErrorStateMatcher, ngControl: NgControl, parentForm: NgForm, parentFormGroup: FormGroupDirective);
    private addDefaultStyle;
    /**
     * Gives focus to the control.
     */
    focus(): void;
    /**Reacts to focus changes from the UI. */
    focusChanged(isFocused: boolean): void;
    ngDoCheck(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaSelect, [null, null, { optional: true; self: true; }, { optional: true; }, { optional: true; }]>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaSelect, "[axaSelect]", never, { "id": "id"; "value": "value"; "required": "required"; "disabled": "disabled"; "placeholder": "placeholder"; }, {}, never>;
}

//# sourceMappingURL=axa-select.d.ts.map