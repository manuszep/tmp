/**Component to display social items in the footer. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaFooterSocialComponent {
    /**Title of the list. */
    title: string;
    /**Default style of the step. */
    cls: boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaFooterSocialComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaFooterSocialComponent, "[axa-footer-social]", never, { "title": "title"; }, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-footer-social.d.ts.map