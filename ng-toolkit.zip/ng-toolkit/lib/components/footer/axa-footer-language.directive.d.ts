/**Directive to mark the links associated with languages. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaFooterLanguage {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaFooterLanguage, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaFooterLanguage, "a[AxaFooterLanguage]", never, {}, {}, never>;
}

//# sourceMappingURL=axa-footer-language.directive.d.ts.map