/**Default style. */
export declare const FOOTER_CLASS_BASE = "axa-footer";
