import { QueryList } from '@angular/core';
import { AxaFooterListComponent } from './axa-footer-list';
import { AxaFooterSocialComponent } from './axa-footer-social';
/**Component to generate the footer. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaFooterComponent {
    /**Whether the legal is shown. */
    showLegal: boolean;
    /**Text used for the legal information. */
    legalText: string;
    /**Whether the languages are shown */
    showLanguages: boolean;
    /**Default style for the footer. */
    cls: string;
    /**The list of menu items displayed. */
    lists: QueryList<AxaFooterListComponent>;
    /**the list of social items displayed */
    social: QueryList<AxaFooterSocialComponent>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaFooterComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaFooterComponent, "axa-footer", never, { "showLegal": "showLegal"; "legalText": "legalText"; "showLanguages": "showLanguages"; }, {}, ["lists", "social"], ["[axa-footer-list]", "[axa-footer-social]", "[AxaFooterLanguage]"]>;
}

//# sourceMappingURL=axa-footer.component.d.ts.map