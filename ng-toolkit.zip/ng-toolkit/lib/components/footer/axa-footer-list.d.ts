/**Component to display list items in the footer. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaFooterListComponent {
    /**Title of the list. */
    title: string;
    /**Default style of the step. */
    cls: boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaFooterListComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaFooterListComponent, "[axa-footer-list]", never, { "title": "title"; }, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-footer-list.d.ts.map