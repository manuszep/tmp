import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-footer.component';
import * as ɵngcc2 from './axa-footer-list';
import * as ɵngcc3 from './axa-footer-social';
import * as ɵngcc4 from './axa-footer-language.directive';
import * as ɵngcc5 from '@angular/common';
export declare class AxaFooterModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaFooterModule, [typeof ɵngcc1.AxaFooterComponent, typeof ɵngcc2.AxaFooterListComponent, typeof ɵngcc3.AxaFooterSocialComponent, typeof ɵngcc4.AxaFooterLanguage], [typeof ɵngcc5.CommonModule], [typeof ɵngcc1.AxaFooterComponent, typeof ɵngcc2.AxaFooterListComponent, typeof ɵngcc3.AxaFooterSocialComponent, typeof ɵngcc4.AxaFooterLanguage]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaFooterModule>;
}

//# sourceMappingURL=axa-footer.module.d.ts.map