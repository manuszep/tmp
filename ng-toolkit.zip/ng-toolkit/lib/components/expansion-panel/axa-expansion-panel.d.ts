import { AnimationTriggerMetadata } from '@angular/animations';
import { CdkAccordionItem } from '@angular/cdk/accordion';
import { UniqueSelectionDispatcher } from '@angular/cdk/collections';
import { ChangeDetectorRef } from '@angular/core';
import { AxaAccordion } from './axa-accordion';
/** AxaExpansionPanel's states. */
import * as ɵngcc0 from '@angular/core';
export declare type AxaExpansionPanelState = 'expanded' | 'collapsed';
/** Time and timing curve for expansion panel animations. */
export declare const EXPANSION_PANEL_ANIMATION_TIMING = "225ms cubic-bezier(0.4,0.0,0.2,1)";
/** Animations for the expansion panel. */
export declare const axaExpansionAnimations: {
    readonly bodyExpansion: AnimationTriggerMetadata;
};
/**Expansion panel found inside the axa accordion. */
export declare class AxaExpansionPanel extends CdkAccordionItem {
    /** ID for the associated header element. Used for a11y labelling. */
    headerId: string;
    /**Parent AxaAccordion */
    accordion: AxaAccordion;
    /**
     *Creates an instance of AxaExpansionPanel.
     * @param accordion parent accordion.
     * @param cdr ChangeDetectorRef.
     * @param uniqueSelectionDispatcher selection dispatcher to sync panels.
     */
    constructor(accordion: AxaAccordion, cdr: ChangeDetectorRef, uniqueSelectionDispatcher: UniqueSelectionDispatcher);
    /** Gets the expanded state string. */
    getExpandedState(): AxaExpansionPanelState;
    /** Determines whether the expansion panel should have spacing between it and its siblings. */
    hasSpacing(): boolean;
    /** Handles animation events */
    bodyAnimation(event: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaExpansionPanel, [{ optional: true; skipSelf: true; }, null, null]>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaExpansionPanel, "axa-expansion-panel", ["axaExpansionPanel"], { "disabled": "disabled"; "expanded": "expanded"; }, { "opened": "opened"; "closed": "closed"; "expandedChange": "expandedChange"; }, never, ["axa-expansion-panel-header", "*"]>;
}

//# sourceMappingURL=axa-expansion-panel.d.ts.map