import { AxaExpansionPanel } from './axa-expansion-panel';
/**Header of the panel ment for the accordion. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaExpansionPanelHeader {
    panel: AxaExpansionPanel;
    /**
     *Creates an instance of AxaExpansionPanelHeader.
     * @param panel parent expansion panel.
     */
    constructor(panel: AxaExpansionPanel);
    /** Gets the panel id. */
    getPanelId(): string;
    /** Gets whether the panel is expanded. */
    isExpanded(): boolean;
    /** Toggles the expanded state of the panel. */
    toggle(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaExpansionPanelHeader, [{ host: true; }]>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaExpansionPanelHeader, "axa-expansion-panel-header", never, {}, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-expansion-panel-header.d.ts.map