import { CdkAccordion } from '@angular/cdk/accordion';
/**Display mode for the accordion. */
import * as ɵngcc0 from '@angular/core';
export declare type AxaAccordionDisplayMode = 'default' | 'flat';
/**Accordion control to display collapsible steps. */
export declare class AxaAccordion extends CdkAccordion {
    /**Current display mode, defaults to default. */
    displayMode: AxaAccordionDisplayMode;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaAccordion, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaAccordion, "axa-accordion", never, { "displayMode": "displayMode"; }, {}, never>;
}

//# sourceMappingURL=axa-accordion.d.ts.map