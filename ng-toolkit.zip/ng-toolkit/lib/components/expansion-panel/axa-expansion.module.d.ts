import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-accordion';
import * as ɵngcc2 from './axa-expansion-panel';
import * as ɵngcc3 from './axa-expansion-panel-header';
import * as ɵngcc4 from '@angular/common';
import * as ɵngcc5 from '@angular/cdk/accordion';
export declare class AxaExpansionModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaExpansionModule, [typeof ɵngcc1.AxaAccordion, typeof ɵngcc2.AxaExpansionPanel, typeof ɵngcc3.AxaExpansionPanelHeader], [typeof ɵngcc4.CommonModule, typeof ɵngcc5.CdkAccordionModule], [typeof ɵngcc1.AxaAccordion, typeof ɵngcc2.AxaExpansionPanel, typeof ɵngcc3.AxaExpansionPanelHeader]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaExpansionModule>;
}

//# sourceMappingURL=axa-expansion.module.d.ts.map