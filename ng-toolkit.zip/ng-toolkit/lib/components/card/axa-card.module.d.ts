import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-card.component';
import * as ɵngcc2 from '@angular/common';
export declare class AxaCardModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaCardModule, [typeof ɵngcc1.AxaCardComponent, typeof ɵngcc1.AxaCardTitleDirective, typeof ɵngcc1.AxaCardContentDirective], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaCardComponent, typeof ɵngcc1.AxaCardTitleDirective, typeof ɵngcc1.AxaCardContentDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaCardModule>;
}

//# sourceMappingURL=axa-card.module.d.ts.map