/**Default style. */
export declare const CLASS_BASE = "axa-card";
/**Active style. */
export declare const CLASS_ACTIVE: string;
/**Wide style. */
export declare const CLASS_WIDE: string;
/**Block style. */
export declare const CLASS_BLOCK: string;
/**Title style. */
export declare const CLASS_TITLE: string;
/**Info style. */
export declare const CLASS_INFO: string;
/**Content style. */
export declare const CLASS_CONTENT: string;
/**Compact style. */
export declare const CLASS_BLOCK_COMPACT: string;
