/**
 * The card component used to display information in a formatted way.
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaCardComponent {
    /**Base styling binding. */
    baseCls: boolean;
    private _active;
    private _wide;
    private _info;
    private _content;
    /**Weither the card is active. */
    set active(value: boolean);
    /**Weither the card is of type wide. */
    set wide(value: boolean);
    /**Weither the card is of type info. */
    set info(value: boolean);
    /**Weither the card is of type content. */
    set content(value: boolean);
    /**Weither the card is active. */
    get hasActiveClass(): boolean;
    /**Weither the card is wide. */
    get hasWideClass(): boolean;
    /**Weither the card is info. */
    get hasInfoClass(): boolean;
    /**Weither the card is content. */
    get hasContentClass(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaCardComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaCardComponent, "axa-card", never, { "active": "active"; "wide": "wide"; "info": "info"; "content": "content"; }, {}, never, ["*"]>;
}
/**Directive of the card title. */
export declare class AxaCardTitleDirective {
    /**Base styling binding. */
    baseCls: boolean;
    private _compact;
    /**Weither the card is compact. */
    set compact(value: boolean);
    /**Weither the card is compact. */
    get hasCompactClass(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaCardTitleDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaCardTitleDirective, "axa-card-title", never, { "compact": "compact"; }, {}, never>;
}
/**Directive for the card content. */
export declare class AxaCardContentDirective {
    /**Base styling binding. */
    baseCls: boolean;
    private _compact;
    /**Weither the card is compact. */
    set compact(value: boolean);
    /**Weither the card is compact. */
    get hasCompactClass(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaCardContentDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaCardContentDirective, "axa-card-content", never, { "compact": "compact"; }, {}, never>;
}

//# sourceMappingURL=axa-card.component.d.ts.map