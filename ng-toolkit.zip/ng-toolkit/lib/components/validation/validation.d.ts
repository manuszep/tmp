import { FormGroupDirective, NgForm, FormControl } from '@angular/forms';
/** Error state matcher that matches when a control is invalid and dirty. */
import * as ɵngcc0 from '@angular/core';
export declare class ShowOnDirtyErrorStateMatcher implements ErrorStateMatcher {
    /**Evaluates the error state. */
    isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean;
}
/** Provider that defines how form controls behave with regards to displaying error messages. */
export declare class ErrorStateMatcher {
    /**Evaluates the error state. */
    isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ErrorStateMatcher, never>;
}

//# sourceMappingURL=validation.d.ts.map