import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-radio-button';
import * as ɵngcc2 from '@angular/common';
export declare class AxaRadioButtonModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaRadioButtonModule, [typeof ɵngcc1.AxaRadioButton, typeof ɵngcc1.AxaRadioGroup, typeof ɵngcc1.AxaRadioImage], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaRadioButton, typeof ɵngcc1.AxaRadioGroup, typeof ɵngcc1.AxaRadioImage]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaRadioButtonModule>;
}

//# sourceMappingURL=axa-radio-button.module.d.ts.map