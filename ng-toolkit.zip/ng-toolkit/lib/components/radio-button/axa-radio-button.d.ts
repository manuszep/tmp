import { OnInit, AfterContentInit, EventEmitter, OnDestroy } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { UniqueSelectionDispatcher } from '../helpers/selection-dispatcher';
/**Interface of the axa radio button. */
import * as ɵngcc0 from '@angular/core';
export interface AxaRadio {
    value: any;
    checked: boolean;
}
/**Value Accessor provider to enable ngModel. */
export declare const AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR: any;
/**
 * Group of radiobuttons
 * @export
 */
export declare class AxaRadioGroup implements AfterContentInit, ControlValueAccessor {
    private _value;
    /** The HTML name attribute applied to radio buttons in this group. */
    private _name;
    /** The currently selected radio button. Should match value. */
    private _selected;
    /** Whether the `value` has been set to its initial value. */
    private _isInitialized;
    /** Whether the labels should appear after or before the radio-buttons. Defaults to 'after' */
    private _labelPosition;
    /** Whether the radio group is disabled. */
    private _disabled;
    /** Whether the radio group is required. */
    private _required;
    /**
     * Event emitted when the group value changes.
     * Change events are only emitted when the value changes due to user interaction with
     * a radio button (the same behavior as `<input type-"radio">`).
     */
    readonly change: EventEmitter<AxaRadioChange>;
    /** Child radio buttons. */
    private _radios;
    /** Name of the radio button group. All radio buttons inside this group will use this name. */
    get name(): string;
    set name(value: string);
    /** Value of the radio button. */
    get value(): any;
    set value(newValue: any);
    /** The method to be called in order to update ngModel */
    valueAccessorChange: (value: any) => void;
    /**
     * The method called to update the blur status of ngModel
     */
    valueAccessorTouch: () => any;
    private checkSelectedRadioButton;
    /** Whether the radio button is selected. */
    get selected(): AxaRadio | null;
    set selected(selected: AxaRadio | null);
    /** Whether the radio group is disabled */
    get disabled(): boolean;
    set disabled(value: boolean);
    /** Whether the radio group is required */
    get required(): boolean;
    set required(value: boolean);
    ngAfterContentInit(): void;
    /**
     * @ignore
     */
    touch(): void;
    private _updateRadioButtonNames;
    /** Updates the `selected` radio button from the internal _value state. */
    private updateSelectedRadioFromValue;
    /** Dispatch change event with current selection and group value. */
    fireChangeEvent(): void;
    /**
     * Sets the model value. Implemented as part of ControlValueAccessor.
     */
    writeValue(value: any): void;
    /**
     * Registers a callback to be triggered when the model value changes.
     * Implemented as part of ControlValueAccessor.
     * @param fn Callback to be registered.
     */
    registerOnChange(fn: (value: any) => void): void;
    /**
     * Registers a callback to be triggered when the control is touched.
     * Implemented as part of ControlValueAccessor.
     * @param fn Callback to be registered.
     */
    registerOnTouched(fn: any): void;
    /**
     * Sets the disabled state of the control. Implemented as a part of ControlValueAccessor.
     * @param isDisabled Whether the control should be disabled.
     */
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaRadioGroup, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaRadioGroup, "axa-radio-group", ["axaRadioGroup"], { "disabled": "disabled"; "name": "name"; "value": "value"; "selected": "selected"; "required": "required"; }, { "change": "change"; }, ["_radios"]>;
}
/**Directive to use images for the content of axa-radio-button. */
export declare class AxaRadioImage {
    /**Base style. */
    elementClass: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaRadioImage, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaRadioImage, "axa-radio-button[axa-radio-image]", never, {}, {}, never>;
}
/**
 * Change event emitted by the AxaRadioButton.
 * @export
 */
export declare class AxaRadioChange {
    source: AxaRadio;
    value: any;
    /**
     * Creates an instance of AxaRadioChange.
     * @param source The AxaRadioButton that emits the change event.
     * @param value The value of the AxaRadioButton.
     */
    constructor(source: AxaRadio, value: any);
}
/**
 * An AXA styled radio-button, used with the AxaRadioGroup.
 * @export
 */
export declare class AxaRadioButton implements OnInit, OnDestroy, AxaRadio {
    private _radioDispatcher;
    private _uniqueId;
    /**
     * The parent AxaRadioGroup
     */
    radioGroup: AxaRadioGroup;
    private _checked;
    private _disabled;
    private _required;
    private _value;
    /**
     * Element ID.
     */
    id: string;
    /**
     * TabIndex.
     */
    tabIndex: any;
    /**
     * The name attribute of the control.
     */
    name: string;
    /**
     * The style applied to the radio button, can be '1' or '2'.
     */
    style: string;
    /** Used to set the 'aria-label' attribute on the underlying input element. */
    ariaLabel: string;
    /** The 'aria-labelledby' attribute takes precedence as the element's text alternative. */
    ariaLabelledby: string;
    /** The 'aria-describedby' attribute is read after the element's label and field type. */
    ariaDescribedby: string;
    /**
     * Whether the control is checked.
     */
    get checked(): boolean;
    set checked(value: boolean);
    /**
     * The value of the control.
     */
    get value(): any;
    set value(value: any);
    /**
     * Whether the control is disabled.
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * Whether the control is required.
     */
    get required(): boolean;
    set required(value: boolean);
    /**
     *Gets the ID of the element.
     */
    get inputId(): string;
    /**
     * Event emitted when the checked state changes.
     */
    readonly change: EventEmitter<AxaRadioChange>;
    private removeUniqueSelectionListener;
    /**
     * Implementation of the value accessor.
     */
    onTouched: () => any;
    /**
     * Creates an instance of AxaRadioButton.
     */
    constructor(radioGroup: AxaRadioGroup, _radioDispatcher: UniqueSelectionDispatcher);
    /**Handles the click on the input. */
    onInputClick(event: Event): void;
    /**Handles value change on the input. */
    onInputChange(event: Event): void;
    private fireChangeEvent;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaRadioButton, [{ optional: true; }, null]>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaRadioButton, "axa-radio-button", never, { "id": "id"; "style": "style"; "checked": "checked"; "value": "value"; "disabled": "disabled"; "required": "required"; "name": "name"; "tabIndex": "tabIndex"; "ariaLabel": "aria-label"; "ariaLabelledby": "aria-labelledby"; "ariaDescribedby": "aria-describedby"; }, { "change": "change"; }, never, ["*"]>;
}

//# sourceMappingURL=axa-radio-button.d.ts.map