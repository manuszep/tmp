/** Header control generated to display the tab list. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaTabHeader {
    /** Wether the header is active */
    active: boolean;
    /** The title. */
    label: string;
    /** The index. */
    index: number;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaTabHeader, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaTabHeader, "axa-tab-header", never, { "active": "active"; "label": "label"; "index": "index"; }, {}, never, never>;
}

//# sourceMappingURL=axa-tab-header.d.ts.map