import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-tab';
import * as ɵngcc2 from './axa-tab-item';
import * as ɵngcc3 from './axa-tab-header';
import * as ɵngcc4 from '@angular/common';
export declare class AxaTabModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaTabModule, [typeof ɵngcc1.AxaTab, typeof ɵngcc2.AxaTabItem, typeof ɵngcc3.AxaTabHeader], [typeof ɵngcc4.CommonModule], [typeof ɵngcc1.AxaTab, typeof ɵngcc2.AxaTabItem]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaTabModule>;
}

//# sourceMappingURL=axa-tab.module.d.ts.map