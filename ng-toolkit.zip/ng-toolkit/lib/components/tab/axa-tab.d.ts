import { QueryList, EventEmitter } from '@angular/core';
import { AxaTabItem } from './axa-tab-item';
/** Tab control to display sub organized content. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaTab {
    /** Children tab items. */
    tabs: QueryList<AxaTabItem>;
    private _current;
    /** The currently selected tab item. */
    get current(): number;
    set current(value: number);
    private _alt;
    /** Weither the alternate style should be used.
     *
     * Example 1: <axa-tab alt>
     *
     * Example 2: <axa-tab [alt]="showAltStyle">
    */
    get alt(): boolean;
    set alt(value: boolean);
    /**The change event for the current property. */
    currentChange: EventEmitter<any>;
    /**Returns the current active tab. */
    getActive(index: number): boolean;
    /**Sets the curent active item. */
    onTabClick(index: number): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaTab, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaTab, "axa-tab", never, { "current": "current"; "alt": "alt"; }, { "currentChange": "currentChange"; }, ["tabs"], never>;
}

//# sourceMappingURL=axa-tab.d.ts.map