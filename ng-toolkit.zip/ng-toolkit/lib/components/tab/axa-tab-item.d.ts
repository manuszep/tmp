import { TemplateRef } from '@angular/core';
/** TabItem displayed in the tab control. */
import * as ɵngcc0 from '@angular/core';
export declare class AxaTabItem {
    /** Title. */
    label: string;
    /** Content that will be projected. */
    content: TemplateRef<any>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaTabItem, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaTabItem, "axa-tab-item", never, { "label": "label"; }, {}, never, ["*"]>;
}

//# sourceMappingURL=axa-tab-item.d.ts.map