import { OnChanges, ElementRef, SimpleChanges } from '@angular/core';
/**
 * Defines all the buttons available in the toolkit.
 * Takes care of applying the styles to a button.
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaButton implements OnChanges {
    private el;
    /**@ignore */
    _disabled: boolean;
    private _ghost;
    private _neg;
    private _split;
    private _alt;
    private _small;
    private _large;
    private host;
    /**
     * Creates an instance of AxaButton.
     * @param el
     * ElementRef to modify styles.
     */
    constructor(el: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Whether the control is disabled.
     */
    set disabled(value: boolean);
    /**
     * Whether the control is ghost styled.
     */
    set ghost(value: boolean);
    /**
     * Whether the control is neg styled.
     */
    set neg(value: boolean);
    /**
      * Whether the control is split styled.
      */
    set split(value: boolean);
    /**
   * Whether the control is ghost styled.
   */
    set alt(value: boolean);
    /**
     * Whether the control is ghost styled.
     */
    set small(value: boolean);
    /**
    * Whether the control is ghost styled.
    */
    set large(value: boolean);
    /**
    * Whether the aria-disabled attribute should be set.
    */
    get DisabledAttr(): string | null;
    /**
     * Sets the role attribute.
     */
    get roleAttr(): string | boolean;
    /**
     * Sets the tabIndex.
     */
    get tabIndexAttr(): number;
    /**
     * Disables the click event when the control is disabled.
     */
    _haltDisabledEvents(event: Event): void;
    private clearStyles;
    private addDefaultStyles;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaButton, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaButton, "button[axa-button], a[axa-button]", never, { "disabled": "disabled"; "ghost": "ghost"; "neg": "neg"; "split": "split"; "alt": "alt"; "small": "small"; "large": "large"; }, {}, never>;
}

//# sourceMappingURL=axa-button.d.ts.map