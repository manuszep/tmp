/**This dictionary contains all the styles to apply for the different buttons. */
export declare const BUTTON_STYLES: {
    [name: string]: string;
};
