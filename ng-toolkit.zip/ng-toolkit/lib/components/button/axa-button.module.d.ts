import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-button';
import * as ɵngcc2 from '@angular/common';
export declare class AxaButtonModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaButtonModule, [typeof ɵngcc1.AxaButton], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaButton]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaButtonModule>;
}

//# sourceMappingURL=axa-button.module.d.ts.map