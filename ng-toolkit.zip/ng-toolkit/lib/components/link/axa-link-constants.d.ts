/**This dictionary contains all the styles to apply for the different links. */
export declare const LINK_STYLES: {
    [name: string]: string[];
};
