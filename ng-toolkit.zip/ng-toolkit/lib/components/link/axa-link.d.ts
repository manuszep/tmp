import { ElementRef } from '@angular/core';
/**
 * Defines all the links available in the toolkit.
 * Takes care of applying the styles to a button.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaLink {
    private el;
    private host;
    /**
     * Creates an instance of AxaLink.
     */
    constructor(el: ElementRef);
    private clearStyles;
    private hasHostAttributes;
    private addDefaultStyle;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaLink, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AxaLink, "a[axa-link], a[axa-arrow-link], a[axa-icon-link]", never, {}, {}, never>;
}

//# sourceMappingURL=axa-link.d.ts.map