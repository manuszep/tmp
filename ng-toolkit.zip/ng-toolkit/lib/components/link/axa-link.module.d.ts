import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-link';
import * as ɵngcc2 from '@angular/common';
export declare class AxaLinkModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaLinkModule, [typeof ɵngcc1.AxaLink], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.AxaLink]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaLinkModule>;
}

//# sourceMappingURL=axa-link.module.d.ts.map