import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './axa-cookie-message';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '../button/axa-button.module';
export declare class AxaCookieMessageModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AxaCookieMessageModule, [typeof ɵngcc1.AxaCookieMessage], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.AxaButtonModule], [typeof ɵngcc1.AxaCookieMessage]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AxaCookieMessageModule>;
}

//# sourceMappingURL=axa-cookie-message.module.d.ts.map