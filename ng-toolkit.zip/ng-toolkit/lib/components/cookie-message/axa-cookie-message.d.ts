/**
 * Cookie message warning, that stores it's state in the local storage.
 * @export
 */
import * as ɵngcc0 from '@angular/core';
export declare class AxaCookieMessage {
    /**
     * Whether the cookie message was already closed.
     */
    closed: boolean;
    /**
     * The legal message to display.
     */
    legalMessage: string;
    /**
     * The close action message.
     */
    closeMessage: string;
    /**
     * The close action.
     */
    close(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AxaCookieMessage, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AxaCookieMessage, "axa-cookie-message", never, { "legalMessage": "legalMessage"; "closeMessage": "closeMessage"; }, {}, never, never>;
}
/**Key for the stored cookie state. */
export declare const COOKIE_STORAGE = "axa-cookie.closed";

//# sourceMappingURL=axa-cookie-message.d.ts.map