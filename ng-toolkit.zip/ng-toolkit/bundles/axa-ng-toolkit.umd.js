(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(require('@angular/core'),require('@angular/forms'),require('@angular/common'),require('@angular/router'),require('@angular/cdk/collections'),require('@angular/cdk/accordion'),require('@angular/common/http'),exports, require('rxjs'), require('@angular/core'), require('@angular/common'), require('@angular/forms'), require('@angular/animations'), require('@angular/router'), require('@angular/cdk/accordion'), require('@angular/cdk/collections'), require('@angular/common/http'), require('rxjs/operators'), require('html2canvas'), require('jspdf')) :
    typeof define === 'function' && define.amd ? define('@axa/ng-toolkit', ['@angular/core','@angular/forms','@angular/common','@angular/router','@angular/cdk/collections','@angular/cdk/accordion','@angular/common/http','exports', 'rxjs', '@angular/core', '@angular/common', '@angular/forms', '@angular/animations', '@angular/router', '@angular/cdk/accordion', '@angular/cdk/collections', '@angular/common/http', 'rxjs/operators', 'html2canvas', 'jspdf'], factory) :
    (global = global || self, factory(global.ng.core,global.ng.forms,global.ng.common,global.ng.router,global.ng.cdk.collections,global.ng.cdk.accordion,global.ng.common.http,(global.axa = global.axa || {}, global.axa['ng-toolkit'] = {}), global.rxjs, global.ng.core, global.ng.common, global.ng.forms, global.ng.animations, global.ng.router, global.ng.cdk.accordion, global.ng.cdk.collections, global.ng.common.http, global.rxjs.operators, global.html2canvas, global.jspdf));
}(this, (function (ɵngcc0,ɵngcc1,ɵngcc2,ɵngcc3,ɵngcc4,ɵngcc5,ɵngcc6,exports, rxjs, i0, common, forms, animations, router, accordion, collections, http, operators, html2canvas, jspdf) { 
var _c0 = ["*"];
var _c1 = ["div"];
function AxaFormField_label_2_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "label");
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var ctx_r1 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(ctx_r1.label);
} }
function AxaFormField_6_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0, 3, ["*ngSwitchCase", "true"]);
} }
function AxaFormField_7_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0, 4, ["*ngSwitchDefault", ""]);
} }
var _c2 = [[["axa-prefix"]], "*", [["axa-suffix"]], [["axa-error"]], [["axa-hint"]]];
var _c3 = ["axa-prefix", "*", "axa-suffix", "axa-error", "axa-hint"];
function AxaPhoneInputComponent_option_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 4);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var country_r2 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", country_r2);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate2(" ", country_r2.code, " ", country_r2.dial, " ");
} }
function AxaPhoneInputComponent_option_6_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 4);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var country_r3 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", country_r3);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate2("", country_r3.code, " ", country_r3.dial, "");
} }
function AxaAlertManager_axa_top_content_bar_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "axa-top-content-bar", 1);
    ɵngcc0.ɵɵlistener("buttonClick", function AxaAlertManager_axa_top_content_bar_1_Template_axa_top_content_bar_buttonClick_0_listener() { var alert_r1 = ctx.$implicit; return alert_r1.action && alert_r1.action.handler && alert_r1.action.handler(alert_r1.action, alert_r1); });
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var alert_r1 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("type", alert_r1.type)("buttonLabel", alert_r1.action && alert_r1.action.content);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate1(" ", alert_r1.message, " ");
} }
function AxaTopContentBarComponent_a_3_Template(rf, ctx) { if (rf & 1) {
    var _r2 = ɵngcc0.ɵɵgetCurrentView();
    ɵngcc0.ɵɵelementStart(0, "a", 1);
    ɵngcc0.ɵɵlistener("click", function AxaTopContentBarComponent_a_3_Template_a_click_0_listener($event) { ɵngcc0.ɵɵrestoreView(_r2); var ctx_r1 = ɵngcc0.ɵɵnextContext(); return ctx_r1.handleClick($event); });
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵproperty("href", ctx_r0.href, ɵngcc0.ɵɵsanitizeUrl);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(ctx_r0.buttonLabel);
} }
function AxaCookieMessage_div_0_Template(rf, ctx) { if (rf & 1) {
    var _r2 = ɵngcc0.ɵɵgetCurrentView();
    ɵngcc0.ɵɵelementStart(0, "div", 1);
    ɵngcc0.ɵɵelement(1, "div", 2);
    ɵngcc0.ɵɵelementStart(2, "a", 3);
    ɵngcc0.ɵɵlistener("click", function AxaCookieMessage_div_0_Template_a_click_2_listener() { ɵngcc0.ɵɵrestoreView(_r2); var ctx_r1 = ɵngcc0.ɵɵnextContext(); return ctx_r1.close(); });
    ɵngcc0.ɵɵtext(3);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("innerHTML", ctx_r0.legalMessage, ɵngcc0.ɵɵsanitizeHtml);
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵtextInterpolate1(" ", ctx_r0.closeMessage, " ");
} }
function AxaDateComboPicker_option_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 2);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var day_r3 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", day_r3);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(day_r3);
} }
function AxaDateComboPicker_option_7_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 2);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var month_r4 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", month_r4);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(month_r4);
} }
function AxaDateComboPicker_option_11_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "option", 2);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var year_r5 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("ngValue", year_r5);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate(year_r5);
} }
var _c4 = ["axa-footer-list", ""];
var _c5 = ["axa-footer-social", ""];
function AxaFooterComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 5);
    ɵngcc0.ɵɵprojection(1);
    ɵngcc0.ɵɵprojection(2, 1);
    ɵngcc0.ɵɵelementEnd();
} }
function AxaFooterComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 6);
    ɵngcc0.ɵɵprojection(1, 2);
    ɵngcc0.ɵɵelementEnd();
} }
function AxaFooterComponent_div_4_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 7);
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var ctx_r2 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate1(" ", ctx_r2.legalText, " ");
} }
var _c6 = [[["", "axa-footer-list", ""]], [["", "axa-footer-social", ""]], [["", "AxaFooterLanguage", ""]]];
var _c7 = ["[axa-footer-list]", "[axa-footer-social]", "[AxaFooterLanguage]"];
function AxaStepComponent_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0);
} }
function AxaStepHeaderComponent_span_0_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "span", 3);
    ɵngcc0.ɵɵnamespaceSVG();
    ɵngcc0.ɵɵelementStart(1, "svg", 4);
    ɵngcc0.ɵɵelement(2, "path", 5);
    ɵngcc0.ɵɵelement(3, "path", 6);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} }
function AxaStepHeaderComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0);
} }
function AxaStepHeaderComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelement(0, "div");
} if (rf & 2) {
    var ctx_r2 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵclassMap(ctx_r2.getProgressClass());
    ɵngcc0.ɵɵstyleProp("width", ctx_r2.getWidth());
} }
function AxaStepperComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementContainerStart(0);
    ɵngcc0.ɵɵelement(1, "axa-step-header", 1);
    ɵngcc0.ɵɵelementContainerEnd();
} if (rf & 2) {
    var step_r2 = ctx.$implicit;
    var i_r3 = ctx.index;
    var ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("step", step_r2)("label", step_r2.label)("pricing", step_r2.pricing)("active", ctx_r0.getActive(i_r3))("done", ctx_r0.getDone(i_r3));
} }
function AxaStepperComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementContainerStart(0);
    ɵngcc0.ɵɵelementStart(1, "div", 2);
    ɵngcc0.ɵɵelementContainer(2, 3);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementContainerEnd();
} if (rf & 2) {
    var step_r4 = ctx.$implicit;
    var i_r5 = ctx.index;
    var ctx_r1 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵattribute("aria-expanded", ctx_r1.getActive(i_r5));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngTemplateOutlet", step_r4.content);
} }
var _c8 = ["navs"];
function AxaHeaderComponent_div_12_nav_2_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "nav", 26);
    ɵngcc0.ɵɵprojection(1, 2);
    ɵngcc0.ɵɵelementEnd();
} }
function AxaHeaderComponent_div_12_nav_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "nav", 27);
    ɵngcc0.ɵɵprojection(1, 3);
    ɵngcc0.ɵɵelementEnd();
} }
function AxaHeaderComponent_div_12_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 22);
    ɵngcc0.ɵɵelementStart(1, "div", 23);
    ɵngcc0.ɵɵtemplate(2, AxaHeaderComponent_div_12_nav_2_Template, 2, 0, "nav", 24);
    ɵngcc0.ɵɵtemplate(3, AxaHeaderComponent_div_12_nav_3_Template, 2, 0, "nav", 25);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.hasDomains());
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.hasHelpers());
} }
var _c9 = [[["axa-header-nav"], ["axa-header-nav-route"]], [["axa-header-search"]], [["axa-header-meta-domain"]], [["axa-header-meta-helper"]]];
var _c10 = ["axa-header-nav, axa-header-nav-route", "axa-header-search", "axa-header-meta-domain", "axa-header-meta-helper"];
var _c11 = function (a0, a1) { return { "radio1": a0, "radio2": a1 }; };
var _c12 = [[["axa-table-of-contents-title"]], [["axa-table-of-contents-item"]]];
var _c13 = ["axa-table-of-contents-title", "axa-table-of-contents-item"];
function AxaTabItem_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵprojection(0);
} }
function AxaTab_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    var _r5 = ɵngcc0.ɵɵgetCurrentView();
    ɵngcc0.ɵɵelementContainerStart(0);
    ɵngcc0.ɵɵelementStart(1, "axa-tab-header", 3);
    ɵngcc0.ɵɵlistener("click", function AxaTab_ng_container_3_Template_axa_tab_header_click_1_listener() { ɵngcc0.ɵɵrestoreView(_r5); var i_r3 = ctx.index; var ctx_r4 = ɵngcc0.ɵɵnextContext(); return ctx_r4.onTabClick(i_r3); });
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementContainerEnd();
} if (rf & 2) {
    var tab_r2 = ctx.$implicit;
    var i_r3 = ctx.index;
    var ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngClass", ctx_r0.alt ? "axa-tab-list__tab-alt" : "axa-tab-list__tab")("label", tab_r2.label)("index", i_r3)("active", ctx_r0.getActive(i_r3));
    ɵngcc0.ɵɵattribute("aria-selected", ctx_r0.getActive(i_r3));
} }
function AxaTab_ng_container_5_div_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div");
    ɵngcc0.ɵɵelementContainer(1, 5);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    var ctx_r9 = ɵngcc0.ɵɵnextContext();
    var i_r7 = ctx_r9.index;
    var tab_r6 = ctx_r9.$implicit;
    var ctx_r8 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵattribute("aria-selected", ctx_r8.getActive(i_r7));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngTemplateOutlet", tab_r6.content);
} }
function AxaTab_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementContainerStart(0);
    ɵngcc0.ɵɵtemplate(1, AxaTab_ng_container_5_div_1_Template, 2, 2, "div", 4);
    ɵngcc0.ɵɵelementContainerEnd();
} if (rf & 2) {
    var i_r7 = ctx.index;
    var ctx_r1 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r1.getActive(i_r7));
} }
var _c14 = function (a0) { return { "axa-tab": a0 }; };
var _c15 = [[["axa-expansion-panel-header"]], "*"];
var _c16 = ["axa-expansion-panel-header", "*"];
'use strict';

    html2canvas = html2canvas && Object.prototype.hasOwnProperty.call(html2canvas, 'default') ? html2canvas['default'] : html2canvas;

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (b.hasOwnProperty(p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, exports) {
        for (var p in m)
            if (p !== "default" && !exports.hasOwnProperty(p))
                __createBinding(exports, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    ;
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (Object.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }
    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * Mixin to augment a directive with updateErrorState method.
     * For component with `errorState` and need to update `errorState`.
     */
    function mixinErrorState(base) {
        return /** @class */ (function (_super) {
            __extends(class_1, _super);
            function class_1() {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                var _this = _super.apply(this, __spread(args)) || this;
                /** Whether the component is in an error state. */
                _this.errorState = false;
                /**
                 * Stream that emits whenever the error state of the input changes such that the wrapping
                 * `AxaFormField` needs to run change detection.
                 */
                _this.errorStateChanges = new rxjs.Subject();
                /**
                 * Stream that emits whenever the touched state of the input changes such that the wrapping
                 * `AxaFormField` needs to run change detection.
                 */
                _this.touchedChanges = new rxjs.Subject();
                return _this;
            }
            /**Updates the errorstate value of a control. */
            class_1.prototype.updateErrorState = function () {
                var oldState = this.errorState;
                var parent = this._parentFormGroup || this._parentForm;
                var matcher = this.errorStateMatcher || this._defaultErrorStateMatcher;
                var control = this.ngControl ? this.ngControl.control : null;
                var newState = matcher.isErrorState(control, parent);
                if (newState !== oldState) {
                    this.errorState = newState;
                    this.errorStateChanges.next();
                }
            };
            return class_1;
        }(base));
    }

    /** Coerces a data-bound value to a boolean. */
    function coerceBooleanProperty(value) {
        return value != null && "" + value !== 'false';
    }

    /** Mixin to augment a directive with a `disabled` property. */
    function mixinDisabled(base) {
        return /** @class */ (function (_super) {
            __extends(class_1, _super);
            function class_1() {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                var _this = _super.apply(this, __spread(args)) || this;
                _this._disabled = false;
                return _this;
            }
            Object.defineProperty(class_1.prototype, "disabled", {
                /**Wether the control is disabled. */
                get: function () { return this._disabled; },
                set: function (value) { this._disabled = coerceBooleanProperty(value); },
                enumerable: false,
                configurable: true
            });
            return class_1;
        }(base));
    }

    /**
     * Mixin to augment a directive with updateErrorState method.
     * For component with `errorState` and need to update `errorState`.
     */
    function mixinParentErrorState(base) {
        return /** @class */ (function (_super) {
            __extends(class_1, _super);
            function class_1() {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                var _this = _super.apply(this, __spread(args)) || this;
                /** Whether the component is in an error state. */
                _this.errorState = false;
                /**
                 * Stream that emits whenever the state of the input changes such that the wrapping
                 * `AxaFormField` needs to run change detection.
                 */
                _this.errorStateChanges = new rxjs.Subject();
                /**The subscriptions used to monitor state. */
                _this.subArray = new Array();
                /**Implementation of the value accessor. */
                _this.valueAccessorTouch = function () { };
                _this.childrenTouchedState = new Array();
                if (_this._parentForm != null) {
                    _this.subArray.push(_this._parentForm.ngSubmit.subscribe(function () {
                        _this.updateErrorState();
                    }));
                }
                if (_this._parentFormGroup != null) {
                    _this.subArray.push(_this._parentFormGroup.ngSubmit.subscribe(function () {
                        _this.updateErrorState();
                    }));
                }
                return _this;
            }
            /**Updates the errorstate value of a control. */
            class_1.prototype.updateErrorState = function () {
                var oldState = this.errorState;
                var parent = this._parentFormGroup || this._parentForm;
                var matcher = this.errorStateMatcher || this._defaultErrorStateMatcher;
                var control = this.ngControl ? this.ngControl.control : null;
                var newState = matcher.isErrorState(control, parent);
                if (newState !== oldState) {
                    this.errorState = newState;
                    this.errorStateChanges.next();
                }
            };
            /**Stops monitoring the states. */
            class_1.prototype.unMonitorChildrenControls = function () {
                this.subArray.forEach(function (sub) { return sub.unsubscribe(); });
            };
            /**Monitors the state changes for the form field and children controls. */
            class_1.prototype.monitorChildrenControls = function () {
                var _this = this;
                var parent = this._parentFormGroup || this._parentForm;
                if (parent != null) {
                    this.subArray.push(parent.statusChanges.subscribe(function (test) {
                        _this.updateErrorState();
                    }));
                }
                this.childrenControls.forEach(function (s) {
                    _this.subArray.push(s.errorStateChanges.subscribe(function () {
                        if (_this.childrenControls.some(function (su) { return su.errorState === true; })) {
                            _this.errorState = true;
                            _this.errorStateChanges.next();
                        }
                        else {
                            _this.errorState = false;
                            _this.errorStateChanges.next();
                        }
                    }));
                    _this.subArray.push(s.touchedChanges.subscribe(function (id) {
                        if (_this.childrenTouchedState.indexOf(id) === -1) {
                            _this.childrenTouchedState.push(id);
                        }
                        if (_this.childrenControls.length === _this.childrenTouchedState.length) {
                            _this.valueAccessorTouch();
                            _this.updateErrorState();
                        }
                    }));
                });
            };
            return class_1;
        }(base));
    }

    /** Mixin to augment a directive with a `tabIndex` property. */
    function mixinTabIndex(base, defaultTabIndex) {
        if (defaultTabIndex === void 0) { defaultTabIndex = 0; }
        return /** @class */ (function (_super) {
            __extends(class_1, _super);
            function class_1() {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                var _this = _super.apply(this, __spread(args)) || this;
                _this._tabIndex = defaultTabIndex;
                return _this;
            }
            Object.defineProperty(class_1.prototype, "tabIndex", {
                /**The tabIndex value. */
                get: function () { return this.disabled ? -1 : this._tabIndex; },
                set: function (value) {
                    // If the specified tabIndex value is null or undefined, fall back to the default value.
                    this._tabIndex = value != null ? value : defaultTabIndex;
                },
                enumerable: false,
                configurable: true
            });
            return class_1;
        }(base));
    }

    /**
     * Allows a control to work inside an AxaFormField.
     */
    var AxaFormFieldControl = /** @class */ (function () {
        function AxaFormFieldControl() {
        }
        return AxaFormFieldControl;
    }());

    /** Error state matcher that matches when a control is invalid and dirty. */
    var ShowOnDirtyErrorStateMatcher = /** @class */ (function () {
        function ShowOnDirtyErrorStateMatcher() {
        }
        /**Evaluates the error state. */
        ShowOnDirtyErrorStateMatcher.prototype.isErrorState = function (control, form) {
            return !!(control && control.invalid && (control.dirty || (form && form.submitted)));
        };
ShowOnDirtyErrorStateMatcher.ɵfac = function ShowOnDirtyErrorStateMatcher_Factory(t) { return new (t || ShowOnDirtyErrorStateMatcher)(); };
ShowOnDirtyErrorStateMatcher.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: ShowOnDirtyErrorStateMatcher, factory: function (t) { return ShowOnDirtyErrorStateMatcher.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(ShowOnDirtyErrorStateMatcher, [{
        type: i0.Injectable
    }], function () { return []; }, null); })();
        return ShowOnDirtyErrorStateMatcher;
    }());
    /** Provider that defines how form controls behave with regards to displaying error messages. */
    var ErrorStateMatcher = /** @class */ (function () {
        function ErrorStateMatcher() {
        }
        /**Evaluates the error state. */
        ErrorStateMatcher.prototype.isErrorState = function (control, form) {
            return !!(control && control.invalid && (control.touched || (form && form.submitted)));
        };
ErrorStateMatcher.ɵfac = function ErrorStateMatcher_Factory(t) { return new (t || ErrorStateMatcher)(); };
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(ErrorStateMatcher, [{
        type: i0.Injectable,
        args: [{ providedIn: 'root' }]
    }], function () { return []; }, null); })();
        return ErrorStateMatcher;
    }());
    ErrorStateMatcher.ɵprov = i0.ɵɵdefineInjectable({ factory: function ErrorStateMatcher_Factory() { return new ErrorStateMatcher(); }, token: ErrorStateMatcher, providedIn: "root" });

    /**Style applied to the axa-input. */
    var INPUT_STYLE = 'axa-form-control';
    /**Unique ID generated for inputs. */
    var nextUniqueId = 0;
    /**@ignore */
    var AxaInputBase = /** @class */ (function () {
        function AxaInputBase(_defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl) {
            this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
            this._parentForm = _parentForm;
            this._parentFormGroup = _parentFormGroup;
            this.ngControl = ngControl;
        }
        return AxaInputBase;
    }());
    /**@ignore */
    var _AxaInputMixinBase = mixinErrorState(AxaInputBase);
    /**
     * Directive to enhance an input html component.
     * @export
     */
    var AxaInput = /** @class */ (function (_super) {
        __extends(AxaInput, _super);
        /**
         *Creates an instance of AxaInput.
         * @param el the element ref.
         * @param defaultErrorStateMatcher the error state matcher used.
         * @param ngControl the underlying ngControl
         * @param parentForm the parent form
         * @param parentFormGroup the parent form group
         */
        function AxaInput(el, defaultErrorStateMatcher, ngControl, parentForm, parentFormGroup, renderer) {
            var _this = _super.call(this, defaultErrorStateMatcher, parentForm, parentFormGroup, ngControl) || this;
            _this.el = el;
            _this.ngControl = ngControl;
            _this.renderer = renderer;
            _this._uniqueId = "axa-input-" + ++nextUniqueId;
            /**
             * Whether the control is focused.
             */
            _this.focused = false;
            _this._required = false;
            _this._disabled = false;
            _this._readonly = false;
            _this._clearable = false;
            _this._inputValueAccessor = el.nativeElement;
            _this.id = _this.id;
            _this.host = el.nativeElement;
            _this.addDefaultStyle();
            return _this;
        }
        Object.defineProperty(AxaInput.prototype, "value", {
            /**
           * Implemented as part of AxaFormFieldControl.
           */
            get: function () { return this._inputValueAccessor.value; },
            set: function (value) {
                if (value !== this.value) {
                    this._inputValueAccessor.value = value;
                    this.errorStateChanges.next();
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaInput.prototype, "required", {
            /**
             * Whether the control is required.
             */
            get: function () { return this._required; },
            set: function (value) { this._required = coerceBooleanProperty(value); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaInput.prototype, "disabled", {
            /**
             * Whether the control is disabled.
             */
            get: function () {
                if (this.ngControl && this.ngControl.disabled !== null) {
                    return this.ngControl.disabled;
                }
                return this._disabled;
            },
            set: function (value) {
                this._disabled = coerceBooleanProperty(value);
                if (this.focused) {
                    this.focused = false;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaInput.prototype, "readonly", {
            /**
             * Whether the control is readonly.
             */
            get: function () { return this._readonly; },
            set: function (value) { this._readonly = coerceBooleanProperty(value); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaInput.prototype, "clearable", {
            /**
           * Whether the control is readonly.
           */
            get: function () { return this._clearable; },
            set: function (value) { this._clearable = coerceBooleanProperty(value); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaInput.prototype, "id", {
            /**
             * Element ID.
             */
            get: function () { return this._id; },
            set: function (value) { this._id = value || this._uniqueId; },
            enumerable: false,
            configurable: true
        });
        AxaInput.prototype.ngOnInit = function () {
            this.createClearButton();
        };
        AxaInput.prototype.ngDoCheck = function () {
            this.updateErrorState();
            this.createClearButton();
        };
        AxaInput.prototype.createClearButton = function () {
            var _this = this;
            if (this.clearable && !this.clearButton && this.value) {
                this.clearButton = this.renderer.createElement('a');
                this.renderer.setAttribute(this.clearButton, 'clearable', 'true');
                // If have suffix, add another class to rightless
                var hasSuffix = Array
                    .from(this.el.nativeElement.parentNode.children)
                    .find(function (e) { return e.tagName === 'AXA-SUFFIX'; });
                if (hasSuffix) {
                    this.renderer.addClass(this.clearButton, 'clear');
                }
                else {
                    this.renderer.addClass(this.clearButton, 'clear-suffix');
                }
                this.renderer.listen(this.clearButton, 'click', function () { _this.removeClearButton(); });
                this.renderer.setStyle(this.el.nativeElement, 'padding-right', '36px');
                this.renderer.appendChild(this.el.nativeElement.parentNode, this.clearButton);
            }
            if (this.clearable && this.clearButton && !this.value) {
                this.removeClearButton();
            }
        };
        AxaInput.prototype.removeClearButton = function () {
            this.value = '';
            this.renderer.removeStyle(this.el.nativeElement, 'padding-right');
            this.renderer.removeChild(this.el.nativeElement.parentNode, this.clearButton);
            this.clearButton = null;
        };
        /**Responds to focus changes events. */
        AxaInput.prototype.focusChanged = function (isFocused) {
            if (isFocused !== this.focused && !this.readonly) {
                this.focused = isFocused;
            }
            if (!isFocused) {
                this.touchedChanges.next(this.id);
            }
        };
        AxaInput.prototype.addDefaultStyle = function () {
            this.host.classList.add(INPUT_STYLE);
        };
        /**
         * Focuses the input.
         */
        AxaInput.prototype.focus = function () {
            this.host.focus();
        };
AxaInput.ɵfac = function AxaInput_Factory(t) { return new (t || AxaInput)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef), ɵngcc0.ɵɵdirectiveInject(ErrorStateMatcher), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgControl, 10), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgForm, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.FormGroupDirective, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.Renderer2)); };
AxaInput.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaInput, selectors: [["input", "axaInput", ""], ["textarea", "axaInput", ""]], hostVars: 7, hostBindings: function AxaInput_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("blur", function AxaInput_blur_HostBindingHandler() { return ctx.focusChanged(false); })("focus", function AxaInput_focus_HostBindingHandler() { return ctx.focusChanged(true); });
    } if (rf & 2) {
        ɵngcc0.ɵɵhostProperty("disabled", ctx.disabled)("required", ctx.required)("readonly", ctx.readonly);
        ɵngcc0.ɵɵattribute("id", ctx.id)("aria-invalid", ctx.errorState)("placeholder", ctx.placeholder)("aria-required", ctx.required.toString());
    } }, inputs: { value: "value", required: "required", disabled: "disabled", readonly: "readonly", clearable: "clearable", id: "id", placeholder: "placeholder" }, features: [ɵngcc0.ɵɵProvidersFeature([{ provide: AxaFormFieldControl, useExisting: AxaInput }]), ɵngcc0.ɵɵInheritDefinitionFeature] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaInput, [{
        type: i0.Directive,
        args: [{
                selector: 'input[axaInput], textarea[axaInput]',
                host: {
                    '[attr.id]': 'id',
                    '[attr.aria-invalid]': 'errorState',
                    '[attr.placeholder]': 'placeholder',
                    '[attr.aria-required]': 'required.toString()',
                    '[disabled]': 'disabled',
                    '[required]': 'required',
                    '[readonly]': 'readonly',
                    '(blur)': 'focusChanged(false)',
                    '(focus)': 'focusChanged(true)'
                },
                providers: [{ provide: AxaFormFieldControl, useExisting: AxaInput }]
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }, { type: ErrorStateMatcher }, { type: ɵngcc1.NgControl, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Self
            }] }, { type: ɵngcc1.NgForm, decorators: [{
                type: i0.Optional
            }] }, { type: ɵngcc1.FormGroupDirective, decorators: [{
                type: i0.Optional
            }] }, { type: ɵngcc0.Renderer2 }]; }, { value: [{
            type: i0.Input
        }], required: [{
            type: i0.Input
        }], disabled: [{
            type: i0.Input
        }], readonly: [{
            type: i0.Input
        }], clearable: [{
            type: i0.Input
        }], id: [{
            type: i0.Input
        }], placeholder: [{
            type: i0.Input
        }] }); })();
        return AxaInput;
    }(_AxaInputMixinBase));
    AxaInput.ctorParameters = function () { return [
        { type: i0.ElementRef },
        { type: ErrorStateMatcher },
        { type: forms.NgControl, decorators: [{ type: i0.Optional }, { type: i0.Self }] },
        { type: forms.NgForm, decorators: [{ type: i0.Optional }] },
        { type: forms.FormGroupDirective, decorators: [{ type: i0.Optional }] },
        { type: i0.Renderer2 }
    ]; };
    AxaInput.propDecorators = {
        value: [{ type: i0.Input }],
        placeholder: [{ type: i0.Input }],
        required: [{ type: i0.Input }],
        disabled: [{ type: i0.Input }],
        readonly: [{ type: i0.Input }],
        clearable: [{ type: i0.Input }],
        id: [{ type: i0.Input }]
    };

    var AxaInputModule = /** @class */ (function () {
        function AxaInputModule() {
        }
AxaInputModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaInputModule });
AxaInputModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaInputModule_Factory(t) { return new (t || AxaInputModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaInputModule, { declarations: [AxaInput], imports: [ɵngcc2.CommonModule], exports: [AxaInput] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaInputModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaInput],
                declarations: [AxaInput]
            }]
    }], function () { return []; }, null); })();
        return AxaInputModule;
    }());

    /**This dictionary contains all the styles to apply for the different buttons. */
    var BUTTON_STYLES = {
        'default': 'axa-btn',
        'ghost': 'axa-btn--ghost',
        'neg': 'axa-btn--neg',
        'split': 'axa-btn--split',
        'alt': 'axa-btn--alt',
        'small': 'axa-btn--sm',
        'large': 'axa-btn--lg'
    };

    /** Coerces a data-bound value to a boolean. */
    function coerceBooleanProperty$1(value) {
        return value != null && "" + value !== 'false';
    }

    /**
     * Defines all the buttons available in the toolkit.
     * Takes care of applying the styles to a button.
     */
    var AxaButton = /** @class */ (function () {
        /**
         * Creates an instance of AxaButton.
         * @param el
         * ElementRef to modify styles.
         */
        function AxaButton(el) {
            this.el = el;
            this.host = el.nativeElement;
            this.addDefaultStyles();
        }
        AxaButton.prototype.ngOnChanges = function (changes) {
            this.addDefaultStyles();
        };
        Object.defineProperty(AxaButton.prototype, "disabled", {
            /**
             * Whether the control is disabled.
             */
            set: function (value) {
                this._disabled = coerceBooleanProperty$1(value);
                this.host.disabled = this._disabled;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "ghost", {
            /**
             * Whether the control is ghost styled.
             */
            set: function (value) {
                this._ghost = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "neg", {
            /**
             * Whether the control is neg styled.
             */
            set: function (value) {
                this._neg = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "split", {
            /**
              * Whether the control is split styled.
              */
            set: function (value) {
                this._split = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "alt", {
            /**
           * Whether the control is ghost styled.
           */
            set: function (value) {
                this._alt = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "small", {
            /**
             * Whether the control is ghost styled.
             */
            set: function (value) {
                this._small = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "large", {
            /**
            * Whether the control is ghost styled.
            */
            set: function (value) {
                this._large = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "DisabledAttr", {
            /**
            * Whether the aria-disabled attribute should be set.
            */
            get: function () {
                return this._disabled ? 'disabled' : null;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "roleAttr", {
            /**
             * Sets the role attribute.
             */
            get: function () {
                return (this.host.tagName !== 'BUTTON') ? 'button' : null;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaButton.prototype, "tabIndexAttr", {
            /**
             * Sets the tabIndex.
             */
            get: function () {
                return this._disabled ? -1 : 0;
            },
            enumerable: false,
            configurable: true
        });
        /**
         * Disables the click event when the control is disabled.
         */
        AxaButton.prototype._haltDisabledEvents = function (event) {
            if (this._disabled) {
                event.preventDefault();
                event.stopImmediatePropagation();
            }
        };
        AxaButton.prototype.clearStyles = function () {
            var _this = this;
            Object.keys(BUTTON_STYLES).forEach(function (key) {
                var value = BUTTON_STYLES[key];
                _this.host.classList.remove(value);
            });
        };
        AxaButton.prototype.addDefaultStyles = function () {
            var _this = this;
            this.clearStyles();
            Object.keys(BUTTON_STYLES).forEach(function (key) {
                var value = BUTTON_STYLES[key];
                if (key === 'default' || (_this.hasOwnProperty("_" + key) && _this["_" + key])) {
                    _this.host.classList.add(value);
                }
            });
        };
AxaButton.ɵfac = function AxaButton_Factory(t) { return new (t || AxaButton)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaButton.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaButton, selectors: [["button", "axa-button", ""], ["a", "axa-button", ""]], hostVars: 3, hostBindings: function AxaButton_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("click", function AxaButton_click_HostBindingHandler($event) { return ctx._haltDisabledEvents($event); });
    } if (rf & 2) {
        ɵngcc0.ɵɵattribute("aria-disabled", ctx.DisabledAttr)("role", ctx.roleAttr)("tabindex", ctx.tabIndexAttr);
    } }, inputs: { disabled: "disabled", ghost: "ghost", neg: "neg", split: "split", alt: "alt", small: "small", large: "large" }, features: [ɵngcc0.ɵɵNgOnChangesFeature] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaButton, [{
        type: i0.Directive,
        args: [{
                selector: "button[axa-button], a[axa-button]"
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { disabled: [{
            type: i0.Input,
            args: ['disabled']
        }], ghost: [{
            type: i0.Input,
            args: ['ghost']
        }], neg: [{
            type: i0.Input,
            args: ['neg']
        }], split: [{
            type: i0.Input,
            args: ['split']
        }], alt: [{
            type: i0.Input,
            args: ['alt']
        }], small: [{
            type: i0.Input,
            args: ['small']
        }], large: [{
            type: i0.Input,
            args: ['large']
        }], DisabledAttr: [{
            type: i0.HostBinding,
            args: ['attr.aria-disabled']
        }], roleAttr: [{
            type: i0.HostBinding,
            args: ['attr.role']
        }], tabIndexAttr: [{
            type: i0.HostBinding,
            args: ['attr.tabindex']
        }], _haltDisabledEvents: [{
            type: i0.HostListener,
            args: ['click', ['$event']]
        }] }); })();
        return AxaButton;
    }());
    AxaButton.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };
    AxaButton.propDecorators = {
        disabled: [{ type: i0.Input, args: ['disabled',] }],
        ghost: [{ type: i0.Input, args: ['ghost',] }],
        neg: [{ type: i0.Input, args: ['neg',] }],
        split: [{ type: i0.Input, args: ['split',] }],
        alt: [{ type: i0.Input, args: ['alt',] }],
        small: [{ type: i0.Input, args: ['small',] }],
        large: [{ type: i0.Input, args: ['large',] }],
        DisabledAttr: [{ type: i0.HostBinding, args: ['attr.aria-disabled',] }],
        roleAttr: [{ type: i0.HostBinding, args: ['attr.role',] }],
        tabIndexAttr: [{ type: i0.HostBinding, args: ['attr.tabindex',] }],
        _haltDisabledEvents: [{ type: i0.HostListener, args: ['click', ['$event'],] }]
    };

    var AxaButtonModule = /** @class */ (function () {
        function AxaButtonModule() {
        }
AxaButtonModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaButtonModule });
AxaButtonModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaButtonModule_Factory(t) { return new (t || AxaButtonModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaButtonModule, { declarations: [AxaButton], imports: [ɵngcc2.CommonModule], exports: [AxaButton] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaButtonModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                declarations: [AxaButton],
                exports: [AxaButton]
            }]
    }], function () { return []; }, null); })();
        return AxaButtonModule;
    }());

    /**
     * Generated unique id.
     */
    var nextUniqueId$1 = 0;
    /**@ignore */
    var AxaSelectBase = /** @class */ (function () {
        function AxaSelectBase(_defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl) {
            this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
            this._parentForm = _parentForm;
            this._parentFormGroup = _parentFormGroup;
            this.ngControl = ngControl;
        }
        return AxaSelectBase;
    }());
    /**@ignore */
    var _AxaSelectMixinBase = mixinTabIndex(mixinDisabled(mixinErrorState(AxaSelectBase)));
    /**Style injected in the axaSelect */
    var SELECT_STYLE = 'custom-select';
    /**
     * Directive to enhance a select html component.
     * @export
     */
    var AxaSelect = /** @class */ (function (_super) {
        __extends(AxaSelect, _super);
        /**
         * Creates an instance of AxaSelect.
         * @param el the element ref.
         * @param defaultErrorStateMatcher the error state matcher used.
         * @param ngControl the underlying ngControl
         * @param parentForm the parent form
         * @param parentFormGroup the parent form group
         */
        function AxaSelect(el, defaultErrorStateMatcher, ngControl, parentForm, parentFormGroup) {
            var _this = _super.call(this, defaultErrorStateMatcher, parentForm, parentFormGroup, ngControl) || this;
            _this.el = el;
            _this.ngControl = ngControl;
            _this.parentForm = parentForm;
            _this.parentFormGroup = parentFormGroup;
            _this._uniqueId = "axa-select-" + ++nextUniqueId$1;
            /**
             * Whether the control is focused.
             */
            _this.focused = false;
            _this._required = false;
            _this._disabled = false;
            /**
             * Stream that emits when the errorState of the control changes.
             */
            _this.errorStateChanges = new rxjs.Subject();
            _this.host = el.nativeElement;
            _this.addDefaultStyle();
            _this.id = _this.id;
            return _this;
        }
        Object.defineProperty(AxaSelect.prototype, "id", {
            /**
             * Element ID.
             */
            get: function () { return this._id; },
            set: function (value) { this._id = value || this._uniqueId; },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaSelect.prototype, "value", {
            /** Value of the select control. */
            get: function () { return this._value; },
            set: function (newValue) {
                if (newValue !== this._value) {
                    this._value = newValue;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaSelect.prototype, "required", {
            /**
             * Whether the control is required.
             */
            get: function () { return this._required; },
            set: function (value) { this._required = coerceBooleanProperty(value); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaSelect.prototype, "disabled", {
            /**
             * Whether the control is disabled.
             */
            get: function () {
                if (this.ngControl && this.ngControl.disabled !== null) {
                    return this.ngControl.disabled;
                }
                return this._disabled;
            },
            set: function (value) {
                this._disabled = coerceBooleanProperty(value);
                if (this.focused) {
                    this.focused = false;
                }
            },
            enumerable: false,
            configurable: true
        });
        AxaSelect.prototype.addDefaultStyle = function () {
            this.host.classList.add(SELECT_STYLE);
        };
        /**
         * Gives focus to the control.
         */
        AxaSelect.prototype.focus = function () {
            this.host.focus();
        };
        /**Reacts to focus changes from the UI. */
        AxaSelect.prototype.focusChanged = function (isFocused) {
            if (isFocused !== this.focused) {
                this.focused = isFocused;
            }
            if (!isFocused) {
                this.touchedChanges.next(this.id);
            }
        };
        AxaSelect.prototype.ngDoCheck = function () {
            this.updateErrorState();
        };
AxaSelect.ɵfac = function AxaSelect_Factory(t) { return new (t || AxaSelect)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef), ɵngcc0.ɵɵdirectiveInject(ErrorStateMatcher), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgControl, 10), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgForm, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.FormGroupDirective, 8)); };
AxaSelect.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaSelect, selectors: [["", "axaSelect", ""]], hostAttrs: ["role", "listbox"], hostVars: 8, hostBindings: function AxaSelect_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("blur", function AxaSelect_blur_HostBindingHandler() { return ctx.focusChanged(false); })("focus", function AxaSelect_focus_HostBindingHandler() { return ctx.focusChanged(true); });
    } if (rf & 2) {
        ɵngcc0.ɵɵhostProperty("disabled", ctx.disabled)("required", ctx.required);
        ɵngcc0.ɵɵattribute("id", ctx.id)("placeholder", ctx.placeholder)("tabindex", ctx.tabIndex)("aria-required", ctx.required.toString())("aria-disabled", ctx.disabled.toString())("aria-invalid", ctx.errorState);
    } }, inputs: { id: "id", value: "value", required: "required", disabled: "disabled", placeholder: "placeholder" }, features: [ɵngcc0.ɵɵProvidersFeature([
            { provide: AxaFormFieldControl, useExisting: AxaSelect }
        ]), ɵngcc0.ɵɵInheritDefinitionFeature] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaSelect, [{
        type: i0.Directive,
        args: [{
                selector: '[axaSelect]',
                host: {
                    'role': 'listbox',
                    '[attr.id]': 'id',
                    '[attr.placeholder]': 'placeholder',
                    '[disabled]': 'disabled',
                    '[required]': 'required',
                    '[attr.tabindex]': 'tabIndex',
                    '[attr.aria-required]': 'required.toString()',
                    '[attr.aria-disabled]': 'disabled.toString()',
                    '[attr.aria-invalid]': 'errorState',
                    '(blur)': 'focusChanged(false)',
                    '(focus)': 'focusChanged(true)'
                },
                providers: [
                    { provide: AxaFormFieldControl, useExisting: AxaSelect }
                ]
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }, { type: ErrorStateMatcher }, { type: ɵngcc1.NgControl, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Self
            }] }, { type: ɵngcc1.NgForm, decorators: [{
                type: i0.Optional
            }] }, { type: ɵngcc1.FormGroupDirective, decorators: [{
                type: i0.Optional
            }] }]; }, { id: [{
            type: i0.Input
        }], value: [{
            type: i0.Input
        }], required: [{
            type: i0.Input
        }], disabled: [{
            type: i0.Input
        }], placeholder: [{
            type: i0.Input
        }] }); })();
        return AxaSelect;
    }(_AxaSelectMixinBase));
    AxaSelect.ctorParameters = function () { return [
        { type: i0.ElementRef },
        { type: ErrorStateMatcher },
        { type: forms.NgControl, decorators: [{ type: i0.Optional }, { type: i0.Self }] },
        { type: forms.NgForm, decorators: [{ type: i0.Optional }] },
        { type: forms.FormGroupDirective, decorators: [{ type: i0.Optional }] }
    ]; };
    AxaSelect.propDecorators = {
        id: [{ type: i0.Input }],
        value: [{ type: i0.Input }],
        placeholder: [{ type: i0.Input }],
        required: [{ type: i0.Input }],
        disabled: [{ type: i0.Input }]
    };

    var AxaSelectModule = /** @class */ (function () {
        function AxaSelectModule() {
        }
AxaSelectModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaSelectModule });
AxaSelectModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaSelectModule_Factory(t) { return new (t || AxaSelectModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaSelectModule, { declarations: [AxaSelect], imports: [ɵngcc2.CommonModule], exports: [AxaSelect] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaSelectModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaSelect],
                declarations: [AxaSelect]
            }]
    }], function () { return []; }, null); })();
        return AxaSelectModule;
    }());

    /**@ignore */
    var nextUniqueId$2 = 0;
    /** Error message to be shown underneath the form field. */
    var AxaError = /** @class */ (function () {
        function AxaError() {
            /**The id of the control. */
            this.id = "axa-error-" + nextUniqueId$2++;
        }
AxaError.ɵfac = function AxaError_Factory(t) { return new (t || AxaError)(); };
AxaError.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaError, selectors: [["axa-error"]], hostAttrs: ["role", "alert", 1, "axa-form-control-feedback"], hostVars: 1, hostBindings: function AxaError_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
    } }, inputs: { id: "id" } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaError, [{
        type: i0.Directive,
        args: [{
                selector: 'axa-error',
                host: {
                    'class': 'axa-form-control-feedback',
                    'role': 'alert',
                    '[attr.id]': 'id'
                }
            }]
    }], function () { return []; }, { id: [{
            type: i0.Input
        }] }); })();
        return AxaError;
    }());
    AxaError.propDecorators = {
        id: [{ type: i0.Input }]
    };

    /**@ignore */
    var nextUniqueId$3 = 0;
    /** Info message to be shown underneath the form field. */
    var AxaHint = /** @class */ (function () {
        function AxaHint() {
            /**The id of the control. */
            this.id = "axa-hint-" + nextUniqueId$3++;
        }
AxaHint.ɵfac = function AxaHint_Factory(t) { return new (t || AxaHint)(); };
AxaHint.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaHint, selectors: [["axa-hint"]], hostAttrs: [1, "axa-form-hint"], hostVars: 1, hostBindings: function AxaHint_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
    } }, inputs: { id: "id" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaHint_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHint, [{
        type: i0.Component,
        args: [{
                selector: 'axa-hint',
                template: "  <ng-content></ng-content>\r\n",
                host: {
                    'class': 'axa-form-hint',
                    '[attr.id]': 'id'
                }
            }]
    }], function () { return []; }, { id: [{
            type: i0.Input
        }] }); })();
        return AxaHint;
    }());
    AxaHint.propDecorators = {
        id: [{ type: i0.Input }]
    };

    /**Form error style. */
    var FORM_ERROR_STYLE = 'axa-form-group--has-danger';

    /**
     * Container for form inputs that displays errors and hints.
     * @export
     */
    var AxaFormField = /** @class */ (function () {
        /**
         *Creates an instance of AxaFormField.
         * @param cdr change detector ref
         */
        function AxaFormField(cdr) {
            this.cdr = cdr;
        }
        AxaFormField.prototype.ngAfterContentInit = function () {
            var _this = this;
            this.checkChildIsAxaControl();
            this.showErrorOrHint();
            this.control.errorStateChanges.subscribe(function () {
                _this.showErrorOrHint();
                _this.applyErrorStyle();
            });
        };
        AxaFormField.prototype.ngAfterContentChecked = function () {
            this.checkChildIsAxaControl();
        };
        /**Applies the error style to the root div. */
        AxaFormField.prototype.applyErrorStyle = function () {
            var element = this.divRef.nativeElement;
            if (this.control.errorState) {
                if (!element.classList.contains(FORM_ERROR_STYLE)) {
                    element.classList.add(FORM_ERROR_STYLE);
                }
            }
            else {
                element.classList.remove(FORM_ERROR_STYLE);
            }
        };
        AxaFormField.prototype.showErrorOrHint = function () {
            this.showError = this.axaErrors && this.axaErrors.length > 0 &&
                this.control.errorState;
            this.cdr.detectChanges();
        };
        AxaFormField.prototype.checkChildIsAxaControl = function () {
            if (!this.control) {
                throw new Error('axa-form-field must contain an axa control');
            }
        };
AxaFormField.ɵfac = function AxaFormField_Factory(t) { return new (t || AxaFormField)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef)); };
AxaFormField.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaFormField, selectors: [["axa-form-field"]], contentQueries: function AxaFormField_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaFormFieldControl, true);
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaError, false);
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaHint, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.control = _t.first);
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.axaErrors = _t);
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.axaHints = _t);
    } }, viewQuery: function AxaFormField_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵstaticViewQuery(_c1, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.divRef = _t.first);
    } }, inputs: { label: "label" }, ngContentSelectors: _c3, decls: 8, vars: 3, consts: [[1, "axa-form-group", 3, "ngSwitch"], ["div", ""], [4, "ngIf"], [4, "ngSwitchCase"], [4, "ngSwitchDefault"]], template: function AxaFormField_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c2);
        ɵngcc0.ɵɵelementStart(0, "div", 0, 1);
        ɵngcc0.ɵɵtemplate(2, AxaFormField_label_2_Template, 2, 1, "label", 2);
        ɵngcc0.ɵɵprojection(3);
        ɵngcc0.ɵɵprojection(4, 1);
        ɵngcc0.ɵɵprojection(5, 2);
        ɵngcc0.ɵɵtemplate(6, AxaFormField_6_Template, 1, 0, undefined, 3);
        ɵngcc0.ɵɵtemplate(7, AxaFormField_7_Template, 1, 0, undefined, 4);
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngSwitch", ctx.showError);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngIf", ctx.label);
        ɵngcc0.ɵɵadvance(4);
        ɵngcc0.ɵɵproperty("ngSwitchCase", true);
    } }, directives: [ɵngcc2.NgSwitch, ɵngcc2.NgIf, ɵngcc2.NgSwitchCase, ɵngcc2.NgSwitchDefault], encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFormField, [{
        type: i0.Component,
        args: [{
                selector: 'axa-form-field',
                template: "<div #div class=\"axa-form-group\" [ngSwitch]=\"showError\">\r\n    <label *ngIf=\"label\">{{label}}</label>\r\n    <ng-content select=\"axa-prefix\"></ng-content>\r\n\r\n    <ng-content></ng-content>\r\n\r\n    <ng-content select=\"axa-suffix\"></ng-content>\r\n\r\n    <ng-content *ngSwitchCase=\"true\" select=\"axa-error\"></ng-content>\r\n\r\n    <ng-content *ngSwitchDefault select=\"axa-hint\"></ng-content>\r\n</div>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc0.ChangeDetectorRef }]; }, { control: [{
            type: i0.ContentChild,
            args: [AxaFormFieldControl]
        }], axaErrors: [{
            type: i0.ContentChildren,
            args: [AxaError]
        }], axaHints: [{
            type: i0.ContentChildren,
            args: [AxaHint]
        }], divRef: [{
            type: i0.ViewChild,
            args: ['div', { static: true }]
        }], label: [{
            type: i0.Input
        }] }); })();
        return AxaFormField;
    }());
    AxaFormField.ctorParameters = function () { return [
        { type: i0.ChangeDetectorRef }
    ]; };
    AxaFormField.propDecorators = {
        control: [{ type: i0.ContentChild, args: [AxaFormFieldControl,] }],
        axaErrors: [{ type: i0.ContentChildren, args: [AxaError,] }],
        axaHints: [{ type: i0.ContentChildren, args: [AxaHint,] }],
        divRef: [{ type: i0.ViewChild, args: ['div', { static: true },] }],
        label: [{ type: i0.Input }]
    };

    /**Directive to attach an HTML element as a prefix in a form field. */
    var AxaPrefixDirective = /** @class */ (function () {
        function AxaPrefixDirective() {
            /**Style applied to the prefix element. */
            this.className = 'axa-form-field-prefix';
        }
AxaPrefixDirective.ɵfac = function AxaPrefixDirective_Factory(t) { return new (t || AxaPrefixDirective)(); };
AxaPrefixDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaPrefixDirective, selectors: [["axa-prefix"]], hostVars: 2, hostBindings: function AxaPrefixDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.className);
    } } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaPrefixDirective, [{
        type: i0.Directive,
        args: [{ selector: 'axa-prefix' }]
    }], function () { return []; }, { className: [{
            type: i0.HostBinding,
            args: ['class']
        }] }); })();
        return AxaPrefixDirective;
    }());
    AxaPrefixDirective.propDecorators = {
        className: [{ type: i0.HostBinding, args: ['class',] }]
    };

    /**Directive to attach an HTML element as a suffix in a form field. */
    var AxaSuffixDirective = /** @class */ (function () {
        function AxaSuffixDirective() {
            /**Style applied to the suffix element. */
            this.className = 'axa-form-field-suffix';
        }
AxaSuffixDirective.ɵfac = function AxaSuffixDirective_Factory(t) { return new (t || AxaSuffixDirective)(); };
AxaSuffixDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaSuffixDirective, selectors: [["axa-suffix"]], hostVars: 2, hostBindings: function AxaSuffixDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.className);
    } } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaSuffixDirective, [{
        type: i0.Directive,
        args: [{ selector: 'axa-suffix' }]
    }], function () { return []; }, { className: [{
            type: i0.HostBinding,
            args: ['class']
        }] }); })();
        return AxaSuffixDirective;
    }());
    AxaSuffixDirective.propDecorators = {
        className: [{ type: i0.HostBinding, args: ['class',] }]
    };

    var AxaFormFieldModule = /** @class */ (function () {
        function AxaFormFieldModule() {
        }
AxaFormFieldModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaFormFieldModule });
AxaFormFieldModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaFormFieldModule_Factory(t) { return new (t || AxaFormFieldModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaFormFieldModule, { declarations: [AxaFormField, AxaError, AxaHint, AxaPrefixDirective, AxaSuffixDirective], imports: [ɵngcc2.CommonModule], exports: [AxaFormField, AxaError, AxaHint, AxaPrefixDirective, AxaSuffixDirective] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFormFieldModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaFormField, AxaError, AxaHint, AxaPrefixDirective, AxaSuffixDirective],
                declarations: [AxaFormField, AxaError, AxaHint, AxaPrefixDirective, AxaSuffixDirective]
            }]
    }], function () { return []; }, null); })();
        return AxaFormFieldModule;
    }());

    /**Json array of the countries. */
    var countries = [
        {
            'name': 'Afghanistan',
            'dial': '+93',
            'code': 'AF'
        },
        {
            'name': 'Åland Islands',
            'dial': '+358',
            'code': 'AX'
        },
        {
            'name': 'Albania',
            'dial': '+355',
            'code': 'AL'
        },
        {
            'name': 'Algeria',
            'dial': '+213',
            'code': 'DZ'
        },
        {
            'name': 'American Samoa',
            'dial': '+1684',
            'code': 'AS'
        },
        {
            'name': 'Andorra',
            'dial': '+376',
            'code': 'AD'
        },
        {
            'name': 'Angola',
            'dial': '+244',
            'code': 'AO'
        },
        {
            'name': 'Anguilla',
            'dial': '+1264',
            'code': 'AI'
        },
        {
            'name': 'Antarctica',
            'dial': '+672',
            'code': 'AQ'
        },
        {
            'name': 'Antigua and Barbuda',
            'dial': '+1268',
            'code': 'AG'
        },
        {
            'name': 'Argentina',
            'dial': '+54',
            'code': 'AR'
        },
        {
            'name': 'Armenia',
            'dial': '+374',
            'code': 'AM'
        },
        {
            'name': 'Aruba',
            'dial': '+297',
            'code': 'AW'
        },
        {
            'name': 'Australia',
            'dial': '+61',
            'code': 'AU'
        },
        {
            'name': 'Austria',
            'dial': '+43',
            'code': 'AT'
        },
        {
            'name': 'Azerbaijan',
            'dial': '+994',
            'code': 'AZ'
        },
        {
            'name': 'Bahamas',
            'dial': '+1242',
            'code': 'BS'
        },
        {
            'name': 'Bahrain',
            'dial': '+973',
            'code': 'BH'
        },
        {
            'name': 'Bangladesh',
            'dial': '+880',
            'code': 'BD'
        },
        {
            'name': 'Barbados',
            'dial': '+1246',
            'code': 'BB'
        },
        {
            'name': 'Belarus',
            'dial': '+375',
            'code': 'BY'
        },
        {
            'name': 'Belgium',
            'dial': '+32',
            'code': 'BE'
        },
        {
            'name': 'Belize',
            'dial': '+501',
            'code': 'BZ'
        },
        {
            'name': 'Benin',
            'dial': '+229',
            'code': 'BJ'
        },
        {
            'name': 'Bermuda',
            'dial': '+1441',
            'code': 'BM'
        },
        {
            'name': 'Bhutan',
            'dial': '+975',
            'code': 'BT'
        },
        {
            'name': 'Bolivia, Plurinational State of bolivia',
            'dial': '+591',
            'code': 'BO'
        },
        {
            'name': 'Bosnia and Herzegovina',
            'dial': '+387',
            'code': 'BA'
        },
        {
            'name': 'Botswana',
            'dial': '+267',
            'code': 'BW'
        },
        {
            'name': 'Bouvet Island',
            'dial': '+47',
            'code': 'BV'
        },
        {
            'name': 'Brazil',
            'dial': '+55',
            'code': 'BR'
        },
        {
            'name': 'British Indian Ocean Territory',
            'dial': '+246',
            'code': 'IO'
        },
        {
            'name': 'Brunei Darussalam',
            'dial': '+673',
            'code': 'BN'
        },
        {
            'name': 'Bulgaria',
            'dial': '+359',
            'code': 'BG'
        },
        {
            'name': 'Burkina Faso',
            'dial': '+226',
            'code': 'BF'
        },
        {
            'name': 'Burundi',
            'dial': '+257',
            'code': 'BI'
        },
        {
            'name': 'Cambodia',
            'dial': '+855',
            'code': 'KH'
        },
        {
            'name': 'Cameroon',
            'dial': '+237',
            'code': 'CM'
        },
        {
            'name': 'Canada',
            'dial': '+1',
            'code': 'CA'
        },
        {
            'name': 'Cape Verde',
            'dial': '+238',
            'code': 'CV'
        },
        {
            'name': 'Cayman Islands',
            'dial': '+ 345',
            'code': 'KY'
        },
        {
            'name': 'Central African Republic',
            'dial': '+236',
            'code': 'CF'
        },
        {
            'name': 'Chad',
            'dial': '+235',
            'code': 'TD'
        },
        {
            'name': 'Chile',
            'dial': '+56',
            'code': 'CL'
        },
        {
            'name': 'China',
            'dial': '+86',
            'code': 'CN'
        },
        {
            'name': 'Christmas Island',
            'dial': '+61',
            'code': 'CX'
        },
        {
            'name': 'Cocos (Keeling) Islands',
            'dial': '+61',
            'code': 'CC'
        },
        {
            'name': 'Colombia',
            'dial': '+57',
            'code': 'CO'
        },
        {
            'name': 'Comoros',
            'dial': '+269',
            'code': 'KM'
        },
        {
            'name': 'Congo',
            'dial': '+242',
            'code': 'CG'
        },
        {
            'name': 'Congo, The Democratic Republic of the Congo',
            'dial': '+243',
            'code': 'CD'
        },
        {
            'name': 'Cook Islands',
            'dial': '+682',
            'code': 'CK'
        },
        {
            'name': 'Costa Rica',
            'dial': '+506',
            'code': 'CR'
        },
        {
            'name': 'Cote d\'Ivoire',
            'dial': '+225',
            'code': 'CI'
        },
        {
            'name': 'Croatia',
            'dial': '+385',
            'code': 'HR'
        },
        {
            'name': 'Cuba',
            'dial': '+53',
            'code': 'CU'
        },
        {
            'name': 'Cyprus',
            'dial': '+357',
            'code': 'CY'
        },
        {
            'name': 'Czech Republic',
            'dial': '+420',
            'code': 'CZ'
        },
        {
            'name': 'Denmark',
            'dial': '+45',
            'code': 'DK'
        },
        {
            'name': 'Djibouti',
            'dial': '+253',
            'code': 'DJ'
        },
        {
            'name': 'Dominica',
            'dial': '+1767',
            'code': 'DM'
        },
        {
            'name': 'Dominican Republic',
            'dial': '+1849',
            'code': 'DO'
        },
        {
            'name': 'Ecuador',
            'dial': '+593',
            'code': 'EC'
        },
        {
            'name': 'Egypt',
            'dial': '+20',
            'code': 'EG'
        },
        {
            'name': 'El Salvador',
            'dial': '+503',
            'code': 'SV'
        },
        {
            'name': 'Equatorial Guinea',
            'dial': '+240',
            'code': 'GQ'
        },
        {
            'name': 'Eritrea',
            'dial': '+291',
            'code': 'ER'
        },
        {
            'name': 'Estonia',
            'dial': '+372',
            'code': 'EE'
        },
        {
            'name': 'Ethiopia',
            'dial': '+251',
            'code': 'ET'
        },
        {
            'name': 'Falkland Islands (Malvinas)',
            'dial': '+500',
            'code': 'FK'
        },
        {
            'name': 'Faroe Islands',
            'dial': '+298',
            'code': 'FO'
        },
        {
            'name': 'Fiji',
            'dial': '+679',
            'code': 'FJ'
        },
        {
            'name': 'Finland',
            'dial': '+358',
            'code': 'FI'
        },
        {
            'name': 'France',
            'dial': '+33',
            'code': 'FR'
        },
        {
            'name': 'French Guiana',
            'dial': '+594',
            'code': 'GF'
        },
        {
            'name': 'French Polynesia',
            'dial': '+689',
            'code': 'PF'
        },
        {
            'name': 'French Southern Territories',
            'dial': '+262',
            'code': 'TF'
        },
        {
            'name': 'Gabon',
            'dial': '+241',
            'code': 'GA'
        },
        {
            'name': 'Gambia',
            'dial': '+220',
            'code': 'GM'
        },
        {
            'name': 'Georgia',
            'dial': '+995',
            'code': 'GE'
        },
        {
            'name': 'Germany',
            'dial': '+49',
            'code': 'DE'
        },
        {
            'name': 'Ghana',
            'dial': '+233',
            'code': 'GH'
        },
        {
            'name': 'Gibraltar',
            'dial': '+350',
            'code': 'GI'
        },
        {
            'name': 'Greece',
            'dial': '+30',
            'code': 'GR'
        },
        {
            'name': 'Greenland',
            'dial': '+299',
            'code': 'GL'
        },
        {
            'name': 'Grenada',
            'dial': '+1473',
            'code': 'GD'
        },
        {
            'name': 'Guadeloupe',
            'dial': '+590',
            'code': 'GP'
        },
        {
            'name': 'Guam',
            'dial': '+1671',
            'code': 'GU'
        },
        {
            'name': 'Guatemala',
            'dial': '+502',
            'code': 'GT'
        },
        {
            'name': 'Guernsey',
            'dial': '+44',
            'code': 'GG'
        },
        {
            'name': 'Guinea',
            'dial': '+224',
            'code': 'GN'
        },
        {
            'name': 'Guinea-Bissau',
            'dial': '+245',
            'code': 'GW'
        },
        {
            'name': 'Guyana',
            'dial': '+592',
            'code': 'GY'
        },
        {
            'name': 'Haiti',
            'dial': '+509',
            'code': 'HT'
        },
        {
            'name': 'Heard Island and Mcdonald Islands',
            'dial': '+0',
            'code': 'HM'
        },
        {
            'name': 'Holy See (Vatican City State)',
            'dial': '+379',
            'code': 'VA'
        },
        {
            'name': 'Honduras',
            'dial': '+504',
            'code': 'HN'
        },
        {
            'name': 'Hong Kong',
            'dial': '+852',
            'code': 'HK'
        },
        {
            'name': 'Hungary',
            'dial': '+36',
            'code': 'HU'
        },
        {
            'name': 'Iceland',
            'dial': '+354',
            'code': 'IS'
        },
        {
            'name': 'India',
            'dial': '+91',
            'code': 'IN'
        },
        {
            'name': 'Indonesia',
            'dial': '+62',
            'code': 'ID'
        },
        {
            'name': 'Iran, Islamic Republic of Persian Gulf',
            'dial': '+98',
            'code': 'IR'
        },
        {
            'name': 'Iraq',
            'dial': '+964',
            'code': 'IQ'
        },
        {
            'name': 'Ireland',
            'dial': '+353',
            'code': 'IE'
        },
        {
            'name': 'Isle of Man',
            'dial': '+44',
            'code': 'IM'
        },
        {
            'name': 'Israel',
            'dial': '+972',
            'code': 'IL'
        },
        {
            'name': 'Italy',
            'dial': '+39',
            'code': 'IT'
        },
        {
            'name': 'Jamaica',
            'dial': '+1876',
            'code': 'JM'
        },
        {
            'name': 'Japan',
            'dial': '+81',
            'code': 'JP'
        },
        {
            'name': 'Jersey',
            'dial': '+44',
            'code': 'JE'
        },
        {
            'name': 'Jordan',
            'dial': '+962',
            'code': 'JO'
        },
        {
            'name': 'Kazakhstan',
            'dial': '+7',
            'code': 'KZ'
        },
        {
            'name': 'Kenya',
            'dial': '+254',
            'code': 'KE'
        },
        {
            'name': 'Kiribati',
            'dial': '+686',
            'code': 'KI'
        },
        {
            'name': 'Korea, Democratic People\'s Republic of Korea',
            'dial': '+850',
            'code': 'KP'
        },
        {
            'name': 'Korea, Republic of South Korea',
            'dial': '+82',
            'code': 'KR'
        },
        {
            'name': 'Kosovo',
            'dial': '+383',
            'code': 'XK'
        },
        {
            'name': 'Kuwait',
            'dial': '+965',
            'code': 'KW'
        },
        {
            'name': 'Kyrgyzstan',
            'dial': '+996',
            'code': 'KG'
        },
        {
            'name': 'Laos',
            'dial': '+856',
            'code': 'LA'
        },
        {
            'name': 'Latvia',
            'dial': '+371',
            'code': 'LV'
        },
        {
            'name': 'Lebanon',
            'dial': '+961',
            'code': 'LB'
        },
        {
            'name': 'Lesotho',
            'dial': '+266',
            'code': 'LS'
        },
        {
            'name': 'Liberia',
            'dial': '+231',
            'code': 'LR'
        },
        {
            'name': 'Libyan Arab Jamahiriya',
            'dial': '+218',
            'code': 'LY'
        },
        {
            'name': 'Liechtenstein',
            'dial': '+423',
            'code': 'LI'
        },
        {
            'name': 'Lithuania',
            'dial': '+370',
            'code': 'LT'
        },
        {
            'name': 'Luxembourg',
            'dial': '+352',
            'code': 'LU'
        },
        {
            'name': 'Macao',
            'dial': '+853',
            'code': 'MO'
        },
        {
            'name': 'Macedonia',
            'dial': '+389',
            'code': 'MK'
        },
        {
            'name': 'Madagascar',
            'dial': '+261',
            'code': 'MG'
        },
        {
            'name': 'Malawi',
            'dial': '+265',
            'code': 'MW'
        },
        {
            'name': 'Malaysia',
            'dial': '+60',
            'code': 'MY'
        },
        {
            'name': 'Maldives',
            'dial': '+960',
            'code': 'MV'
        },
        {
            'name': 'Mali',
            'dial': '+223',
            'code': 'ML'
        },
        {
            'name': 'Malta',
            'dial': '+356',
            'code': 'MT'
        },
        {
            'name': 'Marshall Islands',
            'dial': '+692',
            'code': 'MH'
        },
        {
            'name': 'Martinique',
            'dial': '+596',
            'code': 'MQ'
        },
        {
            'name': 'Mauritania',
            'dial': '+222',
            'code': 'MR'
        },
        {
            'name': 'Mauritius',
            'dial': '+230',
            'code': 'MU'
        },
        {
            'name': 'Mayotte',
            'dial': '+262',
            'code': 'YT'
        },
        {
            'name': 'Mexico',
            'dial': '+52',
            'code': 'MX'
        },
        {
            'name': 'Micronesia, Federated States of Micronesia',
            'dial': '+691',
            'code': 'FM'
        },
        {
            'name': 'Moldova',
            'dial': '+373',
            'code': 'MD'
        },
        {
            'name': 'Monaco',
            'dial': '+377',
            'code': 'MC'
        },
        {
            'name': 'Mongolia',
            'dial': '+976',
            'code': 'MN'
        },
        {
            'name': 'Montenegro',
            'dial': '+382',
            'code': 'ME'
        },
        {
            'name': 'Montserrat',
            'dial': '+1664',
            'code': 'MS'
        },
        {
            'name': 'Morocco',
            'dial': '+212',
            'code': 'MA'
        },
        {
            'name': 'Mozambique',
            'dial': '+258',
            'code': 'MZ'
        },
        {
            'name': 'Myanmar',
            'dial': '+95',
            'code': 'MM'
        },
        {
            'name': 'Namibia',
            'dial': '+264',
            'code': 'NA'
        },
        {
            'name': 'Nauru',
            'dial': '+674',
            'code': 'NR'
        },
        {
            'name': 'Nepal',
            'dial': '+977',
            'code': 'NP'
        },
        {
            'name': 'Netherlands',
            'dial': '+31',
            'code': 'NL'
        },
        {
            'name': 'Netherlands Antilles',
            'dial': '+599',
            'code': 'AN'
        },
        {
            'name': 'New Caledonia',
            'dial': '+687',
            'code': 'NC'
        },
        {
            'name': 'New Zealand',
            'dial': '+64',
            'code': 'NZ'
        },
        {
            'name': 'Nicaragua',
            'dial': '+505',
            'code': 'NI'
        },
        {
            'name': 'Niger',
            'dial': '+227',
            'code': 'NE'
        },
        {
            'name': 'Nigeria',
            'dial': '+234',
            'code': 'NG'
        },
        {
            'name': 'Niue',
            'dial': '+683',
            'code': 'NU'
        },
        {
            'name': 'Norfolk Island',
            'dial': '+672',
            'code': 'NF'
        },
        {
            'name': 'Northern Mariana Islands',
            'dial': '+1670',
            'code': 'MP'
        },
        {
            'name': 'Norway',
            'dial': '+47',
            'code': 'NO'
        },
        {
            'name': 'Oman',
            'dial': '+968',
            'code': 'OM'
        },
        {
            'name': 'Pakistan',
            'dial': '+92',
            'code': 'PK'
        },
        {
            'name': 'Palau',
            'dial': '+680',
            'code': 'PW'
        },
        {
            'name': 'Palestinian Territory, Occupied',
            'dial': '+970',
            'code': 'PS'
        },
        {
            'name': 'Panama',
            'dial': '+507',
            'code': 'PA'
        },
        {
            'name': 'Papua New Guinea',
            'dial': '+675',
            'code': 'PG'
        },
        {
            'name': 'Paraguay',
            'dial': '+595',
            'code': 'PY'
        },
        {
            'name': 'Peru',
            'dial': '+51',
            'code': 'PE'
        },
        {
            'name': 'Philippines',
            'dial': '+63',
            'code': 'PH'
        },
        {
            'name': 'Pitcairn',
            'dial': '+64',
            'code': 'PN'
        },
        {
            'name': 'Poland',
            'dial': '+48',
            'code': 'PL'
        },
        {
            'name': 'Portugal',
            'dial': '+351',
            'code': 'PT'
        },
        {
            'name': 'Puerto Rico',
            'dial': '+1939',
            'code': 'PR'
        },
        {
            'name': 'Qatar',
            'dial': '+974',
            'code': 'QA'
        },
        {
            'name': 'Romania',
            'dial': '+40',
            'code': 'RO'
        },
        {
            'name': 'Russia',
            'dial': '+7',
            'code': 'RU'
        },
        {
            'name': 'Rwanda',
            'dial': '+250',
            'code': 'RW'
        },
        {
            'name': 'Reunion',
            'dial': '+262',
            'code': 'RE'
        },
        {
            'name': 'Saint Barthelemy',
            'dial': '+590',
            'code': 'BL'
        },
        {
            'name': 'Saint Helena, Ascension and Tristan Da Cunha',
            'dial': '+290',
            'code': 'SH'
        },
        {
            'name': 'Saint Kitts and Nevis',
            'dial': '+1869',
            'code': 'KN'
        },
        {
            'name': 'Saint Lucia',
            'dial': '+1758',
            'code': 'LC'
        },
        {
            'name': 'Saint Martin',
            'dial': '+590',
            'code': 'MF'
        },
        {
            'name': 'Saint Pierre and Miquelon',
            'dial': '+508',
            'code': 'PM'
        },
        {
            'name': 'Saint Vincent and the Grenadines',
            'dial': '+1784',
            'code': 'VC'
        },
        {
            'name': 'Samoa',
            'dial': '+685',
            'code': 'WS'
        },
        {
            'name': 'San Marino',
            'dial': '+378',
            'code': 'SM'
        },
        {
            'name': 'Sao Tome and Principe',
            'dial': '+239',
            'code': 'ST'
        },
        {
            'name': 'Saudi Arabia',
            'dial': '+966',
            'code': 'SA'
        },
        {
            'name': 'Senegal',
            'dial': '+221',
            'code': 'SN'
        },
        {
            'name': 'Serbia',
            'dial': '+381',
            'code': 'RS'
        },
        {
            'name': 'Seychelles',
            'dial': '+248',
            'code': 'SC'
        },
        {
            'name': 'Sierra Leone',
            'dial': '+232',
            'code': 'SL'
        },
        {
            'name': 'Singapore',
            'dial': '+65',
            'code': 'SG'
        },
        {
            'name': 'Slovakia',
            'dial': '+421',
            'code': 'SK'
        },
        {
            'name': 'Slovenia',
            'dial': '+386',
            'code': 'SI'
        },
        {
            'name': 'Solomon Islands',
            'dial': '+677',
            'code': 'SB'
        },
        {
            'name': 'Somalia',
            'dial': '+252',
            'code': 'SO'
        },
        {
            'name': 'South Africa',
            'dial': '+27',
            'code': 'ZA'
        },
        {
            'name': 'South Sudan',
            'dial': '+211',
            'code': 'SS'
        },
        {
            'name': 'South Georgia and the South Sandwich Islands',
            'dial': '+500',
            'code': 'GS'
        },
        {
            'name': 'Spain',
            'dial': '+34',
            'code': 'ES'
        },
        {
            'name': 'Sri Lanka',
            'dial': '+94',
            'code': 'LK'
        },
        {
            'name': 'Sudan',
            'dial': '+249',
            'code': 'SD'
        },
        {
            'name': 'Suriname',
            'dial': '+597',
            'code': 'SR'
        },
        {
            'name': 'Svalbard and Jan Mayen',
            'dial': '+47',
            'code': 'SJ'
        },
        {
            'name': 'Swaziland',
            'dial': '+268',
            'code': 'SZ'
        },
        {
            'name': 'Sweden',
            'dial': '+46',
            'code': 'SE'
        },
        {
            'name': 'Switzerland',
            'dial': '+41',
            'code': 'CH'
        },
        {
            'name': 'Syrian Arab Republic',
            'dial': '+963',
            'code': 'SY'
        },
        {
            'name': 'Taiwan',
            'dial': '+886',
            'code': 'TW'
        },
        {
            'name': 'Tajikistan',
            'dial': '+992',
            'code': 'TJ'
        },
        {
            'name': 'Tanzania, United Republic of Tanzania',
            'dial': '+255',
            'code': 'TZ'
        },
        {
            'name': 'Thailand',
            'dial': '+66',
            'code': 'TH'
        },
        {
            'name': 'Timor-Leste',
            'dial': '+670',
            'code': 'TL'
        },
        {
            'name': 'Togo',
            'dial': '+228',
            'code': 'TG'
        },
        {
            'name': 'Tokelau',
            'dial': '+690',
            'code': 'TK'
        },
        {
            'name': 'Tonga',
            'dial': '+676',
            'code': 'TO'
        },
        {
            'name': 'Trinidad and Tobago',
            'dial': '+1868',
            'code': 'TT'
        },
        {
            'name': 'Tunisia',
            'dial': '+216',
            'code': 'TN'
        },
        {
            'name': 'Turkey',
            'dial': '+90',
            'code': 'TR'
        },
        {
            'name': 'Turkmenistan',
            'dial': '+993',
            'code': 'TM'
        },
        {
            'name': 'Turks and Caicos Islands',
            'dial': '+1649',
            'code': 'TC'
        },
        {
            'name': 'Tuvalu',
            'dial': '+688',
            'code': 'TV'
        },
        {
            'name': 'Uganda',
            'dial': '+256',
            'code': 'UG'
        },
        {
            'name': 'Ukraine',
            'dial': '+380',
            'code': 'UA'
        },
        {
            'name': 'United Arab Emirates',
            'dial': '+971',
            'code': 'AE'
        },
        {
            'name': 'United Kingdom',
            'dial': '+44',
            'code': 'GB'
        },
        {
            'name': 'United States',
            'dial': '+1',
            'code': 'US'
        },
        {
            'name': 'Uruguay',
            'dial': '+598',
            'code': 'UY'
        },
        {
            'name': 'Uzbekistan',
            'dial': '+998',
            'code': 'UZ'
        },
        {
            'name': 'Vanuatu',
            'dial': '+678',
            'code': 'VU'
        },
        {
            'name': 'Venezuela, Bolivarian Republic of Venezuela',
            'dial': '+58',
            'code': 'VE'
        },
        {
            'name': 'Vietnam',
            'dial': '+84',
            'code': 'VN'
        },
        {
            'name': 'Virgin Islands, British',
            'dial': '+1284',
            'code': 'VG'
        },
        {
            'name': 'Virgin Islands, U.S.',
            'dial': '+1340',
            'code': 'VI'
        },
        {
            'name': 'Wallis and Futuna',
            'dial': '+681',
            'code': 'WF'
        },
        {
            'name': 'Yemen',
            'dial': '+967',
            'code': 'YE'
        },
        {
            'name': 'Zambia',
            'dial': '+260',
            'code': 'ZM'
        },
        {
            'name': 'Zimbabwe',
            'dial': '+263',
            'code': 'ZW'
        }
    ];

    /**Service that returns a list of countries. */
    var AxaCountryService = /** @class */ (function () {
        function AxaCountryService() {
        }
        /**Returns an array of all the countries. */
        AxaCountryService.prototype.getCountries = function () {
            return countries;
        };
AxaCountryService.ɵfac = function AxaCountryService_Factory(t) { return new (t || AxaCountryService)(); };
AxaCountryService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaCountryService, factory: function (t) { return AxaCountryService.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCountryService, [{
        type: i0.Injectable
    }], function () { return []; }, null); })();
        return AxaCountryService;
    }());

    /**Unique ID generated for phone inputs. */
    var nextUniqueId$4 = 0;
    /**Value Accessor provider to enable ngModel. */
    var AXA_PHONE_INPUT_CONTROL_VALUE_ACCESSOR = {
        provide: forms.NG_VALUE_ACCESSOR,
        useExisting: i0.forwardRef(function () { return AxaPhoneInputComponent; }),
        multi: true
    };
    /**@ignore */
    var AxaPhoneInputBase = /** @class */ (function () {
        function AxaPhoneInputBase(_defaultErrorStateMatcher, cdr, _parentForm, _parentFormGroup, ngControl) {
            this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
            this.cdr = cdr;
            this._parentForm = _parentForm;
            this._parentFormGroup = _parentFormGroup;
            this.ngControl = ngControl;
        }
        return AxaPhoneInputBase;
    }());
    /**@ignore */
    var _AxaPhoneInputMixinBase = mixinParentErrorState(AxaPhoneInputBase);
    /**Input to enter international phone number. */
    var AxaPhoneInputComponent = /** @class */ (function (_super) {
        __extends(AxaPhoneInputComponent, _super);
        /**
         *Creates an instance of AxaPhoneInputComponent.
         * @param ngControl the underlying control
         * @param parentForm the parent form
         * @param parentFormGroup the parent formgroup
         * @param defaultErrorStateMatcher the errorstatematcher that will be used
         * @param cdr changedetectorref
         * @param _injector dependency injector
         * @param countrySvc the country service
         */
        function AxaPhoneInputComponent(ngControl, parentForm, parentFormGroup, defaultErrorStateMatcher, cdr, _injector, countrySvc) {
            var _this = _super.call(this, defaultErrorStateMatcher, cdr, parentForm, parentFormGroup, ngControl) || this;
            _this.ngControl = ngControl;
            _this.cdr = cdr;
            _this._injector = _injector;
            _this.countrySvc = countrySvc;
            _this._uniqueId = "axa-phone-input-" + ++nextUniqueId$4;
            /**Default style of the step. */
            _this.cls = true;
            /**
             * Stream that emits when the errorState of the control changes.
             */
            _this.errorStateChanges = new rxjs.Subject();
            /**
             * Whether the control is focused.
             */
            _this.focused = false;
            _this._required = false;
            _this._disabled = false;
            _this._readonly = false;
            _this._selectedCountry = null;
            /**Input associated with the internal input control. */
            _this.inputValue = '';
            /**
             * Implementation of the value accessor.
             */
            _this.valueAccessorChange = function () { };
            _this.id = _this.id;
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            if (_this.ngControl != null) {
                _this.ngControl.valueAccessor = _this;
            }
            _this.countries = _this.countrySvc.getCountries();
            return _this;
        }
        Object.defineProperty(AxaPhoneInputComponent.prototype, "required", {
            /**
             * Whether the control is required.
             */
            get: function () { return this._required; },
            set: function (value) { this._required = coerceBooleanProperty(value); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaPhoneInputComponent.prototype, "disabled", {
            /**
             * Whether the control is disabled.
             */
            get: function () {
                return this._disabled;
            },
            set: function (value) {
                this._disabled = coerceBooleanProperty(value);
                if (this.focused) {
                    this.focused = false;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaPhoneInputComponent.prototype, "readonly", {
            /**
             * Whether the control is readonly.
             */
            get: function () { return this._readonly; },
            set: function (value) { this._readonly = coerceBooleanProperty(value); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaPhoneInputComponent.prototype, "id", {
            /**
             * Element ID.
             */
            get: function () { return this._id; },
            set: function (value) { this._id = value || this._uniqueId; },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaPhoneInputComponent.prototype, "selectedCountry", {
            /**The selected dial country. */
            get: function () {
                return this._selectedCountry;
            },
            set: function (v) {
                this._selectedCountry = v;
                this.evaluateInput();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaPhoneInputComponent.prototype, "value", {
            /**The phone number. */
            get: function () { return this._value; },
            set: function (value) {
                this._value = value;
                this.valueAccessorChange(this._value);
            },
            enumerable: false,
            configurable: true
        });
        AxaPhoneInputComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.favoriteCountries = this.countries.filter(function (c) { return _this.favorites.indexOf(c.code) !== -1; });
            setTimeout(function () {
                if (_this.default) {
                    _this.selectedCountry = _this.countries.find((function (country) { return country.code === _this.default; }));
                }
                _this.cdr.markForCheck();
            }, 0);
            this.ngControl = this._injector.get(forms.NgControl);
        };
        AxaPhoneInputComponent.prototype.ngOnDestroy = function () {
            this.unMonitorChildrenControls();
        };
        AxaPhoneInputComponent.prototype.ngAfterViewInit = function () {
            this.childrenControls = this.axaControls;
            this.monitorChildrenControls();
        };
        /**Reacts to changes in the inner input control. */
        AxaPhoneInputComponent.prototype.onInputChange = function () {
            this.evaluateInput();
        };
        /**Evaluates the input to read the dial code. */
        AxaPhoneInputComponent.prototype.evaluateInput = function () {
            var input = this.inputValue;
            if (input && input.length > 1) {
                var result = this.countries.filter(function (count) { return count.dial === input.substring(0, count.dial.length); });
                if (result && result.length > 0 && this._selectedCountry === null) {
                    this._selectedCountry = result[0];
                    if (input && input.indexOf(this._selectedCountry.dial) !== -1) {
                        this.inputValue = input.substring(this._selectedCountry.dial.length, input.length);
                    }
                }
            }
            this._value = this._selectedCountry && this.inputValue ? this._selectedCountry.dial + this.inputValue : '';
            this.valueAccessorChange(this._value);
        };
        /**
         * Implementation of the value accessor.
         */
        AxaPhoneInputComponent.prototype.writeValue = function (value) {
            if (value && value.length > 1) {
                var result = this.countries.filter(function (count) { return count.dial === value.substring(0, count.dial.length); });
                if (result.length > 0 && this._selectedCountry === null) {
                    this._selectedCountry = result[0];
                    if (value.indexOf(this._selectedCountry.dial) !== -1) {
                        this.inputValue = value.substring(this._selectedCountry.dial.length, value.length);
                    }
                }
            }
            else if (value === null) {
                this._selectedCountry = null;
                this.inputValue = null;
                this.cdr.markForCheck();
            }
        };
        /**
         * Implementation of the value accessor.
         */
        AxaPhoneInputComponent.prototype.registerOnChange = function (fn) {
            this.valueAccessorChange = fn;
        };
        /**
         * Implementation of the value accessor.
         */
        AxaPhoneInputComponent.prototype.registerOnTouched = function (fn) {
            this.valueAccessorTouch = fn;
        };
        /**
         * Implementation of the value accessor.
         */
        AxaPhoneInputComponent.prototype.setDisabledState = function (isDisabled) {
            this.disabled = isDisabled;
            this.cdr.markForCheck();
        };
AxaPhoneInputComponent.ɵfac = function AxaPhoneInputComponent_Factory(t) { return new (t || AxaPhoneInputComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgControl, 10), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgForm, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.FormGroupDirective, 8), ɵngcc0.ɵɵdirectiveInject(ErrorStateMatcher), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.Injector), ɵngcc0.ɵɵdirectiveInject(AxaCountryService)); };
AxaPhoneInputComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaPhoneInputComponent, selectors: [["axa-phone-input"]], viewQuery: function AxaPhoneInputComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵviewQuery(AxaFormFieldControl, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.axaControls = _t);
    } }, hostVars: 3, hostBindings: function AxaPhoneInputComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
        ɵngcc0.ɵɵclassProp("axa-phone-input", ctx.cls);
    } }, inputs: { required: "required", disabled: "disabled", readonly: "readonly", id: "id", value: "value", name: "name", placeholder: "placeholder", favorites: "favorites", default: "default" }, features: [ɵngcc0.ɵɵProvidersFeature([
            { provide: AxaFormFieldControl, useExisting: AxaPhoneInputComponent },
            AxaCountryService
        ]), ɵngcc0.ɵɵInheritDefinitionFeature], decls: 8, vars: 12, consts: [["axaSelect", "", "id", "flags", "name", "flags", 3, "ngModel", "required", "disabled", "ngModelChange"], [3, "ngValue", 4, "ngFor", "ngForOf"], ["disabled", ""], ["axaInput", "", "axaNumbersOnly", "", 3, "id", "name", "placeholder", "required", "disabled", "readonly", "ngModel", "ngModelChange"], [3, "ngValue"]], template: function AxaPhoneInputComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "axa-prefix");
        ɵngcc0.ɵɵelementStart(1, "select", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaPhoneInputComponent_Template_select_ngModelChange_1_listener($event) { return ctx.selectedCountry = $event; });
        ɵngcc0.ɵɵelementStart(2, "optgroup");
        ɵngcc0.ɵɵtemplate(3, AxaPhoneInputComponent_option_3_Template, 2, 3, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(4, "option", 2);
        ɵngcc0.ɵɵtext(5, "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtemplate(6, AxaPhoneInputComponent_option_6_Template, 2, 3, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(7, "input", 3);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaPhoneInputComponent_Template_input_ngModelChange_7_listener($event) { return ctx.inputValue = $event; })("ngModelChange", function AxaPhoneInputComponent_Template_input_ngModelChange_7_listener() { return ctx.onInputChange(); });
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngModel", ctx.selectedCountry)("required", ctx.required)("disabled", ctx.disabled);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.favoriteCountries);
        ɵngcc0.ɵɵadvance(3);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.countries);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("id", ctx.id)("name", ctx.name)("placeholder", ctx.placeholder)("required", ctx.required)("disabled", ctx.disabled)("readonly", ctx.readonly)("ngModel", ctx.inputValue);
    } }, directives: function () { return [AxaPrefixDirective, ɵngcc1.SelectControlValueAccessor, AxaSelect, ɵngcc1.NgControlStatus, ɵngcc1.NgModel, ɵngcc1.RequiredValidator, ɵngcc2.NgForOf, ɵngcc1.NgSelectOption, ɵngcc1.ɵangular_packages_forms_forms_x, AxaInput, ɵngcc1.DefaultValueAccessor, AxaNumbersOnlyDirective]; }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaPhoneInputComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-phone-input',
                host: {
                    '[attr.id]': 'id'
                },
                template: "<axa-prefix>\r\n  <select axaSelect id=\"flags\" name=\"flags\" [(ngModel)]=\"selectedCountry\" [required]=\"required\" [disabled]=\"disabled\">\r\n    <optgroup>\r\n      <option *ngFor=\"let country of favoriteCountries\" [ngValue]=\"country\">\r\n        {{country.code}} {{country.dial}}\r\n      </option>\r\n    </optgroup>\r\n    <option disabled>\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500</option>\r\n    <option *ngFor=\"let country of countries\" [ngValue]=\"country\">{{country.code}} {{country.dial}}</option>\r\n  </select>\r\n</axa-prefix>\r\n<input axaInput axaNumbersOnly [id]=\"id\" [name]=\"name\" [placeholder]=\"placeholder\" [required]=\"required\"\r\n  [disabled]=\"disabled\" [readonly]=\"readonly\" [(ngModel)]=\"inputValue\" (ngModelChange)=\"onInputChange()\">",
                providers: [
                    { provide: AxaFormFieldControl, useExisting: AxaPhoneInputComponent },
                    AxaCountryService
                ],
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc1.NgControl, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Self
            }] }, { type: ɵngcc1.NgForm, decorators: [{
                type: i0.Optional
            }] }, { type: ɵngcc1.FormGroupDirective, decorators: [{
                type: i0.Optional
            }] }, { type: ErrorStateMatcher }, { type: ɵngcc0.ChangeDetectorRef }, { type: ɵngcc0.Injector }, { type: AxaCountryService }]; }, { required: [{
            type: i0.Input
        }], disabled: [{
            type: i0.Input
        }], readonly: [{
            type: i0.Input
        }], id: [{
            type: i0.Input
        }], value: [{
            type: i0.Input
        }], cls: [{
            type: i0.HostBinding,
            args: ["class.axa-phone-input"]
        }], name: [{
            type: i0.Input
        }], placeholder: [{
            type: i0.Input
        }], favorites: [{
            type: i0.Input
        }], default: [{
            type: i0.Input
        }], axaControls: [{
            type: i0.ViewChildren,
            args: [AxaFormFieldControl]
        }] }); })();
        return AxaPhoneInputComponent;
    }(_AxaPhoneInputMixinBase));
    AxaPhoneInputComponent.ctorParameters = function () { return [
        { type: forms.NgControl, decorators: [{ type: i0.Optional }, { type: i0.Self }] },
        { type: forms.NgForm, decorators: [{ type: i0.Optional }] },
        { type: forms.FormGroupDirective, decorators: [{ type: i0.Optional }] },
        { type: ErrorStateMatcher },
        { type: i0.ChangeDetectorRef },
        { type: i0.Injector },
        { type: AxaCountryService }
    ]; };
    AxaPhoneInputComponent.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ["class.axa-phone-input",] }],
        name: [{ type: i0.Input }],
        required: [{ type: i0.Input }],
        disabled: [{ type: i0.Input }],
        readonly: [{ type: i0.Input }],
        placeholder: [{ type: i0.Input }],
        id: [{ type: i0.Input }],
        value: [{ type: i0.Input }],
        favorites: [{ type: i0.Input }],
        default: [{ type: i0.Input }],
        axaControls: [{ type: i0.ViewChildren, args: [AxaFormFieldControl,] }]
    };

    /**Directive to only allow numeric input. */
    var AxaNumbersOnlyDirective = /** @class */ (function () {
        function AxaNumbersOnlyDirective() {
            this.regexStr = '^[0-9+]*$';
        }
        /**Handles the key down event. */
        AxaNumbersOnlyDirective.prototype.onKeyDown = function (event) {
            var allowKeys = {
                'Delete': 0,
                'Del': 0,
                'Tab': 0,
                'Escape': 0,
                'Esc': 0,
                'Backspace': 0,
                'Enter': 0,
                'Home': 0,
                'End': 0,
                'ArrowLeft': 0,
                'ArrowRight': 0
            };
            if (allowKeys[event.key] === 0) {
                return;
            }
            if (event.ctrlKey && ['a', 'c', 'v', 'x'].find(function (key) { return event.key.toLowerCase() === key; })) {
                return;
            }
            if (new RegExp(this.regexStr).test(event.key)) {
                return;
            }
            event.preventDefault();
        };
AxaNumbersOnlyDirective.ɵfac = function AxaNumbersOnlyDirective_Factory(t) { return new (t || AxaNumbersOnlyDirective)(); };
AxaNumbersOnlyDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaNumbersOnlyDirective, selectors: [["", "axaNumbersOnly", ""]], hostBindings: function AxaNumbersOnlyDirective_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("keydown", function AxaNumbersOnlyDirective_keydown_HostBindingHandler($event) { return ctx.onKeyDown($event); });
    } } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaNumbersOnlyDirective, [{
        type: i0.Directive,
        args: [{ selector: '[axaNumbersOnly]' }]
    }], function () { return []; }, { onKeyDown: [{
            type: i0.HostListener,
            args: ['keydown', ['$event']]
        }] }); })();
        return AxaNumbersOnlyDirective;
    }());
    AxaNumbersOnlyDirective.propDecorators = {
        onKeyDown: [{ type: i0.HostListener, args: ['keydown', ['$event'],] }]
    };

    var AxaPhoneInputModule = /** @class */ (function () {
        function AxaPhoneInputModule() {
        }
        AxaPhoneInputModule.forRoot = function () {
            return {
                ngModule: AxaPhoneInputModule,
                providers: [AxaCountryService]
            };
        };
AxaPhoneInputModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaPhoneInputModule });
AxaPhoneInputModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaPhoneInputModule_Factory(t) { return new (t || AxaPhoneInputModule)(); }, providers: [], imports: [[common.CommonModule, forms.FormsModule, AxaSelectModule, AxaInputModule, AxaFormFieldModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaPhoneInputModule, { declarations: [AxaPhoneInputComponent, AxaNumbersOnlyDirective], imports: [ɵngcc2.CommonModule, ɵngcc1.FormsModule, AxaSelectModule, AxaInputModule, AxaFormFieldModule], exports: [AxaPhoneInputComponent, AxaNumbersOnlyDirective] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaPhoneInputModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule, forms.FormsModule, AxaSelectModule, AxaInputModule, AxaFormFieldModule],
                exports: [AxaPhoneInputComponent, AxaNumbersOnlyDirective],
                declarations: [AxaPhoneInputComponent, AxaNumbersOnlyDirective],
                providers: []
            }]
    }], function () { return []; }, null); })();
        return AxaPhoneInputModule;
    }());

    /**
     * Service used to communicate with the alert manager.
     * @export
     */
    var AxaAlertService = /** @class */ (function () {
        function AxaAlertService() {
            this.newAlerts = new rxjs.ReplaySubject(10);
            this.removedAlerts = new rxjs.ReplaySubject(10);
        }
        /**
         * Add an alert.
         */
        AxaAlertService.prototype.addAlert = function (alert) {
            var _this = this;
            this.newAlerts.next(alert);
            if (alert.ttl) {
                setTimeout(function () {
                    _this.removeAlert(alert);
                }, alert.ttl);
            }
        };
        /**
         * Remove an alert.
         */
        AxaAlertService.prototype.removeAlert = function (alert) {
            this.removedAlerts.next(alert);
        };
        /**
         * Gets the stream of added alerts.
         */
        AxaAlertService.prototype.getNewAlerts = function () {
            return this.newAlerts;
        };
        /**
         * Gets the stream of removed alerts.
         */
        AxaAlertService.prototype.getRemovedAlerts = function () {
            return this.removedAlerts;
        };
AxaAlertService.ɵfac = function AxaAlertService_Factory(t) { return new (t || AxaAlertService)(); };
AxaAlertService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaAlertService, factory: function (t) { return AxaAlertService.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAlertService, [{
        type: i0.Injectable
    }], function () { return []; }, null); })();
        return AxaAlertService;
    }());

    /**
     * The alert manager displays the alerts submitted to the alert service.
     * @export
     */
    var AxaAlertManager = /** @class */ (function () {
        /**
         * Creates an instance of AxaAlertManager.
         */
        function AxaAlertManager(alertSvc, cdr) {
            this.alertSvc = alertSvc;
            this.cdr = cdr;
            /** List of alerts received from the alert service. */
            this.alerts = new Array();
        }
        AxaAlertManager.prototype.ngOnInit = function () {
            var _this = this;
            this.newAlertSub = this.alertSvc.getNewAlerts().subscribe(function (alert) {
                _this.alerts = __spread(_this.alerts, [alert]);
                _this.cdr.markForCheck();
            });
            this.removeAlertSub = this.alertSvc.getRemovedAlerts().subscribe(function (alert) {
                _this.alerts = _this.alerts.filter(function (currentAlert) { return currentAlert !== alert; });
                _this.cdr.markForCheck();
            });
        };
        AxaAlertManager.prototype.ngOnDestroy = function () {
            this.newAlertSub.unsubscribe();
            this.removeAlertSub.unsubscribe();
        };
AxaAlertManager.ɵfac = function AxaAlertManager_Factory(t) { return new (t || AxaAlertManager)(ɵngcc0.ɵɵdirectiveInject(AxaAlertService), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef)); };
AxaAlertManager.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaAlertManager, selectors: [["axa-alert-manager"]], decls: 2, vars: 2, consts: [[3, "type", "buttonLabel", "buttonClick", 4, "ngFor", "ngForOf"], [3, "type", "buttonLabel", "buttonClick"]], template: function AxaAlertManager_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div");
        ɵngcc0.ɵɵtemplate(1, AxaAlertManager_axa_top_content_bar_1_Template, 2, 3, "axa-top-content-bar", 0);
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("@simpleFadeAnimation", undefined);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.alerts);
    } }, directives: function () { return [ɵngcc2.NgForOf, AxaTopContentBarComponent]; }, encapsulation: 2, data: { animation: [
            animations.trigger('simpleFadeAnimation', [
                animations.transition('void => *', [
                    animations.style({ opacity: '0' }),
                    animations.animate(1000)
                ]),
                animations.transition('* => void', [
                    animations.animate(1000, animations.style({ opacity: '1' }))
                ])
            ])
        ] }, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAlertManager, [{
        type: i0.Component,
        args: [{
                selector: 'axa-alert-manager',
                template: "\n    <div [@simpleFadeAnimation]>\n      <axa-top-content-bar *ngFor=\"let alert of alerts\"\n      [type]=\"alert.type\" [buttonLabel]=\"alert.action && alert.action.content\"\n      (buttonClick)=\"alert.action && alert.action.handler  && alert.action.handler(alert.action, alert)\">\n        {{alert.message}}\n      </axa-top-content-bar>\n    </div>",
                changeDetection: i0.ChangeDetectionStrategy.OnPush,
                animations: [
                    animations.trigger('simpleFadeAnimation', [
                        animations.transition('void => *', [
                            animations.style({ opacity: '0' }),
                            animations.animate(1000)
                        ]),
                        animations.transition('* => void', [
                            animations.animate(1000, animations.style({ opacity: '1' }))
                        ])
                    ])
                ]
            }]
    }], function () { return [{ type: AxaAlertService }, { type: ɵngcc0.ChangeDetectorRef }]; }, null); })();
        return AxaAlertManager;
    }());
    AxaAlertManager.ctorParameters = function () { return [
        { type: AxaAlertService },
        { type: i0.ChangeDetectorRef }
    ]; };

    /** Base css class. */
    var AXA_BAR_CLASS_BASE = 'axa-top-content-bar';
    /** Corporate css class. */
    var AXA_BAR_CLASS_CORPORATE = 'corporate';
    /** Commercial css class. */
    var AXA_BAR_CLASS_COMMERCIAL = 'commercial';
    /** Warning css class. */
    var AXA_BAR_CLASS_WARNING = 'warning';
    /** Base content css class. */
    var AXA_BAR_CLASS_CONTENT = 'content';

    /**
     * Alert component message displayed by the `AxaAlertManager`
     * @export
     * ### Example
     * ```
     * <axa-alert-manager></axa-alert-manager>
     * ```
     */
    var AxaTopContentBarComponent = /** @class */ (function () {
        /**
         * Creates an instance of AxaTopContentBarComponent.
         */
        function AxaTopContentBarComponent() {
            /**
             * Occurs when the button is clicked.
             */
            this.buttonClick = new i0.EventEmitter();
        }
        /**
         * Handles the click on the button.
         */
        AxaTopContentBarComponent.prototype.handleClick = function (e) {
            e.preventDefault();
            this.buttonClick.emit(e);
        };
        /**
         * Sets the css class depending on type.
         */
        AxaTopContentBarComponent.prototype.getTypeClass = function () {
            switch (this.type) {
                case 'corporate':
                    return AXA_BAR_CLASS_BASE + "--" + AXA_BAR_CLASS_CORPORATE;
                case 'warning':
                    return AXA_BAR_CLASS_BASE + "--" + AXA_BAR_CLASS_WARNING;
            }
            return AXA_BAR_CLASS_BASE + "--" + AXA_BAR_CLASS_COMMERCIAL;
        };
        /**
         * Sets the base css class.
         */
        AxaTopContentBarComponent.prototype.getClass = function () {
            return AXA_BAR_CLASS_BASE + " " + this.getTypeClass();
        };
        /**
         * Sets the base css content class.
         */
        AxaTopContentBarComponent.prototype.getContentClass = function () {
            return AXA_BAR_CLASS_BASE + "__" + AXA_BAR_CLASS_CONTENT;
        };
AxaTopContentBarComponent.ɵfac = function AxaTopContentBarComponent_Factory(t) { return new (t || AxaTopContentBarComponent)(); };
AxaTopContentBarComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTopContentBarComponent, selectors: [["axa-top-content-bar"]], inputs: { type: "type", href: "href", buttonLabel: "buttonLabel" }, outputs: { buttonClick: "buttonClick" }, ngContentSelectors: _c0, decls: 4, vars: 5, consts: [["axa-button", "", "neg", "", "small", "", 3, "href", "click", 4, "ngIf"], ["axa-button", "", "neg", "", "small", "", 3, "href", "click"]], template: function AxaTopContentBarComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "div");
        ɵngcc0.ɵɵelementStart(1, "div");
        ɵngcc0.ɵɵprojection(2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtemplate(3, AxaTopContentBarComponent_a_3_Template, 2, 2, "a", 0);
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.getClass());
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵclassMap(ctx.getContentClass());
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngIf", ctx.buttonLabel);
    } }, directives: [ɵngcc2.NgIf, AxaButton], encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTopContentBarComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-top-content-bar',
                template: "<div [class]=\"getClass()\">\r\n  <div [class]=\"getContentClass()\">\r\n      <ng-content></ng-content>\r\n  </div>\r\n  <a *ngIf=\"buttonLabel\" [href]=\"href\" (click)=\"handleClick($event)\" axa-button neg small>{{buttonLabel}}</a>\r\n</div>\r\n",
                encapsulation: i0.ViewEncapsulation.None,
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { buttonClick: [{
            type: i0.Output
        }], type: [{
            type: i0.Input
        }], href: [{
            type: i0.Input
        }], buttonLabel: [{
            type: i0.Input
        }] }); })();
        return AxaTopContentBarComponent;
    }());
    AxaTopContentBarComponent.ctorParameters = function () { return []; };
    AxaTopContentBarComponent.propDecorators = {
        type: [{ type: i0.Input }],
        href: [{ type: i0.Input }],
        buttonLabel: [{ type: i0.Input }],
        buttonClick: [{ type: i0.Output }]
    };

    var AxaTopContentBarModule = /** @class */ (function () {
        function AxaTopContentBarModule() {
        }
AxaTopContentBarModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaTopContentBarModule });
AxaTopContentBarModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaTopContentBarModule_Factory(t) { return new (t || AxaTopContentBarModule)(); }, imports: [[common.CommonModule, AxaButtonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaTopContentBarModule, { declarations: [AxaTopContentBarComponent], imports: [ɵngcc2.CommonModule, AxaButtonModule], exports: [AxaTopContentBarComponent] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTopContentBarModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule, AxaButtonModule],
                declarations: [AxaTopContentBarComponent],
                exports: [AxaTopContentBarComponent]
            }]
    }], function () { return []; }, null); })();
        return AxaTopContentBarModule;
    }());

    var AxaAlertModule = /** @class */ (function () {
        function AxaAlertModule() {
        }
        AxaAlertModule.forRoot = function () {
            return {
                ngModule: AxaAlertModule,
                providers: [AxaAlertService]
            };
        };
AxaAlertModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaAlertModule });
AxaAlertModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaAlertModule_Factory(t) { return new (t || AxaAlertModule)(); }, imports: [[common.CommonModule, AxaTopContentBarModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaAlertModule, { declarations: [AxaAlertManager], imports: [ɵngcc2.CommonModule, AxaTopContentBarModule], exports: [AxaAlertManager] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAlertModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule, AxaTopContentBarModule],
                exports: [AxaAlertManager],
                declarations: [AxaAlertManager]
            }]
    }], function () { return []; }, null); })();
        return AxaAlertModule;
    }());

    /**
     * The busy component displayed by the busy directive
     * @export
     */
    var AxaBusyComponent = /** @class */ (function () {
        function AxaBusyComponent() {
            /**
             * The busy message displayed, defaults to 'loading'.
             */
            this.message = '';
        }
AxaBusyComponent.ɵfac = function AxaBusyComponent_Factory(t) { return new (t || AxaBusyComponent)(); };
AxaBusyComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaBusyComponent, selectors: [["axa-busy-component"]], inputs: { message: "message" }, decls: 4, vars: 1, consts: [[1, "axa-busy-indicator", "axa-busy-indicator--active"], [1, "axa-busy-indicator__animation"], [1, "axa-busy-indicator__caption"]], template: function AxaBusyComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelement(1, "div", 1);
        ɵngcc0.ɵɵelementStart(2, "div", 2);
        ɵngcc0.ɵɵtext(3);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(3);
        ɵngcc0.ɵɵtextInterpolate1(" ", ctx.message, " ");
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-busy-component',
                template: "\n    <div class=\"axa-busy-indicator axa-busy-indicator--active\">\n        <div class=\"axa-busy-indicator__animation\"></div>\n        <div class=\"axa-busy-indicator__caption\">\n        {{ message }}\n        </div>\n    </div>"
            }]
    }], function () { return []; }, { message: [{
            type: i0.Input
        }] }); })();
        return AxaBusyComponent;
    }());
    AxaBusyComponent.propDecorators = {
        message: [{ type: i0.Input }]
    };

    /**
     * The backdrop displayed with the busy component.
     * @export
     */
    var AxaBusyBackdropComponent = /** @class */ (function () {
        function AxaBusyBackdropComponent() {
        }
AxaBusyBackdropComponent.ɵfac = function AxaBusyBackdropComponent_Factory(t) { return new (t || AxaBusyBackdropComponent)(); };
AxaBusyBackdropComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaBusyBackdropComponent, selectors: [["axa-busy-backdrop"]], decls: 1, vars: 0, consts: [[1, "axa-busy-indicator__backdrop", "axa-busy-indicator__backdrop--active"]], template: function AxaBusyBackdropComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelement(0, "div", 0);
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyBackdropComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-busy-backdrop',
                template: "\n    <div class=\"axa-busy-indicator__backdrop axa-busy-indicator__backdrop--active\">\n    </div>"
            }]
    }], function () { return []; }, null); })();
        return AxaBusyBackdropComponent;
    }());

    /**Axa busy container style. */
    var BUSY_CONTAINER = 'axa-busy-indicator-wrapper';
    /**Axa busy container full screen style. */
    var BUSY_CONTAINER_FULL_SCREEN = 'axa-busy-indicator-wrapper--fixed';

    /**Busy directive for local busy. */
    var AxaBusyContainerDirective = /** @class */ (function () {
        /**
         *Creates an instance of AxaBusyContainerDirective.
         * @param  el The element ref.
         */
        function AxaBusyContainerDirective(el) {
            this.el = el;
            this.host = el.nativeElement;
            this.addDefaultStyles();
        }
        /**Adds the default style. */
        AxaBusyContainerDirective.prototype.addDefaultStyles = function () {
            this.host.classList.add(BUSY_CONTAINER);
        };
AxaBusyContainerDirective.ɵfac = function AxaBusyContainerDirective_Factory(t) { return new (t || AxaBusyContainerDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaBusyContainerDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaBusyContainerDirective, selectors: [["", "AxaBusyContainer", ""]] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyContainerDirective, [{
        type: i0.Directive,
        args: [{ selector: '[AxaBusyContainer]' }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, null); })();
        return AxaBusyContainerDirective;
    }());
    AxaBusyContainerDirective.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };
    /**Busy directive for fullscreen busy. */
    var AxaBusyContainerFullScreenDirective = /** @class */ (function () {
        /**
         *Creates an instance of AxaBusyContainerFullScreenDirective.
         * @param  el The element ref
         */
        function AxaBusyContainerFullScreenDirective(el) {
            this.el = el;
            this.host = el.nativeElement;
            this.addDefaultStyles();
        }
        /**Adds the default style. */
        AxaBusyContainerFullScreenDirective.prototype.addDefaultStyles = function () {
            this.host.classList.add(BUSY_CONTAINER_FULL_SCREEN);
        };
AxaBusyContainerFullScreenDirective.ɵfac = function AxaBusyContainerFullScreenDirective_Factory(t) { return new (t || AxaBusyContainerFullScreenDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaBusyContainerFullScreenDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaBusyContainerFullScreenDirective, selectors: [["", "AxaBusyContainerFullScreen", ""]] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyContainerFullScreenDirective, [{
        type: i0.Directive,
        args: [{ selector: '[AxaBusyContainerFullScreen]' }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, null); })();
        return AxaBusyContainerFullScreenDirective;
    }());
    AxaBusyContainerFullScreenDirective.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };

    /**
     * The busy component displayed by the busy raw directive
     * @export
     */
    var AxaBusyRawComponent = /** @class */ (function () {
        function AxaBusyRawComponent() {
        }
AxaBusyRawComponent.ɵfac = function AxaBusyRawComponent_Factory(t) { return new (t || AxaBusyRawComponent)(); };
AxaBusyRawComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaBusyRawComponent, selectors: [["axa-busy-raw-component"]], decls: 2, vars: 0, consts: [[1, "axa-busy-indicator", "axa-busy-indicator--active"], [1, "axa-busy-indicator__animation"]], template: function AxaBusyRawComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelement(1, "div", 1);
        ɵngcc0.ɵɵelementEnd();
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyRawComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-busy-raw-component',
                template: "\n    <div class=\"axa-busy-indicator axa-busy-indicator--active\">\n        <div class=\"axa-busy-indicator__animation\"></div>\n    </div>"
            }]
    }], function () { return []; }, null); })();
        return AxaBusyRawComponent;
    }());

    /**
     * Directive used to connect an observable or promise to the busy indicator.
     * You can optionnally add a message too.
     * @export
     */
    var AxaBusyRawDirective = /** @class */ (function () {
        /**
         * Creates an instance of AxaBusyDirective.
         */
        function AxaBusyRawDirective(componentFactory, viewContainer, template) {
            this.componentFactory = componentFactory;
            this.viewContainer = viewContainer;
            this.template = template;
        }
        Object.defineProperty(AxaBusyRawDirective.prototype, "axaBusyRaw", {
            /**
             * Busy promise or observable input
             */
            set: function (busy) {
                this.processBusy(busy);
            },
            enumerable: false,
            configurable: true
        });
        AxaBusyRawDirective.prototype.processBusy = function (busy) {
            var _this = this;
            if (busy == null || this.asyncOperation === busy) {
                return;
            }
            if (typeof busy === 'boolean') {
                if (busy) {
                    this.createBusy();
                }
                else {
                    this.busyFinished();
                }
            }
            else {
                this.asyncOperation = busy;
                if (this.asyncOperation instanceof Promise) {
                    this.createBusy();
                    this.asyncOperation.then(function () { return _this.busyFinished(); }, function () { return _this.busyFinished(); });
                }
                else if (this.asyncOperation instanceof rxjs.Subscription) {
                    this.createBusy();
                    this.asyncOperation.add(function () { return _this.busyFinished(); });
                }
            }
        };
        AxaBusyRawDirective.prototype.ngOnInit = function () {
            this.createViews();
        };
        AxaBusyRawDirective.prototype.ngOnDestroy = function () {
            this.deleteViews();
        };
        AxaBusyRawDirective.prototype.createViews = function () {
            if (this.parentElement == null) {
                var ref = this.viewContainer.createEmbeddedView(this.template);
                this.parentElement = ref.rootNodes[0];
            }
        };
        AxaBusyRawDirective.prototype.createBusy = function () {
            this.createViews();
            var busyFactory = this.componentFactory.resolveComponentFactory(AxaBusyRawComponent);
            var busyBackdropFactory = this.componentFactory.resolveComponentFactory(AxaBusyBackdropComponent);
            this.backdropRef = this.viewContainer.createComponent(busyBackdropFactory);
            this.busyRef = this.viewContainer.createComponent(busyFactory);
            this.backdropElement = this.parentElement.appendChild(this.backdropRef.location.nativeElement);
            this.busyElement = this.parentElement.appendChild(this.busyRef.location.nativeElement);
        };
        AxaBusyRawDirective.prototype.busyFinished = function () {
            if (this.backdropElement && this.backdropElement.parentNode) {
                this.backdropElement.parentNode.removeChild(this.backdropElement);
            }
            if (this.busyElement && this.busyElement.parentNode) {
                this.busyElement.parentNode.removeChild(this.busyElement);
            }
        };
        AxaBusyRawDirective.prototype.deleteViews = function () {
            if (this.busyRef) {
                this.busyRef.destroy();
            }
            if (this.backdropRef) {
                this.backdropRef.destroy();
            }
        };
AxaBusyRawDirective.ɵfac = function AxaBusyRawDirective_Factory(t) { return new (t || AxaBusyRawDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ComponentFactoryResolver), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ViewContainerRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.TemplateRef)); };
AxaBusyRawDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaBusyRawDirective, selectors: [["", "axaBusyRaw", ""]], inputs: { axaBusyRaw: "axaBusyRaw" } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyRawDirective, [{
        type: i0.Directive,
        args: [{ selector: '[axaBusyRaw]' }]
    }], function () { return [{ type: ɵngcc0.ComponentFactoryResolver }, { type: ɵngcc0.ViewContainerRef }, { type: ɵngcc0.TemplateRef }]; }, { axaBusyRaw: [{
            type: i0.Input
        }] }); })();
        return AxaBusyRawDirective;
    }());
    AxaBusyRawDirective.ctorParameters = function () { return [
        { type: i0.ComponentFactoryResolver },
        { type: i0.ViewContainerRef },
        { type: i0.TemplateRef }
    ]; };
    AxaBusyRawDirective.propDecorators = {
        axaBusyRaw: [{ type: i0.Input }]
    };

    /**
     * Directive used to connect an observable or promise to the busy indicator.
     * You can optionnally add a message too.
     * @export
     */
    var AxaBusyDirective = /** @class */ (function () {
        /**
         * Creates an instance of AxaBusyDirective.
         */
        function AxaBusyDirective(componentFactory, viewContainer, template) {
            this.componentFactory = componentFactory;
            this.viewContainer = viewContainer;
            this.template = template;
        }
        Object.defineProperty(AxaBusyDirective.prototype, "axaBusy", {
            /**
             * Busy promise or observable input
             */
            set: function (busy) {
                this.processBusy(busy);
            },
            enumerable: false,
            configurable: true
        });
        AxaBusyDirective.prototype.processBusy = function (busy) {
            var _this = this;
            if (busy == null || this.asyncOperation === busy) {
                return;
            }
            if (typeof busy === 'boolean') {
                if (busy) {
                    this.createBusy();
                }
                else {
                    this.busyFinished();
                }
            }
            else {
                this.asyncOperation = busy;
                if (this.asyncOperation instanceof Promise) {
                    this.createBusy();
                    this.asyncOperation.then(function () { return _this.busyFinished(); }, function () { return _this.busyFinished(); });
                }
                else if (this.asyncOperation instanceof rxjs.Subscription) {
                    this.createBusy();
                    this.asyncOperation.add(function () { return _this.busyFinished(); });
                }
            }
        };
        AxaBusyDirective.prototype.ngOnInit = function () {
            this.createViews();
        };
        AxaBusyDirective.prototype.ngOnDestroy = function () {
            this.deleteViews();
        };
        AxaBusyDirective.prototype.createViews = function () {
            if (this.parentElement == null) {
                var ref = this.viewContainer.createEmbeddedView(this.template);
                this.parentElement = ref.rootNodes[0];
            }
        };
        AxaBusyDirective.prototype.createBusy = function () {
            this.createViews();
            var busyFactory = this.componentFactory.resolveComponentFactory(AxaBusyComponent);
            var busyBackdropFactory = this.componentFactory.resolveComponentFactory(AxaBusyBackdropComponent);
            this.backdropRef = this.viewContainer.createComponent(busyBackdropFactory);
            this.busyRef = this.viewContainer.createComponent(busyFactory);
            this.backdropElement = this.parentElement.appendChild(this.backdropRef.location.nativeElement);
            this.busyElement = this.parentElement.appendChild(this.busyRef.location.nativeElement);
            if (this.axaBusyMessage) {
                this.busyRef.instance.message = this.axaBusyMessage;
            }
        };
        AxaBusyDirective.prototype.busyFinished = function () {
            if (this.backdropElement && this.backdropElement.parentNode) {
                this.backdropElement.parentNode.removeChild(this.backdropElement);
            }
            if (this.busyElement && this.busyElement.parentNode) {
                this.busyElement.parentNode.removeChild(this.busyElement);
            }
        };
        AxaBusyDirective.prototype.deleteViews = function () {
            if (this.busyRef) {
                this.busyRef.destroy();
            }
            if (this.backdropRef) {
                this.backdropRef.destroy();
            }
        };
AxaBusyDirective.ɵfac = function AxaBusyDirective_Factory(t) { return new (t || AxaBusyDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ComponentFactoryResolver), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ViewContainerRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.TemplateRef)); };
AxaBusyDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaBusyDirective, selectors: [["", "axaBusy", ""]], inputs: { axaBusy: "axaBusy", axaBusyMessage: "axaBusyMessage" } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyDirective, [{
        type: i0.Directive,
        args: [{ selector: '[axaBusy]' }]
    }], function () { return [{ type: ɵngcc0.ComponentFactoryResolver }, { type: ɵngcc0.ViewContainerRef }, { type: ɵngcc0.TemplateRef }]; }, { axaBusy: [{
            type: i0.Input
        }], axaBusyMessage: [{
            type: i0.Input
        }] }); })();
        return AxaBusyDirective;
    }());
    AxaBusyDirective.ctorParameters = function () { return [
        { type: i0.ComponentFactoryResolver },
        { type: i0.ViewContainerRef },
        { type: i0.TemplateRef }
    ]; };
    AxaBusyDirective.propDecorators = {
        axaBusy: [{ type: i0.Input }],
        axaBusyMessage: [{ type: i0.Input }]
    };

    var AxaBusyModule = /** @class */ (function () {
        function AxaBusyModule() {
        }
AxaBusyModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaBusyModule });
AxaBusyModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaBusyModule_Factory(t) { return new (t || AxaBusyModule)(); }, imports: [[]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaBusyModule, { declarations: [AxaBusyComponent, AxaBusyBackdropComponent, AxaBusyDirective, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective, AxaBusyRawComponent, AxaBusyRawDirective], exports: [AxaBusyDirective, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective, AxaBusyRawDirective] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaBusyModule, [{
        type: i0.NgModule,
        args: [{
                imports: [],
                exports: [AxaBusyDirective, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective, AxaBusyRawDirective],
                declarations: [
                    AxaBusyComponent, AxaBusyBackdropComponent,
                    AxaBusyDirective, AxaBusyContainerDirective, AxaBusyContainerFullScreenDirective,
                    AxaBusyRawComponent, AxaBusyRawDirective
                ]
            }]
    }], function () { return []; }, null); })();
        return AxaBusyModule;
    }());

    /**Default style. */
    var CLASS_BASE = 'axa-card';
    /**Active style. */
    var CLASS_ACTIVE = CLASS_BASE + "--active";
    /**Wide style. */
    var CLASS_WIDE = CLASS_BASE + "--wide";
    /**Block style. */
    var CLASS_BLOCK = CLASS_BASE + "__block";
    /**Title style. */
    var CLASS_TITLE = CLASS_BASE + "__title";
    /**Info style. */
    var CLASS_INFO = CLASS_BASE + "--info";
    /**Content style. */
    var CLASS_CONTENT = CLASS_BASE + "--content";
    /**Compact style. */
    var CLASS_BLOCK_COMPACT = CLASS_BLOCK + "--compact";

    /**
     * The card component used to display information in a formatted way.
     */
    var AxaCardComponent = /** @class */ (function () {
        function AxaCardComponent() {
            /**Base styling binding. */
            this.baseCls = true;
        }
        Object.defineProperty(AxaCardComponent.prototype, "active", {
            /**Weither the card is active. */
            set: function (value) {
                this._active = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardComponent.prototype, "wide", {
            /**Weither the card is of type wide. */
            set: function (value) {
                this._wide = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardComponent.prototype, "info", {
            /**Weither the card is of type info. */
            set: function (value) {
                this._info = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardComponent.prototype, "content", {
            /**Weither the card is of type content. */
            set: function (value) {
                this._content = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardComponent.prototype, "hasActiveClass", {
            /**Weither the card is active. */
            get: function () {
                return this._active;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardComponent.prototype, "hasWideClass", {
            /**Weither the card is wide. */
            get: function () {
                return this._wide;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardComponent.prototype, "hasInfoClass", {
            /**Weither the card is info. */
            get: function () {
                return this._info;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardComponent.prototype, "hasContentClass", {
            /**Weither the card is content. */
            get: function () {
                return this._content;
            },
            enumerable: false,
            configurable: true
        });
AxaCardComponent.ɵfac = function AxaCardComponent_Factory(t) { return new (t || AxaCardComponent)(); };
AxaCardComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaCardComponent, selectors: [["axa-card"]], hostVars: 10, hostBindings: function AxaCardComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-card", ctx.baseCls)("axa-card--active", ctx.hasActiveClass)("axa-card--wide", ctx.hasWideClass)("axa-card--info", ctx.hasInfoClass)("axa-card--content", ctx.hasContentClass);
    } }, inputs: { active: "active", wide: "wide", info: "info", content: "content" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaCardComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCardComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-card',
                template: "<ng-content></ng-content>",
                encapsulation: i0.ViewEncapsulation.None,
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { baseCls: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_BASE]
        }], active: [{
            type: i0.Input,
            args: ['active']
        }], wide: [{
            type: i0.Input,
            args: ['wide']
        }], info: [{
            type: i0.Input,
            args: ['info']
        }], content: [{
            type: i0.Input,
            args: ['content']
        }], hasActiveClass: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_ACTIVE]
        }], hasWideClass: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_WIDE]
        }], hasInfoClass: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_INFO]
        }], hasContentClass: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_CONTENT]
        }] }); })();
        return AxaCardComponent;
    }());
    AxaCardComponent.propDecorators = {
        baseCls: [{ type: i0.HostBinding, args: ["class." + CLASS_BASE,] }],
        active: [{ type: i0.Input, args: ['active',] }],
        wide: [{ type: i0.Input, args: ['wide',] }],
        info: [{ type: i0.Input, args: ['info',] }],
        content: [{ type: i0.Input, args: ['content',] }],
        hasActiveClass: [{ type: i0.HostBinding, args: ["class." + CLASS_ACTIVE,] }],
        hasWideClass: [{ type: i0.HostBinding, args: ["class." + CLASS_WIDE,] }],
        hasInfoClass: [{ type: i0.HostBinding, args: ["class." + CLASS_INFO,] }],
        hasContentClass: [{ type: i0.HostBinding, args: ["class." + CLASS_CONTENT,] }]
    };
    /**Directive of the card title. */
    var AxaCardTitleDirective = /** @class */ (function () {
        function AxaCardTitleDirective() {
            /**Base styling binding. */
            this.baseCls = true;
        }
        Object.defineProperty(AxaCardTitleDirective.prototype, "compact", {
            /**Weither the card is compact. */
            set: function (value) {
                this._compact = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardTitleDirective.prototype, "hasCompactClass", {
            /**Weither the card is compact. */
            get: function () {
                return this._compact;
            },
            enumerable: false,
            configurable: true
        });
AxaCardTitleDirective.ɵfac = function AxaCardTitleDirective_Factory(t) { return new (t || AxaCardTitleDirective)(); };
AxaCardTitleDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaCardTitleDirective, selectors: [["axa-card-title"]], hostVars: 4, hostBindings: function AxaCardTitleDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-card__title", ctx.baseCls)("axa-card__block--compact", ctx.hasCompactClass);
    } }, inputs: { compact: "compact" } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCardTitleDirective, [{
        type: i0.Directive,
        args: [{
                selector: 'axa-card-title'
            }]
    }], function () { return []; }, { baseCls: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_TITLE]
        }], compact: [{
            type: i0.Input,
            args: ['compact']
        }], hasCompactClass: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_BLOCK_COMPACT]
        }] }); })();
        return AxaCardTitleDirective;
    }());
    AxaCardTitleDirective.propDecorators = {
        baseCls: [{ type: i0.HostBinding, args: ["class." + CLASS_TITLE,] }],
        compact: [{ type: i0.Input, args: ['compact',] }],
        hasCompactClass: [{ type: i0.HostBinding, args: ["class." + CLASS_BLOCK_COMPACT,] }]
    };
    /**Directive for the card content. */
    var AxaCardContentDirective = /** @class */ (function () {
        function AxaCardContentDirective() {
            /**Base styling binding. */
            this.baseCls = true;
        }
        Object.defineProperty(AxaCardContentDirective.prototype, "compact", {
            /**Weither the card is compact. */
            set: function (value) {
                this._compact = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCardContentDirective.prototype, "hasCompactClass", {
            /**Weither the card is compact. */
            get: function () {
                return this._compact;
            },
            enumerable: false,
            configurable: true
        });
AxaCardContentDirective.ɵfac = function AxaCardContentDirective_Factory(t) { return new (t || AxaCardContentDirective)(); };
AxaCardContentDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaCardContentDirective, selectors: [["axa-card-content"]], hostVars: 4, hostBindings: function AxaCardContentDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-card__block", ctx.baseCls)("axa-card__block--compact", ctx.hasCompactClass);
    } }, inputs: { compact: "compact" } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCardContentDirective, [{
        type: i0.Directive,
        args: [{
                selector: 'axa-card-content'
            }]
    }], function () { return []; }, { baseCls: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_BLOCK]
        }], compact: [{
            type: i0.Input,
            args: ['compact']
        }], hasCompactClass: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_BLOCK_COMPACT]
        }] }); })();
        return AxaCardContentDirective;
    }());
    AxaCardContentDirective.propDecorators = {
        baseCls: [{ type: i0.HostBinding, args: ["class." + CLASS_BLOCK,] }],
        compact: [{ type: i0.Input, args: ['compact',] }],
        hasCompactClass: [{ type: i0.HostBinding, args: ["class." + CLASS_BLOCK_COMPACT,] }]
    };

    var AxaCardModule = /** @class */ (function () {
        function AxaCardModule() {
        }
AxaCardModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaCardModule });
AxaCardModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaCardModule_Factory(t) { return new (t || AxaCardModule)(); }, imports: [[
            common.CommonModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaCardModule, { declarations: [AxaCardComponent, AxaCardTitleDirective, AxaCardContentDirective], imports: [ɵngcc2.CommonModule], exports: [AxaCardComponent, AxaCardTitleDirective, AxaCardContentDirective] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCardModule, [{
        type: i0.NgModule,
        args: [{
                imports: [
                    common.CommonModule
                ],
                declarations: [
                    AxaCardComponent,
                    AxaCardTitleDirective,
                    AxaCardContentDirective
                ],
                exports: [
                    AxaCardComponent,
                    AxaCardTitleDirective,
                    AxaCardContentDirective
                ]
            }]
    }], function () { return []; }, null); })();
        return AxaCardModule;
    }());

    /**
     * Generated unique id.
     */
    var nextUniqueId$5 = 0;
    /**Value Accessor provider to enable ngModel. */
    var AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR = {
        provide: forms.NG_VALUE_ACCESSOR,
        useExisting: i0.forwardRef(function () { return AxaCheckbox; }),
        multi: true
    };
    /**
     * Change event emitted by the AxaCheckbox.
     * @export
     */
    var AxaCheckboxChange = /** @class */ (function () {
        function AxaCheckboxChange() {
        }
        return AxaCheckboxChange;
    }());
    /**
     * An AXA styled checkbox.
     * @export
     */
    var AxaCheckbox = /** @class */ (function () {
        function AxaCheckbox() {
            this._uniqueId = "axa-checkbox-" + ++nextUniqueId$5;
            /**
             * Element ID.
             */
            this.id = this._uniqueId;
            /**
             * Name of the control.
             */
            this.name = null;
            /** Used to set the 'aria-label' attribute on the underlying input element. */
            this.ariaLabel = '';
            /** The 'aria-labelledby' attribute takes precedence as the element's text alternative. */
            this.ariaLabelledby = null;
            this._checked = false;
            /**
             *Event emitted when the checked state changes.
             */
            this.change = new i0.EventEmitter();
            /**
             * Implementation of the value accessor.
             */
            this.valueAccessorChange = function () { };
            /**
             * Implementation of the value accessor.
             */
            this.valueAccessorTouch = function () { };
        }
        Object.defineProperty(AxaCheckbox.prototype, "inputId", {
            /**
             * Returns the element id
             */
            get: function () {
                return this.id;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCheckbox.prototype, "required", {
            /**
             * Whether the control is required.
             */
            get: function () {
                return this._required;
            },
            set: function (value) {
                this._required = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaCheckbox.prototype, "checked", {
            /**
             *Whether the control is checked.
             */
            get: function () {
                return this._checked;
            },
            set: function (value) {
                this._checked = coerceBooleanProperty$1(value);
                this.valueAccessorChange(this._checked);
            },
            enumerable: false,
            configurable: true
        });
        /**
         * Gets the aria value of the checked state.
         */
        AxaCheckbox.prototype.getAriaChecked = function () {
            return this.checked ? 'true' : this.indeterminate ? 'mixed' : 'false';
        };
        /** Toggles the `checked` state of the checkbox. */
        AxaCheckbox.prototype.toggle = function () {
            this.checked = !this.checked;
        };
        AxaCheckbox.prototype.fireChangeEvent = function () {
            var event = new AxaCheckboxChange();
            event.source = this;
            event.checked = this.checked;
            this.valueAccessorChange(this.checked);
            this.change.emit(event);
        };
        /**
         * Handles the change event of the checkbox.
         */
        AxaCheckbox.prototype.onInteractionEvent = function (event) {
            event.stopPropagation();
        };
        /**
         * Handles the click event of the checkbox.
         */
        AxaCheckbox.prototype.onInputClick = function (event) {
            event.stopPropagation();
            this.toggle();
            this.fireChangeEvent();
        };
        /**
         * Implementation of the value accessor.
         */
        AxaCheckbox.prototype.writeValue = function (value) {
            if (this._checked !== value) {
                this.checked = value;
            }
        };
        /**
         * Implementation of the value accessor.
         */
        AxaCheckbox.prototype.registerOnChange = function (fn) {
            this.valueAccessorChange = fn;
        };
        /**
         * Implementation of the value accessor.
         */
        AxaCheckbox.prototype.registerOnTouched = function (fn) {
            this.valueAccessorTouch = fn;
        };
        /**
         * Implementation of the value accessor.
         */
        AxaCheckbox.prototype.setDisabledState = function (isDisabled) {
            this.disabled = isDisabled;
        };
AxaCheckbox.ɵfac = function AxaCheckbox_Factory(t) { return new (t || AxaCheckbox)(); };
AxaCheckbox.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaCheckbox, selectors: [["axa-checkbox"]], inputs: { id: "id", name: "name", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], required: "required", checked: "checked", disabled: "disabled", value: "value", tabIndex: "tabIndex", indeterminate: "indeterminate" }, outputs: { change: "change" }, features: [ɵngcc0.ɵɵProvidersFeature([AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR])], ngContentSelectors: _c0, decls: 5, vars: 11, consts: [[1, "custom-control", "custom-checkbox"], ["type", "checkbox", 1, "custom-control-input", 3, "id", "required", "checked", "disabled", "tabIndex", "indeterminate", "change", "click"], [1, "custom-control-indicator"], [1, "custom-control-description"]], template: function AxaCheckbox_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "label", 0);
        ɵngcc0.ɵɵelementStart(1, "input", 1);
        ɵngcc0.ɵɵlistener("change", function AxaCheckbox_Template_input_change_1_listener($event) { return ctx.onInteractionEvent($event); })("click", function AxaCheckbox_Template_input_click_1_listener($event) { return ctx.onInputClick($event); });
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelement(2, "span", 2);
        ɵngcc0.ɵɵelementStart(3, "span", 3);
        ɵngcc0.ɵɵprojection(4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("id", ctx.inputId)("required", ctx.required)("checked", ctx.checked)("disabled", ctx.disabled)("tabIndex", ctx.tabIndex)("indeterminate", ctx.indeterminate);
        ɵngcc0.ɵɵattribute("value", ctx.value)("name", ctx.name)("aria-label", ctx.ariaLabel || null)("aria-labelledby", ctx.ariaLabelledby)("aria-checked", ctx.getAriaChecked());
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCheckbox, [{
        type: i0.Component,
        args: [{
                selector: 'axa-checkbox',
                template: "<label class=\"custom-control custom-checkbox\">\r\n    <input type=\"checkbox\"  class=\"custom-control-input\" \r\n    [id]=\"inputId\"\r\n    [required]=\"required\"\r\n    [checked]=\"checked\"\r\n    [attr.value]=\"value\"\r\n    [disabled]=\"disabled\"\r\n    [attr.name]=\"name\"\r\n    [tabIndex]=\"tabIndex\"\r\n    [indeterminate]=\"indeterminate\"\r\n    [attr.aria-label]=\"ariaLabel || null\"\r\n    [attr.aria-labelledby]=\"ariaLabelledby\"\r\n    [attr.aria-checked]=\"getAriaChecked()\"\r\n    (change)=\"onInteractionEvent($event)\"\r\n    (click)=\"onInputClick($event)\">\r\n    <span class=\"custom-control-indicator\"></span>\r\n    <span class=\"custom-control-description\">\r\n        <ng-content></ng-content>\r\n    </span>\r\n</label>",
                providers: [AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR]
            }]
    }], function () { return []; }, { id: [{
            type: i0.Input
        }], name: [{
            type: i0.Input
        }], ariaLabel: [{
            type: i0.Input,
            args: ['aria-label']
        }], ariaLabelledby: [{
            type: i0.Input,
            args: ['aria-labelledby']
        }], change: [{
            type: i0.Output
        }], required: [{
            type: i0.Input
        }], checked: [{
            type: i0.Input
        }], disabled: [{
            type: i0.Input
        }], value: [{
            type: i0.Input
        }], tabIndex: [{
            type: i0.Input
        }], indeterminate: [{
            type: i0.Input
        }] }); })();
        return AxaCheckbox;
    }());
    AxaCheckbox.propDecorators = {
        id: [{ type: i0.Input }],
        required: [{ type: i0.Input }],
        value: [{ type: i0.Input }],
        disabled: [{ type: i0.Input }],
        tabIndex: [{ type: i0.Input }],
        name: [{ type: i0.Input }],
        indeterminate: [{ type: i0.Input }],
        ariaLabel: [{ type: i0.Input, args: ['aria-label',] }],
        ariaLabelledby: [{ type: i0.Input, args: ['aria-labelledby',] }],
        checked: [{ type: i0.Input }],
        change: [{ type: i0.Output }]
    };

    var AxaCheckboxModule = /** @class */ (function () {
        function AxaCheckboxModule() {
        }
AxaCheckboxModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaCheckboxModule });
AxaCheckboxModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaCheckboxModule_Factory(t) { return new (t || AxaCheckboxModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaCheckboxModule, { declarations: [AxaCheckbox], imports: [ɵngcc2.CommonModule], exports: [AxaCheckbox] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCheckboxModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaCheckbox],
                declarations: [AxaCheckbox]
            }]
    }], function () { return []; }, null); })();
        return AxaCheckboxModule;
    }());

    /**
     * Cookie message warning, that stores it's state in the local storage.
     * @export
     */
    var AxaCookieMessage = /** @class */ (function () {
        function AxaCookieMessage() {
            /**
             * Whether the cookie message was already closed.
             */
            this.closed = localStorage.getItem(COOKIE_STORAGE) === 'true';
        }
        /**
         * The close action.
         */
        AxaCookieMessage.prototype.close = function () {
            this.closed = true;
            localStorage.setItem(COOKIE_STORAGE, 'true');
        };
AxaCookieMessage.ɵfac = function AxaCookieMessage_Factory(t) { return new (t || AxaCookieMessage)(); };
AxaCookieMessage.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaCookieMessage, selectors: [["axa-cookie-message"]], inputs: { legalMessage: "legalMessage", closeMessage: "closeMessage" }, decls: 1, vars: 1, consts: [["class", "alert axa-top-content-bar axa-top-content-bar--corporate cookie-message", "role", "alert", 4, "ngIf"], ["role", "alert", 1, "alert", "axa-top-content-bar", "axa-top-content-bar--corporate", "cookie-message"], [1, "axa-top-content-bar__content", 3, "innerHTML"], ["axa-button", "", "neg", "", "small", "", 3, "click"]], template: function AxaCookieMessage_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵtemplate(0, AxaCookieMessage_div_0_Template, 4, 2, "div", 0);
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngIf", !ctx.closed);
    } }, directives: [ɵngcc2.NgIf, AxaButton], styles: [".cookie-message[_ngcontent-%COMP%] {\n        z-index: 1000000;\n        position: fixed;\n        width: 100%;\n        left: 0;\n        bottom: 0;\n        margin: 0;\n      }"] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCookieMessage, [{
        type: i0.Component,
        args: [{
                selector: 'axa-cookie-message',
                template: "\n    <div *ngIf=\"!closed\" class=\"alert axa-top-content-bar axa-top-content-bar--corporate cookie-message\" role=\"alert\">\n        <div class=\"axa-top-content-bar__content\" [innerHTML]=\"legalMessage\"></div>\n        <a axa-button neg small (click)=\"close()\" >\n            {{ closeMessage }}\n        </a>\n    </div>\n",
                styles: ["\n    .cookie-message {\n        z-index: 1000000;\n        position: fixed;\n        width: 100%;\n        left: 0;\n        bottom: 0;\n        margin: 0;\n      }\n    "]
            }]
    }], function () { return []; }, { legalMessage: [{
            type: i0.Input
        }], closeMessage: [{
            type: i0.Input
        }] }); })();
        return AxaCookieMessage;
    }());
    AxaCookieMessage.propDecorators = {
        legalMessage: [{ type: i0.Input }],
        closeMessage: [{ type: i0.Input }]
    };
    /**Key for the stored cookie state. */
    var COOKIE_STORAGE = 'axa-cookie.closed';

    var AxaCookieMessageModule = /** @class */ (function () {
        function AxaCookieMessageModule() {
        }
AxaCookieMessageModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaCookieMessageModule });
AxaCookieMessageModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaCookieMessageModule_Factory(t) { return new (t || AxaCookieMessageModule)(); }, imports: [[common.CommonModule, AxaButtonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaCookieMessageModule, { declarations: [AxaCookieMessage], imports: [ɵngcc2.CommonModule, AxaButtonModule], exports: [AxaCookieMessage] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaCookieMessageModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule, AxaButtonModule],
                exports: [AxaCookieMessage],
                declarations: [AxaCookieMessage]
            }]
    }], function () { return []; }, null); })();
        return AxaCookieMessageModule;
    }());

    /**Unique ID generated for phone inputs. */
    var nextUniqueId$6 = 0;
    /**Value Accessor provider to enable ngModel. */
    var AXA_DATECOMBOPICKER_CONTROL_VALUE_ACCESSOR = {
        provide: forms.NG_VALUE_ACCESSOR,
        useExisting: i0.forwardRef(function () { return AxaDateComboPicker; }),
        multi: true
    };
    /**@ignore */
    var AxaDateComboBase = /** @class */ (function () {
        function AxaDateComboBase(_defaultErrorStateMatcher, cdr, _parentForm, _parentFormGroup, ngControl) {
            this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
            this.cdr = cdr;
            this._parentForm = _parentForm;
            this._parentFormGroup = _parentFormGroup;
            this.ngControl = ngControl;
        }
        return AxaDateComboBase;
    }());
    /**@ignore */
    var _AxaDateComboBase = mixinParentErrorState(AxaDateComboBase);
    /**Date picker control. */
    var AxaDateComboPicker = /** @class */ (function (_super) {
        __extends(AxaDateComboPicker, _super);
        /**
         *Creates an instance of AxaDateComboPicker.
         * @param ngControl The underlying ngControl.
         * @param parentForm the parent form
         * @param parentFormGroup the parent formgroup
         * @param defaultErrorStateMatcher the errorstatematcher that will be used
         * @param cdr The change detector.
         * @param el The element ref.
         */
        function AxaDateComboPicker(ngControl, parentForm, parentFormGroup, defaultErrorStateMatcher, cdr, el) {
            var _this = _super.call(this, defaultErrorStateMatcher, cdr, parentForm, parentFormGroup, ngControl) || this;
            _this.ngControl = ngControl;
            _this.parentForm = parentForm;
            _this.parentFormGroup = parentFormGroup;
            _this.cdr = cdr;
            _this._uniqueId = "axa-datecombopicker-" + ++nextUniqueId$6;
            /**
             * Stream that emits when the errorState of the control changes.
             */
            _this.errorStateChanges = new rxjs.Subject();
            /**
             * Whether the control is focused.
             */
            _this.focused = false;
            _this._required = false;
            _this._disabled = false;
            _this._readonly = false;
            _this.generateRange = function (start, end) {
                var array = new Array();
                for (var i = start; i <= end; i++) {
                    array.push(i);
                }
                return array;
            };
            /**
              * Implementation of the value accessor.
              */
            _this.valueAccessorChange = function () { };
            _this.id = _this.id;
            _this.host = el.nativeElement;
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            if (_this.ngControl != null) {
                _this.ngControl.valueAccessor = _this;
            }
            return _this;
        }
        Object.defineProperty(AxaDateComboPicker.prototype, "id", {
            /**
             * Element ID.
             */
            get: function () { return this._id; },
            set: function (value) { this._id = value || this._uniqueId; },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "required", {
            /**
             * Whether the control is required.
             */
            get: function () { return this._required; },
            set: function (value) { this._required = coerceBooleanProperty$1(value); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "disabled", {
            /**
             * Whether the control is disabled.
             */
            get: function () {
                return this._disabled;
            },
            set: function (value) {
                this._disabled = coerceBooleanProperty$1(value);
                if (this.focused) {
                    this.focused = false;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "readonly", {
            /**
             * Whether the control is readonly.
             */
            get: function () { return this._readonly; },
            set: function (value) { this._readonly = coerceBooleanProperty$1(value); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "selectedDay", {
            /**The selected day. */
            get: function () {
                return this._selectedDay;
            },
            set: function (value) {
                this._selectedDay = value;
                this.updateSelectedDate();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "selectedMonth", {
            /**The selected month. */
            get: function () {
                return this._selectedMonth;
            },
            set: function (value) {
                this._selectedMonth = value;
                this.adaptDayList();
                this.updateSelectedDate();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "selectedYear", {
            /**The selected year. */
            get: function () {
                return this._selectedYear;
            },
            set: function (value) {
                if ((this._minDate && value < this._minDate.getFullYear())
                    || (this._maxDate && value > this._maxDate.getFullYear())) {
                    value = null;
                }
                this._selectedYear = value;
                this.adaptDayList();
                this.adaptMonthList();
                this.updateSelectedDate();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "value", {
            /**The selected Date. */
            get: function () {
                return this._value;
            },
            set: function (value) {
                this._value = value;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "minDate", {
            get: function () {
                return this._minDate;
            },
            set: function (minDate) {
                this._minDate = minDate;
                this.validateSelectedDate();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaDateComboPicker.prototype, "maxDate", {
            /**The latest date that is selectable. */
            get: function () {
                return this._maxDate;
            },
            set: function (maxDate) {
                this._maxDate = maxDate;
                this.validateSelectedDate();
            },
            enumerable: false,
            configurable: true
        });
        AxaDateComboPicker.prototype.validateSelectedDate = function () {
            if (this.value < this._minDate || this.value > this._maxDate) {
                this._selectedYear = null;
                this._selectedMonth = null;
                this._selectedDay = null;
            }
            this.adaptDayList();
            this.adaptMonthList();
            this.adaptYearList();
            this.updateSelectedDate();
        };
        AxaDateComboPicker.prototype.ngOnInit = function () {
            // this.ngControl = this._injector.get(NgControl);
            this.adaptDayList();
            this.adaptMonthList();
            this.adaptYearList();
        };
        AxaDateComboPicker.prototype.ngOnDestroy = function () {
            this.unMonitorChildrenControls();
        };
        AxaDateComboPicker.prototype.ngAfterViewInit = function () {
            this.childrenControls = this.axaSelects;
            this.monitorChildrenControls();
        };
        /**Returns the number of days in current month. */
        AxaDateComboPicker.prototype.daysInMonth = function (month, year) {
            return new Date(year, month, 0).getDate();
        };
        /**Adapts the day list depending on the month and year. */
        AxaDateComboPicker.prototype.adaptDayList = function () {
            var maxRange = 31;
            var minRange = 1;
            if (Number(this._selectedMonth) > 0 && Number(this._selectedYear) > 0) {
                // calulate max range of days if current selected month and year are the same or earlier than the maxDate
                if (this._maxDate
                    && Number(this._selectedYear) === this._maxDate.getFullYear()
                    && Number(this._selectedMonth) >= this._maxDate.getMonth() + 1) {
                    // clear day if it is earlier than the maxDate
                    if (this._selectedDay > this.maxDate.getDate()) {
                        this.selectedDay = null;
                    }
                    maxRange = this._maxDate.getDate();
                }
                else {
                    maxRange = this.daysInMonth(this._selectedMonth, this._selectedYear);
                }
                // calulate min range of days if current selected month and year are the same or earlier than the minDate
                if (this._minDate
                    && Number(this._selectedYear) === this._minDate.getFullYear()
                    && Number(this._selectedMonth) <= this._minDate.getMonth() + 1) {
                    // clear day if it is earlier than the minDate
                    if (this._selectedDay < this.minDate.getDate()) {
                        this.selectedDay = null;
                    }
                    minRange = this._minDate.getDate();
                }
            }
            // clear day if it is greater than the number of days that exist on the month
            if (maxRange < this._selectedDay) {
                this.selectedDay = null;
            }
            this.days = this.generateRange(minRange, maxRange);
        };
        /**Adapts the month list depending on the year. */
        AxaDateComboPicker.prototype.adaptMonthList = function () {
            var maxRange = 12;
            var minRange = 1;
            if (Number(this._selectedYear) > 0) {
                // calulate max range of months if current selected year is the same as of the maxDate
                if (this._maxDate
                    && Number(this._selectedYear) === this._maxDate.getFullYear()) {
                    // clear month and day if month is later than the maxDate
                    if (this._selectedMonth > this.maxDate.getMonth() + 1) {
                        this.selectedMonth = null;
                        this.selectedDay = null;
                    }
                    maxRange = this._maxDate.getMonth() + 1;
                }
                // calulate min range of months if current selected year is the same as of the minDate
                if (this._minDate
                    && Number(this._selectedYear) === this._minDate.getFullYear()) {
                    // clear month and day if month is earlier than the maxDate
                    if (this._selectedMonth < this._minDate.getMonth() + 1) {
                        this.selectedMonth = null;
                        this.selectedDay = null;
                    }
                    minRange = this.minDate.getMonth() + 1;
                }
            }
            this.months = this.generateRange(minRange, maxRange);
        };
        /**Adapts the year list depending on the allowed range. */
        AxaDateComboPicker.prototype.adaptYearList = function () {
            this.years = this.generateRange(this._minDate ? this._minDate.getFullYear() : 1900, this._maxDate ? this._maxDate.getFullYear() : 2050);
        };
        /**
         * Focuses the input.
         */
        AxaDateComboPicker.prototype.focus = function () {
            this.host.focus();
        };
        AxaDateComboPicker.prototype.updateSelectedDate = function () {
            var previousValue = this._value;
            if (Number(this._selectedDay) > 0 && Number(this._selectedMonth) > 0 && Number(this._selectedYear) > 0 &&
                Number.isInteger(+this._selectedDay) && Number.isInteger(+this._selectedMonth) && Number.isInteger(+this._selectedYear)) {
                this.value = new Date(this._selectedYear, this._selectedMonth - 1, this._selectedDay);
            }
            else {
                this.value = null;
            }
            if (previousValue !== this._value) {
                this.valueAccessorChange(this.value);
            }
        };
        /**
         * Implementation of the value accessor.
         */
        AxaDateComboPicker.prototype.writeValue = function (newValue) {
            this.value = newValue;
            if (newValue) {
                this.selectedDay = newValue.getDate();
                this.selectedMonth = newValue.getMonth() + 1;
                this.selectedYear = newValue.getFullYear();
            }
            else {
                this.selectedYear = null;
                this.selectedMonth = null;
                this.selectedDay = null;
                this.cdr.markForCheck();
            }
        };
        /**
         * Implementation of the value accessor.
         */
        AxaDateComboPicker.prototype.registerOnChange = function (fn) {
            this.valueAccessorChange = function (value) { Promise.resolve(null).then(function () { return fn(value); }); };
        };
        /**
         * Implementation of the value accessor.
         */
        AxaDateComboPicker.prototype.registerOnTouched = function (fn) {
            this.valueAccessorTouch = fn;
        };
        /**
         * Implementation of the value accessor.
         */
        AxaDateComboPicker.prototype.setDisabledState = function (isDisabled) {
            this.disabled = isDisabled;
        };
AxaDateComboPicker.ɵfac = function AxaDateComboPicker_Factory(t) { return new (t || AxaDateComboPicker)(ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgControl, 10), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.NgForm, 8), ɵngcc0.ɵɵdirectiveInject(ɵngcc1.FormGroupDirective, 8), ɵngcc0.ɵɵdirectiveInject(ErrorStateMatcher), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaDateComboPicker.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaDateComboPicker, selectors: [["axa-datecombopicker"]], viewQuery: function AxaDateComboPicker_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵviewQuery(AxaSelect, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.axaSelects = _t);
    } }, hostVars: 1, hostBindings: function AxaDateComboPicker_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
    } }, inputs: { id: "id", required: "required", disabled: "disabled", readonly: "readonly", minDate: "minDate", maxDate: "maxDate", days: "days", months: "months", years: "years", placeholder: "placeholder", name: "name" }, features: [ɵngcc0.ɵɵProvidersFeature([{ provide: AxaFormFieldControl, useExisting: AxaDateComboPicker }]), ɵngcc0.ɵɵInheritDefinitionFeature], decls: 12, vars: 12, consts: [["axaSelect", "", 1, "datepicker", 3, "ngModel", "required", "disabled", "ngModelChange"], [3, "ngValue", 4, "ngFor", "ngForOf"], [3, "ngValue"]], template: function AxaDateComboPicker_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div");
        ɵngcc0.ɵɵelementStart(1, "select", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaDateComboPicker_Template_select_ngModelChange_1_listener($event) { return ctx.selectedDay = $event; });
        ɵngcc0.ɵɵelement(2, "option");
        ɵngcc0.ɵɵtemplate(3, AxaDateComboPicker_option_3_Template, 2, 2, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtext(4, " / ");
        ɵngcc0.ɵɵelementStart(5, "select", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaDateComboPicker_Template_select_ngModelChange_5_listener($event) { return ctx.selectedMonth = $event; });
        ɵngcc0.ɵɵelement(6, "option");
        ɵngcc0.ɵɵtemplate(7, AxaDateComboPicker_option_7_Template, 2, 2, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtext(8, " / ");
        ɵngcc0.ɵɵelementStart(9, "select", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaDateComboPicker_Template_select_ngModelChange_9_listener($event) { return ctx.selectedYear = $event; });
        ɵngcc0.ɵɵelement(10, "option");
        ɵngcc0.ɵɵtemplate(11, AxaDateComboPicker_option_11_Template, 2, 2, "option", 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngModel", ctx.selectedDay)("required", ctx.required)("disabled", ctx.disabled);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.days);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngModel", ctx.selectedMonth)("required", ctx.required)("disabled", ctx.disabled);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.months);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngModel", ctx.selectedYear)("required", ctx.required)("disabled", ctx.disabled);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.years);
    } }, directives: [ɵngcc1.SelectControlValueAccessor, AxaSelect, ɵngcc1.NgControlStatus, ɵngcc1.NgModel, ɵngcc1.RequiredValidator, ɵngcc1.NgSelectOption, ɵngcc1.ɵangular_packages_forms_forms_x, ɵngcc2.NgForOf], styles: [".datepicker[_ngcontent-%COMP%]{display:inline;width:108px}"], changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaDateComboPicker, [{
        type: i0.Component,
        args: [{
                selector: 'axa-datecombopicker',
                host: {
                    '[attr.id]': 'id'
                },
                template: "<div>\r\n  <select class=\"datepicker\" axaSelect [(ngModel)]=\"selectedDay\" [required]=\"required\" [disabled]=\"disabled\">\r\n    <option></option>\r\n    <option *ngFor=\"let day of days\"  [ngValue]=\"day\">{{day}}</option>\r\n  </select> / <select class=\"datepicker\" axaSelect [(ngModel)]=\"selectedMonth\" [required]=\"required\" [disabled]=\"disabled\">\r\n    <option></option>\r\n    <option *ngFor=\"let month of months\"  [ngValue]=\"month\">{{month}}</option>\r\n  </select> / <select class=\"datepicker\" axaSelect [(ngModel)]=\"selectedYear\" [required]=\"required\" [disabled]=\"disabled\">\r\n    <option></option>\r\n    <option *ngFor=\"let year of years\"  [ngValue]=\"year\">{{year}}</option>\r\n  </select>\r\n</div>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush,
                providers: [{ provide: AxaFormFieldControl, useExisting: AxaDateComboPicker }],
                styles: [".datepicker{display:inline;width:108px}"]
            }]
    }], function () { return [{ type: ɵngcc1.NgControl, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Self
            }] }, { type: ɵngcc1.NgForm, decorators: [{
                type: i0.Optional
            }] }, { type: ɵngcc1.FormGroupDirective, decorators: [{
                type: i0.Optional
            }] }, { type: ErrorStateMatcher }, { type: ɵngcc0.ChangeDetectorRef }, { type: ɵngcc0.ElementRef }]; }, { id: [{
            type: i0.Input
        }], required: [{
            type: i0.Input
        }], disabled: [{
            type: i0.Input
        }], readonly: [{
            type: i0.Input
        }], minDate: [{
            type: i0.Input
        }], maxDate: [{
            type: i0.Input
        }], days: [{
            type: i0.Input
        }], months: [{
            type: i0.Input
        }], years: [{
            type: i0.Input
        }], placeholder: [{
            type: i0.Input
        }], name: [{
            type: i0.Input
        }], axaSelects: [{
            type: i0.ViewChildren,
            args: [AxaSelect]
        }] }); })();
        return AxaDateComboPicker;
    }(_AxaDateComboBase));
    AxaDateComboPicker.ctorParameters = function () { return [
        { type: forms.NgControl, decorators: [{ type: i0.Optional }, { type: i0.Self }] },
        { type: forms.NgForm, decorators: [{ type: i0.Optional }] },
        { type: forms.FormGroupDirective, decorators: [{ type: i0.Optional }] },
        { type: ErrorStateMatcher },
        { type: i0.ChangeDetectorRef },
        { type: i0.ElementRef }
    ]; };
    AxaDateComboPicker.propDecorators = {
        id: [{ type: i0.Input }],
        placeholder: [{ type: i0.Input }],
        name: [{ type: i0.Input }],
        required: [{ type: i0.Input }],
        disabled: [{ type: i0.Input }],
        readonly: [{ type: i0.Input }],
        days: [{ type: i0.Input }],
        months: [{ type: i0.Input }],
        years: [{ type: i0.Input }],
        axaSelects: [{ type: i0.ViewChildren, args: [AxaSelect,] }],
        minDate: [{ type: i0.Input }],
        maxDate: [{ type: i0.Input }]
    };

    var AxaDateComboPickerModule = /** @class */ (function () {
        function AxaDateComboPickerModule() {
        }
AxaDateComboPickerModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaDateComboPickerModule });
AxaDateComboPickerModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaDateComboPickerModule_Factory(t) { return new (t || AxaDateComboPickerModule)(); }, providers: [], imports: [[common.CommonModule, forms.FormsModule, AxaSelectModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaDateComboPickerModule, { declarations: [AxaDateComboPicker], imports: [ɵngcc2.CommonModule, ɵngcc1.FormsModule, AxaSelectModule], exports: [AxaDateComboPicker] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaDateComboPickerModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule, forms.FormsModule, AxaSelectModule],
                exports: [AxaDateComboPicker],
                declarations: [AxaDateComboPicker],
                providers: []
            }]
    }], function () { return []; }, null); })();
        return AxaDateComboPickerModule;
    }());

    /**
     * Defines all the flags icons available in the toolkit.
     * Takes care of applying the styles to a button.
     */
    var AxaFlagIcon = /** @class */ (function () {
        /**
         * Creates an instance of AxaFlagIcon.
         * @param el
         * ElementRef to modify styles.
         */
        function AxaFlagIcon(el) {
            this.el = el;
            this._country = 'be';
            this.host = el.nativeElement;
            this.addDefaultStyles('be');
        }
        Object.defineProperty(AxaFlagIcon.prototype, "country", {
            /**Applies country styling. */
            set: function (country) {
                this.addDefaultStyles(country || 'be');
            },
            enumerable: false,
            configurable: true
        });
        AxaFlagIcon.prototype.addDefaultStyles = function (country) {
            this.host.className = "axa-flag axa-flag--" + country;
        };
AxaFlagIcon.ɵfac = function AxaFlagIcon_Factory(t) { return new (t || AxaFlagIcon)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaFlagIcon.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaFlagIcon, selectors: [["", "axa-flag-icon", ""]], inputs: { country: "country" } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFlagIcon, [{
        type: i0.Directive,
        args: [{
                selector: "[axa-flag-icon]"
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { country: [{
            type: i0.Input
        }] }); })();
        return AxaFlagIcon;
    }());
    AxaFlagIcon.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };
    AxaFlagIcon.propDecorators = {
        country: [{ type: i0.Input }]
    };

    var AxaFlagIconModule = /** @class */ (function () {
        function AxaFlagIconModule() {
        }
AxaFlagIconModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaFlagIconModule });
AxaFlagIconModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaFlagIconModule_Factory(t) { return new (t || AxaFlagIconModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaFlagIconModule, { declarations: [AxaFlagIcon], imports: [ɵngcc2.CommonModule], exports: [AxaFlagIcon] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFlagIconModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                declarations: [AxaFlagIcon],
                exports: [AxaFlagIcon]
            }]
    }], function () { return []; }, null); })();
        return AxaFlagIconModule;
    }());

    /**Component to display icons. */
    var IconComponent = /** @class */ (function () {
        /**
         * Creates an instance of IconComponent.
         * @param el
         * ElementRef to modify styles.
         */
        function IconComponent(el) {
            this.el = el;
            this.host = el.nativeElement;
            this.host.classList.add('axa-icon');
        }
        /**Gets the path of the icon. */
        IconComponent.prototype.getPath = function () {
            return "./assets/icons.svg#" + this.name;
        };
IconComponent.ɵfac = function IconComponent_Factory(t) { return new (t || IconComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
IconComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: IconComponent, selectors: [["axa-icon"]], inputs: { name: "name" }, decls: 2, vars: 1, consts: [["focusable", "false"]], template: function IconComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵnamespaceSVG();
        ɵngcc0.ɵɵelementStart(0, "svg", 0);
        ɵngcc0.ɵɵelement(1, "use");
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵattribute("href", ctx.getPath(), null, "xlink");
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(IconComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-icon',
                template: "<svg focusable=\"false\">\r\n    <use [attr.xlink:href]=\"getPath()\"></use>\r\n</svg>",
                encapsulation: i0.ViewEncapsulation.None,
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { name: [{
            type: i0.Input
        }] }); })();
        return IconComponent;
    }());
    IconComponent.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };
    IconComponent.propDecorators = {
        name: [{ type: i0.Input }]
    };

    var AxaIconModule = /** @class */ (function () {
        function AxaIconModule() {
        }
AxaIconModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaIconModule });
AxaIconModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaIconModule_Factory(t) { return new (t || AxaIconModule)(); }, imports: [[]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaIconModule, { declarations: [IconComponent], exports: [IconComponent] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaIconModule, [{
        type: i0.NgModule,
        args: [{
                exports: [
                    IconComponent
                ],
                imports: [],
                declarations: [
                    IconComponent
                ]
            }]
    }], function () { return []; }, null); })();
        return AxaIconModule;
    }());

    /**Component to display list items in the footer. */
    var AxaFooterListComponent = /** @class */ (function () {
        function AxaFooterListComponent() {
            /**Default style of the step. */
            this.cls = true;
        }
AxaFooterListComponent.ɵfac = function AxaFooterListComponent_Factory(t) { return new (t || AxaFooterListComponent)(); };
AxaFooterListComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaFooterListComponent, selectors: [["", "axa-footer-list", ""]], hostVars: 2, hostBindings: function AxaFooterListComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-footer__main__quarter", ctx.cls);
    } }, inputs: { title: "title" }, attrs: _c4, ngContentSelectors: _c0, decls: 5, vars: 1, consts: [[1, "axa-footer__main__quarter"], [1, "axa-footer__main__title"], [1, "axa-footer__main__links"]], template: function AxaFooterListComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelementStart(1, "h1", 1);
        ɵngcc0.ɵɵtext(2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "ul", 2);
        ɵngcc0.ɵɵprojection(4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵtextInterpolate(ctx.title);
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterListComponent, [{
        type: i0.Component,
        args: [{
                selector: '[axa-footer-list]',
                template: "<div class=\"axa-footer__main__quarter\">\r\n  <h1 class=\"axa-footer__main__title\">{{title}}</h1>\r\n  <ul class=\"axa-footer__main__links\">\r\n    <ng-content></ng-content>\r\n  </ul>\r\n</div>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ["class.axa-footer__main__quarter"]
        }], title: [{
            type: i0.Input
        }] }); })();
        return AxaFooterListComponent;
    }());
    AxaFooterListComponent.propDecorators = {
        title: [{ type: i0.Input }],
        cls: [{ type: i0.HostBinding, args: ["class.axa-footer__main__quarter",] }]
    };

    /**Component to display social items in the footer. */
    var AxaFooterSocialComponent = /** @class */ (function () {
        function AxaFooterSocialComponent() {
            /**Default style of the step. */
            this.cls = true;
        }
AxaFooterSocialComponent.ɵfac = function AxaFooterSocialComponent_Factory(t) { return new (t || AxaFooterSocialComponent)(); };
AxaFooterSocialComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaFooterSocialComponent, selectors: [["", "axa-footer-social", ""]], hostVars: 2, hostBindings: function AxaFooterSocialComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-footer__main__quarter", ctx.cls);
    } }, inputs: { title: "title" }, attrs: _c5, ngContentSelectors: _c0, decls: 5, vars: 1, consts: [[1, "axa-footer__main__quarter"], [1, "axa-footer__main__title"], [1, "axa-footer__main__social"]], template: function AxaFooterSocialComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelementStart(1, "h1", 1);
        ɵngcc0.ɵɵtext(2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "ul", 2);
        ɵngcc0.ɵɵprojection(4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵtextInterpolate(ctx.title);
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterSocialComponent, [{
        type: i0.Component,
        args: [{
                selector: '[axa-footer-social]',
                template: "<div class=\"axa-footer__main__quarter\">\r\n  <h1 class=\"axa-footer__main__title\">{{title}}</h1>\r\n  <ul class=\"axa-footer__main__social\">\r\n    <ng-content></ng-content>\r\n  </ul>\r\n</div>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ["class.axa-footer__main__quarter"]
        }], title: [{
            type: i0.Input
        }] }); })();
        return AxaFooterSocialComponent;
    }());
    AxaFooterSocialComponent.propDecorators = {
        title: [{ type: i0.Input }],
        cls: [{ type: i0.HostBinding, args: ["class.axa-footer__main__quarter",] }]
    };

    /**Default style. */
    var FOOTER_CLASS_BASE = 'axa-footer';

    /**Component to generate the footer. */
    var AxaFooterComponent = /** @class */ (function () {
        function AxaFooterComponent() {
            /**Whether the legal is shown. */
            this.showLegal = true;
            /**Text used for the legal information. */
            this.legalText = "Policy privacy \u00A9 " + new Date().getFullYear() + " AXA all rights reserved";
            /**Whether the languages are shown */
            this.showLanguages = true;
            /**Default style for the footer. */
            this.cls = FOOTER_CLASS_BASE;
        }
AxaFooterComponent.ɵfac = function AxaFooterComponent_Factory(t) { return new (t || AxaFooterComponent)(); };
AxaFooterComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaFooterComponent, selectors: [["axa-footer"]], contentQueries: function AxaFooterComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaFooterListComponent, false);
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaFooterSocialComponent, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.lists = _t);
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.social = _t);
    } }, hostVars: 2, hostBindings: function AxaFooterComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, inputs: { showLegal: "showLegal", legalText: "legalText", showLanguages: "showLanguages" }, ngContentSelectors: _c7, decls: 5, vars: 3, consts: [["axa-footer", "", 1, "content-wrapper"], ["class", "axa-footer__main", 4, "ngIf"], [1, "axa-footer__bottom"], ["class", "axa-footer__bottom__language", 4, "ngIf"], ["class", "axa-footer__bottom__legal", 4, "ngIf"], [1, "axa-footer__main"], [1, "axa-footer__bottom__language"], [1, "axa-footer__bottom__legal"]], template: function AxaFooterComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c6);
        ɵngcc0.ɵɵelementStart(0, "footer", 0);
        ɵngcc0.ɵɵtemplate(1, AxaFooterComponent_div_1_Template, 3, 0, "div", 1);
        ɵngcc0.ɵɵelementStart(2, "div", 2);
        ɵngcc0.ɵɵtemplate(3, AxaFooterComponent_div_3_Template, 2, 0, "div", 3);
        ɵngcc0.ɵɵtemplate(4, AxaFooterComponent_div_4_Template, 2, 1, "div", 4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngIf", ctx.lists && ctx.lists.length > 0 || ctx.social && ctx.social.length > 0);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngIf", ctx.showLanguages);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngIf", ctx.showLegal);
    } }, directives: [ɵngcc2.NgIf], encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-footer',
                template: "<footer axa-footer class=\"content-wrapper\">\r\n  <div *ngIf=\"(lists && lists.length > 0) || (social && social.length > 0)\" class=\"axa-footer__main\">\r\n    <ng-content select=\"[axa-footer-list]\">\r\n    </ng-content>\r\n\r\n    <ng-content select=\"[axa-footer-social]\">\r\n    </ng-content>\r\n  </div>\r\n  <div class=\"axa-footer__bottom\">\r\n    <div *ngIf=\"showLanguages\" class=\"axa-footer__bottom__language\">\r\n      <ng-content select=\"[AxaFooterLanguage]\"></ng-content>\r\n    </div>\r\n    <div *ngIf=\"showLegal\" class=\"axa-footer__bottom__legal\">\r\n      {{legalText}}\r\n    </div>\r\n  </div>\r\n</footer>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { showLegal: [{
            type: i0.Input
        }], legalText: [{
            type: i0.Input
        }], showLanguages: [{
            type: i0.Input
        }], cls: [{
            type: i0.HostBinding,
            args: ['class']
        }], lists: [{
            type: i0.ContentChildren,
            args: [AxaFooterListComponent]
        }], social: [{
            type: i0.ContentChildren,
            args: [AxaFooterSocialComponent]
        }] }); })();
        return AxaFooterComponent;
    }());
    AxaFooterComponent.propDecorators = {
        showLegal: [{ type: i0.Input }],
        legalText: [{ type: i0.Input }],
        showLanguages: [{ type: i0.Input }],
        cls: [{ type: i0.HostBinding, args: ['class',] }],
        lists: [{ type: i0.ContentChildren, args: [AxaFooterListComponent,] }],
        social: [{ type: i0.ContentChildren, args: [AxaFooterSocialComponent,] }]
    };

    /**Directive to mark the links associated with languages. */
    var AxaFooterLanguage = /** @class */ (function () {
        function AxaFooterLanguage() {
        }
AxaFooterLanguage.ɵfac = function AxaFooterLanguage_Factory(t) { return new (t || AxaFooterLanguage)(); };
AxaFooterLanguage.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaFooterLanguage, selectors: [["a", "AxaFooterLanguage", ""]] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterLanguage, [{
        type: i0.Directive,
        args: [{ selector: 'a[AxaFooterLanguage]' }]
    }], function () { return []; }, null); })();
        return AxaFooterLanguage;
    }());

    var AxaFooterModule = /** @class */ (function () {
        function AxaFooterModule() {
        }
AxaFooterModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaFooterModule });
AxaFooterModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaFooterModule_Factory(t) { return new (t || AxaFooterModule)(); }, providers: [], imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaFooterModule, { declarations: [AxaFooterComponent, AxaFooterListComponent, AxaFooterSocialComponent, AxaFooterLanguage], imports: [ɵngcc2.CommonModule], exports: [AxaFooterComponent, AxaFooterListComponent, AxaFooterSocialComponent, AxaFooterLanguage] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaFooterModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaFooterComponent, AxaFooterListComponent, AxaFooterSocialComponent, AxaFooterLanguage],
                declarations: [AxaFooterComponent, AxaFooterListComponent, AxaFooterSocialComponent, AxaFooterLanguage],
                providers: []
            }]
    }], function () { return []; }, null); })();
        return AxaFooterModule;
    }());

    /**The step provided by the user. */
    var AxaStepComponent = /** @class */ (function () {
        function AxaStepComponent() {
            this.labelChange = new i0.EventEmitter();
        }
        Object.defineProperty(AxaStepComponent.prototype, "label", {
            get: function () {
                return this._label;
            },
            /**The label of the step. */
            set: function (value) {
                if (this._label !== value) {
                    this._label = value;
                    this.labelChange.emit(this._label);
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaStepComponent.prototype, "pricing", {
            get: function () {
                return this._pricing;
            },
            /**Weither this is a pricing step. */
            set: function (value) {
                this._pricing = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
AxaStepComponent.ɵfac = function AxaStepComponent_Factory(t) { return new (t || AxaStepComponent)(); };
AxaStepComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaStepComponent, selectors: [["axa-step"]], viewQuery: function AxaStepComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵstaticViewQuery(i0.TemplateRef, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.content = _t.first);
    } }, inputs: { label: "label", pricing: "pricing", type: "type" }, outputs: { labelChange: "labelChange" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaStepComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵtemplate(0, AxaStepComponent_ng_template_0_Template, 1, 0, "ng-template");
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaStepComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-step',
                template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { labelChange: [{
            type: i0.Output
        }], label: [{
            type: i0.Input
        }], pricing: [{
            type: i0.Input,
            args: ['pricing']
        }], content: [{
            type: i0.ViewChild,
            args: [i0.TemplateRef, { static: true }]
        }], type: [{
            type: i0.Input
        }] }); })();
        return AxaStepComponent;
    }());
    AxaStepComponent.propDecorators = {
        content: [{ type: i0.ViewChild, args: [i0.TemplateRef, { static: true },] }],
        type: [{ type: i0.Input }],
        label: [{ type: i0.Input }],
        labelChange: [{ type: i0.Output }],
        pricing: [{ type: i0.Input, args: ['pricing',] }]
    };

    /**Default stepper style. */
    var CLASS_BASE$1 = 'axa-form-steps';
    /**Wrapper style. */
    var CLASS_WRAPPER = CLASS_BASE$1 + "__wrapper";
    /**Step style. */
    var CLASS_STEP = CLASS_BASE$1 + "__step";
    /**Pricing step style. */
    var CLASS_STEP_PRICING = CLASS_BASE$1 + "--pricing";
    /**progress bar style. */
    var CLASS_PROGRESS = CLASS_STEP + "__progress";
    /**Active step style. */
    var CLASS_STEP_ACTIVE = CLASS_STEP + "--active";
    /**Done step style. */
    var CLASS_STEP_DONE = CLASS_STEP + "--done";

    /**
     *Step generated at runtime to display progress.
     */
    var AxaStepHeaderComponent = /** @class */ (function () {
        function AxaStepHeaderComponent(cdr) {
            this.cdr = cdr;
            /**Default style of the step. */
            this.cls = true;
            /**Active style of the step. */
            this.active = false;
            /**Done style of the step. */
            this.done = false;
        }
        Object.defineProperty(AxaStepHeaderComponent.prototype, "step", {
            /**The step. */
            get: function () {
                return this._step;
            },
            set: function (step) {
                this._step = step;
                this.subToLabelChange();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaStepHeaderComponent.prototype, "pricingClass", {
            /**Pricing style of the step. */
            get: function () {
                return this._pricing;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaStepHeaderComponent.prototype, "pricing", {
            /**Weither this is a pricing step. */
            get: function () {
                return this._pricing;
            },
            set: function (value) {
                this._pricing = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        AxaStepHeaderComponent.prototype.ngOnDestroy = function () {
            this._labelSub.unsubscribe();
        };
        AxaStepHeaderComponent.prototype.subToLabelChange = function () {
            var _this = this;
            this._labelSub = this._step.labelChange.subscribe(function (newLabel) {
                _this.label = newLabel;
                _this.cdr.markForCheck();
            });
        };
        /**Gets the progress of the step. */
        AxaStepHeaderComponent.prototype.getWidth = function () {
            var pc = 0;
            if (this.done) {
                pc = 100;
            }
            else if (this.active) {
                pc = 30;
            }
            return pc + "%";
        };
        /**Gets the label of the step. */
        AxaStepHeaderComponent.prototype.getLabel = function () {
            if (this.label !== undefined) {
                return this.label;
            }
            return null;
        };
        /**Gets the progress class of the step. */
        AxaStepHeaderComponent.prototype.getProgressClass = function () {
            return "" + CLASS_PROGRESS;
        };
AxaStepHeaderComponent.ɵfac = function AxaStepHeaderComponent_Factory(t) { return new (t || AxaStepHeaderComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef)); };
AxaStepHeaderComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaStepHeaderComponent, selectors: [["axa-step-header"]], hostVars: 8, hostBindings: function AxaStepHeaderComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-form-steps__step", ctx.cls)("axa-form-steps__step--active", ctx.active)("axa-form-steps__step--done", ctx.done)("axa-form-steps--pricing", ctx.pricingClass);
    } }, inputs: { active: "active", done: "done", step: "step", pricing: "pricing", type: "type", label: "label" }, ngContentSelectors: _c0, decls: 6, vars: 3, consts: [["class", "axa-form-steps--pricing__icon", 4, "ngIf"], [1, "axa-form-steps__step__content"], [3, "class", "width", 4, "ngIf"], [1, "axa-form-steps--pricing__icon"], ["viewBox", "0 0 24 24", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M15 18.5c-2.51 0-4.68-1.42-5.76-3.5H15v-2H8.58c-.05-.33-.08-.66-.08-1s.03-.67.08-1H15V9H9.24C10.32 6.92 12.5 5.5 15 5.5c1.61 0 3.09.59 4.23 1.57L21 5.3C19.41 3.87 17.3 3 15 3c-3.92 0-7.24 2.51-8.48 6H3v2h3.06c-.04.33-.06.66-.06 1 0 .34.02.67.06 1H3v2h3.52c1.24 3.49 4.56 6 8.48 6 2.31 0 4.41-.87 6-2.3l-1.78-1.77c-1.13.98-2.6 1.57-4.22 1.57z"], ["d", "M0 0h24v24H0z", "fill", "none"]], template: function AxaStepHeaderComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵtemplate(0, AxaStepHeaderComponent_span_0_Template, 4, 0, "span", 0);
        ɵngcc0.ɵɵelementStart(1, "span", 1);
        ɵngcc0.ɵɵtext(2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "span", 1);
        ɵngcc0.ɵɵtemplate(4, AxaStepHeaderComponent_ng_template_4_Template, 1, 0, "ng-template");
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵtemplate(5, AxaStepHeaderComponent_div_5_Template, 1, 4, "div", 2);
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngIf", ctx.pricing);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵtextInterpolate(ctx.getLabel());
        ɵngcc0.ɵɵadvance(3);
        ɵngcc0.ɵɵproperty("ngIf", !ctx.pricing);
    } }, directives: [ɵngcc2.NgIf], encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaStepHeaderComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-step-header',
                template: "<span class=\"axa-form-steps--pricing__icon\" *ngIf=\"pricing\">\r\n  <svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\r\n      <path d=\"M15 18.5c-2.51 0-4.68-1.42-5.76-3.5H15v-2H8.58c-.05-.33-.08-.66-.08-1s.03-.67.08-1H15V9H9.24C10.32 6.92 12.5 5.5 15 5.5c1.61 0 3.09.59 4.23 1.57L21 5.3C19.41 3.87 17.3 3 15 3c-3.92 0-7.24 2.51-8.48 6H3v2h3.06c-.04.33-.06.66-.06 1 0 .34.02.67.06 1H3v2h3.52c1.24 3.49 4.56 6 8.48 6 2.31 0 4.41-.87 6-2.3l-1.78-1.77c-1.13.98-2.6 1.57-4.22 1.57z\"\r\n      />\r\n      <path d=\"M0 0h24v24H0z\" fill=\"none\" />\r\n  </svg>\r\n</span>\r\n<span class=\"axa-form-steps__step__content\">{{ getLabel() }}</span>\r\n<span class=\"axa-form-steps__step__content\">\r\n  <ng-template>\r\n      <ng-content></ng-content>\r\n  </ng-template>\r\n</span>\r\n\r\n<div [class]=\"getProgressClass()\" [style.width]=\"getWidth()\" *ngIf=\"!pricing\"></div>\r\n",
                encapsulation: i0.ViewEncapsulation.None,
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc0.ChangeDetectorRef }]; }, { cls: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_STEP]
        }], active: [{
            type: i0.Input
        }, {
            type: i0.HostBinding,
            args: ["class." + CLASS_STEP_ACTIVE]
        }], done: [{
            type: i0.Input
        }, {
            type: i0.HostBinding,
            args: ["class." + CLASS_STEP_DONE]
        }], step: [{
            type: i0.Input
        }], pricingClass: [{
            type: i0.HostBinding,
            args: ["class." + CLASS_STEP_PRICING]
        }], pricing: [{
            type: i0.Input,
            args: ['pricing']
        }], type: [{
            type: i0.Input
        }], label: [{
            type: i0.Input
        }] }); })();
        return AxaStepHeaderComponent;
    }());
    AxaStepHeaderComponent.ctorParameters = function () { return [
        { type: i0.ChangeDetectorRef }
    ]; };
    AxaStepHeaderComponent.propDecorators = {
        type: [{ type: i0.Input }],
        step: [{ type: i0.Input }],
        label: [{ type: i0.Input }],
        cls: [{ type: i0.HostBinding, args: ["class." + CLASS_STEP,] }],
        active: [{ type: i0.Input }, { type: i0.HostBinding, args: ["class." + CLASS_STEP_ACTIVE,] }],
        done: [{ type: i0.Input }, { type: i0.HostBinding, args: ["class." + CLASS_STEP_DONE,] }],
        pricingClass: [{ type: i0.HostBinding, args: ["class." + CLASS_STEP_PRICING,] }],
        pricing: [{ type: i0.Input, args: ['pricing',] }]
    };

    /**
     *Stepper control to display forms in a workflow format.
     */
    var AxaStepperComponent = /** @class */ (function () {
        function AxaStepperComponent() {
        }
        Object.defineProperty(AxaStepperComponent.prototype, "current", {
            /**The current step. */
            get: function () {
                return this._current;
            },
            set: function (value) {
                this._current = value;
            },
            enumerable: false,
            configurable: true
        });
        /**Gets the wrapper class. */
        AxaStepperComponent.prototype.getWrapperClass = function () {
            return "" + CLASS_WRAPPER;
        };
        /**Gets the active step. */
        AxaStepperComponent.prototype.getActive = function (index) {
            return index === this.current - 1;
        };
        /**Gets the done steps. */
        AxaStepperComponent.prototype.getDone = function (index) {
            return index < this.current - 1;
        };
        /**Gets the default style. */
        AxaStepperComponent.prototype.getClass = function () {
            return "" + CLASS_BASE$1;
        };
        /**Gets the transform of the view. */
        AxaStepperComponent.prototype.getTransform = function () {
            var translate = -100 * this._current - 1;
            return "translate3d(" + translate + "%, 0, 0)";
        };
AxaStepperComponent.ɵfac = function AxaStepperComponent_Factory(t) { return new (t || AxaStepperComponent)(); };
AxaStepperComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaStepperComponent, selectors: [["axa-stepper"]], contentQueries: function AxaStepperComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaStepComponent, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.steps = _t);
    } }, viewQuery: function AxaStepperComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵviewQuery(AxaStepHeaderComponent, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.stepHeaders = _t);
    } }, inputs: { current: "current" }, decls: 5, vars: 8, consts: [[4, "ngFor", "ngForOf"], [3, "step", "label", "pricing", "active", "done"], [1, "axa-form-steps-content"], [3, "ngTemplateOutlet"]], template: function AxaStepperComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div");
        ɵngcc0.ɵɵelementStart(1, "div");
        ɵngcc0.ɵɵtemplate(2, AxaStepperComponent_ng_container_2_Template, 2, 5, "ng-container", 0);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "div");
        ɵngcc0.ɵɵtemplate(4, AxaStepperComponent_ng_container_4_Template, 3, 2, "ng-container", 0);
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.getClass());
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵclassMap(ctx.getWrapperClass());
        ɵngcc0.ɵɵstyleProp("transform", ctx.getTransform());
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.steps);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.steps);
    } }, directives: [ɵngcc2.NgForOf, AxaStepHeaderComponent, ɵngcc2.NgTemplateOutlet], encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaStepperComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-stepper',
                template: "<div [class]=\"getClass()\">\r\n  <div [class]=\"getWrapperClass()\" [style.transform]=\"getTransform()\">\r\n      <ng-container *ngFor=\"let step of steps; let i = index;\">\r\n          <axa-step-header [step]=\"step\" [label]=\"step.label\" [pricing]=\"step.pricing\" [active]=\"getActive(i)\" [done]=\"getDone(i)\">\r\n          </axa-step-header>\r\n      </ng-container>\r\n  </div>\r\n</div>\r\n<div>\r\n  <ng-container *ngFor=\"let step of steps; let i = index;\">\r\n      <div class=\"axa-form-steps-content\" [attr.aria-expanded]=\"getActive(i)\">\r\n          <ng-container [ngTemplateOutlet]=\"step.content\"></ng-container>\r\n      </div>\r\n  </ng-container>\r\n</div>\r\n",
                encapsulation: i0.ViewEncapsulation.None,
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { current: [{
            type: i0.Input
        }], steps: [{
            type: i0.ContentChildren,
            args: [AxaStepComponent]
        }], stepHeaders: [{
            type: i0.ViewChildren,
            args: [AxaStepHeaderComponent]
        }] }); })();
        return AxaStepperComponent;
    }());
    AxaStepperComponent.propDecorators = {
        current: [{ type: i0.Input }],
        steps: [{ type: i0.ContentChildren, args: [AxaStepComponent,] }],
        stepHeaders: [{ type: i0.ViewChildren, args: [AxaStepHeaderComponent,] }]
    };

    var AxaStepperModule = /** @class */ (function () {
        function AxaStepperModule() {
        }
AxaStepperModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaStepperModule });
AxaStepperModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaStepperModule_Factory(t) { return new (t || AxaStepperModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaStepperModule, { declarations: [AxaStepperComponent, AxaStepComponent, AxaStepHeaderComponent], imports: [ɵngcc2.CommonModule], exports: [AxaStepperComponent, AxaStepComponent] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaStepperModule, [{
        type: i0.NgModule,
        args: [{
                exports: [
                    AxaStepperComponent,
                    AxaStepComponent
                ],
                declarations: [
                    AxaStepperComponent,
                    AxaStepComponent,
                    AxaStepHeaderComponent
                ],
                imports: [common.CommonModule]
            }]
    }], function () { return []; }, null); })();
        return AxaStepperModule;
    }());

    /**Default style. */
    var HEADER_CLASS_BASE = 'axa-header';
    /**Meta domain style. */
    var HEADER_CLASS_META_DOMAIN = HEADER_CLASS_BASE + "__meta__domain__link";
    /**Meta helper style. */
    var HEADER_CLASS_META_HELPER = HEADER_CLASS_BASE + "__meta__helper__link";
    /**search button style. */
    var HEADER_CLASS_SEARCH = HEADER_CLASS_BASE + "__search";
    /**Navigation link style. */
    var HEADER_CLASS_NAV_LINK = HEADER_CLASS_BASE + "__nav__link";
    /**Active navigation link style. */
    var HEADER_CLASS_NAV_LINK_ACTIVE = HEADER_CLASS_NAV_LINK + "--active";
    /**Button navigation link style. */
    var HEADER_CLASS_NAV_LINK_BUTTON = HEADER_CLASS_NAV_LINK + "--button";

    /**The meta domain link in the header. */
    var AxaHeaderMetaDomainDirective = /** @class */ (function () {
        function AxaHeaderMetaDomainDirective() {
            /**Default styling of domain link. */
            this.cls = HEADER_CLASS_META_DOMAIN;
        }
AxaHeaderMetaDomainDirective.ɵfac = function AxaHeaderMetaDomainDirective_Factory(t) { return new (t || AxaHeaderMetaDomainDirective)(); };
AxaHeaderMetaDomainDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaHeaderMetaDomainDirective, selectors: [["axa-header-meta-domain"]], hostVars: 2, hostBindings: function AxaHeaderMetaDomainDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderMetaDomainDirective, [{
        type: i0.Directive,
        args: [{
                selector: 'axa-header-meta-domain'
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ["class"]
        }] }); })();
        return AxaHeaderMetaDomainDirective;
    }());
    AxaHeaderMetaDomainDirective.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ["class",] }]
    };
    /**The meta helper link in the header. */
    var AxaHeaderMetaHelperDirective = /** @class */ (function () {
        function AxaHeaderMetaHelperDirective() {
            /**Default styling of helper link. */
            this.cls = HEADER_CLASS_META_HELPER;
        }
AxaHeaderMetaHelperDirective.ɵfac = function AxaHeaderMetaHelperDirective_Factory(t) { return new (t || AxaHeaderMetaHelperDirective)(); };
AxaHeaderMetaHelperDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaHeaderMetaHelperDirective, selectors: [["axa-header-meta-helper"]], hostVars: 2, hostBindings: function AxaHeaderMetaHelperDirective_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderMetaHelperDirective, [{
        type: i0.Directive,
        args: [{
                selector: 'axa-header-meta-helper'
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ["class"]
        }] }); })();
        return AxaHeaderMetaHelperDirective;
    }());
    AxaHeaderMetaHelperDirective.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ["class",] }]
    };

    /**Component to generate the navigation bar */
    var AxaHeaderComponent = /** @class */ (function () {
        function AxaHeaderComponent(headerEl) {
            this.headerEl = headerEl;
            /**Default style for the header. */
            this.cls = HEADER_CLASS_BASE;
            this.navToggleValue = false;
            /**Unique id for the header. */
            this.uuid = this.guid();
        }
        /**Whether any domain is provided. */
        AxaHeaderComponent.prototype.hasDomains = function () {
            return this._domains.length > 0;
        };
        /**Whether any helper is provided. */
        AxaHeaderComponent.prototype.hasHelpers = function () {
            return this._helpers.length > 0;
        };
        /**Whether any meta is provided. */
        AxaHeaderComponent.prototype.hasMeta = function () {
            return this._domains.length > 0 || this._helpers.length > 0;
        };
        AxaHeaderComponent.prototype.guid = function () {
            var s4 = function () {
                return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
            };
            return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
        };
        AxaHeaderComponent.prototype.ngOnInit = function () {
            var _this = this;
            var navs = this._navigateEl.nativeElement.children;
            for (var navIdx = 0; navIdx < navs.length; navIdx++) {
                navs[navIdx].onclick = function () {
                    _this.navToggleValue = false;
                };
            }
        };
        AxaHeaderComponent.prototype.clickout = function (event) {
            if (!this.headerEl.nativeElement.contains(event.target)) {
                this.navToggleValue = false;
            }
        };
AxaHeaderComponent.ɵfac = function AxaHeaderComponent_Factory(t) { return new (t || AxaHeaderComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaHeaderComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaHeaderComponent, selectors: [["axa-header"]], contentQueries: function AxaHeaderComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaHeaderMetaDomainDirective, false);
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaHeaderMetaHelperDirective, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx._domains = _t);
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx._helpers = _t);
    } }, viewQuery: function AxaHeaderComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵstaticViewQuery(_c8, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx._navigateEl = _t.first);
    } }, hostVars: 2, hostBindings: function AxaHeaderComponent_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("click", function AxaHeaderComponent_click_HostBindingHandler($event) { return ctx.clickout($event); }, false, ɵngcc0.ɵɵresolveDocument);
    } if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, ngContentSelectors: _c10, decls: 24, vars: 5, consts: [["type", "checkbox", 1, "axa-header__toggle__input", 3, "id", "ngModel", "ngModelChange"], [1, "axa-header__toggle", 3, "for"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 0 24 24", 1, "axa-header__toggle__close"], ["d", "M0,0H24V24H0Z", "fill", "none"], ["d", "M4.31,21a1.25,1.25,0,0,1-.92-.38,1.3,1.3,0,0,1,0-1.84L18.77,3.39a1.3,1.3,0,0,1,1.84,1.84L5.23,20.61A1.29,1.29,0,0,1,4.31,21Z"], ["d", "M9.63,10.93a1.29,1.29,0,0,1-.92-.38L3.39,5.23A1.3,1.3,0,0,1,5.23,3.39l5.32,5.32a1.3,1.3,0,0,1,0,1.84A1.33,1.33,0,0,1,9.63,10.93Z"], ["d", "M19.69,21a1.29,1.29,0,0,1-.92-.38l-5.28-5.28a1.3,1.3,0,0,1,1.84-1.84l5.28,5.28a1.3,1.3,0,0,1,0,1.84A1.25,1.25,0,0,1,19.69,21Z"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 0 24 24", 1, "axa-header__toggle__open"], ["d", "M0 0h24v24H0z", "fill", "none"], ["d", "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"], [1, "axa-header__toggle--bg", 3, "for"], [1, "axa-header__wrapper"], ["class", "axa-header__meta", 4, "ngIf"], [1, "axa-header__main"], [1, "axa-header__main__logo"], ["preserveAspectRatio", "xMinYMin meet", "viewBox", "0 0 512 512", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M320.667 253.814l-37.712-.1L480.678.008 511.425 0 320.667 253.814z", "fill", "#ff1721"], ["d", "M298.442 354.484c15.66-19.294 28.628-36.51 33.912-45.023l2.087-3.36.163 4.485c.09 2.466.373 5.445.63 6.62.628 2.86 3.673 12.924 7.843 25.92 1.883 5.87 3.49 10.98 3.57 11.358l.146.686h-48.907l.556-.686zM210.752 409.708c-2.757-8.54-3.97-12.712-3.797-13.057.435-.866 12.09-15.865 12.328-15.865.124 0 .67 1.338 1.21 2.973 1.885 5.698 5.696 16.41 6.62 18.61l.93 2.214-1.69 2.358c-5.074 7.083-11.175 15.317-11.35 15.317-.108 0-2.02-5.647-4.25-12.55zM101.462 354.79c.162-.21 3.035-3.813 6.384-8.006 8.2-10.27 16.55-21.16 21.075-27.5 3.84-5.374 8.305-12.172 8.305-12.64 0-.146.137-.265.304-.265.185 0 .304 1.358.304 3.466 0 1.906.21 4.685.466 6.175.515 2.992 3.335 12.51 8.404 28.365 1.83 5.725 3.328 10.494 3.328 10.597 0 .103-10.995.188-24.433.188-19.5 0-24.374-.077-24.138-.38z", "fill", "#00008f"], ["d", "M511.695 511.91S.315 511.82.203 511.708C.09 511.597 0 459.46 0 459.46h10.978c10.07 0 11.017-.044 11.453-.533.263-.294 1.6-2.35 2.975-4.572 3.387-5.476 9.006-13.483 12.564-17.904 2.948-3.664 15.66-20.205 34.223-44.535l10.004-13.112h75.58l3.746 12.96 4.34 15.022.59 2.062L160.17 417c-19.426 25.198-22.406 28.796-29.935 36.147-3.44 3.36-5.21 5.3-5.145 5.64.092.482 1.41.527 17.88.6 9.78.043 17.964-.026 18.185-.153.222-.127 1.458-2.324 2.75-4.882 2.455-4.866 4.923-8.578 10.05-15.117 1.687-2.15 3.22-4.106 3.406-4.345.185-.24.42-.435.52-.435.187 0 2.267 6.425 3.663 11.31.412 1.442 1.13 4.92 1.596 7.73.484 2.93 1.028 5.294 1.273 5.538.356.357 3.418.427 18.542.427h18.116l.42-.686c.233-.377 1.436-2.603 2.676-4.947 1.24-2.343 3.304-5.667 4.586-7.386 3.32-4.45 9.142-11.155 9.434-10.86.694.698 3.738 12.02 4.69 17.445.624 3.56 1.198 6.017 1.44 6.17.454.29 45.677.366 46.423.08.264-.102.482-.35.482-.55 0-.198-1.18-2.482-2.624-5.074-5.554-9.973-5.155-8.908-15.953-42.562-2.697-8.407-4.904-15.448-4.904-15.646 0-.198 2.62-4.058 5.82-8.578l5.818-8.216 38.01.077 38.01.078 5.578 17.99c8.252 26.62 13.137 42.647 13.954 45.784.92 3.537 1.638 8.354 1.884 12.658.13 2.274.333 3.502.624 3.794.364.363 4.12.43 24.17.43 13.056 0 23.956-.083 24.22-.185.703-.27.61-.603-.615-2.197-2.235-2.91-5.89-11.374-10.44-24.19-2.66-7.483-8.313-24.683-15.914-48.417-2.71-8.454-5.33-16.476-5.83-17.827-1.722-4.673-24.928-85.657-25.394-88.624-.25-1.595-.605-4.34-.788-6.1-.184-1.76-.405-3.442-.492-3.735-.15-.5-1.33-.534-19.178-.534h-19.02l-1.336 2.822c-1.76 3.71-6.486 11.835-9.002 15.476-6.745 9.757-59.662 79.577-60.024 79.196-.265-.28-5.607-19.293-5.5-19.574.126-.327 11.45-14.763 37.675-48.035 12.288-15.59 18.12-22.302 23.18-26.682 1.357-1.174 2.467-2.374 2.467-2.668 0-.503-1.127-.534-19.51-.534h-19.51l-.152.687c-.084.377-.296 1.535-.473 2.574-.716 4.192-2.022 6.913-5.536 11.53-5.666 7.447-29.763 37.773-30.114 37.9-.132.048-.822-2.01-1.533-4.574-2.1-7.568-7.45-26.462-9.276-32.76-1.615-5.568-2.128-8.51-2.41-13.83l-.072-1.373-23.16-.078c-14.18-.048-23.27.033-23.444.21-.18.178.23 1.294 1.094 2.974 3.646 7.09 5.36 11.892 16.697 46.766 6.228 19.162 11.264 35.07 11.19 35.354-.22.836-11.903 15.582-12.148 15.33-.608-.625-25.192-81.055-25.746-84.23-.248-1.42-.73-5.4-1.073-8.845-.343-3.444-.686-6.57-.764-6.948l-.142-.686H129.403l-4.147 8.31c-2.28 4.57-5.182 10.044-6.446 12.164-2.886 4.837-21.25 29.448-47.754 63.996-5.468 7.128-13.017 17.008-16.776 21.956-14.306 18.833-27.67 35.965-42.676 54.712-5.627 7.03-10.535 13.136-10.907 13.57l-.675.788L0 0h481.946S429.63 68.322 324.52 204.315c-20.327 26.298-36.958 48.067-36.958 48.374 0 .32.29.636.686.74.9.243 27.924.24 28.825 0 .734-.197 1.177-.765 42.004-53.78 12.723-16.522 26.304-34.155 30.182-39.186C405.642 139.204 511.276.16 511.424 0l.27 511.91z", "fill", "#00008f"], [1, "axa-header__nav"], ["navs", ""], [1, "axa-header__tools"], [1, "axa-header__meta"], [1, "axa-header__meta__container"], ["class", "axa-header__meta__domain", 4, "ngIf"], ["class", "axa-header__meta__helper", 4, "ngIf"], [1, "axa-header__meta__domain"], [1, "axa-header__meta__helper"]], template: function AxaHeaderComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c9);
        ɵngcc0.ɵɵelementStart(0, "input", 0);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaHeaderComponent_Template_input_ngModelChange_0_listener($event) { return ctx.navToggleValue = $event; });
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(1, "label", 1);
        ɵngcc0.ɵɵnamespaceSVG();
        ɵngcc0.ɵɵelementStart(2, "svg", 2);
        ɵngcc0.ɵɵelement(3, "path", 3);
        ɵngcc0.ɵɵelement(4, "path", 4);
        ɵngcc0.ɵɵelement(5, "path", 5);
        ɵngcc0.ɵɵelement(6, "path", 6);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(7, "svg", 7);
        ɵngcc0.ɵɵelement(8, "path", 8);
        ɵngcc0.ɵɵelement(9, "path", 9);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵnamespaceHTML();
        ɵngcc0.ɵɵelement(10, "label", 10);
        ɵngcc0.ɵɵelementStart(11, "div", 11);
        ɵngcc0.ɵɵtemplate(12, AxaHeaderComponent_div_12_Template, 4, 2, "div", 12);
        ɵngcc0.ɵɵelementStart(13, "div", 13);
        ɵngcc0.ɵɵelementStart(14, "div", 14);
        ɵngcc0.ɵɵnamespaceSVG();
        ɵngcc0.ɵɵelementStart(15, "svg", 15);
        ɵngcc0.ɵɵelement(16, "path", 16);
        ɵngcc0.ɵɵelement(17, "path", 17);
        ɵngcc0.ɵɵelement(18, "path", 18);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵnamespaceHTML();
        ɵngcc0.ɵɵelementStart(19, "nav", 19, 20);
        ɵngcc0.ɵɵprojection(21);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(22, "div", 21);
        ɵngcc0.ɵɵprojection(23, 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵpropertyInterpolate1("id", "axa-header__toggle", ctx.uuid, "");
        ɵngcc0.ɵɵproperty("ngModel", ctx.navToggleValue);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵpropertyInterpolate1("for", "axa-header__toggle", ctx.uuid, "");
        ɵngcc0.ɵɵadvance(9);
        ɵngcc0.ɵɵpropertyInterpolate1("for", "axa-header__toggle", ctx.uuid, "");
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵproperty("ngIf", ctx.hasMeta());
    } }, directives: [ɵngcc1.CheckboxControlValueAccessor, ɵngcc1.NgControlStatus, ɵngcc1.NgModel, ɵngcc2.NgIf], encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-header',
                template: "<input class=\"axa-header__toggle__input\" type=\"checkbox\" id=\"axa-header__toggle{{uuid}}\" [(ngModel)]=\"navToggleValue\" />\r\n<label class=\"axa-header__toggle\" for=\"axa-header__toggle{{uuid}}\">\r\n  <svg class=\"axa-header__toggle__close\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\r\n    <path d=\"M0,0H24V24H0Z\" fill=\"none\" />\r\n    <path d=\"M4.31,21a1.25,1.25,0,0,1-.92-.38,1.3,1.3,0,0,1,0-1.84L18.77,3.39a1.3,1.3,0,0,1,1.84,1.84L5.23,20.61A1.29,1.29,0,0,1,4.31,21Z\"\r\n    />\r\n    <path d=\"M9.63,10.93a1.29,1.29,0,0,1-.92-.38L3.39,5.23A1.3,1.3,0,0,1,5.23,3.39l5.32,5.32a1.3,1.3,0,0,1,0,1.84A1.33,1.33,0,0,1,9.63,10.93Z\"\r\n    />\r\n    <path d=\"M19.69,21a1.29,1.29,0,0,1-.92-.38l-5.28-5.28a1.3,1.3,0,0,1,1.84-1.84l5.28,5.28a1.3,1.3,0,0,1,0,1.84A1.25,1.25,0,0,1,19.69,21Z\"\r\n    />\r\n  </svg>\r\n\r\n  <svg class=\"axa-header__toggle__open\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\r\n    <path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\r\n    <path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path>\r\n  </svg>\r\n</label>\r\n<label class=\"axa-header__toggle--bg\" for=\"axa-header__toggle{{uuid}}\"></label>\r\n<div class=\"axa-header__wrapper\">\r\n  <div class=\"axa-header__meta\" *ngIf=\"hasMeta()\">\r\n    <div class=\"axa-header__meta__container\">\r\n      <nav class=\"axa-header__meta__domain\" *ngIf=\"hasDomains()\">\r\n        <ng-content select=\"axa-header-meta-domain\"></ng-content>\r\n      </nav>\r\n      <nav class=\"axa-header__meta__helper\" *ngIf=\"hasHelpers()\">\r\n        <ng-content select=\"axa-header-meta-helper\"></ng-content>\r\n      </nav>\r\n    </div>\r\n  </div>\r\n  <div class=\"axa-header__main\">\r\n    <div class=\"axa-header__main__logo\">\r\n      <svg preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 512 512\" xmlns=\"http://www.w3.org/2000/svg\">\r\n        <path d=\"M320.667 253.814l-37.712-.1L480.678.008 511.425 0 320.667 253.814z\" fill=\"#ff1721\"></path>\r\n        <path d=\"M298.442 354.484c15.66-19.294 28.628-36.51 33.912-45.023l2.087-3.36.163 4.485c.09 2.466.373 5.445.63 6.62.628 2.86 3.673 12.924 7.843 25.92 1.883 5.87 3.49 10.98 3.57 11.358l.146.686h-48.907l.556-.686zM210.752 409.708c-2.757-8.54-3.97-12.712-3.797-13.057.435-.866 12.09-15.865 12.328-15.865.124 0 .67 1.338 1.21 2.973 1.885 5.698 5.696 16.41 6.62 18.61l.93 2.214-1.69 2.358c-5.074 7.083-11.175 15.317-11.35 15.317-.108 0-2.02-5.647-4.25-12.55zM101.462 354.79c.162-.21 3.035-3.813 6.384-8.006 8.2-10.27 16.55-21.16 21.075-27.5 3.84-5.374 8.305-12.172 8.305-12.64 0-.146.137-.265.304-.265.185 0 .304 1.358.304 3.466 0 1.906.21 4.685.466 6.175.515 2.992 3.335 12.51 8.404 28.365 1.83 5.725 3.328 10.494 3.328 10.597 0 .103-10.995.188-24.433.188-19.5 0-24.374-.077-24.138-.38z\"\r\n          fill=\"#00008f\"></path>\r\n        <path d=\"M511.695 511.91S.315 511.82.203 511.708C.09 511.597 0 459.46 0 459.46h10.978c10.07 0 11.017-.044 11.453-.533.263-.294 1.6-2.35 2.975-4.572 3.387-5.476 9.006-13.483 12.564-17.904 2.948-3.664 15.66-20.205 34.223-44.535l10.004-13.112h75.58l3.746 12.96 4.34 15.022.59 2.062L160.17 417c-19.426 25.198-22.406 28.796-29.935 36.147-3.44 3.36-5.21 5.3-5.145 5.64.092.482 1.41.527 17.88.6 9.78.043 17.964-.026 18.185-.153.222-.127 1.458-2.324 2.75-4.882 2.455-4.866 4.923-8.578 10.05-15.117 1.687-2.15 3.22-4.106 3.406-4.345.185-.24.42-.435.52-.435.187 0 2.267 6.425 3.663 11.31.412 1.442 1.13 4.92 1.596 7.73.484 2.93 1.028 5.294 1.273 5.538.356.357 3.418.427 18.542.427h18.116l.42-.686c.233-.377 1.436-2.603 2.676-4.947 1.24-2.343 3.304-5.667 4.586-7.386 3.32-4.45 9.142-11.155 9.434-10.86.694.698 3.738 12.02 4.69 17.445.624 3.56 1.198 6.017 1.44 6.17.454.29 45.677.366 46.423.08.264-.102.482-.35.482-.55 0-.198-1.18-2.482-2.624-5.074-5.554-9.973-5.155-8.908-15.953-42.562-2.697-8.407-4.904-15.448-4.904-15.646 0-.198 2.62-4.058 5.82-8.578l5.818-8.216 38.01.077 38.01.078 5.578 17.99c8.252 26.62 13.137 42.647 13.954 45.784.92 3.537 1.638 8.354 1.884 12.658.13 2.274.333 3.502.624 3.794.364.363 4.12.43 24.17.43 13.056 0 23.956-.083 24.22-.185.703-.27.61-.603-.615-2.197-2.235-2.91-5.89-11.374-10.44-24.19-2.66-7.483-8.313-24.683-15.914-48.417-2.71-8.454-5.33-16.476-5.83-17.827-1.722-4.673-24.928-85.657-25.394-88.624-.25-1.595-.605-4.34-.788-6.1-.184-1.76-.405-3.442-.492-3.735-.15-.5-1.33-.534-19.178-.534h-19.02l-1.336 2.822c-1.76 3.71-6.486 11.835-9.002 15.476-6.745 9.757-59.662 79.577-60.024 79.196-.265-.28-5.607-19.293-5.5-19.574.126-.327 11.45-14.763 37.675-48.035 12.288-15.59 18.12-22.302 23.18-26.682 1.357-1.174 2.467-2.374 2.467-2.668 0-.503-1.127-.534-19.51-.534h-19.51l-.152.687c-.084.377-.296 1.535-.473 2.574-.716 4.192-2.022 6.913-5.536 11.53-5.666 7.447-29.763 37.773-30.114 37.9-.132.048-.822-2.01-1.533-4.574-2.1-7.568-7.45-26.462-9.276-32.76-1.615-5.568-2.128-8.51-2.41-13.83l-.072-1.373-23.16-.078c-14.18-.048-23.27.033-23.444.21-.18.178.23 1.294 1.094 2.974 3.646 7.09 5.36 11.892 16.697 46.766 6.228 19.162 11.264 35.07 11.19 35.354-.22.836-11.903 15.582-12.148 15.33-.608-.625-25.192-81.055-25.746-84.23-.248-1.42-.73-5.4-1.073-8.845-.343-3.444-.686-6.57-.764-6.948l-.142-.686H129.403l-4.147 8.31c-2.28 4.57-5.182 10.044-6.446 12.164-2.886 4.837-21.25 29.448-47.754 63.996-5.468 7.128-13.017 17.008-16.776 21.956-14.306 18.833-27.67 35.965-42.676 54.712-5.627 7.03-10.535 13.136-10.907 13.57l-.675.788L0 0h481.946S429.63 68.322 324.52 204.315c-20.327 26.298-36.958 48.067-36.958 48.374 0 .32.29.636.686.74.9.243 27.924.24 28.825 0 .734-.197 1.177-.765 42.004-53.78 12.723-16.522 26.304-34.155 30.182-39.186C405.642 139.204 511.276.16 511.424 0l.27 511.91z\"\r\n          fill=\"#00008f\"></path>\r\n      </svg>\r\n    </div>\r\n\r\n    <nav class=\"axa-header__nav\" #navs>\r\n      <ng-content select=\"axa-header-nav, axa-header-nav-route\"></ng-content>\r\n    </nav>\r\n\r\n    <div class=\"axa-header__tools\">\r\n      <ng-content select=\"axa-header-search\"></ng-content>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { cls: [{
            type: i0.HostBinding,
            args: ['class']
        }], clickout: [{
            type: i0.HostListener,
            args: ['document:click', ['$event']]
        }], _domains: [{
            type: i0.ContentChildren,
            args: [AxaHeaderMetaDomainDirective]
        }], _helpers: [{
            type: i0.ContentChildren,
            args: [AxaHeaderMetaHelperDirective]
        }], _navigateEl: [{
            type: i0.ViewChild,
            args: ['navs', { static: true }]
        }] }); })();
        return AxaHeaderComponent;
    }());
    AxaHeaderComponent.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };
    AxaHeaderComponent.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ['class',] }],
        _domains: [{ type: i0.ContentChildren, args: [AxaHeaderMetaDomainDirective,] }],
        _helpers: [{ type: i0.ContentChildren, args: [AxaHeaderMetaHelperDirective,] }],
        _navigateEl: [{ type: i0.ViewChild, args: ['navs', { static: true },] }],
        clickout: [{ type: i0.HostListener, args: ['document:click', ['$event'],] }]
    };

    /**Navigation element of the header. */
    var AxaHeaderNavComponent = /** @class */ (function () {
        function AxaHeaderNavComponent() {
            /**Default style for the the header nav. */
            this.cls = true;
        }
        Object.defineProperty(AxaHeaderNavComponent.prototype, "active", {
            /**Active state of the navigation element. */
            set: function (value) {
                this._active = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaHeaderNavComponent.prototype, "activeClass", {
            /**Styling for the active state. */
            get: function () {
                return (this._active) ? 'disabled' : null;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaHeaderNavComponent.prototype, "buttonClass", {
            /**Styling for the button state. */
            get: function () {
                return typeof this.button !== 'undefined';
            },
            enumerable: false,
            configurable: true
        });
AxaHeaderNavComponent.ɵfac = function AxaHeaderNavComponent_Factory(t) { return new (t || AxaHeaderNavComponent)(); };
AxaHeaderNavComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaHeaderNavComponent, selectors: [["axa-header-nav"]], hostVars: 6, hostBindings: function AxaHeaderNavComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-header__nav__link", ctx.cls)("axa-header__nav__link--active", ctx.activeClass)("axa-header__nav__link--button", ctx.buttonClass);
    } }, inputs: { active: "active", link: "link", button: "button" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaHeaderNavComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderNavComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-header-nav',
                template: "<ng-content></ng-content>\r\n",
                encapsulation: i0.ViewEncapsulation.None,
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ["class." + HEADER_CLASS_NAV_LINK]
        }], active: [{
            type: i0.Input,
            args: ['active']
        }], activeClass: [{
            type: i0.HostBinding,
            args: ["class." + HEADER_CLASS_NAV_LINK_ACTIVE]
        }], buttonClass: [{
            type: i0.HostBinding,
            args: ["class." + HEADER_CLASS_NAV_LINK_BUTTON]
        }], link: [{
            type: i0.Input
        }], button: [{
            type: i0.Input
        }] }); })();
        return AxaHeaderNavComponent;
    }());
    AxaHeaderNavComponent.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ["class." + HEADER_CLASS_NAV_LINK,] }],
        link: [{ type: i0.Input }],
        button: [{ type: i0.Input }],
        active: [{ type: i0.Input, args: ['active',] }],
        activeClass: [{ type: i0.HostBinding, args: ["class." + HEADER_CLASS_NAV_LINK_ACTIVE,] }],
        buttonClass: [{ type: i0.HostBinding, args: ["class." + HEADER_CLASS_NAV_LINK_BUTTON,] }]
    };

    /**
     *The search element of the header.
     * @export
     */
    var AxaHeaderSearchComponent = /** @class */ (function () {
        function AxaHeaderSearchComponent() {
            /**Default styling of the search element. */
            this.cls = true;
            /**Event that happens when the search is triggered. */
            this.search = new i0.EventEmitter();
        }
        /**Emits the search event. */
        AxaHeaderSearchComponent.prototype.onSubmit = function () {
            this.search.emit(this.headerSearchValue);
        };
AxaHeaderSearchComponent.ɵfac = function AxaHeaderSearchComponent_Factory(t) { return new (t || AxaHeaderSearchComponent)(); };
AxaHeaderSearchComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaHeaderSearchComponent, selectors: [["axa-header-search"]], hostVars: 2, hostBindings: function AxaHeaderSearchComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-header__search", ctx.cls);
    } }, inputs: { placeholder: "placeholder" }, outputs: { search: "search" }, decls: 7, vars: 3, consts: [[1, "axa-header__search__wrapper", 3, "ngSubmit"], ["headerSearchForm", "ngForm"], ["type", "text", "name", "fld_header_search", 1, "axa-header__search__input", 3, "placeholder", "ngModel", "ngModelChange"], ["type", "submit", 1, "axa-header__search__btn", 3, "disabled"], ["title", "search", "viewBox", "0 0 24 24", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"], ["d", "M0 0h24v24H0z", "fill", "none"]], template: function AxaHeaderSearchComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "form", 0, 1);
        ɵngcc0.ɵɵlistener("ngSubmit", function AxaHeaderSearchComponent_Template_form_ngSubmit_0_listener() { return ctx.onSubmit(); });
        ɵngcc0.ɵɵelementStart(2, "input", 2);
        ɵngcc0.ɵɵlistener("ngModelChange", function AxaHeaderSearchComponent_Template_input_ngModelChange_2_listener($event) { return ctx.headerSearchValue = $event; });
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(3, "button", 3);
        ɵngcc0.ɵɵnamespaceSVG();
        ɵngcc0.ɵɵelementStart(4, "svg", 4);
        ɵngcc0.ɵɵelement(5, "path", 5);
        ɵngcc0.ɵɵelement(6, "path", 6);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        var _r0 = ɵngcc0.ɵɵreference(1);
        ɵngcc0.ɵɵadvance(2);
        ɵngcc0.ɵɵpropertyInterpolate("placeholder", ctx.placeholder);
        ɵngcc0.ɵɵproperty("ngModel", ctx.headerSearchValue);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("disabled", !_r0.form.valid);
    } }, directives: [ɵngcc1.ɵangular_packages_forms_forms_y, ɵngcc1.NgControlStatusGroup, ɵngcc1.NgForm, ɵngcc1.DefaultValueAccessor, ɵngcc1.NgControlStatus, ɵngcc1.NgModel], encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderSearchComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-header-search',
                template: "<form class=\"axa-header__search__wrapper\" #headerSearchForm=\"ngForm\" (ngSubmit)=\"onSubmit()\">\r\n  <input class=\"axa-header__search__input\" type=\"text\" name=\"fld_header_search\" placeholder=\"{{placeholder}}\" [(ngModel)]=\"headerSearchValue\"\r\n  />\r\n  <button type=\"submit\" class=\"axa-header__search__btn\" [disabled]=\"!headerSearchForm.form.valid\">\r\n    <svg title=\"search\" viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\r\n      <path d=\"M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z\"\r\n      />\r\n      <path d=\"M0 0h24v24H0z\" fill=\"none\" />\r\n    </svg>\r\n  </button>\r\n</form>\r\n",
                encapsulation: i0.ViewEncapsulation.None,
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ["class." + HEADER_CLASS_SEARCH]
        }], search: [{
            type: i0.Output
        }], placeholder: [{
            type: i0.Input
        }] }); })();
        return AxaHeaderSearchComponent;
    }());
    AxaHeaderSearchComponent.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ["class." + HEADER_CLASS_SEARCH,] }],
        search: [{ type: i0.Output }],
        placeholder: [{ type: i0.Input }]
    };

    var AxaHeaderModule = /** @class */ (function () {
        function AxaHeaderModule() {
        }
AxaHeaderModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaHeaderModule });
AxaHeaderModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaHeaderModule_Factory(t) { return new (t || AxaHeaderModule)(); }, imports: [[
            common.CommonModule,
            router.RouterModule,
            forms.FormsModule,
            AxaButtonModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaHeaderModule, { declarations: [AxaHeaderComponent, AxaHeaderMetaDomainDirective, AxaHeaderMetaHelperDirective, AxaHeaderNavComponent, AxaHeaderSearchComponent], imports: [ɵngcc2.CommonModule, ɵngcc3.RouterModule, ɵngcc1.FormsModule, AxaButtonModule], exports: [AxaHeaderComponent, AxaHeaderMetaDomainDirective, AxaHeaderMetaHelperDirective, AxaHeaderNavComponent, AxaHeaderSearchComponent] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaHeaderModule, [{
        type: i0.NgModule,
        args: [{
                exports: [
                    AxaHeaderComponent,
                    AxaHeaderMetaDomainDirective,
                    AxaHeaderMetaHelperDirective,
                    AxaHeaderNavComponent,
                    AxaHeaderSearchComponent
                ],
                imports: [
                    common.CommonModule,
                    router.RouterModule,
                    forms.FormsModule,
                    AxaButtonModule
                ],
                declarations: [
                    AxaHeaderComponent,
                    AxaHeaderMetaDomainDirective,
                    AxaHeaderMetaHelperDirective,
                    AxaHeaderNavComponent,
                    AxaHeaderSearchComponent
                ]
            }]
    }], function () { return []; }, null); })();
        return AxaHeaderModule;
    }());

    /**This dictionary contains all the styles to apply for the different links. */
    var LINK_STYLES = {
        'axa-arrow-link': ['axa-link-blue-arrow'],
        'axa-icon-link': ['axa-link-blue-icon']
    };

    /**
     * Defines all the links available in the toolkit.
     * Takes care of applying the styles to a button.
     * @export
     */
    var AxaLink = /** @class */ (function () {
        /**
         * Creates an instance of AxaLink.
         */
        function AxaLink(el) {
            this.el = el;
            this.host = el.nativeElement;
            this.host.classList.add('axa-link');
            this.addDefaultStyle();
        }
        AxaLink.prototype.clearStyles = function () {
            var _this = this;
            Object.keys(LINK_STYLES).forEach(function (key) {
                var value = LINK_STYLES[key];
                value.forEach(function (style) {
                    _this.host.classList.remove(style);
                });
            });
        };
        AxaLink.prototype.hasHostAttributes = function () {
            var _this = this;
            var attributes = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                attributes[_i] = arguments[_i];
            }
            return attributes.some(function (attribute) { return _this.host.hasAttribute(attribute); });
        };
        AxaLink.prototype.addDefaultStyle = function () {
            var _this = this;
            this.clearStyles();
            Object.keys(LINK_STYLES).forEach(function (key) {
                var value = LINK_STYLES[key];
                if (_this.hasHostAttributes(key)) {
                    value.forEach(function (style) {
                        _this.host.classList.add(style);
                    });
                }
            });
        };
AxaLink.ɵfac = function AxaLink_Factory(t) { return new (t || AxaLink)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaLink.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaLink, selectors: [["a", "axa-link", ""], ["a", "axa-arrow-link", ""], ["a", "axa-icon-link", ""]] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaLink, [{
        type: i0.Directive,
        args: [{ selector: 'a[axa-link], a[axa-arrow-link], a[axa-icon-link]' }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, null); })();
        return AxaLink;
    }());
    AxaLink.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };

    var AxaLinkModule = /** @class */ (function () {
        function AxaLinkModule() {
        }
AxaLinkModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaLinkModule });
AxaLinkModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaLinkModule_Factory(t) { return new (t || AxaLinkModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaLinkModule, { declarations: [AxaLink], imports: [ɵngcc2.CommonModule], exports: [AxaLink] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaLinkModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaLink],
                declarations: [AxaLink]
            }]
    }], function () { return []; }, null); })();
        return AxaLinkModule;
    }());

    /**
     * Class to coordinate unique selection based on name.
     */
    var UniqueSelectionDispatcher = /** @class */ (function () {
        function UniqueSelectionDispatcher() {
            this._listeners = [];
        }
        /**
         * Notify other items that selection for the given name has been set.
         * @param id ID of the item.
         * @param name Name of the item.
         */
        UniqueSelectionDispatcher.prototype.notify = function (id, name) {
            var e_1, _a;
            try {
                for (var _b = __values(this._listeners), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var listener = _c.value;
                    listener(id, name);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        };
        /**
         * Listen for future changes to item selection.
         * @return Function used to deregister listener
         */
        UniqueSelectionDispatcher.prototype.listen = function (listener) {
            var _this = this;
            this._listeners.push(listener);
            return function () {
                _this._listeners = _this._listeners.filter(function (registered) {
                    return listener !== registered;
                });
            };
        };
        /**
         * @ignore
         */
        UniqueSelectionDispatcher.prototype.ngOnDestroy = function () {
            this._listeners = [];
        };
UniqueSelectionDispatcher.ɵfac = function UniqueSelectionDispatcher_Factory(t) { return new (t || UniqueSelectionDispatcher)(); };
UniqueSelectionDispatcher.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: UniqueSelectionDispatcher, factory: function (t) { return UniqueSelectionDispatcher.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(UniqueSelectionDispatcher, [{
        type: i0.Injectable
    }], function () { return []; }, null); })();
        return UniqueSelectionDispatcher;
    }());
    /**Factory for the unique selection dispatcher */
    function UNIQUE_SELECTION_DISPATCHER_PROVIDER_FACTORY(parentDispatcher) {
        return parentDispatcher || new UniqueSelectionDispatcher();
    }
    /**Unique selection dispatcher provider */
    var UNIQUE_SELECTION_DISPATCHER_PROVIDER = {
        provide: UniqueSelectionDispatcher,
        deps: [[new i0.Optional(), new i0.SkipSelf(), UniqueSelectionDispatcher]],
        useFactory: UNIQUE_SELECTION_DISPATCHER_PROVIDER_FACTORY
    };

    /**
     * Generated unique id.
     */
    var nextUniqueId$7 = 0;
    /**Value Accessor provider to enable ngModel. */
    var AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR = {
        provide: forms.NG_VALUE_ACCESSOR,
        useExisting: i0.forwardRef(function () { return AxaRadioGroup; }),
        multi: true
    };
    /**
     * Group of radiobuttons
     * @export
     */
    var AxaRadioGroup = /** @class */ (function () {
        function AxaRadioGroup() {
            this._value = null;
            /** The HTML name attribute applied to radio buttons in this group. */
            this._name = "axa-radio-group-" + nextUniqueId$7++;
            /** The currently selected radio button. Should match value. */
            this._selected = null;
            /** Whether the `value` has been set to its initial value. */
            this._isInitialized = false;
            /** Whether the labels should appear after or before the radio-buttons. Defaults to 'after' */
            this._labelPosition = 'after';
            /** Whether the radio group is disabled. */
            this._disabled = false;
            /** Whether the radio group is required. */
            this._required = false;
            /**
             * Event emitted when the group value changes.
             * Change events are only emitted when the value changes due to user interaction with
             * a radio button (the same behavior as `<input type-"radio">`).
             */
            this.change = new i0.EventEmitter();
            /** The method to be called in order to update ngModel */
            this.valueAccessorChange = function () { };
            /**
             * The method called to update the blur status of ngModel
             */
            this.valueAccessorTouch = function () { };
        }
        Object.defineProperty(AxaRadioGroup.prototype, "name", {
            /** Name of the radio button group. All radio buttons inside this group will use this name. */
            get: function () { return this._name; },
            set: function (value) {
                this._name = value;
                this._updateRadioButtonNames();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaRadioGroup.prototype, "value", {
            /** Value of the radio button. */
            get: function () { return this._value; },
            set: function (newValue) {
                if (this._value !== newValue) {
                    // Set this before proceeding to ensure no circular loop occurs with selection.
                    this._value = newValue;
                    this.updateSelectedRadioFromValue();
                    this.checkSelectedRadioButton();
                }
            },
            enumerable: false,
            configurable: true
        });
        AxaRadioGroup.prototype.checkSelectedRadioButton = function () {
            if (this._selected && !this._selected.checked) {
                this._selected.checked = true;
            }
        };
        Object.defineProperty(AxaRadioGroup.prototype, "selected", {
            /** Whether the radio button is selected. */
            get: function () { return this._selected; },
            set: function (selected) {
                this._selected = selected;
                this.value = selected ? selected.value : null;
                this.checkSelectedRadioButton();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaRadioGroup.prototype, "disabled", {
            /** Whether the radio group is disabled */
            get: function () { return this._disabled; },
            set: function (value) {
                this._disabled = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaRadioGroup.prototype, "required", {
            /** Whether the radio group is required */
            get: function () { return this._required; },
            set: function (value) {
                this._required = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        AxaRadioGroup.prototype.ngAfterContentInit = function () {
            this._isInitialized = true;
        };
        /**
         * @ignore
         */
        AxaRadioGroup.prototype.touch = function () {
            if (this.valueAccessorTouch) {
                this.valueAccessorTouch();
            }
        };
        AxaRadioGroup.prototype._updateRadioButtonNames = function () {
            var _this = this;
            if (this._radios) {
                this._radios.forEach(function (radio) {
                    radio.name = _this.name;
                });
            }
        };
        /** Updates the `selected` radio button from the internal _value state. */
        AxaRadioGroup.prototype.updateSelectedRadioFromValue = function () {
            var _this = this;
            // If the value already matches the selected radio, do nothing.
            var isAlreadySelected = this._selected != null && this._selected.value === this._value;
            if (this._radios != null && !isAlreadySelected) {
                this._selected = null;
                this._radios.forEach(function (radio) {
                    radio.checked = _this.value === radio.value;
                    if (radio.checked) {
                        _this._selected = radio;
                    }
                });
            }
        };
        /** Dispatch change event with current selection and group value. */
        AxaRadioGroup.prototype.fireChangeEvent = function () {
            if (this._isInitialized) {
                this.change.emit(new AxaRadioChange(this._selected, this._value));
            }
        };
        /**
         * Sets the model value. Implemented as part of ControlValueAccessor.
         */
        AxaRadioGroup.prototype.writeValue = function (value) {
            this.value = value;
        };
        /**
         * Registers a callback to be triggered when the model value changes.
         * Implemented as part of ControlValueAccessor.
         * @param fn Callback to be registered.
         */
        AxaRadioGroup.prototype.registerOnChange = function (fn) {
            this.valueAccessorChange = fn;
        };
        /**
         * Registers a callback to be triggered when the control is touched.
         * Implemented as part of ControlValueAccessor.
         * @param fn Callback to be registered.
         */
        AxaRadioGroup.prototype.registerOnTouched = function (fn) {
            this.valueAccessorTouch = fn;
        };
        /**
         * Sets the disabled state of the control. Implemented as a part of ControlValueAccessor.
         * @param isDisabled Whether the control should be disabled.
         */
        AxaRadioGroup.prototype.setDisabledState = function (isDisabled) {
            this.disabled = isDisabled;
        };
AxaRadioGroup.ɵfac = function AxaRadioGroup_Factory(t) { return new (t || AxaRadioGroup)(); };
AxaRadioGroup.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaRadioGroup, selectors: [["axa-radio-group"]], contentQueries: function AxaRadioGroup_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaRadioButton, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx._radios = _t);
    } }, inputs: { disabled: "disabled", name: "name", value: "value", selected: "selected", required: "required" }, outputs: { change: "change" }, exportAs: ["axaRadioGroup"], features: [ɵngcc0.ɵɵProvidersFeature([AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR])] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaRadioGroup, [{
        type: i0.Directive,
        args: [{
                selector: 'axa-radio-group',
                exportAs: 'axaRadioGroup',
                providers: [AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR],
                inputs: ['disabled']
            }]
    }], function () { return []; }, { change: [{
            type: i0.Output
        }], name: [{
            type: i0.Input
        }], value: [{
            type: i0.Input
        }], selected: [{
            type: i0.Input
        }], disabled: [{
            type: i0.Input
        }], required: [{
            type: i0.Input
        }], _radios: [{
            type: i0.ContentChildren,
            args: [i0.forwardRef(function () { return AxaRadioButton; }), { descendants: true }]
        }] }); })();
        return AxaRadioGroup;
    }());
    AxaRadioGroup.propDecorators = {
        change: [{ type: i0.Output }],
        _radios: [{ type: i0.ContentChildren, args: [i0.forwardRef(function () { return AxaRadioButton; }), { descendants: true },] }],
        name: [{ type: i0.Input }],
        value: [{ type: i0.Input }],
        selected: [{ type: i0.Input }],
        disabled: [{ type: i0.Input }],
        required: [{ type: i0.Input }]
    };
    /**Directive to use images for the content of axa-radio-button. */
    var AxaRadioImage = /** @class */ (function () {
        function AxaRadioImage() {
            /**Base style. */
            this.elementClass = 'custom-radio--image';
        }
AxaRadioImage.ɵfac = function AxaRadioImage_Factory(t) { return new (t || AxaRadioImage)(); };
AxaRadioImage.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaRadioImage, selectors: [["axa-radio-button", "axa-radio-image", ""]], hostVars: 2, hostBindings: function AxaRadioImage_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.elementClass);
    } } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaRadioImage, [{
        type: i0.Directive,
        args: [{
                selector: "axa-radio-button[axa-radio-image]"
            }]
    }], function () { return []; }, { elementClass: [{
            type: i0.HostBinding,
            args: ['class']
        }] }); })();
        return AxaRadioImage;
    }());
    AxaRadioImage.propDecorators = {
        elementClass: [{ type: i0.HostBinding, args: ['class',] }]
    };
    /**
     * Change event emitted by the AxaRadioButton.
     * @export
     */
    var AxaRadioChange = /** @class */ (function () {
        /**
         * Creates an instance of AxaRadioChange.
         * @param source The AxaRadioButton that emits the change event.
         * @param value The value of the AxaRadioButton.
         */
        function AxaRadioChange(source, value) {
            this.source = source;
            this.value = value;
        }
        return AxaRadioChange;
    }());
    /**
     * An AXA styled radio-button, used with the AxaRadioGroup.
     * @export
     */
    var AxaRadioButton = /** @class */ (function () {
        /**
         * Creates an instance of AxaRadioButton.
         */
        function AxaRadioButton(radioGroup, _radioDispatcher) {
            var _this = this;
            this._radioDispatcher = _radioDispatcher;
            this._uniqueId = "axa-radio-" + ++nextUniqueId$7;
            this._checked = false;
            this._value = null;
            /**
             * Element ID.
             */
            this.id = this._uniqueId;
            /**
             * The style applied to the radio button, can be '1' or '2'.
             */
            this.style = '1';
            /**
             * Event emitted when the checked state changes.
             */
            this.change = new i0.EventEmitter();
            this.removeUniqueSelectionListener = function () { };
            /**
             * Implementation of the value accessor.
             */
            this.onTouched = function () { };
            this.radioGroup = radioGroup;
            this.removeUniqueSelectionListener =
                _radioDispatcher.listen(function (id, name) {
                    if (id !== _this.id && name === _this.name) {
                        _this.checked = false;
                    }
                });
        }
        Object.defineProperty(AxaRadioButton.prototype, "checked", {
            /**
             * Whether the control is checked.
             */
            get: function () { return this._checked; },
            set: function (value) {
                var newCheckedState = coerceBooleanProperty$1(value);
                if (this._checked !== newCheckedState) {
                    this._checked = newCheckedState;
                    if (newCheckedState && this.radioGroup && this.radioGroup.value !== this.value) {
                        this.radioGroup.selected = this;
                    }
                    else if (!newCheckedState && this.radioGroup && this.radioGroup.value === this.value) {
                        // When unchecking the selected radio button, update the selected radio
                        // property on the group.
                        this.radioGroup.selected = null;
                    }
                    if (newCheckedState) {
                        // Notify all radio buttons with the same name to un-check.
                        this._radioDispatcher.notify(this.id, this.name);
                    }
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaRadioButton.prototype, "value", {
            /**
             * The value of the control.
             */
            get: function () { return this._value; },
            set: function (value) {
                if (this._value !== value) {
                    this._value = value;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaRadioButton.prototype, "disabled", {
            /**
             * Whether the control is disabled.
             */
            get: function () {
                return this._disabled || (this.radioGroup != null && this.radioGroup.disabled);
            },
            set: function (value) {
                this._disabled = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaRadioButton.prototype, "required", {
            /**
             * Whether the control is required.
             */
            get: function () {
                return this._required || (this.radioGroup && this.radioGroup.required);
            },
            set: function (value) {
                this._required = coerceBooleanProperty$1(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaRadioButton.prototype, "inputId", {
            /**
             *Gets the ID of the element.
             */
            get: function () { return (this.id || this._uniqueId) + "-input"; },
            enumerable: false,
            configurable: true
        });
        /**Handles the click on the input. */
        AxaRadioButton.prototype.onInputClick = function (event) {
            event.stopPropagation();
        };
        /**Handles value change on the input. */
        AxaRadioButton.prototype.onInputChange = function (event) {
            event.stopPropagation();
            var groupValueChanged = this.radioGroup && this.value !== this.radioGroup.value;
            this.checked = true;
            this.fireChangeEvent();
            if (this.radioGroup) {
                this.radioGroup.valueAccessorChange(this.value);
                this.radioGroup.touch();
                if (groupValueChanged) {
                    this.radioGroup.fireChangeEvent();
                }
            }
        };
        AxaRadioButton.prototype.fireChangeEvent = function () {
            this.change.emit(new AxaRadioChange(this, this._value));
        };
        AxaRadioButton.prototype.ngOnInit = function () {
            if (this.radioGroup) {
                // If the radio is inside a radio group, determine if it should be checked
                this.checked = this.radioGroup.value === this._value;
                // Copy name from parent radio group
                this.name = this.radioGroup.name;
            }
        };
        AxaRadioButton.prototype.ngOnDestroy = function () {
            this.removeUniqueSelectionListener();
        };
AxaRadioButton.ɵfac = function AxaRadioButton_Factory(t) { return new (t || AxaRadioButton)(ɵngcc0.ɵɵdirectiveInject(AxaRadioGroup, 8), ɵngcc0.ɵɵdirectiveInject(UniqueSelectionDispatcher)); };
AxaRadioButton.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaRadioButton, selectors: [["axa-radio-button"]], hostVars: 1, hostBindings: function AxaRadioButton_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.id);
    } }, inputs: { id: "id", style: "style", checked: "checked", value: "value", disabled: "disabled", required: "required", name: "name", tabIndex: "tabIndex", ariaLabel: ["aria-label", "ariaLabel"], ariaLabelledby: ["aria-labelledby", "ariaLabelledby"], ariaDescribedby: ["aria-describedby", "ariaDescribedby"] }, outputs: { change: "change" }, ngContentSelectors: _c0, decls: 5, vars: 13, consts: [[1, "custom-control", "custom-radio", 3, "ngClass"], ["type", "radio", 1, "custom-control-input", 3, "id", "checked", "disabled", "tabIndex", "required", "change", "click"], [1, "custom-control-indicator"], [1, "custom-control-description"]], template: function AxaRadioButton_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "label", 0);
        ɵngcc0.ɵɵelementStart(1, "input", 1);
        ɵngcc0.ɵɵlistener("change", function AxaRadioButton_Template_input_change_1_listener($event) { return ctx.onInputChange($event); })("click", function AxaRadioButton_Template_input_click_1_listener($event) { return ctx.onInputClick($event); });
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelement(2, "span", 2);
        ɵngcc0.ɵɵelementStart(3, "span", 3);
        ɵngcc0.ɵɵprojection(4);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(10, _c11, ctx.style === "1", ctx.style === "2"));
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("id", ctx.inputId)("checked", ctx.checked)("disabled", ctx.disabled)("tabIndex", ctx.tabIndex)("required", ctx.required);
        ɵngcc0.ɵɵattribute("name", ctx.name)("aria-label", ctx.ariaLabel)("aria-labelledby", ctx.ariaLabelledby)("aria-describedby", ctx.ariaDescribedby);
    } }, directives: [ɵngcc2.NgClass], encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaRadioButton, [{
        type: i0.Component,
        args: [{
                selector: 'axa-radio-button',
                template: "<label class=\"custom-control custom-radio\" [ngClass]=\"{'radio1': style==='1','radio2': style==='2'}\">\r\n    <input type=\"radio\" class=\"custom-control-input\"\r\n    [id]=\"inputId\"\r\n    [checked]=\"checked\"\r\n    [disabled]=\"disabled\"\r\n    [tabIndex]=\"tabIndex\"\r\n    [attr.name]=\"name\"\r\n    [required]=\"required\"\r\n    [attr.aria-label]=\"ariaLabel\"\r\n    [attr.aria-labelledby]=\"ariaLabelledby\"\r\n    [attr.aria-describedby]=\"ariaDescribedby\"\r\n    (change)=\"onInputChange($event)\"\r\n    (click)=\"onInputClick($event)\">\r\n    <span class=\"custom-control-indicator\"></span>\r\n    <span class=\"custom-control-description\">\r\n        <ng-content></ng-content>\r\n    </span>\r\n</label>\r\n",
                host: { '[attr.id]': 'id' }
            }]
    }], function () { return [{ type: AxaRadioGroup, decorators: [{
                type: i0.Optional
            }] }, { type: UniqueSelectionDispatcher }]; }, { id: [{
            type: i0.Input
        }], style: [{
            type: i0.Input
        }], change: [{
            type: i0.Output
        }], checked: [{
            type: i0.Input
        }], value: [{
            type: i0.Input
        }], disabled: [{
            type: i0.Input
        }], required: [{
            type: i0.Input
        }], name: [{
            type: i0.Input
        }], tabIndex: [{
            type: i0.Input
        }], ariaLabel: [{
            type: i0.Input,
            args: ['aria-label']
        }], ariaLabelledby: [{
            type: i0.Input,
            args: ['aria-labelledby']
        }], ariaDescribedby: [{
            type: i0.Input,
            args: ['aria-describedby']
        }] }); })();
        return AxaRadioButton;
    }());
    AxaRadioButton.ctorParameters = function () { return [
        { type: AxaRadioGroup, decorators: [{ type: i0.Optional }] },
        { type: UniqueSelectionDispatcher }
    ]; };
    AxaRadioButton.propDecorators = {
        id: [{ type: i0.Input }],
        tabIndex: [{ type: i0.Input }],
        name: [{ type: i0.Input }],
        style: [{ type: i0.Input }],
        ariaLabel: [{ type: i0.Input, args: ['aria-label',] }],
        ariaLabelledby: [{ type: i0.Input, args: ['aria-labelledby',] }],
        ariaDescribedby: [{ type: i0.Input, args: ['aria-describedby',] }],
        checked: [{ type: i0.Input }],
        value: [{ type: i0.Input }],
        disabled: [{ type: i0.Input }],
        required: [{ type: i0.Input }],
        change: [{ type: i0.Output }]
    };

    var AxaRadioButtonModule = /** @class */ (function () {
        function AxaRadioButtonModule() {
        }
AxaRadioButtonModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaRadioButtonModule });
AxaRadioButtonModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaRadioButtonModule_Factory(t) { return new (t || AxaRadioButtonModule)(); }, providers: [UNIQUE_SELECTION_DISPATCHER_PROVIDER], imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaRadioButtonModule, { declarations: [AxaRadioButton, AxaRadioGroup, AxaRadioImage], imports: [ɵngcc2.CommonModule], exports: [AxaRadioButton, AxaRadioGroup, AxaRadioImage] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaRadioButtonModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaRadioButton, AxaRadioGroup, AxaRadioImage],
                providers: [UNIQUE_SELECTION_DISPATCHER_PROVIDER],
                declarations: [AxaRadioButton, AxaRadioGroup, AxaRadioImage]
            }]
    }], function () { return []; }, null); })();
        return AxaRadioButtonModule;
    }());

    /**Wrapper class for the axa table. */
    var TABLE_CLASS_WRAPPER = 'axa-table-wrapper';
    /**Different flex values for the axa table. */
    var TABLE_CLASS_FLEX = {
        xs: 'axa-table--flex-xs',
        sm: 'axa-table--flex-sm',
        md: 'axa-table--flex-md',
        lg: 'axa-table--flex-lg',
        xl: 'axa-table--flex-xl'
    };
    /**This dictionary contains all the styles to apply for the table. */
    var TABLE_STYLES = {};

    /**
     * Takes care of applying the styles to a table.
     * @export
     */
    var AxaTable = /** @class */ (function () {
        /**Creates an instance of AxaTable. */
        function AxaTable(el) {
            this._host = el.nativeElement;
            this.applyStyles();
        }
        Object.defineProperty(AxaTable.prototype, "flexDown", {
            get: function () {
                return this._flexDown;
            },
            /** Weither the card is active. */
            set: function (value) {
                this._flexDown = value;
                this.applyStyles();
            },
            enumerable: false,
            configurable: true
        });
        AxaTable.prototype.applyStyles = function () {
            var _this = this;
            this.getClass().forEach(function (style) {
                if (_this._host && !_this._host.classList.contains(style)) {
                    _this._host.classList.add(style);
                }
            });
        };
        /**Returns the css classes. */
        AxaTable.prototype.getClass = function () {
            var classes = [TABLE_CLASS_WRAPPER];
            if (typeof TABLE_CLASS_FLEX[this.flexDown] !== 'undefined') {
                classes.push(TABLE_CLASS_FLEX[this.flexDown]);
            }
            return classes;
        };
AxaTable.ɵfac = function AxaTable_Factory(t) { return new (t || AxaTable)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
AxaTable.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTable, selectors: [["axa-table"]], inputs: { flexDown: ["flex-down", "flexDown"] }, ngContentSelectors: _c0, decls: 2, vars: 0, consts: [[1, "axa-table"]], template: function AxaTable_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵelementStart(0, "table", 0);
        ɵngcc0.ɵɵprojection(1);
        ɵngcc0.ɵɵelementEnd();
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTable, [{
        type: i0.Component,
        args: [{
                selector: 'axa-table',
                template: "<table class=\"axa-table\">\r\n  <ng-content></ng-content>\r\n</table>\r\n"
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { flexDown: [{
            type: i0.Input,
            args: ['flex-down']
        }] }); })();
        return AxaTable;
    }());
    AxaTable.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };
    AxaTable.propDecorators = {
        flexDown: [{ type: i0.Input, args: ['flex-down',] }]
    };

    var AxaTableModule = /** @class */ (function () {
        function AxaTableModule() {
        }
AxaTableModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaTableModule });
AxaTableModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaTableModule_Factory(t) { return new (t || AxaTableModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaTableModule, { declarations: [AxaTable], imports: [ɵngcc2.CommonModule], exports: [AxaTable] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaTable],
                declarations: [AxaTable]
            }]
    }], function () { return []; }, null); })();
        return AxaTableModule;
    }());

    /**Default style. */
    var TOC_CLASS_BASE = 'table-of-contents';
    /**Title style. */
    var TOC_CLASS_TITLE = TOC_CLASS_BASE + "__heading";
    /**Title style. */
    var TOC_CLASS_ITEM = TOC_CLASS_BASE + "__item";

    /**Table of contents components to display a summary. */
    var AxaTableOfContentsComponent = /** @class */ (function () {
        function AxaTableOfContentsComponent() {
            /**Default style */
            this.cls = TOC_CLASS_BASE;
        }
AxaTableOfContentsComponent.ɵfac = function AxaTableOfContentsComponent_Factory(t) { return new (t || AxaTableOfContentsComponent)(); };
AxaTableOfContentsComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTableOfContentsComponent, selectors: [["axa-table-of-contents"]], hostVars: 2, hostBindings: function AxaTableOfContentsComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, ngContentSelectors: _c13, decls: 4, vars: 0, consts: [[1, "table-of-contents__nav"], [1, "table-of-contents__menu"]], template: function AxaTableOfContentsComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c12);
        ɵngcc0.ɵɵprojection(0);
        ɵngcc0.ɵɵelementStart(1, "nav", 0);
        ɵngcc0.ɵɵelementStart(2, "div", 1);
        ɵngcc0.ɵɵprojection(3, 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableOfContentsComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-table-of-contents',
                template: "<ng-content select=\"axa-table-of-contents-title\"></ng-content>\r\n<nav class=\"table-of-contents__nav\">\r\n  <div class=\"table-of-contents__menu\">\r\n    <ng-content select=\"axa-table-of-contents-item\"></ng-content>\r\n  </div>\r\n</nav>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ['class']
        }] }); })();
        return AxaTableOfContentsComponent;
    }());
    AxaTableOfContentsComponent.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ['class',] }]
    };

    /**Table of contents title component */
    var AxaTableOfContentsTitleComponent = /** @class */ (function () {
        function AxaTableOfContentsTitleComponent() {
            /**Default style */
            this.cls = TOC_CLASS_TITLE;
        }
AxaTableOfContentsTitleComponent.ɵfac = function AxaTableOfContentsTitleComponent_Factory(t) { return new (t || AxaTableOfContentsTitleComponent)(); };
AxaTableOfContentsTitleComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTableOfContentsTitleComponent, selectors: [["axa-table-of-contents-title"]], hostVars: 2, hostBindings: function AxaTableOfContentsTitleComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaTableOfContentsTitleComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableOfContentsTitleComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-table-of-contents-title',
                template: "<ng-content></ng-content>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ['class']
        }] }); })();
        return AxaTableOfContentsTitleComponent;
    }());
    AxaTableOfContentsTitleComponent.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ['class',] }]
    };

    /**Table of contents item component. */
    var AxaTableOfContentsItemComponent = /** @class */ (function () {
        function AxaTableOfContentsItemComponent() {
            /**Default style */
            this.cls = TOC_CLASS_ITEM;
        }
AxaTableOfContentsItemComponent.ɵfac = function AxaTableOfContentsItemComponent_Factory(t) { return new (t || AxaTableOfContentsItemComponent)(); };
AxaTableOfContentsItemComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTableOfContentsItemComponent, selectors: [["axa-table-of-contents-item"]], hostVars: 2, hostBindings: function AxaTableOfContentsItemComponent_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassMap(ctx.cls);
    } }, inputs: { link: "link" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaTableOfContentsItemComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableOfContentsItemComponent, [{
        type: i0.Component,
        args: [{
                selector: 'axa-table-of-contents-item',
                template: "<ng-content></ng-content>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { cls: [{
            type: i0.HostBinding,
            args: ['class']
        }], link: [{
            type: i0.Input
        }] }); })();
        return AxaTableOfContentsItemComponent;
    }());
    AxaTableOfContentsItemComponent.propDecorators = {
        cls: [{ type: i0.HostBinding, args: ['class',] }],
        link: [{ type: i0.Input }]
    };

    var AxaTableOfContentsModule = /** @class */ (function () {
        function AxaTableOfContentsModule() {
        }
AxaTableOfContentsModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaTableOfContentsModule });
AxaTableOfContentsModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaTableOfContentsModule_Factory(t) { return new (t || AxaTableOfContentsModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaTableOfContentsModule, { declarations: [AxaTableOfContentsComponent, AxaTableOfContentsTitleComponent, AxaTableOfContentsItemComponent], imports: [ɵngcc2.CommonModule], exports: [AxaTableOfContentsComponent, AxaTableOfContentsTitleComponent, AxaTableOfContentsItemComponent] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTableOfContentsModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaTableOfContentsComponent, AxaTableOfContentsTitleComponent, AxaTableOfContentsItemComponent],
                declarations: [AxaTableOfContentsComponent, AxaTableOfContentsTitleComponent, AxaTableOfContentsItemComponent]
            }]
    }], function () { return []; }, null); })();
        return AxaTableOfContentsModule;
    }());

    /** TabItem displayed in the tab control. */
    var AxaTabItem = /** @class */ (function () {
        function AxaTabItem() {
        }
AxaTabItem.ɵfac = function AxaTabItem_Factory(t) { return new (t || AxaTabItem)(); };
AxaTabItem.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTabItem, selectors: [["axa-tab-item"]], viewQuery: function AxaTabItem_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵstaticViewQuery(i0.TemplateRef, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.content = _t.first);
    } }, inputs: { label: "label" }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaTabItem_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵtemplate(0, AxaTabItem_ng_template_0_Template, 1, 0, "ng-template");
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTabItem, [{
        type: i0.Component,
        args: [{
                selector: 'axa-tab-item',
                template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { label: [{
            type: i0.Input
        }], content: [{
            type: i0.ViewChild,
            args: [i0.TemplateRef, { static: true }]
        }] }); })();
        return AxaTabItem;
    }());
    AxaTabItem.propDecorators = {
        label: [{ type: i0.Input }],
        content: [{ type: i0.ViewChild, args: [i0.TemplateRef, { static: true },] }]
    };

    /** Tab control to display sub organized content. */
    var AxaTab = /** @class */ (function () {
        function AxaTab() {
            this._current = 1;
            this._alt = false;
            /**The change event for the current property. */
            this.currentChange = new i0.EventEmitter();
        }
        Object.defineProperty(AxaTab.prototype, "current", {
            /** The currently selected tab item. */
            get: function () { return this._current; },
            set: function (value) {
                this._current = value;
                this.currentChange.emit(this.current);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(AxaTab.prototype, "alt", {
            /** Weither the alternate style should be used.
             *
             * Example 1: <axa-tab alt>
             *
             * Example 2: <axa-tab [alt]="showAltStyle">
            */
            get: function () { return this._alt; },
            set: function (value) {
                this._alt = coerceBooleanProperty(value);
            },
            enumerable: false,
            configurable: true
        });
        /**Returns the current active tab. */
        AxaTab.prototype.getActive = function (index) {
            return index === this.current - 1;
        };
        /**Sets the curent active item. */
        AxaTab.prototype.onTabClick = function (index) {
            this.current = index + 1;
        };
AxaTab.ɵfac = function AxaTab_Factory(t) { return new (t || AxaTab)(); };
AxaTab.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTab, selectors: [["axa-tab"]], contentQueries: function AxaTab_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        ɵngcc0.ɵɵcontentQuery(dirIndex, AxaTabItem, false);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.tabs = _t);
    } }, inputs: { current: "current", alt: "alt" }, outputs: { currentChange: "currentChange" }, decls: 6, vars: 6, consts: [[3, "ngClass"], [1, "axa-tab-list"], [4, "ngFor", "ngForOf"], [3, "ngClass", "label", "index", "active", "click"], [4, "ngIf"], [3, "ngTemplateOutlet"]], template: function AxaTab_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelementStart(0, "div", 0);
        ɵngcc0.ɵɵelementStart(1, "div");
        ɵngcc0.ɵɵelementStart(2, "div", 1);
        ɵngcc0.ɵɵtemplate(3, AxaTab_ng_container_3_Template, 2, 5, "ng-container", 2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementStart(4, "div", 0);
        ɵngcc0.ɵɵtemplate(5, AxaTab_ng_container_5_Template, 2, 1, "ng-container", 2);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction1(4, _c14, !ctx.alt));
        ɵngcc0.ɵɵadvance(3);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.tabs);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngClass", ctx.alt ? "axa-tab-panel-alt" : "axa-tab-panel");
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngForOf", ctx.tabs);
    } }, directives: function () { return [ɵngcc2.NgClass, ɵngcc2.NgForOf, AxaTabHeader, ɵngcc2.NgIf, ɵngcc2.NgTemplateOutlet]; }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTab, [{
        type: i0.Component,
        args: [{
                selector: 'axa-tab',
                template: "<div [ngClass]=\"{'axa-tab': !alt}\">\r\n  <div>\r\n    <div class=\"axa-tab-list\">\r\n      <ng-container *ngFor=\"let tab of tabs; let i = index;\">\r\n        <axa-tab-header [ngClass]=\"alt ? 'axa-tab-list__tab-alt' : 'axa-tab-list__tab'\" [label]=\"tab.label\" [index]=\"i\"\r\n                        [active]=\"getActive(i)\" [attr.aria-selected]=\"getActive(i)\" (click)=\"onTabClick(i)\">\r\n        </axa-tab-header>\r\n      </ng-container>\r\n    </div>\r\n  </div>\r\n  <div [ngClass]=\"alt ? 'axa-tab-panel-alt' : 'axa-tab-panel'\">\r\n    <ng-container *ngFor=\"let tab of tabs; let i = index;\">\r\n      <div [attr.aria-selected]=\"getActive(i)\" *ngIf=\"getActive(i)\">\r\n        <ng-container [ngTemplateOutlet]=\"tab.content\"></ng-container>\r\n      </div>\r\n    </ng-container>\r\n  </div>\r\n</div>\r\n",
                changeDetection: i0.ChangeDetectionStrategy.Default
            }]
    }], function () { return []; }, { currentChange: [{
            type: i0.Output
        }], current: [{
            type: i0.Input
        }], alt: [{
            type: i0.Input
        }], tabs: [{
            type: i0.ContentChildren,
            args: [AxaTabItem]
        }] }); })();
        return AxaTab;
    }());
    AxaTab.propDecorators = {
        tabs: [{ type: i0.ContentChildren, args: [AxaTabItem,] }],
        current: [{ type: i0.Input }],
        alt: [{ type: i0.Input }],
        currentChange: [{ type: i0.Output }]
    };

    /** Header control generated to display the tab list. */
    var AxaTabHeader = /** @class */ (function () {
        function AxaTabHeader() {
        }
AxaTabHeader.ɵfac = function AxaTabHeader_Factory(t) { return new (t || AxaTabHeader)(); };
AxaTabHeader.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaTabHeader, selectors: [["axa-tab-header"]], inputs: { active: "active", label: "label", index: "index" }, decls: 1, vars: 1, template: function AxaTabHeader_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵtext(0);
    } if (rf & 2) {
        ɵngcc0.ɵɵtextInterpolate1("", ctx.label, "\n");
    } }, encapsulation: 2, changeDetection: 0 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTabHeader, [{
        type: i0.Component,
        args: [{
                selector: 'axa-tab-header',
                template: "{{label}}\r\n",
                changeDetection: i0.ChangeDetectionStrategy.OnPush
            }]
    }], function () { return []; }, { active: [{
            type: i0.Input
        }], label: [{
            type: i0.Input
        }], index: [{
            type: i0.Input
        }] }); })();
        return AxaTabHeader;
    }());
    AxaTabHeader.propDecorators = {
        active: [{ type: i0.Input }],
        label: [{ type: i0.Input }],
        index: [{ type: i0.Input }]
    };

    var AxaTabModule = /** @class */ (function () {
        function AxaTabModule() {
        }
AxaTabModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaTabModule });
AxaTabModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaTabModule_Factory(t) { return new (t || AxaTabModule)(); }, imports: [[common.CommonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaTabModule, { declarations: [AxaTab, AxaTabItem, AxaTabHeader], imports: [ɵngcc2.CommonModule], exports: [AxaTab, AxaTabItem] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaTabModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule],
                exports: [AxaTab, AxaTabItem],
                declarations: [AxaTab, AxaTabItem, AxaTabHeader]
            }]
    }], function () { return []; }, null); })();
        return AxaTabModule;
    }());

    /**Accordion control to display collapsible steps. */
    var AxaAccordion = /** @class */ (function (_super) {
        __extends(AxaAccordion, _super);
        function AxaAccordion() {
            var _this = _super.apply(this, __spread(arguments)) || this;
            /**Current display mode, defaults to default. */
            _this.displayMode = 'default';
            return _this;
        }
AxaAccordion.ɵfac = function AxaAccordion_Factory(t) { return new (t || AxaAccordion)(); };
AxaAccordion.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaAccordion, selectors: [["axa-accordion"]], hostAttrs: [1, "axa-accordion"], inputs: { displayMode: "displayMode" }, features: [ɵngcc0.ɵɵInheritDefinitionFeature] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAccordion, [{
        type: i0.Directive,
        args: [{
                selector: 'axa-accordion',
                host: {
                    class: 'axa-accordion'
                }
            }]
    }], function () { return []; }, { displayMode: [{
            type: i0.Input
        }] }); })();
        return AxaAccordion;
    }(accordion.CdkAccordion));
    AxaAccordion.propDecorators = {
        displayMode: [{ type: i0.Input }]
    };

    /** Time and timing curve for expansion panel animations. */
    var EXPANSION_PANEL_ANIMATION_TIMING = '225ms cubic-bezier(0.4,0.0,0.2,1)';
    /** Animations for the expansion panel. */
    var axaExpansionAnimations = {
        /** Animation that expands and collapses the panel content. */
        bodyExpansion: animations.trigger('bodyExpansion', [
            animations.state('collapsed', animations.style({ height: '0px', visibility: 'hidden' })),
            animations.state('expanded', animations.style({ height: '*', visibility: 'visible' })),
            animations.transition('expanded <=> collapsed', animations.animate(EXPANSION_PANEL_ANIMATION_TIMING)),
        ])
    };
    /** Counter for generating unique element ids. */
    var uniqueId = 0;
    var ɵ0 = undefined;
    /**Expansion panel found inside the axa accordion. */
    var AxaExpansionPanel = /** @class */ (function (_super) {
        __extends(AxaExpansionPanel, _super);
        /**
         *Creates an instance of AxaExpansionPanel.
         * @param accordion parent accordion.
         * @param cdr ChangeDetectorRef.
         * @param uniqueSelectionDispatcher selection dispatcher to sync panels.
         */
        function AxaExpansionPanel(accordion, cdr, uniqueSelectionDispatcher) {
            var _this = _super.call(this, accordion, cdr, uniqueSelectionDispatcher) || this;
            /** ID for the associated header element. Used for a11y labelling. */
            _this.headerId = "axa-expansion-panel-header-" + uniqueId++;
            _this.accordion = accordion;
            return _this;
        }
        /** Gets the expanded state string. */
        AxaExpansionPanel.prototype.getExpandedState = function () {
            return this.expanded ? 'expanded' : 'collapsed';
        };
        /** Determines whether the expansion panel should have spacing between it and its siblings. */
        AxaExpansionPanel.prototype.hasSpacing = function () {
            if (this.accordion) {
                return (this.expanded ? this.accordion.displayMode : this.getExpandedState()) === 'default';
            }
            return false;
        };
        /** Handles animation events */
        AxaExpansionPanel.prototype.bodyAnimation = function (event) {
            var classList = event.element.classList;
            var cssClass = 'axa-expanded';
            var phaseName = event.phaseName, toState = event.toState;
            if (phaseName === 'done' && toState === 'expanded') {
                classList.add(cssClass);
            }
            else if (phaseName === 'start' && toState === 'collapsed') {
                classList.remove(cssClass);
            }
        };
AxaExpansionPanel.ɵfac = function AxaExpansionPanel_Factory(t) { return new (t || AxaExpansionPanel)(ɵngcc0.ɵɵdirectiveInject(AxaAccordion, 12), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef), ɵngcc0.ɵɵdirectiveInject(ɵngcc4.UniqueSelectionDispatcher)); };
AxaExpansionPanel.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaExpansionPanel, selectors: [["axa-expansion-panel"]], hostAttrs: [1, "axa-expansion-panel"], hostVars: 4, hostBindings: function AxaExpansionPanel_HostBindings(rf, ctx) { if (rf & 2) {
        ɵngcc0.ɵɵclassProp("axa-expanded", ctx.expanded)("axa-expansion-panel-spacing", ctx.hasSpacing());
    } }, inputs: { disabled: "disabled", expanded: "expanded" }, outputs: { opened: "opened", closed: "closed", expandedChange: "expandedChange" }, exportAs: ["axaExpansionPanel"], features: [ɵngcc0.ɵɵProvidersFeature([
            { provide: AxaAccordion, useValue: ɵ0 },
        ]), ɵngcc0.ɵɵInheritDefinitionFeature], ngContentSelectors: _c16, decls: 4, vars: 2, consts: [["role", "region", 1, "axa-expansion-panel-content"], [1, "axa-expansion-panel-body"]], template: function AxaExpansionPanel_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef(_c15);
        ɵngcc0.ɵɵprojection(0);
        ɵngcc0.ɵɵelementStart(1, "div", 0);
        ɵngcc0.ɵɵlistener("@bodyExpansion.done", function AxaExpansionPanel_Template_div_animation_bodyExpansion_done_1_listener($event) { return ctx.bodyAnimation($event); })("@bodyExpansion.start", function AxaExpansionPanel_Template_div_animation_bodyExpansion_start_1_listener($event) { return ctx.bodyAnimation($event); });
        ɵngcc0.ɵɵelementStart(2, "div", 1);
        ɵngcc0.ɵɵprojection(3, 1);
        ɵngcc0.ɵɵelementEnd();
        ɵngcc0.ɵɵelementEnd();
    } if (rf & 2) {
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("@bodyExpansion", ctx.getExpandedState());
        ɵngcc0.ɵɵattribute("aria-labelledby", ctx.headerId);
    } }, encapsulation: 2, data: { animation: [axaExpansionAnimations.bodyExpansion] } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaExpansionPanel, [{
        type: i0.Component,
        args: [{
                selector: 'axa-expansion-panel',
                template: "<ng-content select=\"axa-expansion-panel-header\"></ng-content>\r\n<div class=\"axa-expansion-panel-content\" [@bodyExpansion]=\"getExpandedState()\"\r\n     (@bodyExpansion.done)=\"bodyAnimation($event)\" (@bodyExpansion.start)=\"bodyAnimation($event)\" role=\"region\"\r\n     [attr.aria-labelledby]=\"headerId\">\r\n  <div class=\"axa-expansion-panel-body\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n</div>\r\n",
                exportAs: 'axaExpansionPanel',
                encapsulation: i0.ViewEncapsulation.None,
                providers: [
                    { provide: AxaAccordion, useValue: ɵ0 },
                ],
                animations: [axaExpansionAnimations.bodyExpansion],
                inputs: ['disabled', 'expanded'],
                outputs: ['opened', 'closed', 'expandedChange'],
                host: {
                    'class': 'axa-expansion-panel',
                    '[class.axa-expanded]': 'expanded',
                    '[class.axa-expansion-panel-spacing]': 'hasSpacing()'
                }
            }]
    }], function () { return [{ type: AxaAccordion, decorators: [{
                type: i0.Optional
            }, {
                type: i0.SkipSelf
            }] }, { type: ɵngcc0.ChangeDetectorRef }, { type: ɵngcc4.UniqueSelectionDispatcher }]; }, null); })();
        return AxaExpansionPanel;
    }(accordion.CdkAccordionItem));
    AxaExpansionPanel.ctorParameters = function () { return [
        { type: AxaAccordion, decorators: [{ type: i0.Optional }, { type: i0.SkipSelf }] },
        { type: i0.ChangeDetectorRef },
        { type: collections.UniqueSelectionDispatcher }
    ]; };

    /**Header of the panel ment for the accordion. */
    var AxaExpansionPanelHeader = /** @class */ (function () {
        /**
         *Creates an instance of AxaExpansionPanelHeader.
         * @param panel parent expansion panel.
         */
        function AxaExpansionPanelHeader(panel) {
            this.panel = panel;
        }
        /** Gets the panel id. */
        AxaExpansionPanelHeader.prototype.getPanelId = function () {
            return this.panel.id;
        };
        /** Gets whether the panel is expanded. */
        AxaExpansionPanelHeader.prototype.isExpanded = function () {
            return this.panel.expanded;
        };
        /** Toggles the expanded state of the panel. */
        AxaExpansionPanelHeader.prototype.toggle = function () {
            this.panel.toggle();
        };
AxaExpansionPanelHeader.ɵfac = function AxaExpansionPanelHeader_Factory(t) { return new (t || AxaExpansionPanelHeader)(ɵngcc0.ɵɵdirectiveInject(AxaExpansionPanel, 1)); };
AxaExpansionPanelHeader.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: AxaExpansionPanelHeader, selectors: [["axa-expansion-panel-header"]], hostAttrs: ["role", "button", 1, "axa-expansion-panel-header"], hostVars: 5, hostBindings: function AxaExpansionPanelHeader_HostBindings(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵlistener("click", function AxaExpansionPanelHeader_click_HostBindingHandler() { return ctx.toggle(); });
    } if (rf & 2) {
        ɵngcc0.ɵɵattribute("id", ctx.panel.headerId)("tabindex", ctx.panel.disabled ? 0 - 1 : 0)("aria-controls", ctx.getPanelId())("aria-expanded", ctx.isExpanded())("aria-disabled", ctx.panel.disabled);
    } }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function AxaExpansionPanelHeader_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵprojectionDef();
        ɵngcc0.ɵɵprojection(0);
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaExpansionPanelHeader, [{
        type: i0.Component,
        args: [{
                template: "<ng-content></ng-content>\r\n",
                selector: 'axa-expansion-panel-header',
                encapsulation: i0.ViewEncapsulation.None,
                host: {
                    'class': 'axa-expansion-panel-header',
                    '(click)': 'toggle()',
                    'role': 'button',
                    '[attr.id]': 'panel.headerId',
                    '[attr.tabindex]': 'panel.disabled ? -1 : 0',
                    '[attr.aria-controls]': 'getPanelId()',
                    '[attr.aria-expanded]': 'isExpanded()',
                    '[attr.aria-disabled]': 'panel.disabled'
                }
            }]
    }], function () { return [{ type: AxaExpansionPanel, decorators: [{
                type: i0.Host
            }] }]; }, null); })();
        return AxaExpansionPanelHeader;
    }());
    AxaExpansionPanelHeader.ctorParameters = function () { return [
        { type: AxaExpansionPanel, decorators: [{ type: i0.Host }] }
    ]; };

    var AxaExpansionModule = /** @class */ (function () {
        function AxaExpansionModule() {
        }
AxaExpansionModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaExpansionModule });
AxaExpansionModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaExpansionModule_Factory(t) { return new (t || AxaExpansionModule)(); }, imports: [[common.CommonModule, accordion.CdkAccordionModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaExpansionModule, { declarations: [AxaAccordion, AxaExpansionPanel, AxaExpansionPanelHeader], imports: [ɵngcc2.CommonModule, ɵngcc5.CdkAccordionModule], exports: [AxaAccordion, AxaExpansionPanel, AxaExpansionPanelHeader] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaExpansionModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule, accordion.CdkAccordionModule],
                exports: [AxaAccordion, AxaExpansionPanel, AxaExpansionPanelHeader],
                declarations: [AxaAccordion, AxaExpansionPanel, AxaExpansionPanelHeader]
            }]
    }], function () { return []; }, null); })();
        return AxaExpansionModule;
    }());

    /**Class representing the config.base.json. */
    var EnvSpecific = /** @class */ (function () {
        function EnvSpecific() {
        }
        return EnvSpecific;
    }());

    /**The configuration injectable class. */
    var AxaAppConfig = /** @class */ (function () {
        /**
         *Creates an instance of AxaAppConfig.
         */
        function AxaAppConfig() {
            /**Contains the environment from config.base.config. */
            this.base = new EnvSpecific();
        }
        /**Loads the configuration. */
        AxaAppConfig.prototype.load = function () {
            return __awaiter(this, void 0, void 0, function () {
                var baseFile, baseResponse, _a, env, envFile, envResponse, _b, e_1;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            _c.trys.push([0, 5, , 6]);
                            baseFile = "assets/config/config.base.json";
                            return [4 /*yield*/, fetch(baseFile, { credentials: 'include' })];
                        case 1:
                            baseResponse = _c.sent();
                            _a = this;
                            return [4 /*yield*/, baseResponse.json()];
                        case 2:
                            _a.base = _c.sent();
                            if (this.base.environment.includes('#{token')) {
                                this.base.environment = 'dev';
                            }
                            env = this.base.environment.toLowerCase();
                            envFile = "assets/config/config." + env + ".json";
                            return [4 /*yield*/, fetch(envFile, { credentials: 'include' })];
                        case 3:
                            envResponse = _c.sent();
                            _b = this;
                            return [4 /*yield*/, envResponse.json()];
                        case 4:
                            _b.settings = (_c.sent());
                            return [3 /*break*/, 6];
                        case 5:
                            e_1 = _c.sent();
                            console.error('Configuration file could not be loaded', e_1);
                            return [3 /*break*/, 6];
                        case 6: return [2 /*return*/];
                    }
                });
            });
        };
AxaAppConfig.ɵfac = function AxaAppConfig_Factory(t) { return new (t || AxaAppConfig)(); };
AxaAppConfig.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaAppConfig, factory: function (t) { return AxaAppConfig.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAppConfig, [{
        type: i0.Injectable
    }], function () { return []; }, null); })();
        return AxaAppConfig;
    }());
    AxaAppConfig.ctorParameters = function () { return []; };
    /**Factory function to load the configuration. */
    function initializeAxaConfig(appConfig) {
        return function () { return appConfig.load(); };
    }

    var AxaConfigModule = /** @class */ (function () {
        function AxaConfigModule() {
        }
        AxaConfigModule.forRoot = function () {
            return {
                ngModule: AxaConfigModule,
                providers: [AxaAppConfig]
            };
        };
AxaConfigModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaConfigModule });
AxaConfigModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaConfigModule_Factory(t) { return new (t || AxaConfigModule)(); }, imports: [[common.CommonModule, http.HttpClientModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaConfigModule, { imports: [ɵngcc2.CommonModule, ɵngcc6.HttpClientModule] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaConfigModule, [{
        type: i0.NgModule,
        args: [{
                imports: [common.CommonModule, http.HttpClientModule]
            }]
    }], function () { return []; }, null); })();
        return AxaConfigModule;
    }());

    /**Key for the error close button string. */
    var AXA_ERROR_CLOSE_STRING = 'AXA_ERROR_CLOSE_STRING';
    /**Key for the error title string. */
    var AXA_ERROR_TITLE_STRING = 'AXA_ERROR_TITLE_STRING';

    /**
     * Implementation of a global error handler.
     * The axa implementation pushes alerts to {AxaAlertService}.
     */
    var AxaGlobalErrorHandler = /** @class */ (function (_super) {
        __extends(AxaGlobalErrorHandler, _super);
        /**
         * Creates an instance of AxaGlobalErrorHandler.
         */
        function AxaGlobalErrorHandler(injector) {
            var _this = _super.call(this) || this;
            _this.injector = injector;
            return _this;
        }
        /**
         * Handles an uncaught error in the appliation.
         */
        AxaGlobalErrorHandler.prototype.handleError = function (error) {
            var closeString = this.injector.get(AXA_ERROR_CLOSE_STRING, null);
            var titleString = this.injector.get(AXA_ERROR_TITLE_STRING, null);
            console.error(titleString || 'DEFAULT GLOBAL ERROR HANDLER', error);
            var alertService = this.injector.get(AxaAlertService, null);
            if (alertService) {
                var alertCloseAction = {
                    content: closeString || 'Close',
                    handler: function (action, parent) {
                        alertService.removeAlert(parent);
                    }
                };
                var alert = {
                    message: error.message,
                    type: 'warning',
                    ttl: 0,
                    action: alertCloseAction
                };
                alertService.addAlert(alert);
            }
        };
AxaGlobalErrorHandler.ɵfac = function AxaGlobalErrorHandler_Factory(t) { return new (t || AxaGlobalErrorHandler)(ɵngcc0.ɵɵinject(ɵngcc0.Injector)); };
AxaGlobalErrorHandler.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaGlobalErrorHandler, factory: function (t) { return AxaGlobalErrorHandler.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaGlobalErrorHandler, [{
        type: i0.Injectable
    }], function () { return [{ type: ɵngcc0.Injector }]; }, null); })();
        return AxaGlobalErrorHandler;
    }(i0.ErrorHandler));
    AxaGlobalErrorHandler.ctorParameters = function () { return [
        { type: i0.Injector }
    ]; };

    var AxaErrorHandlingModule = /** @class */ (function () {
        function AxaErrorHandlingModule() {
        }
        AxaErrorHandlingModule.forRoot = function () {
            return {
                ngModule: AxaErrorHandlingModule,
                providers: [AxaGlobalErrorHandler]
            };
        };
AxaErrorHandlingModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaErrorHandlingModule });
AxaErrorHandlingModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaErrorHandlingModule_Factory(t) { return new (t || AxaErrorHandlingModule)(); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaErrorHandlingModule, [{
        type: i0.NgModule,
        args: [{}]
    }], function () { return []; }, null); })();
        return AxaErrorHandlingModule;
    }());

    /**Key for the auth endpoint. */
    var AXA_OAUTH_ENDPOINT_KEY = 'OAUTH2_AUTHENTICATION_ENDPOINT';
    /**Key for the scope. */
    var AXA_OAUTH_SCOPE_KEY = 'OAUTH2_SCOPE';
    /**Key for the client id. */
    var AXA_OAUTH_CLIENTID_KEY = 'OAUTH2_CLIENT_ID';
    /**Key for the callback URL. */
    var AXA_OAUTH_CALLBACK_KEY = 'OAUTH2_CALLBACK_URL';
    /**Key for the token. */
    var AXA_OAUTH_TOKEN_KEY = 'OAUTH2_TOKEN_STORAGE_KEY';
    /**Key for the response type. Set to token by default. */
    var AXA_OAUTH_RESPONSE_TYPE = 'OAUTH2_RESPONSE_TYPE';
    /**Key for the redirect URI.  */
    var AXA_OAUTH_REDIRECT_URI = 'redirect_uri';
    /**Error for missing token key. */
    var AXA_TOKEN_KEY_MISSING_ERROR = new Error('OAUTH2_TOKEN_STORAGE_KEY should be provided in the root module. ' +
        'It is the key to be used for the storage of the token in the sessionStorage.');
    /**Error for missing endpoint. */
    var AXA_ENDPOINT_MISSING_ERROR = new Error('OAUTH2_AUTHENTICATION_ENDPOINT should be provided in the root module. ' +
        'It is the url of the popup to the Authentication Server');
    /**Error for missing client id. */
    var AXA_CLIENTID_MISSING_ERROR = new Error('OAUTH2_CLIENT_ID should be provided in the root module. ' +
        'It is the registered ID of the application in the Authentication Server');
    /**Error for missing scope. */
    var AXA_SCOPE_MISSING_ERROR = new Error('OAUTH2_SCOPE should be provided in the root module. ' +
        'It is the scope of the application.');
    /**Error for failed retrieval of the token. */
    var AXA_TOKEN_RETRIEVE_FAILED_ERROR = new Error('Unable to retrieve access token from request');

    /**
     * Service to do oauth authentification with the MAAM.
     * @export
     */
    var AxaOAuthService = /** @class */ (function () {
        /**
         * Creates an instance of AxaOAuthService.
         * @param authenticationUrl The auth URL (AXA_OAUTH_ENDPOINT_KEY).
         * @param scope The scope (AXA_OAUTH_SCOPE_KEY).
         * @param clientId The client id (AXA_OAUTH_CLIENTID_KEY).
         * @param callbackUrl The callback URL (AXA_OAUTH_CALLBACK_KEY).
         * @param tokenStorageKey The token key in the storage (AXA_OAUTH_TOKEN_KEY).
         */
        function AxaOAuthService(authenticationUrl, scope, clientId, callbackUrl, tokenStorageKey, responseType, router) {
            var _this = this;
            this.authenticationUrl = authenticationUrl;
            this.scope = scope;
            this.clientId = clientId;
            this.callbackUrl = callbackUrl;
            this.tokenStorageKey = tokenStorageKey;
            this.responseType = responseType;
            this.token = new rxjs.BehaviorSubject(null);
            this.currentUrl = '';
            this.authenticating = false;
            router.events.subscribe(function (r) {
                _this.currentUrl = r.url;
            });
            if (!authenticationUrl) {
                throw AXA_ENDPOINT_MISSING_ERROR;
            }
            if (!scope) {
                throw AXA_SCOPE_MISSING_ERROR;
            }
            if (!clientId) {
                throw AXA_CLIENTID_MISSING_ERROR;
            }
            if (!tokenStorageKey) {
                throw AXA_TOKEN_KEY_MISSING_ERROR;
            }
            if (!this.responseType) {
                this.responseType = 'token';
            }
            var token = sessionStorage.getItem(tokenStorageKey);
            if (token) {
                this.token.next(token);
            }
        }
        /**
         * Gets a stream of the current token.
         */
        AxaOAuthService.prototype.getToken = function () {
            var token = sessionStorage.getItem(this.tokenStorageKey);
            if (token) {
                this.token.next(token);
            }
            return this.token;
        };
        /**
         * Gets the token if it's there or authenticates and then returns the token.
         */
        AxaOAuthService.prototype.getTokenOrAuthenticate = function () {
            var token = sessionStorage.getItem(this.tokenStorageKey);
            if (token) {
                this.token.next(token);
            }
            if (!this.token.getValue() && !this.authenticating) {
                this.authenticate();
            }
            return this.token;
        };
        /**
         * Requires a new token from the MAAM.
         */
        AxaOAuthService.prototype.authenticate = function () {
            // console.log('response type: ' + this.responseType);
            this.authenticating = true;
            this.saveDataForAutenticationCallback({
                redirect_uri: this.currentUrl
            });
            var url = this.authenticationUrl + '?' +
                'client_id=' + this.clientId + '&' +
                'redirect_uri=' + encodeURI(window.location.origin + this.callbackUrl) + '&' +
                'response_type=' + this.responseType + '&' +
                'scope=' + this.scope;
            window.open(url, '_self');
            return this.token;
        };
        AxaOAuthService.prototype.saveDataForAutenticationCallback = function (data) {
            Object.keys(data).forEach(function (key) {
                if (data[key]) {
                    sessionStorage.setItem(key, data[key]);
                }
            });
        };
        /**
         * Removes the token from sessionstorage, this is not a disconnect function.
         */
        AxaOAuthService.prototype.forgetToken = function () {
            sessionStorage.removeItem(this.tokenStorageKey);
            this.token.next(null);
        };
AxaOAuthService.ɵfac = function AxaOAuthService_Factory(t) { return new (t || AxaOAuthService)(ɵngcc0.ɵɵinject(AXA_OAUTH_ENDPOINT_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_SCOPE_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_CLIENTID_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_CALLBACK_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_TOKEN_KEY, 8), ɵngcc0.ɵɵinject(AXA_OAUTH_RESPONSE_TYPE, 8), ɵngcc0.ɵɵinject(ɵngcc3.Router)); };
AxaOAuthService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaOAuthService, factory: function (t) { return AxaOAuthService.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaOAuthService, [{
        type: i0.Injectable
    }], function () { return [{ type: String, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Inject,
                args: [AXA_OAUTH_ENDPOINT_KEY]
            }] }, { type: String, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Inject,
                args: [AXA_OAUTH_SCOPE_KEY]
            }] }, { type: String, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Inject,
                args: [AXA_OAUTH_CLIENTID_KEY]
            }] }, { type: String, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Inject,
                args: [AXA_OAUTH_CALLBACK_KEY]
            }] }, { type: String, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Inject,
                args: [AXA_OAUTH_TOKEN_KEY]
            }] }, { type: String, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Inject,
                args: [AXA_OAUTH_RESPONSE_TYPE]
            }] }, { type: ɵngcc3.Router }]; }, null); })();
        return AxaOAuthService;
    }());
    AxaOAuthService.ctorParameters = function () { return [
        { type: String, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [AXA_OAUTH_ENDPOINT_KEY,] }] },
        { type: String, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [AXA_OAUTH_SCOPE_KEY,] }] },
        { type: String, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [AXA_OAUTH_CLIENTID_KEY,] }] },
        { type: String, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [AXA_OAUTH_CALLBACK_KEY,] }] },
        { type: String, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [AXA_OAUTH_TOKEN_KEY,] }] },
        { type: String, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [AXA_OAUTH_RESPONSE_TYPE,] }] },
        { type: router.Router }
    ]; };

    /**
     * This directive takes care of parsing the token and redirecting to the AXA_OAUTH_REDIRECT_URI.
     * @export
     */
    var AxaOAuthCallbackComponent = /** @class */ (function () {
        /**
         * Creates an instance of AxaOAuthCallbackComponent.
         * @param route
         * The route used to parse the fragment of the url.
         * @param router
         * The router used for the redirection.
         * @param tokenStorageKey
         * The key where the token needs to be stored.
         */
        function AxaOAuthCallbackComponent(route, router, tokenStorageKey) {
            this.route = route;
            this.router = router;
            this.tokenStorageKey = tokenStorageKey;
            var dict = {};
            this.route.fragment.subscribe(function (fragment) {
                if (fragment) {
                    fragment.split('&').forEach(function (item) {
                        var parts = item.split('=');
                        dict[parts[0]] = parts[1];
                    });
                }
                if (dict && dict.access_token != null) {
                    if (!tokenStorageKey) {
                        throw AXA_TOKEN_KEY_MISSING_ERROR;
                    }
                    sessionStorage.setItem(tokenStorageKey, dict.access_token);
                }
                else {
                    throw AXA_TOKEN_RETRIEVE_FAILED_ERROR;
                }
                var redirectUri = sessionStorage.getItem(AXA_OAUTH_REDIRECT_URI);
                router.navigateByUrl(redirectUri);
            });
        }
AxaOAuthCallbackComponent.ɵfac = function AxaOAuthCallbackComponent_Factory(t) { return new (t || AxaOAuthCallbackComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc3.ActivatedRoute), ɵngcc0.ɵɵdirectiveInject(ɵngcc3.Router), ɵngcc0.ɵɵdirectiveInject(AXA_OAUTH_TOKEN_KEY, 8)); };
AxaOAuthCallbackComponent.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: AxaOAuthCallbackComponent, selectors: [["axa-oauth-callback"]] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaOAuthCallbackComponent, [{
        type: i0.Directive,
        args: [{
                selector: 'axa-oauth-callback'
            }]
    }], function () { return [{ type: ɵngcc3.ActivatedRoute }, { type: ɵngcc3.Router }, { type: String, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Inject,
                args: [AXA_OAUTH_TOKEN_KEY]
            }] }]; }, null); })();
        return AxaOAuthCallbackComponent;
    }());
    AxaOAuthCallbackComponent.ctorParameters = function () { return [
        { type: router.ActivatedRoute },
        { type: router.Router },
        { type: String, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [AXA_OAUTH_TOKEN_KEY,] }] }
    ]; };

    var AxaOAuthModule = /** @class */ (function () {
        function AxaOAuthModule() {
        }
        AxaOAuthModule.forRoot = function () {
            return {
                ngModule: AxaOAuthModule,
                providers: [AxaOAuthService]
            };
        };
AxaOAuthModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaOAuthModule });
AxaOAuthModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaOAuthModule_Factory(t) { return new (t || AxaOAuthModule)(); }, imports: [[router.RouterModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(AxaOAuthModule, { declarations: [AxaOAuthCallbackComponent], imports: [ɵngcc3.RouterModule], exports: [AxaOAuthCallbackComponent] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaOAuthModule, [{
        type: i0.NgModule,
        args: [{
                imports: [router.RouterModule],
                exports: [AxaOAuthCallbackComponent],
                declarations: [AxaOAuthCallbackComponent]
            }]
    }], function () { return []; }, null); })();
        return AxaOAuthModule;
    }());

    /** Service to provide access to google analytics. */
    var AxaGoogleAnalyticsService = /** @class */ (function () {
        /**
         *Creates an instance of AxaGoogleAnalyticsService.
         * @param router The router to report page views.
         */
        function AxaGoogleAnalyticsService(router) {
            this.router = router;
        }
        /** Will start tracking page views and reporting them to google analytics.
         * Only needs to be called once in the boostrap component for example (app.component.ts)
         */
        AxaGoogleAnalyticsService.prototype.trackPageViews = function () {
            if (typeof ga === 'function') {
                this.router.events.pipe(operators.filter(function (e) { return e instanceof router.NavigationEnd; }), operators.map(function (e) {
                    ga('set', 'page', e.urlAfterRedirects);
                    ga('send', 'pageview');
                })).subscribe();
            }
        };
        /** Emits a custom event to google analytics. */
        AxaGoogleAnalyticsService.prototype.emitEvent = function (eventCategory, eventAction, eventLabel, eventValue) {
            if (eventLabel === void 0) { eventLabel = null; }
            if (eventValue === void 0) { eventValue = null; }
            if (typeof ga === 'function') {
                ga('send', 'event', { eventCategory: eventCategory, eventLabel: eventLabel, eventAction: eventAction, eventValue: eventValue });
            }
        };
AxaGoogleAnalyticsService.ɵfac = function AxaGoogleAnalyticsService_Factory(t) { return new (t || AxaGoogleAnalyticsService)(ɵngcc0.ɵɵinject(ɵngcc3.Router)); };
AxaGoogleAnalyticsService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaGoogleAnalyticsService, factory: function (t) { return AxaGoogleAnalyticsService.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaGoogleAnalyticsService, [{
        type: i0.Injectable
    }], function () { return [{ type: ɵngcc3.Router }]; }, null); })();
        return AxaGoogleAnalyticsService;
    }());
    AxaGoogleAnalyticsService.ctorParameters = function () { return [
        { type: router.Router }
    ]; };

    var AXA_GA_SETTINGS_TOKEN = new i0.InjectionToken('axa-ga-settings', {
        factory: function () { return ({ trackingCode: '' }); }
    });
    var AXA_GA_INIT_PROVIDER = {
        provide: i0.APP_INITIALIZER,
        multi: true,
        useFactory: GoogleAnalyticsInitializer,
        deps: [
            AXA_GA_SETTINGS_TOKEN
        ]
    };
    function GoogleAnalyticsInitializer(settings) {
        var _this = this;
        return function () { return __awaiter(_this, void 0, void 0, function () {
            var initialCommands, _a, _b, command, s, head;
            var e_1, _c;
            return __generator(this, function (_d) {
                if (i0.isDevMode()) {
                    return [2 /*return*/];
                }
                if (!settings.trackingCode) {
                    console.error('Empty tracking code for Google Analytics. Make sure to provide one when initializing google analytics.');
                    return [2 /*return*/];
                }
                // Set default ga.js uri
                settings.uri = settings.uri || "https://www.googletagmanager.com/gtag/js?id=" + settings.trackingCode;
                initialCommands = [
                    { command: 'js', values: [new Date()] },
                    { command: 'config', values: [settings.trackingCode] }
                ];
                settings.initCommands = __spread(initialCommands, (settings.initCommands || []));
                window['dataLayer'] = window['dataLayer'] || [];
                window['gtag'] = window['gtag'] || function () {
                    window['dataLayer'].push(arguments);
                };
                try {
                    for (_a = __values(settings.initCommands), _b = _a.next(); !_b.done; _b = _a.next()) {
                        command = _b.value;
                        window['gtag'].apply(window, __spread([command.command], command.values));
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                s = document.createElement('script');
                s.async = true;
                s.src = settings.uri;
                head = document.getElementsByTagName('head')[0];
                head.appendChild(s);
                return [2 /*return*/];
            });
        }); };
    }

    var AxaAnalyticsModule = /** @class */ (function () {
        function AxaAnalyticsModule() {
        }
        AxaAnalyticsModule.forRoot = function (gaCode, commands, uri) {
            if (commands === void 0) { commands = []; }
            return {
                ngModule: AxaAnalyticsModule,
                providers: [
                    AxaGoogleAnalyticsService,
                    {
                        provide: AXA_GA_SETTINGS_TOKEN,
                        useValue: {
                            trackingCode: gaCode,
                            commands: commands,
                            uri: uri
                        }
                    },
                    AXA_GA_INIT_PROVIDER
                ]
            };
        };
AxaAnalyticsModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaAnalyticsModule });
AxaAnalyticsModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaAnalyticsModule_Factory(t) { return new (t || AxaAnalyticsModule)(); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaAnalyticsModule, [{
        type: i0.NgModule,
        args: [{}]
    }], function () { return []; }, null); })();
        return AxaAnalyticsModule;
    }());

    var PDFService = /** @class */ (function () {
        function PDFService() {
        }
        PDFService.prototype.generateLandscape = function (content, fileName, format, heightPage, widthPage) {
            var _this = this;
            if (format === void 0) { format = 'a4'; }
            if (heightPage === void 0) { heightPage = 800; }
            if (widthPage === void 0) { widthPage = 1750; }
            html2canvas(content).then(function (canvas) {
                var pdf = new jspdf.jsPDF('l', 'pt', format);
                _this.generatePDF(content, fileName, heightPage, canvas, widthPage, pdf);
            });
        };
        PDFService.prototype.generatePortrait = function (content, fileName, format, heightPage, widthPage) {
            var _this = this;
            if (format === void 0) { format = 'a4'; }
            if (heightPage === void 0) { heightPage = 1100; }
            if (widthPage === void 0) { widthPage = 1300; }
            html2canvas(content).then(function (canvas) {
                var pdf = new jspdf.jsPDF('p', 'pt', format);
                _this.generatePDF(content, fileName, heightPage, canvas, widthPage, pdf);
            });
        };
        PDFService.prototype.generatePDF = function (content, fileName, heightPage, canvas, widthPage, pdf) {
            for (var index = 0, len = content.clientHeight / heightPage; index <= len; index++) {
                var _a = this.getCanvas({ index: index, canvas: canvas, heightPage: heightPage, widthPage: widthPage }), url = _a.url, width = _a.width, height = _a.height;
                // If we're on anything other than the first page, add another page
                if (index > 0) {
                    pdf.addPage();
                }
                pdf.setPage(index + 1);
                pdf.addImage(url, 'PNG', 20, 40, (width * 0.62), (height * 0.62));
            }
            pdf.save(fileName + ".pdf");
        };
        PDFService.prototype.getCanvas = function (_a) {
            var index = _a.index, canvas = _a.canvas, heightPage = _a.heightPage, widthPage = _a.widthPage;
            var srcImg = canvas;
            var sX = 0;
            var sY = heightPage * index;
            var sWidth = 1575;
            var sHeight = heightPage;
            var dX = 0;
            var dY = 0;
            var dWidth = widthPage;
            var dHeight = heightPage;
            var onePageCanvas = document.createElement('canvas');
            onePageCanvas.setAttribute('width', '' + widthPage);
            onePageCanvas.setAttribute('height', '' + heightPage);
            var ctx = onePageCanvas.getContext('2d');
            // Details on this usage of this function:
            // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Using_images#Slicing
            ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);
            var url = onePageCanvas.toDataURL('image/png', 1.0);
            var width = onePageCanvas.width;
            var height = onePageCanvas.clientHeight;
            return { url: url, width: width, height: height };
        };
PDFService.ɵfac = function PDFService_Factory(t) { return new (t || PDFService)(); };
PDFService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: PDFService, factory: function (t) { return PDFService.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(PDFService, [{
        type: i0.Injectable
    }], function () { return []; }, null); })();
        return PDFService;
    }());

    var PDFModule = /** @class */ (function () {
        function PDFModule() {
        }
PDFModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: PDFModule });
PDFModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function PDFModule_Factory(t) { return new (t || PDFModule)(); }, providers: [PDFService] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(PDFModule, [{
        type: i0.NgModule,
        args: [{
                providers: [PDFService]
            }]
    }], function () { return []; }, null); })();
        return PDFModule;
    }());

    var GTM_ID = 'GTM_ID';

    // Based on lib https://github.com/mzuccaroli/angular-google-tag-manager
    var AxaGtmService = /** @class */ (function () {
        function AxaGtmService(gtmId) {
            this.gtmId = gtmId;
            this.isLoaded = false;
            this.browserGlobals = {
                windowRef: function () {
                    return window;
                },
                documentRef: function () {
                    return document;
                }
            };
        }
        AxaGtmService.prototype.init = function () {
            if (this.isLoaded) {
                return;
            }
            var doc = this.browserGlobals.documentRef();
            this.pushOnDataLayer({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var gtmScript = doc.createElement('script');
            gtmScript.id = 'GTMscript';
            gtmScript.async = true;
            gtmScript.src = this.appendId('//www.googletagmanager.com/gtm.js');
            doc.head.insertBefore(gtmScript, doc.head.firstChild);
            var ifrm = doc.createElement('iframe');
            ifrm.setAttribute('src', this.appendId('//www.googletagmanager.com/ns.html'));
            ifrm.style.width = '0';
            ifrm.style.height = '0';
            ifrm.style.display = 'none';
            ifrm.style.visibility = 'hidden';
            var noscript = doc.createElement('noscript');
            noscript.id = 'GTMiframe';
            noscript.appendChild(ifrm);
            doc.body.insertBefore(noscript, doc.body.firstChild);
            this.isLoaded = true;
        };
        AxaGtmService.prototype.pushTag = function (item) {
            if (!this.isLoaded) {
                this.init();
            }
            this.pushOnDataLayer(item);
        };
        AxaGtmService.prototype.appendId = function (url) {
            return url + "?id=" + this.gtmId;
        };
        AxaGtmService.prototype.getDataLayer = function () {
            var window = this.browserGlobals.windowRef();
            window['dataLayer'] = window['dataLayer'] || [];
            return window['dataLayer'];
        };
        AxaGtmService.prototype.pushOnDataLayer = function (obj) {
            var dataLayer = this.getDataLayer();
            dataLayer.push(obj);
        };
AxaGtmService.ɵfac = function AxaGtmService_Factory(t) { return new (t || AxaGtmService)(ɵngcc0.ɵɵinject(GTM_ID, 8)); };
AxaGtmService.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: AxaGtmService, factory: function (t) { return AxaGtmService.ɵfac(t); } });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaGtmService, [{
        type: i0.Injectable
    }], function () { return [{ type: String, decorators: [{
                type: i0.Optional
            }, {
                type: i0.Inject,
                args: [GTM_ID]
            }] }]; }, null); })();
        return AxaGtmService;
    }());
    AxaGtmService.ctorParameters = function () { return [
        { type: String, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [GTM_ID,] }] }
    ]; };

    var AxaGtmModule = /** @class */ (function () {
        function AxaGtmModule() {
        }
AxaGtmModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: AxaGtmModule });
AxaGtmModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function AxaGtmModule_Factory(t) { return new (t || AxaGtmModule)(); }, providers: [AxaGtmService] });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(AxaGtmModule, [{
        type: i0.NgModule,
        args: [{
                providers: [AxaGtmService]
            }]
    }], function () { return []; }, null); })();
        return AxaGtmModule;
    }());

    /**Public API Surface of ng-toolkit */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR = AXA_CHECKBOX_CONTROL_VALUE_ACCESSOR;
    exports.AXA_CLIENTID_MISSING_ERROR = AXA_CLIENTID_MISSING_ERROR;
    exports.AXA_DATECOMBOPICKER_CONTROL_VALUE_ACCESSOR = AXA_DATECOMBOPICKER_CONTROL_VALUE_ACCESSOR;
    exports.AXA_ENDPOINT_MISSING_ERROR = AXA_ENDPOINT_MISSING_ERROR;
    exports.AXA_ERROR_CLOSE_STRING = AXA_ERROR_CLOSE_STRING;
    exports.AXA_ERROR_TITLE_STRING = AXA_ERROR_TITLE_STRING;
    exports.AXA_OAUTH_CALLBACK_KEY = AXA_OAUTH_CALLBACK_KEY;
    exports.AXA_OAUTH_CLIENTID_KEY = AXA_OAUTH_CLIENTID_KEY;
    exports.AXA_OAUTH_ENDPOINT_KEY = AXA_OAUTH_ENDPOINT_KEY;
    exports.AXA_OAUTH_REDIRECT_URI = AXA_OAUTH_REDIRECT_URI;
    exports.AXA_OAUTH_RESPONSE_TYPE = AXA_OAUTH_RESPONSE_TYPE;
    exports.AXA_OAUTH_SCOPE_KEY = AXA_OAUTH_SCOPE_KEY;
    exports.AXA_OAUTH_TOKEN_KEY = AXA_OAUTH_TOKEN_KEY;
    exports.AXA_PHONE_INPUT_CONTROL_VALUE_ACCESSOR = AXA_PHONE_INPUT_CONTROL_VALUE_ACCESSOR;
    exports.AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR = AXA_RADIO_GROUP_CONTROL_VALUE_ACCESSOR;
    exports.AXA_SCOPE_MISSING_ERROR = AXA_SCOPE_MISSING_ERROR;
    exports.AXA_TOKEN_KEY_MISSING_ERROR = AXA_TOKEN_KEY_MISSING_ERROR;
    exports.AXA_TOKEN_RETRIEVE_FAILED_ERROR = AXA_TOKEN_RETRIEVE_FAILED_ERROR;
    exports.AxaAccordion = AxaAccordion;
    exports.AxaAlertManager = AxaAlertManager;
    exports.AxaAlertModule = AxaAlertModule;
    exports.AxaAlertService = AxaAlertService;
    exports.AxaAnalyticsModule = AxaAnalyticsModule;
    exports.AxaAppConfig = AxaAppConfig;
    exports.AxaBusyComponent = AxaBusyComponent;
    exports.AxaBusyContainerDirective = AxaBusyContainerDirective;
    exports.AxaBusyContainerFullScreenDirective = AxaBusyContainerFullScreenDirective;
    exports.AxaBusyDirective = AxaBusyDirective;
    exports.AxaBusyModule = AxaBusyModule;
    exports.AxaBusyRawComponent = AxaBusyRawComponent;
    exports.AxaBusyRawDirective = AxaBusyRawDirective;
    exports.AxaButton = AxaButton;
    exports.AxaButtonModule = AxaButtonModule;
    exports.AxaCardComponent = AxaCardComponent;
    exports.AxaCardContentDirective = AxaCardContentDirective;
    exports.AxaCardModule = AxaCardModule;
    exports.AxaCardTitleDirective = AxaCardTitleDirective;
    exports.AxaCheckbox = AxaCheckbox;
    exports.AxaCheckboxChange = AxaCheckboxChange;
    exports.AxaCheckboxModule = AxaCheckboxModule;
    exports.AxaConfigModule = AxaConfigModule;
    exports.AxaCookieMessage = AxaCookieMessage;
    exports.AxaCookieMessageModule = AxaCookieMessageModule;
    exports.AxaDateComboBase = AxaDateComboBase;
    exports.AxaDateComboPicker = AxaDateComboPicker;
    exports.AxaDateComboPickerModule = AxaDateComboPickerModule;
    exports.AxaError = AxaError;
    exports.AxaErrorHandlingModule = AxaErrorHandlingModule;
    exports.AxaExpansionModule = AxaExpansionModule;
    exports.AxaExpansionPanel = AxaExpansionPanel;
    exports.AxaExpansionPanelHeader = AxaExpansionPanelHeader;
    exports.AxaFlagIcon = AxaFlagIcon;
    exports.AxaFlagIconModule = AxaFlagIconModule;
    exports.AxaFooterComponent = AxaFooterComponent;
    exports.AxaFooterLanguage = AxaFooterLanguage;
    exports.AxaFooterListComponent = AxaFooterListComponent;
    exports.AxaFooterModule = AxaFooterModule;
    exports.AxaFooterSocialComponent = AxaFooterSocialComponent;
    exports.AxaFormField = AxaFormField;
    exports.AxaFormFieldModule = AxaFormFieldModule;
    exports.AxaGlobalErrorHandler = AxaGlobalErrorHandler;
    exports.AxaGoogleAnalyticsService = AxaGoogleAnalyticsService;
    exports.AxaGtmModule = AxaGtmModule;
    exports.AxaGtmService = AxaGtmService;
    exports.AxaHeaderComponent = AxaHeaderComponent;
    exports.AxaHeaderMetaDomainDirective = AxaHeaderMetaDomainDirective;
    exports.AxaHeaderMetaHelperDirective = AxaHeaderMetaHelperDirective;
    exports.AxaHeaderModule = AxaHeaderModule;
    exports.AxaHeaderNavComponent = AxaHeaderNavComponent;
    exports.AxaHeaderSearchComponent = AxaHeaderSearchComponent;
    exports.AxaHint = AxaHint;
    exports.AxaIconModule = AxaIconModule;
    exports.AxaInput = AxaInput;
    exports.AxaInputBase = AxaInputBase;
    exports.AxaInputModule = AxaInputModule;
    exports.AxaLink = AxaLink;
    exports.AxaLinkModule = AxaLinkModule;
    exports.AxaNumbersOnlyDirective = AxaNumbersOnlyDirective;
    exports.AxaOAuthCallbackComponent = AxaOAuthCallbackComponent;
    exports.AxaOAuthModule = AxaOAuthModule;
    exports.AxaOAuthService = AxaOAuthService;
    exports.AxaPhoneInputBase = AxaPhoneInputBase;
    exports.AxaPhoneInputComponent = AxaPhoneInputComponent;
    exports.AxaPhoneInputModule = AxaPhoneInputModule;
    exports.AxaPrefixDirective = AxaPrefixDirective;
    exports.AxaRadioButton = AxaRadioButton;
    exports.AxaRadioButtonModule = AxaRadioButtonModule;
    exports.AxaRadioChange = AxaRadioChange;
    exports.AxaRadioGroup = AxaRadioGroup;
    exports.AxaRadioImage = AxaRadioImage;
    exports.AxaSelect = AxaSelect;
    exports.AxaSelectBase = AxaSelectBase;
    exports.AxaSelectModule = AxaSelectModule;
    exports.AxaStepComponent = AxaStepComponent;
    exports.AxaStepperComponent = AxaStepperComponent;
    exports.AxaStepperModule = AxaStepperModule;
    exports.AxaSuffixDirective = AxaSuffixDirective;
    exports.AxaTab = AxaTab;
    exports.AxaTabItem = AxaTabItem;
    exports.AxaTabModule = AxaTabModule;
    exports.AxaTable = AxaTable;
    exports.AxaTableModule = AxaTableModule;
    exports.AxaTableOfContentsComponent = AxaTableOfContentsComponent;
    exports.AxaTableOfContentsItemComponent = AxaTableOfContentsItemComponent;
    exports.AxaTableOfContentsModule = AxaTableOfContentsModule;
    exports.AxaTableOfContentsTitleComponent = AxaTableOfContentsTitleComponent;
    exports.AxaTopContentBarComponent = AxaTopContentBarComponent;
    exports.AxaTopContentBarModule = AxaTopContentBarModule;
    exports.COOKIE_STORAGE = COOKIE_STORAGE;
    exports.EXPANSION_PANEL_ANIMATION_TIMING = EXPANSION_PANEL_ANIMATION_TIMING;
    exports.GTM_ID = GTM_ID;
    exports.INPUT_STYLE = INPUT_STYLE;
    exports.IconComponent = IconComponent;
    exports.PDFModule = PDFModule;
    exports.PDFService = PDFService;
    exports.SELECT_STYLE = SELECT_STYLE;
    exports._AxaDateComboBase = _AxaDateComboBase;
    exports._AxaInputMixinBase = _AxaInputMixinBase;
    exports._AxaPhoneInputMixinBase = _AxaPhoneInputMixinBase;
    exports._AxaSelectMixinBase = _AxaSelectMixinBase;
    exports.axaExpansionAnimations = axaExpansionAnimations;
    exports.initializeAxaConfig = initializeAxaConfig;
    exports.mixinDisabled = mixinDisabled;
    exports.mixinErrorState = mixinErrorState;
    exports.mixinParentErrorState = mixinParentErrorState;
    exports.mixinTabIndex = mixinTabIndex;
    exports.ɵ0 = ɵ0;
    exports.ɵa = ErrorStateMatcher;
    exports.ɵb = AxaFormFieldControl;
    exports.ɵba = AXA_GA_INIT_PROVIDER;
    exports.ɵbb = GoogleAnalyticsInitializer;
    exports.ɵc = AxaCountryService;
    exports.ɵd = AxaBusyBackdropComponent;
    exports.ɵe = CLASS_BASE;
    exports.ɵf = CLASS_ACTIVE;
    exports.ɵg = CLASS_WIDE;
    exports.ɵh = CLASS_BLOCK;
    exports.ɵi = CLASS_TITLE;
    exports.ɵj = CLASS_INFO;
    exports.ɵk = CLASS_CONTENT;
    exports.ɵl = CLASS_BLOCK_COMPACT;
    exports.ɵm = AxaStepHeaderComponent;
    exports.ɵn = CLASS_STEP;
    exports.ɵo = CLASS_STEP_PRICING;
    exports.ɵp = CLASS_STEP_ACTIVE;
    exports.ɵq = CLASS_STEP_DONE;
    exports.ɵr = HEADER_CLASS_SEARCH;
    exports.ɵs = HEADER_CLASS_NAV_LINK;
    exports.ɵt = HEADER_CLASS_NAV_LINK_ACTIVE;
    exports.ɵu = HEADER_CLASS_NAV_LINK_BUTTON;
    exports.ɵv = UniqueSelectionDispatcher;
    exports.ɵw = UNIQUE_SELECTION_DISPATCHER_PROVIDER_FACTORY;
    exports.ɵx = UNIQUE_SELECTION_DISPATCHER_PROVIDER;
    exports.ɵy = AxaTabHeader;
    exports.ɵz = AXA_GA_SETTINGS_TOKEN;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=axa-ng-toolkit.umd.js.map