import { OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldComponent } from '../elib-field.component';
export declare class ElibFieldTextComponent extends ElibFieldComponent implements OnInit {
    readonly translateClient: TranslateService;
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
    initField(): void;
    handleKeyUp(e: KeyboardEvent): void;
}
