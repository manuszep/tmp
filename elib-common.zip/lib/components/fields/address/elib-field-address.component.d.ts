import { EventEmitter, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldConfig } from '../elib-field.model';
export interface ElibOutputType {
    nameOfFormControl: string;
    data: any;
}
export declare class ElibFieldAddressComponent implements OnInit {
    readonly translateClient: TranslateService;
    form: FormGroup;
    config: ElibFieldConfig;
    autocompleteDataForCity: string[];
    autocompleteDataForStreet: string[];
    changeEvent: EventEmitter<ElibOutputType>;
    keyUpEvent: EventEmitter<ElibOutputType>;
    blurEvent: EventEmitter<ElibOutputType>;
    clickEvent: EventEmitter<ElibOutputType>;
    selectionEvent: EventEmitter<ElibOutputType>;
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
    getZipConfig(): ElibFieldConfig;
    getCityConfig(): ElibFieldConfig;
    getStreetConfig(): ElibFieldConfig;
    getNumberConfig(): ElibFieldConfig;
    getBoxConfig(): ElibFieldConfig;
    handleBlur(nameOfFormControl: any, data: any): void;
    handleChange(nameOfFormControl: any, data: any): void;
    handleKeyUp(nameOfFormControl: any, data: any): void;
    handleClick(nameOfFormControl: any, data: any): void;
    handleSelectionEvent(data: any, nameOfFormControl: any): void;
}
