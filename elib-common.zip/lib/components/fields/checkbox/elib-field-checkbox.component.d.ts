import { OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldComponent } from '../elib-field.component';
export declare class ElibFieldCheckboxComponent extends ElibFieldComponent implements OnInit {
    readonly translateClient: TranslateService;
    private $isToggle;
    grow: string | boolean;
    set isToggle(value: boolean);
    get isToggle(): boolean;
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
}
