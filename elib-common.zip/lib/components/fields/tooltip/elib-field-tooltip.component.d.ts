export declare class ElibFieldTooltipComponent {
    toggled: boolean;
    content: string;
    constructor();
    handleBlur(): void;
    handleClick(e: MouseEvent): void;
}
