import { OnDestroy, EventEmitter, OnInit } from '@angular/core';
import { ValidatorFn, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldConfig } from './elib-field.model';
export declare class ElibFieldComponent implements OnDestroy, OnInit {
    readonly translateClient: TranslateService;
    form: FormGroup;
    config: ElibFieldConfig;
    changeEvent: EventEmitter<any>;
    keyUpEvent: EventEmitter<any>;
    blurEvent: EventEmitter<any>;
    clickEvent: EventEmitter<any>;
    placeholder: string;
    validatorsList: ValidatorFn[];
    regExToAccept: string;
    standardMandatory: boolean;
    constructor(translateClient: TranslateService);
    get showError(): boolean;
    getConfigValue(): any;
    getValue(): any;
    ngOnInit(): void;
    initField(): void;
    getErrorMessage(): string;
    handleChange(e: InputEvent): void;
    handleKeyUp(e: KeyboardEvent): void;
    handleBlur(e: FocusEvent): void;
    handleClick(e: MouseEvent): void;
    ngOnDestroy(): void;
}
