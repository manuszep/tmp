import { OnInit, SimpleChanges, OnChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldComponent } from '../elib-field.component';
import { ElibFieldOption } from '../elib-field.model';
export declare class ElibFieldDropdownComponent extends ElibFieldComponent implements OnInit, OnChanges {
    readonly translateClient: TranslateService;
    options: ElibFieldOption[];
    listOfOptions: ElibFieldOption[];
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    handleChange(e: InputEvent): void;
}
