import { OnChanges, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { ElibFieldComponent } from '../elib-field.component';
export declare class ElibFieldStreetAutocompleteComponent extends ElibFieldComponent implements OnInit, OnChanges {
    readonly translateClient: TranslateService;
    autocompleteDataForStreet: string[];
    streets: string[];
    filteredStreets: Observable<string[]>;
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
    initField(): void;
    handleKeyUp(e: KeyboardEvent): void;
    ngOnChanges(changes: any): void;
    private _filter;
    private _normalizeValue;
    extractStreet(val: any): any;
}
