export declare class ElibFieldWrapperComponent {
    class: string;
    prefix: string;
    suffix: string;
    error: string;
    hint: string;
    help: string;
    constructor();
    getClass(): string;
}
