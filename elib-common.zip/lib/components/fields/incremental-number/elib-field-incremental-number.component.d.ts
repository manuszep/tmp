import { OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldComponent } from '../elib-field.component';
export declare class ElibFieldIncrementalNumberComponent extends ElibFieldComponent implements OnInit {
    readonly translateClient: TranslateService;
    min: number | null;
    max: number | null;
    errorMessageParameters: {
        [key: string]: string;
    };
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
    initField(): void;
    increaseDisabled(): boolean;
    increase(): void;
    decreaseDisabled(): boolean;
    decrease(): void;
    numberOnly(event: any): boolean;
}
