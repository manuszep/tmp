import { OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldComponent } from '../elib-field.component';
export declare class ElibFieldNumberComponent extends ElibFieldComponent implements OnInit {
    readonly translateClient: TranslateService;
    min: number | null;
    errorMessageParameters: {
        [key: string]: string;
    };
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
    initField(): void;
    handleKeyUp(e: KeyboardEvent): void;
}
