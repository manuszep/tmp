import { OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldComponent } from '../elib-field.component';
export declare class ElibFieldPhoneComponent extends ElibFieldComponent implements OnInit {
    readonly translateClient: TranslateService;
    errorMessageParameters: {
        [key: string]: string;
    };
    default: string;
    standardMandatory: boolean;
    constructor(translateClient: TranslateService);
    getConfigValue(): any;
    ngOnInit(): void;
    initField(): void;
}
