import { OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldComponent } from '../elib-field.component';
import { ElibFieldOption } from '../elib-field.model';
export declare class ElibFieldRadioComponent extends ElibFieldComponent implements OnInit {
    readonly translateClient: TranslateService;
    options: ElibFieldOption[];
    radioStyle: string;
    grow: string | boolean;
    style: string;
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
    initField(): void;
    getClassName(): string;
}
