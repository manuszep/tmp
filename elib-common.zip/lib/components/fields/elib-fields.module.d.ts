export declare class ElibFieldsModule {
}
