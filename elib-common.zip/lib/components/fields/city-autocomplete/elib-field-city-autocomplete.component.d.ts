import { EventEmitter, OnChanges, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibFieldComponent } from '../elib-field.component';
import { Observable } from 'rxjs';
export declare class ElibFieldCityAutocompleteComponent extends ElibFieldComponent implements OnInit, OnChanges {
    readonly translateClient: TranslateService;
    autocompleteDataForCity: string[];
    selectionEvent: EventEmitter<string>;
    streets: string[];
    filteredStreets: Observable<string[]>;
    constructor(translateClient: TranslateService);
    ngOnInit(): void;
    initField(): void;
    handleKeyUp(e: KeyboardEvent): void;
    ngOnChanges(changes: any): void;
    private _filter;
    private _normalizeValue;
    extractStreet(val: any): any;
    extractZIP(val: any): any;
    handleSelection(rawCity: string): void;
}
