import { ValidatorFn } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
export declare enum ElibFieldTypes {
    checkbox = "checkbox",
    currency = "currency",
    date = "date",
    dropdown = "dropdown",
    mail = "mail",
    numberInteger = "integer",
    numberPositiveInteger = "positiveInteger",
    numberFloat = "float",
    numberPositiveFloat = "positiveFloat",
    percentage = "percentage",
    radio = "radio",
    postalAddress = "postalAddress",
    text = "text",
    textWithoutNumbers = "textWithoutNumbers",
    phone = "phone",
    mobile = "mobile"
}
interface ElibFieldConfigParams {
    name: string;
    type: ElibFieldTypes;
    mandatory?: boolean;
    placeholder?: string;
    label?: string;
    value?: any;
    additionalValidators?: ValidatorFn[];
    disabled?: boolean;
    maxlength?: any;
    help?: string;
    prefix?: string;
    suffix?: string;
    hint?: string;
    labelTranslationParam?: any;
}
export interface ElibFieldOption {
    label: string;
    value: string;
    help?: string;
    icon?: string;
    priceType?: string;
    secondaryLabel?: string;
    reductionPercent?: string;
    price?: number;
    labelTranslationParam?: any;
}
export declare class ElibFieldConfig {
    name: string;
    type: ElibFieldTypes;
    $mandatory: boolean;
    placeholder?: string;
    label?: string;
    value?: any;
    additionalValidators?: ValidatorFn[];
    disabled?: boolean;
    maxlength?: any;
    help?: string;
    prefix?: string;
    suffix?: string;
    hint?: string;
    labelTranslationParam?: any;
    configChange$: BehaviorSubject<boolean>;
    constructor(params: ElibFieldConfigParams);
    set mandatory(value: boolean);
    get mandatory(): boolean;
}
export {};
