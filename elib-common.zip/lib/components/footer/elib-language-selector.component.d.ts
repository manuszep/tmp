import { OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ElibSharedService } from '../../services/elib-shared.service';
export declare class ElibLanguageSelectorComponent implements OnInit {
    private fb;
    private translateService;
    private readonly sharedService;
    languageSelectorForm: FormGroup;
    defaultLanguage: string;
    languages: {
        id: string;
        name: string;
    }[];
    constructor(fb: FormBuilder, translateService: TranslateService, sharedService: ElibSharedService);
    ngOnInit(): void;
    onChange($event: any): void;
    private setCookie;
    private deleteCookie;
    getParamValue(param: any): RegExpMatchArray;
}
