import { OnInit, ElementRef } from '@angular/core';
import { AxaAppConfig } from '@axa/ng-toolkit';
import { TranslateService } from '@ngx-translate/core';
import { ElibAppConfig } from '../app-wrapper/elib-app-config';
export declare class ElibFooterComponent implements OnInit {
    private translateService;
    private readonly config;
    private eRef;
    precontract_url: string;
    toggled: boolean;
    clickout(event: any): void;
    constructor(translateService: TranslateService, config: AxaAppConfig<ElibAppConfig>, eRef: ElementRef);
    ngOnInit(): void;
    changeLang(userLanguage: any): void;
    year(): number;
    handleToggleClick(): void;
}
