export declare class ElibFooterModule {
}
