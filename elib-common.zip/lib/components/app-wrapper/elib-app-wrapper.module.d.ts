import { ModuleWithProviders } from '@angular/core';
import { ElibSharedConfig } from '../../services/elib-shared.config.token';
export declare class ElibAppWrapperModule {
    static forRoot(config: ElibSharedConfig): ModuleWithProviders<ElibAppWrapperModule>;
}
