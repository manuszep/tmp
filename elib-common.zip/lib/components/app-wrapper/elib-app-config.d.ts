export interface ElibAppConfig {
    test?: string;
    name?: string;
    SELLING_API_URL?: string;
    selligent_url?: string;
    environment?: string;
    ingenico_url?: string;
    ingenico_pspid?: string;
    dlt_url?: string;
    maps_key?: string;
    value_proposition?: string;
    commercial_offer?: string;
    nhf_flow?: string;
    gtm_id?: string;
    smartlook_id?: string;
    precontractFR_url: string;
    precontractNL_url: string;
}
