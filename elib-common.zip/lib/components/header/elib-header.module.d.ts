export declare class ElibHeaderModule {
}
