import { ElementRef, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ElibModalService } from '../modal/elib-modal.service';
export declare class ElibHeaderHelpComponent implements OnInit {
    private readonly modalService;
    private readonly translateClient;
    private readonly sanitizer;
    helpLinkLabel: string;
    showPhoneIcon: string;
    modal: ElementRef;
    phoneUrl: string;
    whatsappUrl: string;
    constructor(modalService: ElibModalService, translateClient: TranslateService, sanitizer: DomSanitizer);
    ngOnInit(): void;
    showHelpPopUp(): void;
    setPhoneUrl(lang: string): void;
    getMinutes(s: string): number;
    checkAvailableTime(): void;
}
