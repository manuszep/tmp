import { OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibModalService } from '../modal/elib-modal.service';
export declare class ElibHeaderComponent implements OnInit {
    private readonly modalService;
    private readonly translateClient;
    showHelp: boolean;
    showSave: boolean;
    showBanner: boolean;
    constructor(modalService: ElibModalService, translateClient: TranslateService);
    ngOnInit(): void;
}
