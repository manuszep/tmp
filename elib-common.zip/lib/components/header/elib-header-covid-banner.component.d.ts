import { OnInit } from '@angular/core';
export declare class ElibHeaderCovidBannerComponent implements OnInit {
    constructor();
    ngOnInit(): void;
}
