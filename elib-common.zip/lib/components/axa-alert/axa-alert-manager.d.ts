import { OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { AxaAlertService } from './axa-alert.service';
import { AxaAlert } from './axa-alert';
/**
 * Implement AXAAlertManager since importing it from ng-toolkit causes issues
 */
export declare class AxaAlertManager implements OnInit, OnDestroy {
    private alertSvc;
    private cdr;
    private removeAlertSub;
    private newAlertSub;
    /** List of alerts received from the alert service. */
    alerts: AxaAlert[];
    /**
     * Creates an instance of AxaAlertManager.
     */
    constructor(alertSvc: AxaAlertService, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
}
