import { AxaAlert } from './axa-alert';
import { Observable } from 'rxjs';
/**
 * Service used to communicate with the alert manager.
 * @export
 */
export declare class AxaAlertService {
    private newAlerts;
    private removedAlerts;
    /**
     * Add an alert.
     */
    addAlert(alert: AxaAlert): void;
    /**
     * Remove an alert.
     */
    removeAlert(alert: AxaAlert): void;
    /**
     * Gets the stream of added alerts.
     */
    getNewAlerts(): Observable<AxaAlert>;
    /**
     * Gets the stream of removed alerts.
     */
    getRemovedAlerts(): Observable<AxaAlert>;
}
