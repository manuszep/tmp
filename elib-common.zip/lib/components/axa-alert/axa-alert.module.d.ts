import { ModuleWithProviders } from '@angular/core';
export declare class AxaAlertModule {
    static forRoot(): ModuleWithProviders<AxaAlertModule>;
}
