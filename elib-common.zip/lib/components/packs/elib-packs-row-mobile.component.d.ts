import { EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibAccordionData } from '../accordion-block/elib-accordion-block.models';
import { ElibMobileTableDataRow } from './elib-packs.model';
export declare class ElibPacksRowMobileComponent {
    private readonly translateService;
    hasColumns: boolean;
    mobile: boolean;
    hideToggle: boolean;
    isHeader: boolean;
    data: ElibMobileTableDataRow;
    guid: string;
    rowId: number;
    selectPack: EventEmitter<string>;
    constructor(translateService: TranslateService);
    getId(): string;
    getJointLabel(prefix: string, suffix?: string): any;
    getLabel(): string;
    getIndicatorLabel(): string;
    getContent(): string;
    getAccordionData(): ElibAccordionData;
    hasContent(): boolean;
    shouldShowAccordion(): boolean;
    shouldShowLabel(): boolean;
    shouldShowAction(): boolean;
    handlePackSelect(e: string): void;
}
