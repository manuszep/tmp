import { ModuleWithProviders } from '@angular/core';
export declare class ElibPacksModule {
    static forRoot(): ModuleWithProviders<ElibPacksModule>;
    static forChild(): ModuleWithProviders<ElibPacksModule>;
}
