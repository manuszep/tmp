export interface ElibPacksColumnData {
    label?: string;
    content?: string;
    action?: string;
    packId?: string;
    icon?: string;
    price?: number;
    included?: 'YES' | 'NO' | 'OPTION';
}
export interface ElibPacksHeaderColumnData {
    icon?: string;
    price?: number;
    label: string;
}
export interface ElibPacksActionColumnData {
    action: string;
    packId: string;
}
export interface ElibPacksRowData {
    label?: string;
    content?: string;
    columns?: ElibPacksColumnData[] | ElibPacksHeaderColumnData[] | ElibPacksActionColumnData[];
}
export interface ElibPacksData extends Array<ElibPacksRowData> {
}
export interface ElibDesktopTableDataRowHeading {
    label: string;
    content?: string;
    section?: boolean;
}
export interface ElibDesktopTableDataRow {
    heading?: ElibDesktopTableDataRowHeading;
    columns?: ElibPacksColumnData[];
}
export interface ElibMobileTableDataRow {
    label?: string[];
    content?: string[];
    included?: 'YES' | 'NO' | 'OPTION';
    action?: string;
    packId?: string;
    icon?: string;
    price?: number;
    section?: boolean;
}
