import { TranslateService } from '@ngx-translate/core';
import { ElibDesktopTableDataRowHeading } from './elib-packs.model';
export declare class ElibPacksRowHeaderComponent {
    private readonly translateService;
    data: ElibDesktopTableDataRowHeading;
    guid: string;
    rowId: number;
    constructor(translateService: TranslateService);
    getId(): string;
    getColumnAccordionData(): {
        id: string;
        header: any;
        content: any;
        expanded: boolean;
        static: boolean;
    };
    getLabel(): any;
    hasLabel(): boolean;
    hasContent(): boolean;
    shouldShowAccordion(): boolean;
    shouldShowLabel(): boolean;
}
