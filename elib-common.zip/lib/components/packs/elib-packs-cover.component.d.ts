export declare class ElibPacksCoverComponent {
    data: {
        icon: string;
        label: string;
        price: number;
    };
    constructor();
    getIconSrc(): string;
}
