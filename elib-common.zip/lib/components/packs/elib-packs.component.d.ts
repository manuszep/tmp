import { EventEmitter } from '@angular/core';
import { ElibPacksData, ElibPacksRowData, ElibDesktopTableDataRow, ElibMobileTableDataRow } from './elib-packs.model';
export declare class ElibPacksComponent {
    desktopPacksDataHeader: ElibDesktopTableDataRow;
    desktopPacksData: ElibDesktopTableDataRow[];
    mobilePacksData: ElibMobileTableDataRow[][];
    guid: string;
    set packsData(value: ElibPacksData);
    selectPack: EventEmitter<string>;
    getJointLabel(prefix: string, suffix?: string): string;
    generateDesktopPacksData(data: ElibPacksData): void;
    generateDesktopPacksDataRow(data: ElibPacksRowData): ElibDesktopTableDataRow;
    generateMobilePacksData(data: ElibPacksData): void;
    generateMobilePacksDataRow(data: any, index: any): ElibMobileTableDataRow;
    handlePackSelect(e: string): void;
}
