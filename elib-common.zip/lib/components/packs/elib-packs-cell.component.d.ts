import { EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibAccordionData } from '../accordion-block/elib-accordion-block.models';
import { ElibPacksColumnData } from './elib-packs.model';
export declare class ElibPacksCellComponent {
    private readonly translateService;
    hasColumns: boolean;
    mobile: boolean;
    isHeader: boolean;
    data: ElibPacksColumnData;
    guid: string;
    rowId: number;
    set setHasColumns(attribute: boolean | '');
    set setMobile(attribute: boolean | '');
    set setIsHeader(attribute: boolean | '');
    selectPack: EventEmitter<string>;
    constructor(translateService: TranslateService);
    getId(): string;
    getColumnAccordionData(): ElibAccordionData;
    getLabel(): string;
    getIndicatorLabel(): string;
    hasLabel(): boolean;
    hasContent(): boolean;
    shouldShowAccordion(): boolean;
    shouldShowLabel(): boolean;
    shouldShowAction(): boolean;
    handlePackSelect(e: MouseEvent): any;
}
