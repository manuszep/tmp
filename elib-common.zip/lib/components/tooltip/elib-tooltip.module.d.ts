export declare class ElibTooltipModule {
}
