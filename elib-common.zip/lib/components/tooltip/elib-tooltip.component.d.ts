import { OnInit } from '@angular/core';
export declare class ElibTooltipComponent implements OnInit {
    toggled: boolean;
    content: string;
    constructor();
    ngOnInit(): void;
    handleBlur(): void;
    handleClick(e: MouseEvent): void;
    getClassName(): string;
}
