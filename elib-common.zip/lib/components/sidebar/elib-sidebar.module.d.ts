export declare class ElibSidebarModule {
}
