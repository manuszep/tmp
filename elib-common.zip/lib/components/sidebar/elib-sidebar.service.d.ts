import { Observable } from 'rxjs';
import { ElibSidebarData } from './elib-sidebar.model';
export declare class ElibSideBarService {
    private data;
    constructor();
    setData(data: ElibSidebarData): void;
    getData(): Observable<ElibSidebarData>;
}
