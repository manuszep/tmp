export interface ElibSidebarCoverData {
    name: string;
    price?: number;
    editId?: string;
    removeId?: string;
    highlight?: boolean;
}
export interface ElibSidebarOptionData {
    name: string;
    price?: number;
    editId?: string;
    removeId?: string;
}
export interface ElibSidebarData {
    packName: string;
    covers: ElibSidebarCoverData[];
    options?: ElibSidebarOptionData[];
}
