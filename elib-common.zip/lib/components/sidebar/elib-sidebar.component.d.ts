import { EventEmitter, OnInit, ElementRef, Renderer2, OnDestroy } from '@angular/core';
import { ElibSidebarCoverData, ElibSidebarOptionData } from './elib-sidebar.model';
import { ElibSideBarService } from './elib-sidebar.service';
export declare class ElibSidebarComponent implements OnInit, OnDestroy {
    private readonly service;
    private readonly eref;
    private readonly renderer;
    price: number;
    coversPrice: number;
    optionsPrice: number;
    covers: ElibSidebarCoverData[];
    options: ElibSidebarOptionData[];
    packName: string;
    toggled: boolean;
    editEvent: EventEmitter<string>;
    removeEvent: EventEmitter<string>;
    clickout(e: any): void;
    constructor(service: ElibSideBarService, eref: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnDestroy(): void;
    getPrice(): void;
    handleEdit(id: string): void;
    handleRemove(id: string): void;
    handleToggle(): void;
}
