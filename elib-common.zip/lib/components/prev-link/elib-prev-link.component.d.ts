import { Router } from '@angular/router';
export declare class ElibPrevLinkComponent {
    private readonly router;
    prevRoute: string;
    constructor(router: Router);
    handlePrevClick(): void;
}
