export declare class ElibPrevLinkModule {
}
