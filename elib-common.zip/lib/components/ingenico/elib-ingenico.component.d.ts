import { OnInit, ElementRef, ChangeDetectorRef } from '@angular/core';
import { Router, Params, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { ElibIngenicoParams } from './elib-ingenico.model';
import { ElibIngenicoService } from './elib-ingenico.service';
export declare class ElibIngenicoComponent implements OnInit {
    private readonly aRoute;
    private readonly router;
    private readonly service;
    private readonly cdRef;
    url: string;
    successRoute: string;
    successCallback: Promise<any>;
    createPaymentRequestMethod: (url: string) => Observable<any>;
    form: ElementRef;
    private readonly unsubscribe;
    params: ElibIngenicoParams;
    constructor(aRoute: ActivatedRoute, router: Router, service: ElibIngenicoService, cdRef: ChangeDetectorRef);
    ngOnInit(): void;
    canGoToThankyou(params: Params): boolean;
    constructIngenicoParameters(url: string): void;
    bindHiddenFields(objResponse: {
        parameters: Array<{
            key: string;
            value: string;
        }>;
    }): void;
    submit(): void;
    ngOnDestroy(): void;
}
