import { Observable } from 'rxjs';
export declare abstract class ElibIngenicoService {
    abstract createPaymentRequest(url: string): Observable<any>;
}
