import { Params } from '@angular/router';
export declare const elibIngenicoIsSuccess: (params: Params) => boolean;
