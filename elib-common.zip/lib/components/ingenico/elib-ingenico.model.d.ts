export interface ElibIngenicoParams {
    ACCEPTURL: string;
    BACKURL: string;
    CANCELURL: string;
    DECLINEURL: string;
    EXCEPTIONURL: string;
    AMOUNT: string;
    CN: string;
    EMAIL: string;
    LANGUAGE: string;
    ORDERID: string;
    OWNERADDRESS: string;
    OWNERTELNO: string;
    OWNERTOWN: string;
    OWNERZIP: string;
    PSPID: string;
    PARAMPLUS: string;
    SHASIGN: string;
}
