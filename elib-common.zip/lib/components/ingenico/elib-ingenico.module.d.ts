import { ModuleWithProviders, ExistingProvider } from '@angular/core';
export interface ElibIngenicoModuleConfig {
    IngenicoService: ExistingProvider;
}
export declare class ElibIngenicoModule {
    static forRoot(config: ElibIngenicoModuleConfig): ModuleWithProviders<ElibIngenicoModule>;
    static forChild(config: ElibIngenicoModuleConfig): ModuleWithProviders<ElibIngenicoModule>;
}
