import { OnInit, EventEmitter, ElementRef } from '@angular/core';
import { ElibCoverCard, ElibCoverSelectionEvent } from './elib-cover-cards.model';
import { ElibModalService } from '../modal/elib-modal.service';
export declare class ElibCoverCardComponent implements OnInit {
    private readonly modalService;
    data: ElibCoverCard;
    applied: boolean;
    selection: EventEmitter<ElibCoverSelectionEvent>;
    modal: ElementRef;
    constructor(modalService: ElibModalService);
    ngOnInit(): void;
    handleSelection(value: boolean, id: string): any;
    showDetails(): void;
}
