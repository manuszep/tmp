export declare class ElibCoverCardsModule {
}
