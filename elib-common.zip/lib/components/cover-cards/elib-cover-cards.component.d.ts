import { OnInit, EventEmitter } from '@angular/core';
import { ElibCoverCards, ElibCoverSelectionEvent } from './elib-cover-cards.model';
export declare class ElibCoverCardsComponent implements OnInit {
    data: ElibCoverCards;
    appliedOptions: Record<string, boolean>;
    selection: EventEmitter<ElibCoverSelectionEvent>;
    constructor();
    ngOnInit(): void;
    handleSelection(data: ElibCoverSelectionEvent): any;
}
