import { ElementRef, OnInit } from '@angular/core';
import { ElibModalService } from '../modal/elib-modal.service';
import { ElibCoverCard } from './elib-cover-cards.model';
export declare class ElibCoverCardVpBrokerComponent implements OnInit {
    private readonly modalService;
    data: ElibCoverCard;
    modal: ElementRef;
    constructor(modalService: ElibModalService);
    ngOnInit(): void;
    showDetails(): void;
    handleSelection(): void;
}
