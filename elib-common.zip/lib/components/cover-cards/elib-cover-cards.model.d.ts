export interface ElibCoverCard {
    id: string;
    active: boolean;
    icon: string;
    title: string;
    price: number;
    description: string;
    modalTitle?: string;
    modalHeading?: string;
    modalDescription?: string;
}
export interface ElibCoverCards {
    title: string;
    subTitle: string;
    covers: ElibCoverCard[];
}
export interface ElibCoverSelectionEvent {
    value: boolean;
    id: string;
}
export interface ElibCoverModal {
    icon: string;
    modalTitle?: string;
    modalHeading?: string;
    modalDescription?: string;
}
