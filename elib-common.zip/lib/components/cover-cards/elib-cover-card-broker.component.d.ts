import { OnInit, EventEmitter, ElementRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ElibModalService } from '../modal/elib-modal.service';
import { ElibCoverModal } from './elib-cover-cards.model';
export declare class ElibCoverCardBrokerComponent implements OnInit {
    private readonly modalService;
    data: string[];
    modalData: ElibCoverModal;
    form: FormGroup;
    preloadedData: any;
    handleLeadToBroker: EventEmitter<any>;
    modal: ElementRef;
    nhfOptions: any;
    disablePageNext: EventEmitter<boolean>;
    constructor(modalService: ElibModalService);
    ngOnInit(): void;
    handleSelection(): void;
    isNHF(): boolean;
    showDetails(): void;
}
