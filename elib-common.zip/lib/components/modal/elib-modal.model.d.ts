import { TemplateRef } from '@angular/core';
export interface ElibModalConfigType {
    title?: string;
    content?: string | TemplateRef<any>;
    secondaryActionLabel?: string;
    primaryActionLabel?: string;
    secondaryAction?: () => void;
    primaryAction?: () => void;
    disabledPrimaryAction?: boolean;
    template?: boolean;
    plainMode?: boolean;
}
