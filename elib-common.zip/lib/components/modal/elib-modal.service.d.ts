import { Observable, BehaviorSubject } from 'rxjs';
import { ElibModalConfigType } from './elib-modal.model';
export declare class ElibModalService {
    show: BehaviorSubject<boolean>;
    config: BehaviorSubject<ElibModalConfigType>;
    constructor();
    showModal(config: ElibModalConfigType): void;
    hideModal(): void;
    getModalStatus(): Observable<boolean>;
    getModalConfig(): Observable<ElibModalConfigType>;
    updateConf(config: ElibModalConfigType): void;
}
