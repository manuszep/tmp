export declare class ElibModalModule {
}
