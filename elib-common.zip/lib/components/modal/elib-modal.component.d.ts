import { OnInit, OnDestroy } from '@angular/core';
import { ElibModalConfigType } from './elib-modal.model';
import { ElibModalService } from './elib-modal.service';
import { Subscription } from 'rxjs';
export declare class ElibModalComponent implements OnInit, OnDestroy {
    private readonly service;
    statusSubscription: Subscription;
    configSubscription: Subscription;
    config: ElibModalConfigType;
    modalClass: boolean;
    show: boolean;
    showTemplate: boolean;
    constructor(service: ElibModalService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    executeSecondaryAction(): void;
    executePrimaryAction(): void;
    closeModal(): void;
    getPrimaryActionLabel(): string;
}
