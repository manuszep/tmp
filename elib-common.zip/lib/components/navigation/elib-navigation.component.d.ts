import { OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ElibSharedService, ElibChapter } from '../../services/elib-shared.service';
import { ElibRouteData } from '../../services/elib-shared.config.token';
export declare class ElibNavigationComponent implements OnInit {
    private readonly cdRef;
    private readonly sharedService;
    private readonly router;
    private readonly activatedRoute;
    chapters: ElibChapter[];
    currentRoute: ElibRouteData;
    selectedPage: number;
    selectedTotalSubSteps: number;
    constructor(cdRef: ChangeDetectorRef, sharedService: ElibSharedService, router: Router, activatedRoute: ActivatedRoute);
    ngOnInit(): void;
    getProgress(): number;
    isDisabled(chapterNumber: number): boolean;
}
