export declare class ElibNavigationModule {
}
