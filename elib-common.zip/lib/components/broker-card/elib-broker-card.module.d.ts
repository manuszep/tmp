export declare class ElibBrokerCardModule {
}
