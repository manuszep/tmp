import { OnInit } from '@angular/core';
export declare class ElibBrokerCardComponent implements OnInit {
    name: string;
    constructor();
    ngOnInit(): void;
}
