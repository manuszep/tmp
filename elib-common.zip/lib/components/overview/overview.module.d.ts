export declare class ElibOverviewModule {
}
