export declare class ElibOverviewGroupComponent {
    title: string;
    constructor();
}
