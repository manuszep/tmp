import { EventEmitter, OnInit, ElementRef } from '@angular/core';
export declare class ElibOverviewItemComponent implements OnInit {
    private el;
    $nonEditable: boolean;
    set nonEditable(value: any);
    get nonEditable(): any;
    editEvent: EventEmitter<void>;
    constructor(el: ElementRef);
    ngOnInit(): void;
    handleEditClick(): void;
}
