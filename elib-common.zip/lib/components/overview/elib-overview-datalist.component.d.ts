export declare class ElibOverviewDatalistComponent {
    title: string;
    constructor();
}
