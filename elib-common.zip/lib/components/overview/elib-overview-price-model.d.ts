export interface ElibOverviewPricePopUpLabels {
    linkLabel: string;
    titleLabel: string;
    contentLabel: string;
}
