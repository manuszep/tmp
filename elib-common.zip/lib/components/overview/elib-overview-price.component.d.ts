import { EventEmitter, OnInit } from '@angular/core';
import { ElibSideBarService } from '../sidebar/elib-sidebar.service';
import { ElibSidebarCoverData, ElibSidebarOptionData } from '../sidebar/elib-sidebar.model';
import { ElibModalService } from '../modal/elib-modal.service';
import { ElibOverviewPricePopUpLabels } from './elib-overview-price-model';
export declare class ElibOverviewPriceComponent implements OnInit {
    private readonly service;
    private readonly modalService;
    popupData: ElibOverviewPricePopUpLabels;
    set showPromo(value: any);
    get showPromo(): any;
    submitPromoEvent: EventEmitter<string>;
    editOptionsEvent: EventEmitter<void>;
    $showPromo: boolean;
    price: number;
    coversPrice: number;
    optionsPrice: number;
    covers: ElibSidebarCoverData[];
    options: ElibSidebarOptionData[];
    packName: string;
    constructor(service: ElibSideBarService, modalService: ElibModalService);
    ngOnInit(): void;
    getPrice(): void;
    handlePromoClick(value: any): void;
    handleEditOptions(): void;
    openMeerDetails(): void;
}
