export interface ElibAccordionData {
    id: string;
    header: string;
    content: string;
    expanded: boolean;
    static: boolean;
}
export interface ElibAccordionState {
    accordionID: string;
    state: boolean;
}
