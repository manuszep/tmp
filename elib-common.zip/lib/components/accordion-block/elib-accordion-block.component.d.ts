import { OnInit, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { Observable } from 'rxjs';
import { ElibAccordionData, ElibAccordionState } from './elib-accordion-block.models';
import { ElibAccordionBlockService } from './elib-accordion-block.service';
export declare class ElibAccordionBlockComponent implements OnInit, AfterViewChecked {
    private readonly service;
    private readonly cdRef;
    private $hideToggle;
    accordionData: ElibAccordionData;
    set hideToggle(value: boolean);
    get hideToggle(): boolean;
    accordionState: Observable<ElibAccordionState>;
    open: boolean;
    constructor(service: ElibAccordionBlockService, cdRef: ChangeDetectorRef);
    ngOnInit(): void;
    toggle(id: any, state: any): void;
    ngAfterViewChecked(): void;
}
