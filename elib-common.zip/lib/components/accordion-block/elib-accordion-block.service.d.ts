import { BehaviorSubject } from 'rxjs';
import { ElibAccordionState } from './elib-accordion-block.models';
export declare class ElibAccordionBlockService {
    accordionState: BehaviorSubject<ElibAccordionState>;
    constructor();
    setAccordionState(accordionID: string, state?: boolean): void;
    getAccordionState(): import("rxjs").Observable<ElibAccordionState>;
}
