export declare class ElibAccordionBlockModule {
}
