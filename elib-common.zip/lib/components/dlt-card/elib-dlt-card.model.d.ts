export interface ElibBrokerFieldDataModel {
    id: string;
    name: string;
    street: string;
    nr: string;
    zip: string;
    city: string;
    email: string;
    emailLead: string;
    phone: string;
    fax: string;
    website: string;
    cbfa: string;
    insuranceFederationCode: string;
    mainNetworkCode: string;
    producerNumber: string;
    hasBrocomLogo: boolean;
}
export interface DltMessage {
    ID: string;
    NAME: string;
    STREET: string;
    STREET_NUMBER: string;
    POSTAL_CODE: string;
    CITY: string;
    EMAIL: string;
    EMAIL_LEAD: string;
    FAX: string;
    TELEPHONE: string;
    WEBSITE: string;
    CBFA_NUMBER: string;
    INSURANCE_FEDERATION_CODE: string;
    MAIN_NETWORK_CODE: string;
    PRODUCER_NUMBER: string;
    HAS_BROCOM_LOGO: boolean;
}
export declare const findProducerNumber: (data: any) => string;
export declare const parseBrokerData: (data: any | DltMessage | ElibBrokerFieldDataModel) => ElibBrokerFieldDataModel;
export declare const mergeBrokerData: (apiData: ElibBrokerFieldDataModel, dltData: ElibBrokerFieldDataModel) => ElibBrokerFieldDataModel;
export interface ElibDltConfigDataModel {
    dlt_url: string;
    maps_key: string;
}
export interface ElibDltAddressDataModel {
    zip: string;
    city: string;
    street: string;
    number: string;
}
export interface ElibDltSharedStorageKeys {
    checkProspectResponse: string;
    preloadedData: string;
    Language: string;
}
export interface ElibDltPOSPayloadDataModel {
    language: string;
    reference_id: string;
    reference_type_code: string;
}
