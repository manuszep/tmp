import { ChangeDetectorRef, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ElibSharedService } from '../../services/elib-shared.service';
import { ElibModalService } from '../modal/elib-modal.service';
import { DltMessage, ElibBrokerFieldDataModel, ElibDltAddressDataModel, ElibDltConfigDataModel, ElibDltSharedStorageKeys } from './elib-dlt-card.model';
import { ElibDltCardService } from './elib-dlt-card.service';
declare global {
    interface Window {
        initMap: () => any;
    }
}
export declare class ElibBrokerSelectionCardComponent implements OnInit, OnDestroy {
    private readonly cdRef;
    private readonly sharedService;
    private readonly modalService;
    private readonly service;
    private readonly translateClient;
    choiceCallback: (posData: ElibBrokerFieldDataModel) => any;
    config: ElibDltConfigDataModel;
    InAddress: ElibDltAddressDataModel;
    storageKeys: ElibDltSharedStorageKeys;
    private readonly unsubscribe;
    lang: string;
    dltUrl: string;
    address: string;
    cityAddress: string;
    lng: string;
    lat: string;
    ready: boolean;
    zip: string;
    city: string;
    street: string;
    number: string;
    iframeURL: string;
    constructor(cdRef: ChangeDetectorRef, sharedService: ElibSharedService, modalService: ElibModalService, service: ElibDltCardService, translateClient: TranslateService);
    ngOnInit(): void;
    initMap(): void;
    getDltUrl(): string;
    handleGeocodingResults(results: any, status: any): void;
    handleDltMessage(e: MessageEvent): void;
    handleDltChoice(data: DltMessage): void;
    parsePointOfSale(dltData: ElibBrokerFieldDataModel, data: any): ElibBrokerFieldDataModel;
    handlePosSelectionError(): void;
    ngOnDestroy(): void;
}
