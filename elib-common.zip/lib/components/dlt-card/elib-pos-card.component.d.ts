import { OnInit } from '@angular/core';
import { ElibBrokerFieldDataModel } from './elib-dlt-card.model';
export declare class ElibPosCardComponent implements OnInit {
    parsedData: ElibBrokerFieldDataModel;
    set posData(data: any);
    get posData(): any;
    title: string;
    actionLabel: string;
    actionHandler: (posData: ElibBrokerFieldDataModel) => void;
    constructor();
    ngOnInit(): void;
    getAddress(): string;
    handleClick(e: any): void;
}
