import { Observable } from 'rxjs';
import { ElibDltPOSPayloadDataModel } from './elib-dlt-card.model';
export declare abstract class ElibDltCardService {
    abstract getPointOfSale(payload: ElibDltPOSPayloadDataModel): Observable<any>;
}
