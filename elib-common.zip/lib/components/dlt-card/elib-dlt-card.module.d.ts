import { ExistingProvider, ModuleWithProviders } from '@angular/core';
export interface ElibDltCardModuleConfig {
    DltCardService: ExistingProvider;
}
export declare class ElibDltCardModule {
    static forRoot(config: ElibDltCardModuleConfig): ModuleWithProviders<ElibDltCardModule>;
    static forChild(config: ElibDltCardModuleConfig): ModuleWithProviders<ElibDltCardModule>;
}
