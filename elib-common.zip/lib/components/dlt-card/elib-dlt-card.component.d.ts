import { AfterViewChecked, ChangeDetectorRef, EventEmitter, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ElibSharedService } from '../../services/elib-shared.service';
import { ElibBrokerFieldDataModel, ElibDltAddressDataModel, ElibDltConfigDataModel, ElibDltSharedStorageKeys } from './elib-dlt-card.model';
export declare class ElibDltCardComponent implements OnInit, AfterViewChecked {
    private readonly cdRef;
    private readonly sharedService;
    private readonly unsubscribe;
    config: ElibDltConfigDataModel;
    address: ElibDltAddressDataModel;
    form: FormGroup;
    storageKeys: ElibDltSharedStorageKeys;
    simulationNext: EventEmitter<any>;
    preloadedData: ElibBrokerFieldDataModel;
    prospectPos: ElibBrokerFieldDataModel[];
    constructor(cdRef: ChangeDetectorRef, sharedService: ElibSharedService);
    ngOnInit(): void;
    ngAfterViewChecked(): void;
    detectChanges(): void;
    hasSelectedBroker(): boolean;
    hasExistingBrokers(): boolean;
    hasExistingBroker(): boolean;
    savePosSelection(data: ElibBrokerFieldDataModel): void;
    removePosSelection(): void;
    handleGlobalNext(data: ElibBrokerFieldDataModel): void;
    clearExistingBrokers(): void;
    handleDltChoice(data: ElibBrokerFieldDataModel): void;
}
