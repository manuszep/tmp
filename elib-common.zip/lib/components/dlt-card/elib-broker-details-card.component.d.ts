import { EventEmitter, OnInit } from '@angular/core';
import { ElibBrokerFieldDataModel } from './elib-dlt-card.model';
export declare class ElibBrokerDetailsCardComponent implements OnInit {
    parsedData: ElibBrokerFieldDataModel;
    set posData(data: any);
    get posData(): any;
    title: string;
    editEvent: EventEmitter<any>;
    constructor();
    ngOnInit(): void;
    getAddress(): string;
    handleEditClick(): void;
}
