import { PipeTransform } from '@angular/core';
export declare const eLibAmountTransform: (value: string | number) => string;
export declare class ElibAmountPipe implements PipeTransform {
    transform(value: string | number): string;
}
