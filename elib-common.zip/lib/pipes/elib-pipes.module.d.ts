export declare class ElibPipesModule {
}
