import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ElibAlertService } from '../services/elib-alert.service';
import { ElibSharedService } from '../services/elib-shared.service';
export declare class ElibHTTPStatus {
    private readonly requestInFlight$;
    constructor();
    setHttpStatus(inFlight: boolean): void;
    getHttpStatus(): Observable<boolean>;
}
export declare class ElibHTTPListener implements HttpInterceptor {
    private readonly status;
    private readonly sharedService;
    private readonly alert;
    currentLanguage: string;
    requestPool: any[];
    intanceid: any;
    constructor(status: ElibHTTPStatus, sharedService: ElibSharedService, alert: ElibAlertService);
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    private errorHandler;
}
