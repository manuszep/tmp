export interface ElibPromoButtonInterface {
    link?: string;
    handleClick?: (e: Event) => any;
    label: string;
}
export interface ElibPromoInterface {
    image?: string;
    heading?: string;
    subheading?: string;
    button?: ElibPromoButtonInterface;
    notes?: string;
}
export interface ElibEkomiInterface {
    title: string;
    text: string;
}
