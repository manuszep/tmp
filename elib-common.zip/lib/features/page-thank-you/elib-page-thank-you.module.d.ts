export declare class ElibPageThankYouModule {
}
