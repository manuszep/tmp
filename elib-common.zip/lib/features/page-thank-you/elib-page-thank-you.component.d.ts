import { OnInit } from '@angular/core';
import { ElibEkomiInterface, ElibPromoInterface } from './elib-page-thank-you.model';
export declare class ElibPageThankYouComponent implements OnInit {
    promo: ElibPromoInterface;
    ekomiData: ElibEkomiInterface;
    constructor();
    ngOnInit(): void;
}
