import { MissingTranslationHandler, MissingTranslationHandlerParams } from '@ngx-translate/core';
export declare class ElibMissingTranslationHandler implements MissingTranslationHandler {
    handle(params: MissingTranslationHandlerParams): string;
}
