export declare const elibCompareObjects: (a: any, b: any) => boolean;
