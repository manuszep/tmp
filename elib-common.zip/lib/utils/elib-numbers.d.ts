/**
 * Converts a number (as string or number) to a fixed decimal with 2 places
 * @param value The number to be converted
 */
export declare const elibToFixed: (value: number | string) => string;
