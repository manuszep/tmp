export declare const elibPatternPhone: RegExp;
export declare const elibPatternPhoneMobile: RegExp;
export declare const elibPatternDate: RegExp;
export declare const elibPatternEmail: RegExp;
export declare const elibPatternTextWithoutNumbers: RegExp;
export declare const elibPatternPositiveInteger: RegExp;
export declare const elibPatternPositiveFloat: RegExp;
