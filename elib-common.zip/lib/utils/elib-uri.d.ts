export declare const elibGenerateUrlParam: (name: string, value: string | undefined) => string;
export declare const elibGenerateUrlKeyPair: (index: string, key: string, value: string | number) => string;
export declare const elibFormatDashedDate: (d: string) => string | undefined;
export declare const elibGetCurrentUrl: () => string;
