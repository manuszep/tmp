/// <reference types="@types/googlemaps" />
declare global {
    interface Window {
        initMap: () => any;
    }
}
export declare const elibLoadGoogleMapsJs: (key: string, init: () => any) => void;
export declare const elibGetLatLngFromAddress: (address: any, handleGeocodingResults: (results: google.maps.GeocoderResult[], status: google.maps.GeocoderStatus) => any) => void;
export declare const elibComposeGmapsAddress: (lang: string, street?: string, streetNumber?: string, zip?: string, city?: string) => string;
