import { Router, ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { ElibSharedConfig } from './elib-shared.config.token';
import { ElibStorageService } from './elib-storage.service';
export interface ElibServiceInterface {
    [key: string]: any;
}
export interface ElibFieldsData {
    Language?: string;
    instanceid?: string;
    scrComponents?: ElibServiceInterface;
}
export interface ElibChapter {
    name: string;
    number: number;
    subSteps: number;
}
export declare class ElibSharedService {
    private readonly storage;
    private readonly router;
    private readonly route;
    private readonly sharedConfig;
    routekey: string;
    dataSource: BehaviorSubject<ElibFieldsData>;
    scrComponents: ElibServiceInterface;
    chapters: ElibChapter[];
    constructor(storage: ElibStorageService, router: Router, route: ActivatedRoute, sharedConfig: ElibSharedConfig);
    initStorageData(chapters: any[]): void;
    getStoreData(): ElibFieldsData;
    setData(newData: any): void;
    getData(): any;
    getDataByAttribute(key: string): any;
    reset(): void;
    clearData(key?: string): any | undefined;
    getCurrentRouteData(): import("rxjs").Observable<import("@angular/router").Data>;
    ifAnyDataPresentExceptLanguageAndInstanceID(storedData: ElibFieldsData): boolean;
    private ifAnyDataPresentInStorage;
    handlePageRefresh(): void;
    clearSessionTempData(): void;
}
