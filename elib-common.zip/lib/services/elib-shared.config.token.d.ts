import { InjectionToken } from '@angular/core';
import { DataLayerEntryI } from './elib-datalayer.service';
export interface ElibProgressChapter {
    name: string;
    number: number;
    subSteps: number;
    styleName: string;
}
export interface ElibProgressChapters extends Record<string, ElibProgressChapter> {
}
export interface ElibRouteData {
    chapter: ElibProgressChapter;
    subStep: number;
    name: string;
}
export interface ElibSharedConfig {
    storeName: string;
    progressChapters: ElibProgressChapters;
    datalayerMapperMethod?: () => DataLayerEntryI;
}
export declare const ELIB_SHARED_CONFIG: InjectionToken<ElibSharedConfig>;
