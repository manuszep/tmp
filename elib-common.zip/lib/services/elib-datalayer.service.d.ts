import { ElibSharedConfig, ElibRouteData } from './elib-shared.config.token';
import { Router, ActivatedRoute } from '@angular/router';
import { ElibSharedService } from './elib-shared.service';
import { AxaAppConfig } from '@axa/ng-toolkit';
declare global {
    interface Window {
        dataLayer: DataLayerI;
    }
}
export interface DataLayerEntryI {
    [x: string]: any;
}
export interface DataLayerI extends Array<DataLayerEntryI> {
}
export interface DataLayerConfigI {
    name: string;
    environment: string;
    gtmId: string;
}
export declare class ElibDataLayerService {
    private readonly router;
    private readonly activatedRoute;
    private readonly sharedService;
    private readonly config;
    private readonly sharedConfig;
    private window;
    private document;
    private get dataLayer();
    private setDataLayer;
    private getAppData;
    constructor(router: Router, activatedRoute: ActivatedRoute, sharedService: ElibSharedService, config: AxaAppConfig<DataLayerConfigI>, sharedConfig: ElibSharedConfig);
    init(): void;
    handleNavigation(e: ElibRouteData): void;
    initFlowData(): void;
    initNavEvents(): void;
    private initGtmDom;
    private applyGtmQueryParams;
}
