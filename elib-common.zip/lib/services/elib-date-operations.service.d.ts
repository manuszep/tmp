export declare class ElibDateOperationsService {
    private readonly todayDate;
    constructor();
    get today(): Date;
    getAge(refDate: Date): number;
    getDateDifference(date1: Date, date2: Date): number;
    private isLeapyear;
    private noOfLeapYears;
}
