import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ElibSharedConfig } from './elib-shared.config.token';
export declare class ElibStorageService {
    readonly router: Router;
    private readonly http;
    readonly aroute: ActivatedRoute;
    private readonly sharedConfig;
    private storage;
    constructor(router: Router, http: HttpClient, aroute: ActivatedRoute, sharedConfig: ElibSharedConfig);
    getData(key: string): any;
    getStoreData(): any | undefined;
    setData(key: string, data: any): any | undefined;
    clearData(key: string): any | undefined;
    resetStore(): void;
    reset(): void;
    setSessionData(data: any): void;
    resetSessionData(): void;
    _setDataOnReload(): void;
    _getDataOnReload(): void;
    getJSON(url: string): import("rxjs").Observable<Object>;
}
