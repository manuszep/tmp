import { AxaAlertService } from '../components/axa-alert/axa-alert.service';
export declare class ElibAlertService {
    private readonly axaAlertSvc;
    private readonly alertList;
    constructor(axaAlertSvc: AxaAlertService);
    private open;
    cleanAlerts(): void;
    showError(message: string, ttl?: number): void;
    showAlert(message: string, ttl?: number): void;
    showInfo(message: string, ttl?: number): void;
}
