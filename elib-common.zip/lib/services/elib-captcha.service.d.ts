import { AxaAppConfig } from '@axa/ng-toolkit';
declare global {
    interface Window {
        grecaptcha: any;
    }
}
export interface CaptchaConfigI {
    recaptchaId: string;
}
export declare class ElibCaptchaService {
    private readonly config;
    private document;
    constructor(config: AxaAppConfig<CaptchaConfigI>);
    private initRecaptchaDom;
    verifyRecaptcha(): Promise<any>;
}
