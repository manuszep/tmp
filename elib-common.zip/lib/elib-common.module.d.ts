export declare class ElibCommonModule {
}
