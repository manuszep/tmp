import { ɵɵdefineInjectable, Injectable, Pipe, NgModule, Component, ChangeDetectorRef, Input, ChangeDetectionStrategy, ɵɵinject, InjectionToken, Inject, ViewEncapsulation, Injector, ElementRef, HostListener, ViewChild, HostBinding, APP_INITIALIZER, EventEmitter, Output, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Renderer2 } from '@angular/core';
import { TranslateService, TranslateModule } from '@ngx-translate/core';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule, FormBuilder, ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { MatExpansionModule } from '@angular/material/expansion';
import { BehaviorSubject, ReplaySubject, throwError, of, Subject } from 'rxjs';
import { HttpClient, HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AxaTopContentBarModule, AxaAppConfig, AxaFooterModule, AxaIconModule, AxaCardModule, AxaHeaderModule, AxaButtonModule, initializeAxaConfig, AXA_OAUTH_ENDPOINT_KEY, AXA_OAUTH_SCOPE_KEY, AXA_OAUTH_CLIENTID_KEY, AXA_OAUTH_CALLBACK_KEY, AXA_OAUTH_TOKEN_KEY, AXA_OAUTH_RESPONSE_TYPE, AXA_ERROR_CLOSE_STRING, AXA_ERROR_TITLE_STRING, AxaBusyModule, AxaFormFieldModule, AxaInputModule, AxaPhoneInputModule, AxaRadioButtonModule, AxaDateComboPickerModule, AxaSelectModule, AxaCheckboxModule } from '@axa/ng-toolkit';
import { trigger, transition, style, animate } from '@angular/animations';
import { NavigationEnd, Router, ActivatedRoute, RouterModule } from '@angular/router';
import { filter, map, mergeMap, catchError, finalize, startWith, takeUntil } from 'rxjs/operators';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';

class ElibDateOperationsService {
    constructor() {
        this.todayDate = new Date();
        this.todayDate.setHours(0, 0, 0, 0);
    }
    get today() {
        return this.todayDate;
    }
    getAge(refDate) {
        refDate.setHours(0, 0, 0, 0);
        return this.getDateDifference(this.today, refDate);
    }
    getDateDifference(date1, date2) {
        const noOfDays = (date1.getTime() - date2.getTime()) / 86400000;
        const leapYears = this.noOfLeapYears(date1, date2);
        let adjustment = 0;
        if (this.isLeapyear(date1.getFullYear())) {
            if ((date1.getMonth() < 1) || (date1.getMonth() === 1 && date1.getDate() < 29)) {
                adjustment = 1;
            }
        }
        if (this.isLeapyear(date2.getFullYear())) {
            if (date2.getMonth() > 1) {
                adjustment = 1;
            }
        }
        return (noOfDays - leapYears + adjustment) / 365;
    }
    isLeapyear(year) {
        return ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);
    }
    noOfLeapYears(date1, date2) {
        const year1 = date1.getFullYear();
        const year2 = date2.getFullYear();
        let beginYear = 0;
        let endYear = 0;
        let leapYearCount = 0;
        if (year1 < year2) {
            beginYear = year1;
            endYear = year2;
        }
        else if (year1 > year2) {
            beginYear = year2;
            endYear = year1;
        }
        else {
            return 0;
        }
        for (let yr = beginYear; yr <= endYear; yr++) {
            if (this.isLeapyear(yr)) {
                leapYearCount++;
            }
        }
        return leapYearCount;
    }
}
ElibDateOperationsService.ɵprov = ɵɵdefineInjectable({ factory: function ElibDateOperationsService_Factory() { return new ElibDateOperationsService(); }, token: ElibDateOperationsService, providedIn: "root" });
ElibDateOperationsService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ElibDateOperationsService.ctorParameters = () => [];

const elibPatternPhone = /^((\+|00)32\s?|0)(\d\s?\d{3}|\d{2}\s?\d{2})(\s?\d{2}){2}$/i;
const elibPatternPhoneMobile = /^((\+|00)32\s?|0)4(65|66|46|60|56|[123456789]\d)(\s?\d{2}){3}$/i;
const elibPatternDate = /^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$/;
const elibPatternEmail = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
const elibPatternTextWithoutNumbers = /^[a-zA-ZàâäôéèëêïîçùûüÿæœÀÂÄÔÉÈËÊÏÎŸÇÙÛÜÆŒ,.\-\s]+$/;
const elibPatternPositiveInteger = /^([0-9]\d*|0)$/;
const elibPatternPositiveFloat = /^(0|[1-9]\d{0,9})(\.\d{0,3})?$/;

const isEmptyInputValue = (value) => {
    return value == null || value.length === 0;
};
const ɵ0 = isEmptyInputValue;
const required = (control) => {
    const val = control.value;
    return isEmptyInputValue(val)
        ? { ELIB_ERROR_REQUIRED: true }
        : null;
};
const validEmail = (control) => {
    const val = control.value;
    if (elibPatternEmail.test(val)) {
        return null;
    }
    else {
        return { ELIB_ERROR_VALID_EMAIL: true };
    }
};
const phoneRequired = (control) => {
    const val = control.value;
    return val === null || val === '' || val.length < 4
        ? { ELIB_ERROR_REQUIRED: true }
        : null;
};
const validPhone = (control) => {
    let phoneNumber = control.value;
    if (phoneNumber.length > 3 && !phoneNumber.includes('-')) {
        control.markAsTouched();
        phoneNumber = phoneNumber.replace('+', '00');
        if (phoneNumber.startsWith('0032')) {
            if (elibPatternPhone.test(phoneNumber)) {
                return;
            }
            else if (elibPatternPhoneMobile.test(phoneNumber)) {
                return;
            }
            else {
                return { ELIB_ERROR_VALID_PHONE: true };
            }
        }
        else {
            if (/^\d+$/.test(phoneNumber)) {
                return;
            }
            else {
                return { ELIB_ERROR_VALID_PHONE: true };
            }
        }
    }
};
const validDate = (control) => {
    const valid = elibPatternDate.test(control.value);
    return !valid ? { ELIB_ERROR_VALID_DATE: true } : null;
};
const futureDateNotAllowed = (control) => {
    const val = control.value;
    if (isEmptyInputValue(val)) {
        return null;
    }
    const date = val.split('/').map(Number).reverse().join('/');
    if (Date.parse(date) > Date.now()) {
        return { ELIB_ERROR_FUTURE_DATE: true };
    }
    else {
        return null;
    }
};
const validateMaxAge = (control, maxAge = 99, maxAgeMessage = 'ELIB_GLOBAL_VALIDATION_VALID_DATE_MAX') => {
    const val = control.value;
    const dateOpService = new ElibDateOperationsService();
    if (isEmptyInputValue(val) || val.length < 10) {
        return null;
    }
    const date = val.split('/').map(Number);
    const age = dateOpService.getAge(new Date(date[2], date[1] - 1, date[0]));
    let ret = null;
    if (age > maxAge) {
        ret = { [maxAgeMessage]: maxAgeMessage };
    }
    return ret;
};
const validateMinAge = (control, minAge = 18, minAgeMessage = 'ELIB_GLOBAL_VALIDATION_VALID_DATE_MIN') => {
    const val = control.value;
    const dateOpService = new ElibDateOperationsService();
    if (isEmptyInputValue(val) || val.length < 10) {
        return null;
    }
    const date = val.split('/').map(Number);
    const age = dateOpService.getAge(new Date(date[2], date[1] - 1, date[0]));
    let ret = null;
    if (age < minAge) {
        ret = { [minAgeMessage]: minAgeMessage };
    }
    return ret;
};
const validAge = (minAge, minAgeMessage, maxAge = 100, maxAgeMessage = '', callback) => {
    return (control) => {
        const val = control.value;
        const dateOpService = new ElibDateOperationsService();
        if (isEmptyInputValue(val) || val.length < 10) {
            return null;
        }
        const date = val.split('/').map(Number);
        const age = dateOpService.getAge(new Date(date[2], date[1] - 1, date[0]));
        let ret = null;
        if (age < minAge && !futureDateNotAllowed(control)) {
            ret = { [minAgeMessage]: minAgeMessage };
        }
        else if (age > maxAge) {
            ret = { [maxAgeMessage]: maxAgeMessage };
        }
        if (ret !== null && callback !== null) {
            return callback();
        }
        return ret;
    };
};

var validation = /*#__PURE__*/Object.freeze({
    __proto__: null,
    required: required,
    validEmail: validEmail,
    phoneRequired: phoneRequired,
    validPhone: validPhone,
    validDate: validDate,
    futureDateNotAllowed: futureDateNotAllowed,
    validateMaxAge: validateMaxAge,
    validateMinAge: validateMinAge,
    validAge: validAge,
    ɵ0: ɵ0
});

/**
 * Converts a number (as string or number) to a fixed decimal with 2 places
 * @param value The number to be converted
 */
const elibToFixed = (value) => {
    return (Math.round(Number(value) * 100) / 100).toFixed(2);
};

const eLibAmountTransform = (value) => {
    value = typeof value === 'number' ? value.toString() : value;
    if (value) {
        const digitArr = elibToFixed(value).split('.');
        digitArr[1] = `<small>${digitArr[1] ? digitArr[1] : '00'}</small>`;
        return digitArr.join(',');
    }
    return '';
};
class ElibAmountPipe {
    transform(value) {
        return eLibAmountTransform(value);
    }
}
ElibAmountPipe.decorators = [
    { type: Pipe, args: [{
                name: 'amount'
            },] }
];

class ElibPricePipe {
    constructor(translateService) {
        this.translateService = translateService;
    }
    transform(value) {
        if (typeof value === 'undefined') {
            return '';
        }
        let parsedPrice = parseFloat(value);
        if (typeof parsedPrice !== 'number' || Number.isNaN(parsedPrice)) {
            parsedPrice = 0;
        }
        const num = eLibAmountTransform(parsedPrice);
        return this.translateService.currentLang === 'fr' ? `${num}&nbsp;€` : `€&nbsp;${num}`;
    }
}
ElibPricePipe.decorators = [
    { type: Pipe, args: [{
                name: 'price',
                pure: false
            },] }
];
ElibPricePipe.ctorParameters = () => [
    { type: TranslateService }
];

class ElibSafeUrlPipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(value, ...args) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(value);
    }
}
ElibSafeUrlPipe.decorators = [
    { type: Pipe, args: [{
                name: 'elibSafeUrl'
            },] }
];
ElibSafeUrlPipe.ctorParameters = () => [
    { type: DomSanitizer }
];

class ElibPipesModule {
}
ElibPipesModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibAmountPipe,
                    ElibPricePipe,
                    ElibSafeUrlPipe
                ],
                exports: [
                    ElibAmountPipe,
                    ElibPricePipe,
                    ElibSafeUrlPipe
                ]
            },] }
];

class ElibCommonModule {
}
ElibCommonModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    ElibPipesModule
                ]
            },] }
];

var ElibFieldTypes;
(function (ElibFieldTypes) {
    ElibFieldTypes["checkbox"] = "checkbox";
    ElibFieldTypes["currency"] = "currency";
    ElibFieldTypes["date"] = "date";
    ElibFieldTypes["dropdown"] = "dropdown";
    ElibFieldTypes["mail"] = "mail";
    ElibFieldTypes["numberInteger"] = "integer";
    ElibFieldTypes["numberPositiveInteger"] = "positiveInteger";
    ElibFieldTypes["numberFloat"] = "float";
    ElibFieldTypes["numberPositiveFloat"] = "positiveFloat";
    ElibFieldTypes["percentage"] = "percentage";
    ElibFieldTypes["radio"] = "radio";
    ElibFieldTypes["postalAddress"] = "postalAddress";
    ElibFieldTypes["text"] = "text";
    ElibFieldTypes["textWithoutNumbers"] = "textWithoutNumbers";
    ElibFieldTypes["phone"] = "phone";
    ElibFieldTypes["mobile"] = "mobile";
})(ElibFieldTypes || (ElibFieldTypes = {}));
class ElibFieldConfig {
    constructor(params) {
        this.name = params.name;
        this.type = params.type;
        this.$mandatory = typeof params.mandatory === 'undefined' ? true : params.mandatory;
        this.placeholder = params.placeholder || '';
        this.label = params.label || '';
        this.value = params.value || null;
        this.additionalValidators = params.additionalValidators || [];
        this.disabled = params.disabled || false;
        this.maxlength = params.maxlength || '';
        this.help = params.help;
        this.prefix = params.prefix;
        this.suffix = params.suffix;
        this.hint = params.hint;
        this.labelTranslationParam = params.labelTranslationParam;
    }
    set mandatory(value) {
        this.$mandatory = value;
        this.configChange$.next(true);
    }
    get mandatory() {
        return this.$mandatory;
    }
}

class ElibAccordionBlockService {
    constructor() {
        this.accordionState = new BehaviorSubject({ accordionID: '', state: false });
    }
    setAccordionState(accordionID, state) {
        this.accordionState.next({ accordionID, state });
    }
    getAccordionState() {
        return this.accordionState.asObservable();
    }
}
ElibAccordionBlockService.ɵprov = ɵɵdefineInjectable({ factory: function ElibAccordionBlockService_Factory() { return new ElibAccordionBlockService(); }, token: ElibAccordionBlockService, providedIn: "root" });
ElibAccordionBlockService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ElibAccordionBlockService.ctorParameters = () => [];

class ElibAccordionBlockComponent {
    constructor(service, cdRef) {
        this.service = service;
        this.cdRef = cdRef;
        this.$hideToggle = false;
        this.accordionState = this.service.getAccordionState();
        this.open = false;
    }
    set hideToggle(value) {
        this.$hideToggle = typeof value !== 'undefined' && value;
    }
    get hideToggle() {
        return this.$hideToggle;
    }
    ngOnInit() {
        this.accordionState.subscribe((value) => {
            this.open = value.state && value.accordionID === this.accordionData.id;
        });
    }
    toggle(id, state) {
        this.service.setAccordionState(id, state);
    }
    ngAfterViewChecked() {
        this.cdRef.detectChanges();
    }
}
ElibAccordionBlockComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-accordion-block',
                template: "<mat-expansion-panel\r\n    [class.mat-expansion-panel]=\"false\"\r\n    [expanded]=\"open\"\r\n    [hideToggle]=\"hideToggle\"\r\n    [(ngModel)]=\"accordionData.expanded\" name=\"expanded\" ngDefaultControl>\r\n    <mat-expansion-panel-header\r\n        [class.mat-expansion-toggle-indicator-before]=\"true\"\r\n        (click)=\"toggle(accordionData.id, !open)\">\r\n        <mat-panel-title>\r\n            <div [innerHTML]=\"accordionData?.header\"></div>\r\n        </mat-panel-title>\r\n    </mat-expansion-panel-header>\r\n    <div class=\"accordion-body\" [innerHTML]=\"accordionData?.content\"></div>\r\n</mat-expansion-panel>\r\n",
                styles: ["::ng-deep .mat-expansion-panel-header{height:auto}::ng-deep .mat-expansion-panel-header.mat-expanded{font-weight:700;height:auto}::ng-deep .mat-expansion-panel-body.mat-expansion-panel-body{margin-top:1rem;overflow:hidden;padding-bottom:0}::ng-deep .mat-expansion-panel-header .mat-expansion-panel-header-description,::ng-deep .mat-expansion-panel-header .mat-expansion-panel-header-title{margin-right:0}::ng-deep .mat-expansion-indicator{left:5px;position:absolute;top:0}::ng-deep .mat-expansion-indicator:after{color:#00008f;transform-origin:100% 25%}"]
            },] }
];
ElibAccordionBlockComponent.ctorParameters = () => [
    { type: ElibAccordionBlockService },
    { type: ChangeDetectorRef }
];
ElibAccordionBlockComponent.propDecorators = {
    accordionData: [{ type: Input }],
    hideToggle: [{ type: Input }]
};

class ElibAccordionBlockModule {
}
ElibAccordionBlockModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibAccordionBlockComponent
                ],
                imports: [
                    CommonModule,
                    FormsModule,
                    MatExpansionModule
                ],
                exports: [
                    ElibAccordionBlockComponent
                ]
            },] }
];

/**
 * Service used to communicate with the alert manager.
 * @export
 */
class AxaAlertService {
    constructor() {
        this.newAlerts = new ReplaySubject(10);
        this.removedAlerts = new ReplaySubject(10);
    }
    /**
     * Add an alert.
     */
    addAlert(alert) {
        this.newAlerts.next(alert);
        if (alert.ttl) {
            setTimeout(() => {
                this.removeAlert(alert);
            }, alert.ttl);
        }
    }
    /**
     * Remove an alert.
     */
    removeAlert(alert) {
        this.removedAlerts.next(alert);
    }
    /**
     * Gets the stream of added alerts.
     */
    getNewAlerts() {
        return this.newAlerts;
    }
    /**
     * Gets the stream of removed alerts.
     */
    getRemovedAlerts() {
        return this.removedAlerts;
    }
}
AxaAlertService.decorators = [
    { type: Injectable }
];

/**
 * Implement AXAAlertManager since importing it from ng-toolkit causes issues
 */
class AxaAlertManager {
    /**
     * Creates an instance of AxaAlertManager.
     */
    constructor(alertSvc, cdr) {
        this.alertSvc = alertSvc;
        this.cdr = cdr;
        /** List of alerts received from the alert service. */
        this.alerts = new Array();
    }
    ngOnInit() {
        this.newAlertSub = this.alertSvc.getNewAlerts().subscribe(alert => {
            this.alerts = [...this.alerts, alert];
            this.cdr.markForCheck();
        });
        this.removeAlertSub = this.alertSvc.getRemovedAlerts().subscribe(alert => {
            this.alerts = this.alerts.filter(currentAlert => currentAlert !== alert);
            this.cdr.markForCheck();
        });
    }
    ngOnDestroy() {
        this.newAlertSub.unsubscribe();
        this.removeAlertSub.unsubscribe();
    }
}
AxaAlertManager.decorators = [
    { type: Component, args: [{
                selector: 'axa-alert-manager',
                template: `
    <div [@simpleFadeAnimation]>
      <axa-top-content-bar *ngFor="let alert of alerts"
      [type]="alert.type" [buttonLabel]="alert.action && alert.action.content"
      (buttonClick)="alert.action && alert.action.handler  && alert.action.handler(alert.action, alert)">
        {{alert.message}}
      </axa-top-content-bar>
    </div>`,
                changeDetection: ChangeDetectionStrategy.OnPush,
                animations: [
                    trigger('simpleFadeAnimation', [
                        transition('void => *', [
                            style({ opacity: '0' }),
                            animate(1000)
                        ]),
                        transition('* => void', [
                            animate(1000, style({ opacity: '1' }))
                        ])
                    ])
                ]
            },] }
];
AxaAlertManager.ctorParameters = () => [
    { type: AxaAlertService },
    { type: ChangeDetectorRef }
];

class AxaAlertModule {
    static forRoot() {
        return {
            ngModule: AxaAlertModule,
            providers: [AxaAlertService]
        };
    }
}
AxaAlertModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule, AxaTopContentBarModule],
                exports: [AxaAlertManager],
                declarations: [AxaAlertManager],
            },] }
];

class ElibAlertService {
    constructor(axaAlertSvc) {
        this.axaAlertSvc = axaAlertSvc;
        this.alertList = new Array();
    }
    open(message, type, ttl) {
        const closeAction = {
            content: 'Close',
            handler: (action, alertRef) => {
                this.axaAlertSvc.removeAlert(alertRef);
            }
        };
        const alert = {
            message,
            type,
            ttl: ttl || 0,
            action: closeAction
        };
        this.alertList.push(alert);
        this.axaAlertSvc.addAlert(alert);
    }
    cleanAlerts() {
        this.alertList.forEach((alert) => {
            this.axaAlertSvc.removeAlert(alert);
        });
    }
    showError(message, ttl) {
        this.cleanAlerts();
        this.open(message, 'warning', ttl ? ttl : 10000);
    }
    showAlert(message, ttl) {
        this.cleanAlerts();
        this.open(message, 'corporate', ttl ? ttl : 10000);
    }
    showInfo(message, ttl) {
        this.cleanAlerts();
        this.open(message, 'commercial', ttl ? ttl : 10000);
    }
}
ElibAlertService.ɵprov = ɵɵdefineInjectable({ factory: function ElibAlertService_Factory() { return new ElibAlertService(ɵɵinject(AxaAlertService)); }, token: ElibAlertService, providedIn: "root" });
ElibAlertService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ElibAlertService.ctorParameters = () => [
    { type: AxaAlertService }
];

const ELIB_SHARED_CONFIG = new InjectionToken('ELIB_SHARED_CONFIG');

class ElibStorageService {
    constructor(router, http, aroute, sharedConfig) {
        this.router = router;
        this.http = http;
        this.aroute = aroute;
        this.sharedConfig = sharedConfig;
        this.storage = {};
        this.storage[sharedConfig.storeName] = {};
    }
    getData(key) {
        const stringKeys = ['Language', 'instanceid'];
        if (!key) {
            return {};
        }
        const sessionData = JSON.parse(sessionStorage.getItem(this.sharedConfig.storeName)) || {};
        return sessionData[key] ? sessionData[key] : (stringKeys.includes(key) ? '' : {});
    }
    getStoreData() {
        return JSON.parse(sessionStorage.getItem(this.sharedConfig.storeName));
    }
    setData(key, data) {
        if (!key) {
            return;
        }
        this.storage[this.sharedConfig.storeName][key] = data;
        this.setSessionData({ [key]: data });
    }
    clearData(key) {
        if (!key) {
            return;
        }
        this.storage[this.sharedConfig.storeName][key] = undefined;
        this.setSessionData({ [key]: undefined });
    }
    resetStore() {
        const { Language, instanceid } = JSON.parse(sessionStorage.getItem(this.sharedConfig.storeName));
        this.storage[this.sharedConfig.storeName] = { Language, instanceid };
        this.resetSessionData();
    }
    reset() {
        this.resetStore();
    }
    setSessionData(data) {
        const finalData = Object.assign(Object.assign({}, this.getStoreData()), data);
        sessionStorage.setItem(this.sharedConfig.storeName, JSON.stringify(finalData));
    }
    resetSessionData() {
        const finalData = this.storage[this.sharedConfig.storeName];
        sessionStorage.setItem(this.sharedConfig.storeName, JSON.stringify(finalData));
    }
    _setDataOnReload() {
        this.router.events
            .pipe(filter((rs) => rs instanceof NavigationEnd))
            .subscribe(event => {
            if (event.id === 1 &&
                event.url === event.urlAfterRedirects) {
                sessionStorage.setItem('eMotoSession', JSON.stringify(this.storage));
            }
        });
    }
    _getDataOnReload() {
        sessionStorage.getItem('eMotoSession') && sessionStorage.getItem('eMotoSession') != null
            ? this.storage = JSON.parse(sessionStorage.getItem('eMotoSession'))
            : this.storage = null;
        sessionStorage.getItem('eMotoSession') && sessionStorage.getItem('eMotoSession') != null
            ? sessionStorage.removeItem('eMotoSession')
            : this.storage = null;
    }
    getJSON(url) {
        return this.http.get(url);
    }
}
ElibStorageService.ɵprov = ɵɵdefineInjectable({ factory: function ElibStorageService_Factory() { return new ElibStorageService(ɵɵinject(Router), ɵɵinject(HttpClient), ɵɵinject(ActivatedRoute), ɵɵinject(ELIB_SHARED_CONFIG)); }, token: ElibStorageService, providedIn: "root" });
ElibStorageService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ElibStorageService.ctorParameters = () => [
    { type: Router },
    { type: HttpClient },
    { type: ActivatedRoute },
    { type: undefined, decorators: [{ type: Inject, args: [ELIB_SHARED_CONFIG,] }] }
];

class ElibSharedService {
    constructor(storage, router, route, sharedConfig) {
        this.storage = storage;
        this.router = router;
        this.route = route;
        this.sharedConfig = sharedConfig;
        this.dataSource = new BehaviorSubject({});
        this.scrComponents = {};
        this.chapters = Object.values(sharedConfig.progressChapters);
        this.initStorageData(this.chapters);
        this.getCurrentRouteData().subscribe(data => {
            const currentRoute = data;
            this.routekey = currentRoute.chapter.name + '_' + currentRoute.subStep;
        });
    }
    initStorageData(chapters) {
        chapters.forEach(chapter => {
            for (let index = 1; index <= chapter.subSteps; index++) {
                this.scrComponents = Object.assign(Object.assign({}, this.scrComponents), { [chapter.name + '_' + index]: {} });
            }
        });
        this.dataSource.next({ scrComponents: this.scrComponents });
    }
    getStoreData() {
        return JSON.parse(JSON.stringify(this.dataSource.value || {}));
    }
    setData(newData) {
        const a = Object.keys(newData);
        if (a.includes('fieldData')) {
            this.dataSource.value.scrComponents[this.routekey] = newData.fieldData;
            this.dataSource.next(Object.assign({}, this.dataSource.value));
        }
        else {
            this.dataSource.next(Object.assign(Object.assign({}, this.dataSource.value), newData));
        }
    }
    getData() {
        if (this.dataSource.value.scrComponents[this.routekey]) {
            return this.dataSource.value.scrComponents[this.routekey];
        }
        else {
            return {};
        }
    }
    getDataByAttribute(key) {
        const stringKeys = ['Language', 'instanceid'];
        const storedData = this.getStoreData();
        if (this.dataSource.value[key]) {
            return storedData[key];
        }
        else if (this.dataSource.value.scrComponents[key]) {
            return this.dataSource.value.scrComponents[key];
        }
        else {
            return stringKeys.includes(key) ? '' : {};
        }
    }
    reset() {
        const data = this.getStoreData();
        const { Language } = data;
        this.dataSource.next({ Language });
        this.initStorageData(this.chapters);
    }
    clearData(key) {
        const storedData = this.getStoreData();
        if (!key) {
            storedData.scrComponents[this.routekey] = {};
        }
        if (storedData[key]) {
            storedData[key] = undefined;
            this.setData(storedData);
        }
        if (storedData.scrComponents[key]) {
            storedData.scrComponents[key] = undefined;
            this.setData(storedData);
        }
    }
    getCurrentRouteData() {
        return this.router
            .events.pipe(filter(e => e instanceof NavigationEnd), map(() => {
            let route = this.route.firstChild;
            let child = route;
            while (child) {
                if (child.firstChild) {
                    child = child.firstChild;
                    route = child;
                }
                else {
                    child = null;
                }
            }
            return route;
        }), mergeMap(route => route.data));
    }
    ifAnyDataPresentExceptLanguageAndInstanceID(storedData) {
        let defaultFieldCount = 0;
        defaultFieldCount += storedData.Language ? 1 : 0;
        defaultFieldCount += storedData.instanceid ? 1 : 0;
        return Object.keys(storedData).length > defaultFieldCount;
    }
    ifAnyDataPresentInStorage(storedData) {
        return Object.keys(storedData.scrComponents.risk_1).length > 0;
    }
    handlePageRefresh() {
        const localStorageData = JSON.parse(JSON.stringify(this.storage.getData('saveData')));
        this.setData(localStorageData);
        this.clearSessionTempData();
        return;
    }
    clearSessionTempData() {
        this.storage.clearData('saveData');
    }
}
ElibSharedService.ɵprov = ɵɵdefineInjectable({ factory: function ElibSharedService_Factory() { return new ElibSharedService(ɵɵinject(ElibStorageService), ɵɵinject(Router), ɵɵinject(ActivatedRoute), ɵɵinject(ELIB_SHARED_CONFIG)); }, token: ElibSharedService, providedIn: "root" });
ElibSharedService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ElibSharedService.ctorParameters = () => [
    { type: ElibStorageService },
    { type: Router },
    { type: ActivatedRoute },
    { type: undefined, decorators: [{ type: Inject, args: [ELIB_SHARED_CONFIG,] }] }
];

class ElibHTTPStatus {
    constructor() {
        this.requestInFlight$ = new BehaviorSubject(false);
    }
    setHttpStatus(inFlight) {
        this.requestInFlight$.next(inFlight);
    }
    getHttpStatus() {
        return this.requestInFlight$.asObservable();
    }
}
ElibHTTPStatus.decorators = [
    { type: Injectable }
];
ElibHTTPStatus.ctorParameters = () => [];
class ElibHTTPListener {
    constructor(status, sharedService, alert) {
        this.status = status;
        this.sharedService = sharedService;
        this.alert = alert;
        this.requestPool = [];
        this.currentLanguage = this.sharedService.getDataByAttribute('Language');
        this.intanceid = this.sharedService.getDataByAttribute('IntanceID') || '';
    }
    intercept(req, next) {
        req = req.clone({
            setHeaders: {
                'Content-Type': 'application/json',
                'Accept-Language': this.currentLanguage
            },
        });
        return next.handle(req).pipe(map(event => {
            this.requestPool.push(req.urlWithParams);
            if (this.requestPool.length === 1) {
                this.status.setHttpStatus(true);
            }
            return event;
        }), catchError((error) => {
            if (error.error instanceof ErrorEvent) {
                this.errorHandler(error.error.message);
            }
            else {
                this.errorHandler(error.message);
            }
            this.status.setHttpStatus(false);
            return throwError(error);
        }), finalize(() => {
            this.requestPool = this.requestPool.filter(x => x !== req.urlWithParams);
            if (this.requestPool.length === 0) {
                this.status.setHttpStatus(false);
            }
        }));
    }
    errorHandler(message, ttl) {
        this.alert.showError(message, ttl);
    }
}
ElibHTTPListener.decorators = [
    { type: Injectable }
];
ElibHTTPListener.ctorParameters = () => [
    { type: ElibHTTPStatus },
    { type: ElibSharedService },
    { type: ElibAlertService }
];

const browserGlobals = {
    windowRef() {
        return window;
    },
    documentRef() {
        return document;
    }
};
class ElibDataLayerService {
    constructor(router, activatedRoute, sharedService, config, sharedConfig) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.sharedService = sharedService;
        this.config = config;
        this.sharedConfig = sharedConfig;
        this.window = browserGlobals.windowRef();
        this.document = browserGlobals.documentRef();
    }
    get dataLayer() {
        return this.window.dataLayer;
    }
    setDataLayer(value) {
        this.dataLayer.push(value);
    }
    getAppData() {
        const appMethod = this.sharedConfig.datalayerMapperMethod;
        let appMethodData;
        if (typeof appMethod === 'function') {
            appMethodData = appMethod();
        }
        return (typeof appMethodData === 'object') ? appMethodData : {};
    }
    init() {
        this.window.dataLayer = this.window.dataLayer || [];
        this.initNavEvents();
        this.initFlowData();
        this.initGtmDom();
    }
    handleNavigation(e) {
        const name = this.config.settings.name;
        this.setDataLayer(Object.assign(this.getAppData(), {
            event: 'stepChange',
            [`${name}_funnel_step`]: e.name,
            [`${name}_funnel_chapter`]: e.chapter.name
        }));
    }
    initFlowData() {
        const u = this.sharedService.getDataByAttribute('instanceid') || '';
        this.setDataLayer({
            event: 'init',
            flow: this.config.settings.name,
            env_work: this.config.settings.environment,
            language: this.sharedService.getDataByAttribute('Language').toUpperCase(),
            u
        });
    }
    initNavEvents() {
        this.router.events.pipe(filter(e => e instanceof NavigationEnd), map(() => {
            let route = this.activatedRoute.firstChild;
            let child = route;
            while (child) {
                if (child.firstChild) {
                    child = child.firstChild;
                    route = child;
                }
                else {
                    child = null;
                }
            }
            return route;
        }), mergeMap(route => route.data))
            .subscribe((data) => {
            this.handleNavigation(data);
        });
    }
    initGtmDom() {
        const gtmScript = this.document.createElement('script');
        this.setDataLayer({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        gtmScript.id = 'GTMscript';
        gtmScript.async = true;
        gtmScript.src = this.applyGtmQueryParams('//www.googletagmanager.com/gtm.js');
        this.document.head.insertBefore(gtmScript, this.document.head.firstChild);
    }
    applyGtmQueryParams(url) {
        const params = [`id=${this.config.settings.gtmId}`];
        if (url.indexOf('?') === -1) {
            url += '?';
        }
        return url + params.join('&');
    }
}
ElibDataLayerService.ɵprov = ɵɵdefineInjectable({ factory: function ElibDataLayerService_Factory() { return new ElibDataLayerService(ɵɵinject(Router), ɵɵinject(ActivatedRoute), ɵɵinject(ElibSharedService), ɵɵinject(AxaAppConfig), ɵɵinject(ELIB_SHARED_CONFIG)); }, token: ElibDataLayerService, providedIn: "root" });
ElibDataLayerService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ElibDataLayerService.ctorParameters = () => [
    { type: Router },
    { type: ActivatedRoute },
    { type: ElibSharedService },
    { type: AxaAppConfig },
    { type: undefined, decorators: [{ type: Inject, args: [ELIB_SHARED_CONFIG,] }] }
];

// import { ElibAppConfig } from '@config/etravel-config';
// import { AxaAppConfig } from '@axa/ng-toolkit';
class ElibAppWrapperComponent {
    constructor(injector, cdRef, dataLayerService
    // private readonly config: AxaAppConfig<ElibAppConfig>
    ) {
        this.injector = injector;
        this.cdRef = cdRef;
        this.dataLayerService = dataLayerService;
        this.busy = false;
        this.isThankYouPage = false;
        this.previousLang = 'nl';
        this.httpStatus = this.injector.get(ElibHTTPStatus);
        this.router = this.injector.get(Router);
        this.sharedService = this.injector.get(ElibSharedService);
        this.storage = this.injector.get(ElibStorageService);
        this.translateClient = this.injector.get(TranslateService);
        this.dataLayerService.init();
        this.translateClient.onLangChange.subscribe((t) => {
            this.languageCookie = this.getLanguageCookie('be.AXA.Languages');
            this.message = t.translations.ELIB_GLOBAL_LOADING;
            this.cdRef.detectChanges();
        });
        this.httpStatus.getHttpStatus().subscribe((status) => {
            this.busy = status;
        });
    }
    set showHelp(value) {
        this.$showHelp = typeof value !== 'undefined' ? !!value : true;
    }
    get showHelp() {
        return this.$showHelp;
    }
    set showSave(value) {
        this.$showSave = typeof value !== 'undefined' ? !!value : true;
    }
    get showSave() {
        return this.$showSave;
    }
    set showBanner(value) {
        this.$showBanner = typeof value !== 'undefined' ? !!value : true;
    }
    get showBanner() {
        return this.$showBanner;
    }
    // @HostListener('window:beforeunload', ['$event'])
    // onBeforeUnload(event): void {
    //   this.callToSaveDataOnLocalstorage();
    // }
    getParamValue(param) {
        const rx = new RegExp(`[?&]${param}=([^&]+).*$`, 'i');
        return window.location.href.match(rx);
    }
    ngOnInit() {
        let isOnIOS = navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/Macintosh/i);
        let eventName = isOnIOS ? 'pagehide' : 'beforeunload';
        window.addEventListener(eventName, (event) => {
            event.preventDefault();
            if (Object.keys(this.sharedService.getStoreData()).length > 0) {
                this.callToSaveDataOnLocalstorage();
                return;
            }
            this.storage.clearData('saveData');
        });
        this.languageCookie = this.getLanguageCookie('be.AXA.Languages');
        this.httpStatus.getHttpStatus().subscribe((status) => {
            this.busy = status;
        });
        this.router.events.subscribe((evt) => {
            if (!(evt instanceof NavigationEnd)) {
                return;
            }
            this.isThankYouPage = window.location.href.includes('thankyou');
            document.body.scrollTop = 0;
        });
        // if (this.config.settings.test === 'ft') {
        //   document.addEventListener('keydown', (e) => {
        //     if (e.altKey && e.shiftKey && e.code === "Digit1") {
        //       if (this.translateClient.currentLang !== 'debug') {
        //         this.previousLang = this.translateClient.currentLang;
        //         this.translateClient.setDefaultLang('debug');
        //         this.translateClient.use('debug');
        //       } else {
        //         this.translateClient.setDefaultLang(this.previousLang);
        //         this.translateClient.use(this.previousLang);
        //       }
        //     }
        //   });
        // }
    }
    ngAfterViewChecked() {
        this.cdRef.detectChanges();
    }
    callToSaveDataOnLocalstorage() {
        const storedData = this.sharedService.getStoreData();
        this.storage.setData('saveData', storedData);
        return storedData;
    }
    ngAfterViewInit() {
        this.router.events
            .pipe(filter((rs) => rs instanceof NavigationEnd))
            .subscribe(event => {
            this.sharedService.handlePageRefresh();
            const langInURL = this.getParamValue('lang');
            if (langInURL !== null) {
                const currentLang = langInURL[1].toString().toLowerCase();
                this.sharedService.setData({ Language: currentLang });
                this.translateClient.setDefaultLang(currentLang);
                this.translateClient.use(currentLang);
                this.setCookie('be.AXA.Languages', currentLang, 365, '/');
            }
            else {
                //not in url
                //check if in shared service/cookie
                this.sharedService.setData({ Language: this.languageCookie });
                this.translateClient.setDefaultLang(this.languageCookie);
                this.translateClient.use(this.languageCookie);
            }
            // init ELIB_GLOBAL_LOADING with default language
            this.translateClient.get('ELIB_GLOBAL_LOADING').subscribe((text) => {
                this.message = text;
            });
        });
    }
    setCookie(name, value, expireDays, path = '') {
        this.deleteCookie(name);
        let d = new Date();
        d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
        let expires = `expires=${d.toUTCString()}`;
        let cpath = path ? `; path=${path}` : '';
        var domainName = window.location.hostname.includes('localhost') ? window.location.hostname : '.axa.be';
        document.cookie = `${name}=${value.toUpperCase()}; ${expires}${cpath}; domain=${domainName}`;
    }
    deleteCookie(name) {
        var expires = "";
        var date = new Date();
        date.setTime(date.getTime() + (-1 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
        document.cookie = name + "=" + null + expires;
    }
    getLanguageCookie(name) {
        var _a;
        let ca = document.cookie.split(';');
        let caLen = ca.length;
        let cookieName = `${name}=`;
        let c;
        for (let i = 0; i < caLen; i += 1) {
            c = ca[i].replace(/^\s+/g, '');
            if (c.indexOf(cookieName) == 0) {
                return (_a = c.substring(cookieName.length, c.length)) === null || _a === void 0 ? void 0 : _a.toLowerCase();
            }
        }
        return 'fr';
    }
}
ElibAppWrapperComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-app-wrapper',
                template: "<div class=\"error-messages\">\r\n  <axa-alert-manager></axa-alert-manager>\r\n</div>\r\n<div class=\"content-wrapper\">\r\n  <elib-header [showHelp]=\"showHelp\" [showBanner]=\"showBanner\"></elib-header>\r\n  <elib-navigation></elib-navigation>\r\n  <app-navigation *ngIf=\"!isThankYouPage\"></app-navigation>\r\n  <div class=\"main-container\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n  <elib-footer></elib-footer>\r\n  <elib-modal></elib-modal>\r\n  <div\u00A0AxaBusyContainerFullScreen>\r\n    <div\u00A0*axaBusy=\"busy;message:message\"></div>\r\n  </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                styles: ["body,html{height:100%}body{font-family:Roboto,Helvetica Neue,sans-serif;margin:0}.main-container{box-shadow:none;flex-grow:1;padding:1rem 0;transition:.3s}@media (min-width:992px){.main-container{background:transparent;padding:2rem 0}}.content-wrapper{display:flex;flex-direction:column;min-height:100%}@media (min-width:992px){.content-wrapper{box-shadow:0 0 24px 0 rgba(0,0,0,.2)}}@media (min-width:1200px){.content-wrapper{max-width:100%;width:1260px!important}}@media (max-width:991px){elib-footer{margin:0 0 0 50%;position:relative;transform:translateX(-50%);width:100vw;z-index:1}}.error-messages{position:fixed;z-index:9999}"]
            },] }
];
ElibAppWrapperComponent.ctorParameters = () => [
    { type: Injector },
    { type: ChangeDetectorRef },
    { type: ElibDataLayerService }
];
ElibAppWrapperComponent.propDecorators = {
    showHelp: [{ type: Input }],
    showSave: [{ type: Input }],
    showBanner: [{ type: Input }]
};

class ElibFooterComponent {
    constructor(translateService, config, eRef) {
        this.translateService = translateService;
        this.config = config;
        this.eRef = eRef;
        this.toggled = false;
    }
    clickout(event) {
        if (!this.eRef.nativeElement.contains(event.target)) {
            this.toggled = false;
        }
    }
    ngOnInit() {
        this.translateService.onLangChange.subscribe(() => {
            if (this.translateService.currentLang === 'fr') {
                this.precontract_url = this.config.settings.precontractFR_url;
            }
            else {
                this.precontract_url = this.config.settings.precontractNL_url;
            }
        });
    }
    changeLang(userLanguage) {
        this.translateService.use(userLanguage);
    }
    year() {
        const now = new Date().getFullYear();
        return now;
    }
    handleToggleClick() {
        this.toggled = true;
    }
}
ElibFooterComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-footer',
                template: "<footer class=\"container-fluid px-0 footer mt-auto\">\r\n  <div class=\"d-flex px-0 footer__content\">\r\n    <div class=\"country__language__selection\">\r\n      <elib-elib-language-selector></elib-elib-language-selector>\r\n    </div>\r\n    <div class=\"legal__notice\" [class.toggled]=\"toggled\">\r\n      <span class=\"legal__notice_trigger\" tabindex=\"0\" (click)=\"handleToggleClick()\">{{'ELIB_FOOTER_LEGAL_TRIGGER' | translate}}</span>\r\n      <ul>\r\n        <li><a href=\"{{ precontract_url }}\" target=\"_blank\">{{ 'ELIB_FOOTER_PRECONTRACT_INFO' | translate }}</a></li>\r\n        <li><a href=\"{{'ELIB_FOOTER_CG_URL' | translate}}\" target=\"_blank\">{{ 'ELIB_FOOTER_CG' | translate }}</a></li>\r\n        <li><a href=\"{{'ELIB_FOOTER_FICHE_URL' | translate}}\" target=\"_blank\">{{ 'ELIB_FOOTER_INFOFICHE' | translate }}</a></li>\r\n        <li><a href=\"{{'ELIB_FOOTER_LEGAL_INFO_URL' | translate}}\" target=\"_blank\">{{ 'ELIB_FOOTER_LEGAL_INFO' | translate }}</a></li>\r\n        <li><a href=\"{{'ELIB_FOOTER_PRIVACY_URL' | translate}}\" target=\"_blank\">{{ 'ELIB_FOOTER_PRIVACY' | translate }}</a></li>\r\n        <li class=\"legal__notice__copyright\"><a href=\"{{'ELIB_FOOTER_RIGHT_URL' | translate}}\" target=\"_blank\">{{ 'ELIB_FOOTER_RIGHT' | translate }}</a></li>\r\n      </ul>\r\n    </div>\r\n  </div>\r\n</footer>\r\n",
                styles: ["::ng-deep .footer__bottom{background:#4976ba;margin:0!important;padding:0 2rem!important;width:auto}::ng-deep .footer .content-wrapper{box-shadow:none;width:auto}::ng-deep .footer .ng-select.ng-select-single .ng-select-container{font-size:14px;height:auto;height:50px!important;min-height:0}::ng-deep .footer .custom_option_item{font-size:14px}::ng-deep .footer .ng-dropdown-panel.ng-select-bottom{bottom:100%;top:auto!important}.footer{background:#4976ba;width:100%}.footer .footer__content{align-items:center;display:flex;justify-content:space-between;padding:0 1rem}.footer .footer__content .legal__notice{color:#fff;float:right;font-size:13px;font-stretch:normal;font-style:normal;font-weight:400;letter-spacing:.2px;line-height:normal;opacity:.65;text-align:right}.footer .footer__content .legal__notice ul{margin:0;padding:0}.footer .footer__content .legal__notice ul li{display:inline-block;padding:0 1rem}.footer .footer__content .legal__notice ul li a{color:#fff!important;text-decoration:none!important}.legal__notice_trigger{display:none}@media (max-width:991px){.legal__notice_trigger{align-items:center;color:#fff;cursor:pointer;display:flex;font-size:14px;height:50px;justify-content:flex-end;text-decoration:none}.legal__notice_trigger:after{border:5px solid transparent;border-top-color:#fff;content:\"\";display:block;height:0;margin:5px 0 0 5px;padding:0;transform-origin:center 3px;transition:transform .3s;width:0}.legal__notice_trigger:focus{outline:none}.legal__notice{opacity:1!important}.legal__notice ul{background:#4976ba;height:0;opacity:0;overflow:hidden;position:absolute;right:0;text-align:center;top:100%;transition:opacity .3s;transition-delay:0;z-index:1}.legal__notice ul li{border-bottom:1px solid hsla(0,0%,100%,.2)!important;display:block!important;padding:0!important}.legal__notice ul li a{display:block!important;padding:.5rem 1rem!important;transition:background-color .3s;white-space:nowrap!important}.legal__notice ul li a:hover{background:rgba(0,0,0,.075)}.legal__notice.toggled ul{bottom:100%;height:auto;opacity:1;top:auto}.legal__notice.toggled .legal__notice_trigger:after{transform:rotate(180deg)}}"]
            },] }
];
ElibFooterComponent.ctorParameters = () => [
    { type: TranslateService },
    { type: AxaAppConfig },
    { type: ElementRef }
];
ElibFooterComponent.propDecorators = {
    clickout: [{ type: HostListener, args: ['document:click', ['$event'],] }]
};

class ElibLanguageSelectorComponent {
    constructor(fb, translateService, sharedService) {
        this.fb = fb;
        this.translateService = translateService;
        this.sharedService = sharedService;
        this.languages = [
            { id: 'fr', name: 'Français' },
            { id: 'nl', name: 'Nederlands' }
        ];
    }
    ngOnInit() {
        this.translateService.onLangChange.subscribe((event) => {
            this.defaultLanguage = this.languages.find(l => l.id === event.lang).name;
            this.languageSelectorForm = this.fb.group({
                languageSelector: this.defaultLanguage,
            });
        });
        this.languageSelectorForm = this.fb.group({
            languageSelector: this.defaultLanguage,
        });
    }
    onChange($event) {
        this.setCookie('be.AXA.Languages', $event.id, 365, '/');
        // this.translateService.use($event.id);
        this.sharedService.setData({ Language: $event.id });
        this.translateService.setDefaultLang($event.id);
        this.translateService.use($event.id);
    }
    setCookie(name, value, expireDays, path = '') {
        this.deleteCookie(name);
        let d = new Date();
        d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
        let expires = `expires=${d.toUTCString()}`;
        let cpath = path ? `; path=${path}` : '';
        var domainName = window.location.hostname.includes('localhost') ? window.location.hostname : '.axa.be';
        document.cookie = `${name}=${value.toUpperCase()}; ${expires}${cpath}; domain=${domainName}`;
        const langInURL = this.getParamValue('lang');
        if (langInURL !== null) {
            let url = window.location.href;
            if (langInURL[1] === 'NL') {
                url = url.replace('NL', 'FR');
            }
            else {
                url = url.replace('FR', 'NL');
            }
            window.history.replaceState({}, '', url);
        }
    }
    deleteCookie(name) {
        var expires = "";
        var date = new Date();
        date.setTime(date.getTime() + (-1 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
        document.cookie = name + "=" + null + expires;
    }
    getParamValue(param) {
        const rx = new RegExp(`[?&]${param}=([^&]+).*$`, 'i');
        return window.location.href.match(rx);
    }
}
ElibLanguageSelectorComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-elib-language-selector',
                template: "<ng-container>\r\n  <form [formGroup]=\"languageSelectorForm\" class=\"axa-form\" novalidate style=\"height: 100%;\">\r\n    <ng-select style=\"height: 100%;\" [items]=\"languages\" [searchable]=\"false\" [clearable]=\"false\"\r\n      formControlName=\"languageSelector\" bindLabel=\"name\" bindValue=\"name\" (change)=\"onChange($event)\">\r\n      <ng-template ng-option-tmp let-item=\"item\">\r\n        <div class=\"custom_option_item\">{{item.name}}</div>\r\n      </ng-template>\r\n    </ng-select>\r\n  </form>\r\n</ng-container>",
                styles: [".select_container{display:flex;height:100%;width:100%}.custom_option_item{border:none!important}::ng-deep .ng-select .ng-arrow-wrapper .ng-arrow{border-color:#fff transparent transparent}"]
            },] }
];
ElibLanguageSelectorComponent.ctorParameters = () => [
    { type: FormBuilder },
    { type: TranslateService },
    { type: ElibSharedService }
];

class ElibFooterModule {
}
ElibFooterModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibFooterComponent,
                    ElibLanguageSelectorComponent
                ],
                imports: [
                    CommonModule,
                    AxaFooterModule,
                    AxaIconModule,
                    TranslateModule,
                    NgSelectModule,
                    FormsModule,
                    ReactiveFormsModule
                ],
                exports: [
                    ElibFooterComponent
                ]
            },] }
];

class ElibModalService {
    constructor() {
        this.show = new BehaviorSubject(false);
        this.config = new BehaviorSubject({
            title: '',
            content: ''
        });
    }
    showModal(config) {
        this.show.next(true);
        this.config.next(config);
    }
    hideModal() {
        this.show.next(false);
    }
    getModalStatus() {
        return this.show.asObservable();
    }
    getModalConfig() {
        return this.config.asObservable();
    }
    updateConf(config) {
        let modalconf;
        this.getModalConfig().subscribe(conf => {
            modalconf = conf;
        }).unsubscribe();
        this.config.next(Object.assign(Object.assign({}, modalconf), config));
    }
}
ElibModalService.decorators = [
    { type: Injectable }
];
ElibModalService.ctorParameters = () => [];

class ElibHeaderComponent {
    constructor(modalService, translateClient) {
        this.modalService = modalService;
        this.translateClient = translateClient;
    }
    ngOnInit() {
    }
}
ElibHeaderComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-header',
                template: "<axa-header>\r\n  <axa-header-nav link=\"#\" *ngIf=\"showHelp\">\r\n    <elib-header-help [showPhoneIcon]=\"'yes'\"></elib-header-help>\r\n  </axa-header-nav>\r\n  <axa-header-nav link=\"#\" *ngIf=\"showSave\">\r\n    <a axa-icon-link>\r\n      <p class=\"header-subtitle\">{{ 'ELIB_HEADER_SAVEFORLATER' | translate }}</p>\r\n      <axa-icon name=\"download-blue\" class=\"axa-download-icon\"></axa-icon>\r\n      <span class=\"link-label\">{{ 'ELIB_HEADER_SAVEFORLATER_CTA' | translate }}</span>\r\n    </a>\r\n  </axa-header-nav>\r\n</axa-header>\r\n\r\n\r\n<elib-header-covid-banner *ngIf=\"showBanner\"></elib-header-covid-banner>\r\n",
                styles: [":host{display:block;position:relative;z-index:500}.axa-icon{display:inline-block}.header-subtitle{-ms-grid-column:1;-ms-grid-column-span:2;-ms-grid-row:1;color:#7f7f7f;font-weight:500;grid-area:header;margin-bottom:9px;text-align:right;text-transform:none}axa-icon{-ms-grid-column:1;-ms-grid-row:2;grid-area:icon}axa-header-nav a:not(.axa-btn){align-items:center;display:grid;grid-template:\"header header\" \"icon link\";grid-template-columns:1fr auto;justify-items:end}@media (min-width:992px){axa-header-nav a:not(.axa-btn){padding:18px 1rem}}::ng-deep .axa-header__main__logo{border-top:none!important;padding-left:1rem}@media (min-width:992px){::ng-deep .axa-header__main__logo{padding-left:0}}::ng-deep .axa-header__main__logo svg{display:block!important;height:48px!important;margin:11px 0!important;width:48px!important}@media (min-width:992px){::ng-deep .axa-header__main{width:calc(100% - 4rem)!important}}@media screen and (min-width:992px){::ng-deep .axa-header__wrapper{border-top:0;box-shadow:0 3px 4px 0 rgba(0,0,0,.1);margin:0;width:auto}}@media screen and (max-width:767px){::ng-deep .axa-header__nav__link a:not(.axa-btn){align-items:center;border:none;display:flex;font-weight:200;margin:0;padding:26px 24px!important;width:auto}::ng-deep .axa-header__nav{flex-direction:row!important;flex-grow:1!important;justify-content:flex-end!important;transform:none!important}::ng-deep .axa-header__main__logo{background:#fff!important;border-top:none!important;box-shadow:none!important;left:0!important;min-height:0!important;position:static!important;right:auto!important;top:0!important;z-index:0!important}::ng-deep .axa-header{bottom:auto!important;left:0!important;max-width:none!important;overflow:visible!important;pointer-events:auto!important;position:sticky!important;top:0!important;width:100%!important;z-index:none}::ng-deep .axa-header__main{flex-direction:row!important;flex-grow:1!important;margin:0!important;width:auto!important}::ng-deep .axa-header__toggle__open{display:none!important}::ng-deep .axa-header__nav__link{border:none;color:#999;cursor:pointer;display:flex;flex-direction:column;font-size:12px;height:42px;margin:0 .5rem;padding:0 .25rem;transition:transform .3s;width:auto!important}::ng-deep .axa-header__wrapper{background:#fff!important;box-shadow:0 1px 3px rgba(0,0,0,.1),0 1px 12px rgba(0,0,0,.1)!important;margin-bottom:0!important;margin-left:calc(50% - 50vw)!important;margin-right:calc(50% - 50vw)!important;max-width:none!important;min-height:0!important;padding-top:0!important;position:static!important;width:100vw!important}}"]
            },] }
];
ElibHeaderComponent.ctorParameters = () => [
    { type: ElibModalService },
    { type: TranslateService }
];
ElibHeaderComponent.propDecorators = {
    showHelp: [{ type: Input }],
    showSave: [{ type: Input }],
    showBanner: [{ type: Input }]
};

class ElibHeaderHelpComponent {
    constructor(modalService, translateClient, sanitizer) {
        this.modalService = modalService;
        this.translateClient = translateClient;
        this.sanitizer = sanitizer;
    }
    ngOnInit() {
        this.checkAvailableTime();
        this.translateClient.onLangChange.subscribe((event) => {
            // if (this.phoneUrl) {
            // this.setPhoneUrl(event.lang);
            this.checkAvailableTime();
            // }
        });
    }
    showHelpPopUp() {
        this.modalService.showModal({
            title: '',
            content: this.modal.nativeElement.innerHTML,
            primaryActionLabel: 'ELIB_MODAL_CONFIRM',
            primaryAction: () => {
                this.modalService.hideModal();
            },
            secondaryActionLabel: 'ELIB_MODAL_CLOSE',
            plainMode: true
        });
    }
    setPhoneUrl(lang) {
        this.phoneUrl = lang === 'fr' ? 'tel:080061213' : 'tel:080061214';
        this.whatsappUrl = lang === 'fr' ? 'https://api.whatsapp.com/send?phone=3226785940' : 'https://api.whatsapp.com/send?phone=3226785940';
    }
    // ShowContactDetails() {
    //   if (this.phoneUrl === undefined) {
    //     this.modalService.showModal(
    //       {
    //         title: 'EMOTO_HEADER_HELP',
    //         content: 'EMOTO_HEADER_TEL_HELP'
    //       }
    //     );
    //   }
    // }
    getMinutes(s) {
        const time = s.split(':').map(Number);
        return time[0] * 60 + time[1];
    }
    checkAvailableTime() {
        const date = new Date();
        const day = date.getDay();
        const timeNow = date.getHours() * 60 + date.getMinutes();
        const isSaturday = day === 6;
        const isWeekDay = day > 0 && day < 6;
        const isInSaturdayTime = this.getMinutes('8:00') <= timeNow && timeNow <= this.getMinutes('13:00');
        const isInWeekDayTime = this.getMinutes('8:30') <= timeNow && timeNow <= this.getMinutes('18:00');
        if (
        // (isSaturday && isInSaturdayTime) ||  // RE: EC hours updated
        (isWeekDay && isInWeekDayTime)) {
            this.setPhoneUrl(this.translateClient.store.defaultLang);
        }
    }
}
ElibHeaderHelpComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-header-help',
                template: "<a axa-icon-link (click)=\"showHelpPopUp()\">\r\n  <axa-icon name=\"phone-icon\" class=\"axa-phone-icon\" *ngIf=\"showPhoneIcon === 'yes'\"></axa-icon>\r\n  <span class=\"link-label\" [innerHTML]=\"helpLinkLabel && helpLinkLabel.length > 0 ? (helpLinkLabel | translate) : ('ELIB_HEADER_HELP' | translate)\"></span>\r\n</a>\r\n\r\n\r\n<div class=\"cover-card-hidden\">\r\n  <div #helpmodal>\r\n    <div class=\"cover-card\">\r\n      <axa-card content class=\"elib-broker-card axa-card--transparent\">\r\n        <axa-card-content compact>\r\n          <div class=\"elib-flag-content\">\r\n            <img class=\"elib-broker-card__image elib-round-image elib-flag-content__head\" src=\"assets/BrowkersAXA_icon.svg\" alt=\"\">\r\n            <div class=\"elib-flag-content__body\">\r\n              <h5>{{'ELIB_BROKER_CARD_SUBTITLE' | translate}}</h5>\r\n              <div class=\"help-body\">\r\n\r\n                <!-- <b>{{ 'ELIB_HELP_ADVISER_PU' | translate }}</b> -->\r\n\r\n                <div class=\"clear\">\r\n                  <p [innerHTML]=\"'ELIB_HELP_ADVISER_PU' | translate\"></p>\r\n                </div>\r\n\r\n                <ng-template [ngIf]=\"!!phoneUrl\" [ngIfElse]=\"unavailable\">\r\n                  <div>\r\n                    <div class=\"status-circle float-left background-green\"></div>\r\n                    <div class=\"online float-left\" >{{ 'ELIB_HELP_ADVISOR_AVAILABLE_PU' | translate }}</div>\r\n                  </div>\r\n                </ng-template>\r\n\r\n                <ng-template #unavailable>\r\n                  <div >\r\n                    <div class=\"status-circle float-left\"></div>\r\n                    <div class=\"advisor-unavailable float-left\">{{ 'ELIB_HELP_ADVISOR_UNAVAILABLE_PU' | translate }}</div>\r\n                  </div>\r\n                </ng-template>\r\n                <br><br>\r\n                <div><p [innerHTML]=\"'ELIB_HELP_ADVISOR_INTRO_PU' | translate\"></p></div>\r\n\r\n                <axa-icon name=\"download-blue\" class=\"axa-download-icon\"></axa-icon>\r\n                <div class=\"social\">\r\n\r\n                  <div class=\"phone-url\">\r\n                    <a class=\"icon-call\"\r\n                  [href]=\"phoneUrl ? phoneUrl : 'javascript:void(0)' | elibSafeUrl\"\r\n                  >\r\n                    <!-- phone icon -->\r\n                    <p><img src=\"assets/phone-circle.PNG\" alt=\"\"></p>\r\n                      <p [innerHTML]=\"'ELIB_HELP_ADVISOR_CALL_PU' | translate\" [ngClass]=\"{'advisor-available': !!phoneUrl, 'advisor-unavailable': !phoneUrl}\"></p>\r\n                    </a>\r\n                  </div>\r\n\r\n                  <!-- <div class=\"icon-callback\"></div> -->\r\n                  <div class=\"whatsapp-url\">\r\n                    <a class=\"icon-whatsapp\" [href]=\"whatsappUrl ? whatsappUrl : 'javascript:void(0)' | elibSafeUrl\" [target]=\"whatsappUrl ? '_blank' : ''\">\r\n                      <p><img src=\"assets/whatsapp.PNG\" alt=\"\"></p>\r\n                      <p>{{'ELIB_HELP_ADVISOR_WHATSAPP_PU' | translate}}</p>\r\n                    </a>\r\n                  </div>\r\n\r\n                </div>\r\n                <p class=\"help-advise\" [innerHTML]=\"'ELIB_HELP_ADVISOR_CC_HOURS_PU' | translate\"></p>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </axa-card-content>\r\n      </axa-card>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
                styles: [".axa-phone-icon{background:transparent url(assets/icons/phone.svg) no-repeat 50%;float:left;height:15px;width:24px}axa-icon{display:inline-block;grid-area:icon}.link-label{cursor:pointer;font-size:14px;font-weight:700;grid-area:link;letter-spacing:1px;line-height:18px;margin-left:.5rem}::ng-deep :host{display:block;margin:2rem auto 0;max-width:40rem}::ng-deep .elib-broker-card p:last-of-type{margin-bottom:.5rem}::ng-deep .elib-broker-card__image{height:5rem;width:5rem}::ng-deep .cover-card-hidden{display:none}::ng-deep .advisor-available{color:#333!important}::ng-deep .online{color:#25d366;margin-left:.25rem}::ng-deep .advisor-unavailable{color:grey!important;margin-left:.25rem}::ng-deep .help-body{margin-top:1rem}::ng-deep .whatsapp-url{display:inline-block}::ng-deep .whatsapp-url p{color:#333;margin-bottom:0!important}::ng-deep .whatsapp-url p img{margin-left:1rem}::ng-deep .phone-url{display:inline-block;float:left;margin-right:3rem}::ng-deep .phone-url p{color:#333;margin-bottom:0!important}::ng-deep .help-advise{margin-top:1.5rem!important}::ng-deep .status-circle{background-color:grey;border:2px solid #fff;border-radius:50%;bottom:0;height:15px;margin-top:.25rem;right:0;width:15px}::ng-deep .float-left{float:left}::ng-deep .background-green{background-color:#25d366}::ng-deep .clear{clear:both}@media screen and (max-width:335px){.phone-url p{margin-left:1rem!important}}"]
            },] }
];
ElibHeaderHelpComponent.ctorParameters = () => [
    { type: ElibModalService },
    { type: TranslateService },
    { type: DomSanitizer }
];
ElibHeaderHelpComponent.propDecorators = {
    helpLinkLabel: [{ type: Input }],
    showPhoneIcon: [{ type: Input }],
    modal: [{ type: ViewChild, args: ['helpmodal', { static: true },] }]
};

class ElibHeaderCovidBannerComponent {
    constructor() { }
    ngOnInit() {
    }
}
ElibHeaderCovidBannerComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-header-covid-banner',
                template: "<div class=\"container-cb\">\r\n  <div class=\"covid_banner\">\r\n    <div class=\"covid_banner_bg_2\">\r\n    </div>\r\n    <p class=\"covid_banner_content\"><a [href]=\"'ELIB_GLOBAL_COVID_LINK' | translate\" target=\"_blank\">{{'ELIB_GLOBAL_COVID' | translate}}</a></p>\r\n  </div>\r\n</div>\r\n",
                styles: [".container-cb{font-family:Source Sans Pro,sans-serif;margin:0 0 0 50%;transform:translateX(-50%);width:100%}@media (max-width:991px){.container-cb{width:100vw}}.covid_banner{align-items:center;background-color:#f1afc6;color:#fff;display:flex;height:50px;justify-content:center;padding:1px 1rem;position:relative;width:100%}.covid_banner a{color:#fff;text-decoration:underline}.covid_banner a:hover{color:#f1afc6}.covid_banner p{margin:0;text-shadow:1px 1px 2px rgba(0,0,0,.5)}.covid_banner_bg_2{border-bottom:50px solid #ce7f9a;border-left:150px solid transparent;border-right:150px solid transparent;height:0;left:50%;position:absolute;top:0;transform:translateX(-50%);width:88%}.covid_banner_bg_2:before{bottom:-53px;content:url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22 width%3D%2246%22 height%3D%2247%22 viewBox%3D%220 0 46 47%22%3E%0D  %3Cdefs%3E%0D    %3Crect id%3D%22rect-1%22 width%3D%2246%22 height%3D%2247%22 x%3D%220%22 y%3D%220%22%2F%3E%0D    %3Cmask id%3D%22mask-2%22 maskContentUnits%3D%22userSpaceOnUse%22 maskUnits%3D%22userSpaceOnUse%22%3E%0D      %3Crect width%3D%2246%22 height%3D%2247%22 x%3D%220%22 y%3D%220%22 fill%3D%22black%22%2F%3E%0D      %3Cuse fill%3D%22white%22 xlink%3Ahref%3D%22%23rect-1%22%2F%3E%0D    %3C%2Fmask%3E%0D    %3Cpath id%3D%22path-10%22 fill-rule%3D%22evenodd%22 d%3D%22M18.81784058 1.42696476v22.967453h16.44946289v-22.967453h-16.4494629z%22%2F%3E%0D    %3Cmask id%3D%22mask-11%22 maskContentUnits%3D%22userSpaceOnUse%22 maskUnits%3D%22userSpaceOnUse%22%3E%0D      %3Crect width%3D%2246%22 height%3D%2247%22 x%3D%220%22 y%3D%220%22 fill%3D%22black%22%2F%3E%0D      %3Cuse fill%3D%22white%22 xlink%3Ahref%3D%22%23path-10%22%2F%3E%0D    %3C%2Fmask%3E%0D  %3C%2Fdefs%3E%0D  %3Cg%3E%0D    %3Cuse fill%3D%22none%22 xlink%3Ahref%3D%22%23rect-1%22%2F%3E%0D    %3Cg mask%3D%22url(%23mask-2)%22%3E%0D      %3Cg%3E%0D        %3Cpath fill%3D%22rgb(147%2C145%2C174)%22 fill-rule%3D%22evenodd%22 d%3D%22M40.86749597 46.46104618c.35463473-.42762087.64319682-.9284461.67690738-1.46855178.050341-.8003384-.45621581-1.66227564-.98075162-2.55278044-1.94442314-3.3022328-4.06503998-6.81247323-6.00451891-10.4146656-.62926316-1.16814589-1.25762737-2.33852363-1.84374104-3.52943432.28271894.0834709.56993262.10668203.82028946.0343704.15956316-.04642233.30339474-.12944684.41531368-.25576902.43554.83426233.8845642 1.6600437 1.34392631 2.48761062.9856958 1.77699229 2.01588947 3.5620192 3.04788104 5.342136 1.48640944 2.56527876 2.98135892 5.13011112 4.4987821 7.67842785%22%2F%3E%0D        %3Cpath fill%3D%22rgb(240%2C218%2C219)%22 fill-rule%3D%22evenodd%22 d%3D%22M32.14249292 3.63733359c1.05092848.53960192 1.92525348 1.37591705 2.41754738 2.42029328.524778 1.11538837.64144612 7.16318157.29418679 7.38164571.0288239.7042416.02745134 1.40757855.01418319 2.11136778-.0265363 1.45416611-.12581862 2.90380917-.76909489 4.07664051-.5998116 1.09322538-1.99937203-.3880792-2.43356063.70559848-.4282408 1.07649003.09196196 4.70670378.03797431 6.00889483-.02653623.63368175-.1047726 1.25243731-.45569213 1.64503957-.50830716.56900181-1.50433304.64679861-2.45689425.32385163-1.1049162-.37405767-2.0076075-1.2700773-2.77807493-2.30359818-.7983763-1.07061004-1.43844986-2.24796444-1.83832429-3.5112571-.4922939-1.55412588-.62268776-3.2154485-1.25772857-4.6583069-.52798062-1.2004221-1.40001795-2.23891833-1.86669066-3.4298419-.5595497-1.42883694-.54673906-3.02321817.05398765-4.4045629.60255677-1.3849632 1.80995791-2.49718541 2.93775013-3.7071059.99922858-1.07196693 1.91198533-2.19504452 3.1006281-2.80023092 1.53635963-.78158602 3.39664497-.68162623 4.9998028.141572%22%2F%3E%0D        %3Cpath fill%3D%22none%22 stroke%3D%22rgb(166%2C63%2C68)%22 stroke-dasharray%3D%220 0 0 0%22 stroke-linecap%3D%22butt%22 stroke-linejoin%3D%22miter%22 stroke-width%3D%22.625%22 d%3D%22M33.86868892 12.24824618c-.13283552.16530371-.23189287.35838567-.29869012.56786146-.07362884.23087876-.10892516.46995432-.0341577.65666101.11082276.2768723.40989234.39390553.7374268.28006%22%2F%3E%0D        %3Cpath fill%3D%22none%22 stroke%3D%22rgb(166%2C63%2C68)%22 stroke-dasharray%3D%220 0 0 0%22 stroke-linecap%3D%22butt%22 stroke-linejoin%3D%22miter%22 stroke-width%3D%22.625%22 d%3D%22M34.27326753 13.02215382c.0565735-.12288604.16036958-.22518378.30577756-.29499077.13558938-.0649816.29876423-.09682909.4731603-.09136029%22%2F%3E%0D        %3Cpath fill%3D%22rgb(255%2C225%2C234)%22 fill-rule%3D%22evenodd%22 d%3D%22M24.01207378 22.08295382c.74223822.60968473 2.81312376 1.96008683 3.53895893 2.58823323.58458662.50611935 1.15413708 1.0167416 1.80524722 1.13246459.97643732.17380967 1.65443023-.472348 2.23673868-1.64488793.39002816.9555029 1.16871762 1.9213624 1.50953666 2.89487673.224175.640304.43513656 1.2851109.7832458 1.88353854.55451437.95280124 1.4780974 1.7772715 2.22899279 2.74268066.94773201 1.21936945 1.61387824 2.67288661 2.44268813 4.02824189.68756134 1.12435949 1.48766592 2.17487236 1.79340061 3.41090232.47705549 1.92721608-.25652557 4.26914386-.81924145 6.64934582-.5996227 2.53419913-1.00104193 5.11883004-1.27123665 7.71021528-.25105786 2.40676865-.38091542 4.82074196-.51213984 7.23021236-.09112804 1.67910953-.15947411 3.29743069-1.0247352 4.225016-.96276818 1.03160102-2.64316994 1.16803709-3.95404734.3183509-1.00969913-.65426283-1.65306338-1.84211236-1.88862945-3.25870625-.37727024-2.26537949.33352877-4.91440109.6497432-7.61565563.29981136-2.55851448.1959254-5.1692619.12530109-7.77100357-.06743476-2.4873696-.14124848-4.97383861-.96869144-7.17842974-.91173643-2.42838233-4.45616304-5.96041106-5.61303398-8.35637295-11.44158589-10.06610189-1.95651985-5.86314974-1.06209776-8.98902225%22%2F%3E%0D        %3Cpath fill%3D%22rgb(241%2C175%2C198)%22 fill-rule%3D%22evenodd%22 d%3D%22M31.59087962 24.0933747c-.2364992 1.58951803.53630602 3.54443737 1.03688845 5.0190128.572934 1.68701803 1.61479662 3.21973563 2.71092292 4.7005725 1.17073884 1.5828093 2.44096115 3.0882448 2.85472166 4.8088064.40471662 1.68344007-.02034887 3.5587493-.34683533 5.44971222-.29935463 1.7353208-.50917422 3.48540073-.80400683 5.22206327-.40697756 2.39679993-.96725007 4.77615731-.87047984 7.1157096.08049112 1.9388184.60232685 3.84632953.69909705 5.76502182.1655042 3.27832502-.89625508 6.27488407-.1184757 6.67338174.57474277.29428895 1.84586945-.5782912 2.55446265-2.11637578.81259862-1.76528632.4386314-4.0502744.14334652-6.40861112-.33598254-2.68438022-.5381148-5.42243011-.0750647-7.96592735.32467764-1.7804928.98217258-3.4760085 1.10562241-5.18762516.08863069-1.23574517-.09857902-2.47014859-.11757132-3.71304975-.01447029-.93072225.06104667-1.86233905.07687359-2.7952976.0167313-.96694938-.02713182-1.93434596-.28578873-2.84315309-.25413488-.89181178-.71899372-1.7232451-1.09386532-2.59269447-.60458779-1.40212131-.96589347-2.90979302-1.81511999-4.04714371-.6891487-.92267186-1.67584329-1.6078552-2.43779577-2.46657062-1.87028811-2.1083253-2.25013386-4.72382938-2.51557368-4.61470095-.05562027.02325688-.64483338-.18605505-.70135804-.00313076%22%2F%3E%0D        %3Cpath fill%3D%22rgb(241%2C175%2C198)%22 fill-rule%3D%22evenodd%22 d%3D%22M24.08201667 22.4699077c1.56641705 2.59254314 2.33209099 6.6083902 4.12016225 9.06194226 2.0286089 2.78388139 4.07655074 5.53256379 5.07062308 8.59939113 1.04847427 3.2342483.76387556 6.88321331.83131601 10.52225033.06474281 3.4851541.41048757 6.9563189.72161288 10.43289898.29359077 3.2811803.5615542 6.44773818-.97204177 8.11202-1.12490678 1.22068393-3.18184074 1.5465005-5.2841845 1.80327287-1.51875908.18547171-3.0379677.3222064-4.52570416.13492953-1.4796436-.18592298-2.90938128-.6985651-4.33462286-1.2351245-1.47424838-.55506146-2.92286936-1.17059303-4.3678935-1.80101652 0 0-.99137469-.4553309-2.1549474-.87275513.08407581-3.04381258-13.38288397-8.91888989-13.18415944-12.26415047.1762444-2.96393796 10.67672332-24.37532065 11.35562389-25.8604485.53412842-1.16743412 1.30609684-2.2053539 2.29657234-2.9797323 1.09972901-.85966836 2.46517344-1.36012625 3.84500514-1.84027694 1.67432173-.58304015 5.41951505-1.1796184 6.58263804-1.81320073%22%2F%3E%0D        %3Cg%3E%0D          %3Cuse fill%3D%22none%22 xlink%3Ahref%3D%22%23path-10%22%2F%3E%0D          %3Cg mask%3D%22url(%23mask-11)%22%3E%0D            %3Cpath fill%3D%22rgb(206%2C127%2C154)%22 fill-rule%3D%22evenodd%22 d%3D%22M31.98216262 3.90464702c-.92245195-.32377815-1.91098727-.33045858-2.70896709.08818167-.62009767.32511424-1.0976182.89918583-1.54209699 1.5097771-.40872132.56160144-.78440098 1.14458027-1.08449206 1.7671963-.33268018.68942034-.5743825 1.42115006-.8120112 2.15510656-.24260757.7499896-.47254162 1.50398742-.70519141 2.25709455-.29103857-.14964167-.59429804-.27122545-.9025364-.37900305-.57981399-.20263971-1.15510173-.34871848-1.5746861-.14964168-.5938454.28280488-.80703228 1.11696786-.6164767 1.98542371.19779759.90185804.84505287 1.66075484 1.79058874 2.14530866.07423067.99805614.29556482 1.97651643.59656116 2.92558276.53545664 1.69014873.2847018 6.06004036-1.47465575 5.98210204-1.74034724.38880101-.7119808-.18170764-2.07438529.2026397.34128006-.98068705 4.47420873-5.80662938.62688711-7.36316952-2.02007015-.8172392-2.88005969-8.12562917-2.64514676-8.85023313.26976514-.83327225.9287887-4.71816475 5.10516947-5.85962749 1.25422684-.49524252 2.51705357-.9780149 3.60154562-.88226207.56578263.0503259 2.14318447.119357 2.6677781.20798404.98355646.1652293 3.83419544 1.99433092 4.41898833 2.91712093.5780035.91165597.40555301 2.68865024.576193 3.8087356.15706124 1.0327944-.1620401 2.77994946-.36074295 2.4303403-.39921625-.71970495-.2340077-2.23660784-.51237275-3.65642181-.1299037-.66225326-.04616786-1.2977848-.4788784-1.85537799-.22495511-.290376-.47706782-.55581173-.76493801-.78071953-.33811169-.2636543-.72239123-.46451255-1.12613367-.60613765l-9.0339638 3.24223517%22%2F%3E%0D          %3C%2Fg%3E%0D        %3C%2Fg%3E%0D        %3Cpath fill%3D%22rgb(166%2C63%2C68)%22 fill-rule%3D%22evenodd%22 d%3D%22M31.93645293 15.71136087c.33458962-.12715083.65376726-.28512603.95952152-.45380422.25504386-.14085054.49467568-.29925381.75270245-.43325454.27095293-.13999426.5588094-.25216095.82876806-.25430153.16754339-.00128436.32216063.03681804.40966103.13100386.15412008.1656813.09545497.4640789-.16754339.7123869.22421977.1113104.33508678.30952866.33260096.50945935-.00298292.24616735-.17450363.46664771-.43203325.54798996-.25554095.08091411-.56527253.00727797-.86406655-.11858843-.27741607-.116876-.52748828-.27956051-.80639585-.39600837-.3122174-.13014763-.65774458-.22090843-1.01321498-.24488298%22%2F%3E%0D        %3Cpath fill%3D%22rgb(255%2C255%2C255)%22 fill-rule%3D%22evenodd%22 d%3D%22M32.28744469 11.2845664c.71430472-.28340705 1.35083673-.67326233 1.8938565-.5659043.74300653.14648008 1.23001138 1.12043586 1.47953196 2.25406408.31016478 1.40975666.17915488 2.8886592-.25090934 4.31479251-.43654526 1.4456944-1.12446284 2.75264211-2.24475926 3.24530633-1.15686816.50904087-2.6789899.08233818-4.22379542-.45126771-1.63924366-.5659043-3.11275757-1.20140931-3.22895359-2.09985055-.07082866-.54634327.37543822-1.16456181.78559634-1.81553374.82401969-1.30740262 1.40638867-2.74399877 2.00310855-4.1815048 1.31611688-.05549862 2.6331596-.24246538 3.78632426-.70010182z%22%2F%3E%0D        %3Cpath fill%3D%22none%22 stroke%3D%22rgb(248%2C151%2C172)%22 stroke-dasharray%3D%220 0 0 0%22 stroke-linecap%3D%22butt%22 stroke-linejoin%3D%22miter%22 stroke-width%3D%22.875%22 d%3D%22M29.98910872 11.714096c-.83092772.0553344-1.66360753.0704256-2.49497327.04682145-.85896114-.02476509-1.71573216-.09093418-2.56812304-.19695949%22%2F%3E%0D        %3Cpath fill%3D%22none%22 stroke%3D%22rgb(248%2C151%2C172)%22 stroke-dasharray%3D%220 0 0 0%22 stroke-linecap%3D%22butt%22 stroke-linejoin%3D%22miter%22 stroke-width%3D%22.875%22 d%3D%22M26.87335742 18.4395077c-.3050173-.31968988-.61359312-.6344157-.92572744-.948645-.71628228-.72079157-1.45239063-1.43612255-2.19002415-2.14698575%22%2F%3E%0D        %3Cpath fill%3D%22rgb(216%2C136%2C163)%22 fill-rule%3D%22evenodd%22 d%3D%22M21.6049431 70.23085105c-.30850454-.55266596-1.03533594-.69398283-1.72297767-.91180887-.8238941-.2610312-1.56849749-.6467272-2.48580883-.59677127-.9246024.05085607-1.99639379.50766065-3.04448919 1.35376167-.81979287-.57696887-.93326063-1.76376065-.3736688-2.92624945.4228837-.87850495 1.21624635-1.66924938 2.10986155-2.18726124 1.50105492-.87085404 3.1392735-.83169934 4.6257462-.41900007 1.26409417.35104196 2.35639184.94646305 2.96565425 2.05179505.54364253.98516771.6675912 2.26602066.08111348 3.56757608-.49898457 1.10668218-1.2877903 1.91407861-1.66556026 1.83126872-.35088413-.07650909-.15129035-1.15708814-.48987073-1.76331062z%22%2F%3E%0D        %3Cpath fill%3D%22rgb(240%2C218%2C219)%22 fill-rule%3D%22evenodd%22 d%3D%22M25.70494983 70.55029047c-.66041696.02646124-1.29594011-.1380056-1.8621512-.42989345-.7185024-.37086451-1.30326184-.9574899-1.69765715-.8040147-.17669688.0687992-.30214195.25850597-.32947625.47833783-.04393021.34847425.18450666.70997556.51886409.97947316.53546.43152174 1.2534743.5292248 1.99198933.39732574.48176756-.08630436.94156998-.300844 1.37843118-.62122858%22%2F%3E%0D        %3Cpath fill%3D%22rgb(240%2C218%2C219)%22 fill-rule%3D%22evenodd%22 d%3D%22M16.84868738 63.16446058c.72871806-.08357585 1.46064027-.08357585 2.1852387-.01292407.85505354.08357578 1.69408639.26968284 2.46491627.6039861.74611204.32353324 1.4180707.78880074 2.08499418 1.26569994.50396891.36015156 1.8044011 1.78438705 2.29509567 2.16133992 1.0029028 5.73442226-1.77831006 3.1366784-2.53403464 2.63910066-.76259063-.50231658-5.27908625-2.813576-6.15519575-3.1349552-.786393-.28820742-1.5791943-.50188582-1.86482247-.98653942-.43256188-.73451956.19499619-1.8554696 1.52380804-2.53570793%22%2F%3E%0D        %3Cpath fill%3D%22rgb(255%2C255%2C255)%22 fill-rule%3D%22evenodd%22 d%3D%22M17.23748435 61.9392l.67808717.31828407c-.1048448.42864611-.25371534.84360728-.45205807 1.23649608-.19879666.3937717-.44025745.76547098-.68489531 1.1367288-.31544215.47852974-.62362237.95617658-1.06751076 1.24355927-.47747503.30945505-1.09020438.41010523-1.69022531.23749905.47339016-.48515142.92136343-.99325818 1.3325729-1.52520312.31453442-.40701513.60728295-.82815659.90093914-1.24929804.32588123-.46749353.6558474-.9314555.98309024-1.39806611%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Cpath fill%3D%22rgb(240%2C218%2C219)%22 fill-rule%3D%22evenodd%22 d%3D%22M40.13772073 41.84992065c.38571653-.60092756 1.17481985-.94223563 2.0431869-1.08026116.25293715-.03990538.50839862-.0610317.75275307-.02065687.27565605.0460085.53162239.16431614.72700498.36008705.33018142.3314491.47053377.86430284.45690243 1.43847033.24839336.05305062.43620298.19811833.53061266.39999244.12268209.26196683.06866158.56806429-.1140994.8539744.3049382-.03568008.56797264.0699517.7224612.28919636.19992637.28403215.14994477.65303927-.08077833 1.00045047.26151984.03755797.47406783.18638146.61492504.37370182.18780962.24835215.24031552.57557593.19285827.92063986-.09541941.69670036-.58210885 1.44034821-1.28740465 1.96944618-.91834864.68871927-2.12800414 1.04176422-3.35886396 1.41687447-.91582432.278868-1.78570597.57510647-2.24159868.3009333-.6553142-.39388923-.38117274-1.80888588-.02372863-3.37270595.23425716-1.02533266.51041808-2.0365811.641178-3.05393266.08431238-.6572645.10905074-1.30467004.4245911-1.79621004%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\");height:50px;left:-50px;position:absolute;width:50px}.covid_banner_content{margin:0 2rem;max-width:50rem;position:relative;text-align:center;z-index:1}@media (max-width:991px){.covid_banner_content{margin:0 auto}}"]
            },] }
];
ElibHeaderCovidBannerComponent.ctorParameters = () => [];

class ElibHeaderModule {
}
ElibHeaderModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibHeaderComponent,
                    ElibHeaderHelpComponent,
                    ElibHeaderCovidBannerComponent
                ],
                imports: [
                    CommonModule,
                    AxaCardModule,
                    AxaHeaderModule,
                    AxaIconModule,
                    TranslateModule,
                    ElibPipesModule
                ],
                exports: [
                    ElibHeaderComponent,
                    ElibHeaderHelpComponent,
                    ElibHeaderCovidBannerComponent
                ]
            },] }
];

class ElibModalComponent {
    constructor(service) {
        this.service = service;
        this.modalClass = true;
        this.show = false;
    }
    ngOnInit() {
        this.service.getModalStatus().subscribe(show => this.show = show);
        this.service.getModalConfig().subscribe(config => this.config = config);
    }
    ngOnDestroy() {
        try {
            this.statusSubscription.unsubscribe();
            this.configSubscription.unsubscribe();
        }
        catch (e) {
            return;
        }
    }
    executeSecondaryAction() {
        this.service.hideModal();
        if (typeof this.config.secondaryAction === 'function') {
            this.config.secondaryAction();
        }
    }
    executePrimaryAction() {
        this.service.hideModal();
        if (typeof this.config.primaryAction === 'function') {
            this.config.primaryAction();
        }
    }
    closeModal() {
        this.service.hideModal();
    }
    getPrimaryActionLabel() {
        return this.config.primaryActionLabel || 'GLOBAL_CLOSE_PU';
    }
}
ElibModalComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-modal',
                template: "<div role=\"button\" tabindex=\"0\" class=\"elib-modal__backdrop\" (click)=\"closeModal()\"></div>\r\n<div class=\"elib-modal__dialog\" role=\"document\">\r\n  <div class=\"elib-modal__dialog__header\" [ngClass]=\"{'elib-border-bottom-none': config.plainMode}\">\r\n    <h5 class=\"elib-modal__dialog__header__title\" [innerHTML]=\"config.title | translate\"></h5>\r\n    <button (click)=\"closeModal()\" type=\"button\" class=\"elib-modal__dialog__header__close\" aria-label=\"Close\">\r\n      <axa-icon name=\"cross-icon\" class=\"axa-cross-icon\"></axa-icon>\r\n    </button>\r\n  </div>\r\n  <div *ngIf=\"!config.template\" class=\"elib-modal__dialog__body\" [innerHTML]=\"config.content | translate\"></div>\r\n  <div *ngIf=\"config.template\" class=\"elib-modal__dialog__body\">\r\n    <ng-container *ngTemplateOutlet=\"config.content\"></ng-container>\r\n  </div>\r\n\r\n  <div class=\"elib-modal__dialog__footer\" *ngIf=\"!config.plainMode\">\r\n    <button *ngIf=\"config.secondaryActionLabel\" (click)=\"executeSecondaryAction()\" axa-button small ghost type=\"button\" class=\"elib-modal__dialog__footer__btn elib-modal__dialog__footer__btn--secondary\">{{ config.secondaryActionLabel | translate }}</button>\r\n    <button (click)=\"executePrimaryAction()\" axa-button small type=\"button\" class=\"elib-modal__dialog__footer__btn elib-modal__dialog__footer__btn--primary\" [disabled]=\"config.disabledPrimaryAction\">{{ getPrimaryActionLabel() | translate }}</button>\r\n  </div>\r\n</div>\r\n\r\n\r\n\r\n",
                styles: [":host{align-items:center;display:flex;height:100%;justify-content:center;left:0;opacity:0;pointer-events:none;position:fixed;top:0;transition:opacity .3s;width:100%;z-index:9999}:host.elib-modal--show{opacity:1;pointer-events:auto}:host.elib-modal--show .elib-modal__backdrop{-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px)}.elib-modal__backdrop{background:rgba(0,0,0,.5);height:100%;left:0;position:absolute;top:0;transition:-webkit-backdrop-filter .3s;transition:backdrop-filter .3s;transition:backdrop-filter .3s,-webkit-backdrop-filter .3s;width:100%;z-index:1}.elib-modal__dialog{background:#fff;border-radius:5px;box-shadow:0 0 15px rgba(0,0,0,.5);display:flex;flex-direction:column;max-height:90%;max-width:40rem;position:relative;width:90%;z-index:2}.elib-modal__dialog__header{border-bottom:1px solid #ccc;padding:.5rem 1rem;position:relative}.elib-modal__dialog__header__title{font-size:1.6rem!important;font-weight:400!important;line-height:1.6}.elib-modal__dialog__header__close{background:transparent;border:none;color:#000;cursor:pointer;font-size:1.5rem;font-weight:700;line-height:1;opacity:.5;position:absolute;right:1rem;text-shadow:0 1px 0 #fff;top:1rem}.elib-modal__dialog__body{border-bottom:1px solid #ccc;overflow-y:auto;padding:2em}.elib-modal__dialog__footer{display:flex;flex-wrap:wrap;justify-content:flex-end;padding:1rem}.elib-modal__dialog__footer__btn{margin:0 .5rem 0 0}.elib-modal__dialog__footer__btn:last-child{margin-right:0}.elib-modal__dialog__header__close:focus{outline:none!important}.elib-border-bottom-none{border-bottom:none!important}"]
            },] }
];
ElibModalComponent.ctorParameters = () => [
    { type: ElibModalService }
];
ElibModalComponent.propDecorators = {
    modalClass: [{ type: HostBinding, args: ['class.elib-modal',] }],
    show: [{ type: HostBinding, args: ['class.elib-modal--show',] }]
};

class ElibModalModule {
}
ElibModalModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibModalComponent
                ],
                imports: [
                    CommonModule,
                    AxaIconModule,
                    TranslateModule,
                    AxaButtonModule
                ],
                exports: [
                    ElibModalComponent
                ]
            },] }
];

class ElibNavigationComponent {
    constructor(cdRef, sharedService, router, activatedRoute) {
        this.cdRef = cdRef;
        this.sharedService = sharedService;
        this.router = router;
        this.activatedRoute = activatedRoute;
    }
    ngOnInit() {
        this.chapters = this.sharedService.chapters;
        this.router.events.pipe(filter(e => e instanceof NavigationEnd), map(() => {
            let route = this.activatedRoute.firstChild;
            let child = route;
            while (child) {
                if (child.firstChild) {
                    child = child.firstChild;
                    route = child;
                }
                else {
                    child = null;
                }
            }
            return route;
        }), mergeMap(route => route.data))
            .subscribe(data => {
            this.currentRoute = data;
            this.selectedTotalSubSteps = this.currentRoute && this.currentRoute.chapter ? this.currentRoute.chapter.subSteps : 1;
            this.selectedPage = this.currentRoute && this.currentRoute.chapter ? this.currentRoute.chapter.number : 1;
            this.cdRef.detectChanges();
        });
        this.selectedPage = 1;
    }
    getProgress() {
        const totalSteps = this.chapters.length;
        const pageNumber = this.selectedPage - 1;
        const currentSubstep = this.currentRoute ? this.currentRoute.subStep : 1;
        const singleStepProportion = 100 / totalSteps;
        return (pageNumber + ((totalSteps === this.selectedPage && this.selectedTotalSubSteps === currentSubstep ? currentSubstep : currentSubstep - 1) / this.selectedTotalSubSteps)) * singleStepProportion;
    }
    isDisabled(chapterNumber) {
        return chapterNumber > this.selectedPage;
    }
}
ElibNavigationComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-navigation',
                template: "<div class=\"elib-navigation\">\r\n  <div class=\"elib-navigation__chapters\">\r\n    <div class=\"elib-navigation__chapters__chapter\" *ngFor =\"let chapter of chapters\" [class.elib-navigation__chapters__chapter--active]=\"selectedPage === chapter.number\" [class.elib-navigation__chapters__chapter--disabled]=\"isDisabled(chapter.number)\">\r\n      <div class=\"elib-navigation__chapters__chapter__number\">{{ chapter.number }}</div>\r\n      <div class=\"elib-navigation__chapters__chapter__name\">{{ 'ELIB_NAVIGATION_CHAPTER_' + chapter.number | translate }}</div>\r\n    </div>\r\n  </div>\r\n  <div class=\"elib-navigation__progress\">\r\n    <div class=\"elib-navigation__progress_bar\" [style.width.%]=\"getProgress()\"></div>\r\n  </div>\r\n</div>\r\n",
                styles: [".elib-navigation{background:#4976ba;color:#fff;font-size:13px}@media (max-width:991px){.elib-navigation{margin:0 0 0 50%;transform:translateX(-50%);width:100vw}}.elib-navigation__chapters{display:flex;justify-content:center}.elib-navigation__chapters__chapter{align-items:center;display:flex;flex-grow:1;justify-content:center;max-width:16rem;min-width:20%;overflow:hidden;padding:1rem;position:relative}.elib-navigation__chapters__chapter:after,.elib-navigation__chapters__chapter:before{border-top:1px solid #eee;bottom:50%;content:\"\";opacity:.3;position:absolute;right:0;transform:rotate(60deg);transform-origin:right;width:5rem}.elib-navigation__chapters__chapter:after{transform:rotate(-60deg)}.elib-navigation__chapters__chapter:last-child:after,.elib-navigation__chapters__chapter:last-child:before{content:none}.elib-navigation__chapters__chapter__number{align-items:center;background:#fff;border:1px solid #fff;border-radius:50%;color:#4976ba;display:flex;height:22px;justify-content:center;margin-right:1rem;width:22px}@media (max-width:991px){.elib-navigation__chapters__chapter__name{display:none}}.elib-navigation__progress{background:#d8d8d8;height:4px;width:100%}.elib-navigation__progress_bar{background:#f07662;display:block;height:100%;transition:width .3s;width:0}.elib-navigation__chapters__chapter--active{font-weight:700}.elib-navigation__chapters__chapter--disabled{color:hsla(0,0%,100%,.3)}.elib-navigation__chapters__chapter--disabled .elib-navigation__chapters__chapter__number{background:transparent;border:1px solid;color:inherit}"]
            },] }
];
ElibNavigationComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: ElibSharedService },
    { type: Router },
    { type: ActivatedRoute }
];

class ElibNavigationModule {
}
ElibNavigationModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibNavigationComponent
                ],
                imports: [
                    CommonModule,
                    TranslateModule
                ],
                exports: [
                    ElibNavigationComponent
                ]
            },] }
];

class ElibSideBarService {
    constructor() {
        this.data = new BehaviorSubject({
            packName: '',
            covers: [],
            options: []
        });
    }
    // SIDE-BAR DATA
    setData(data) {
        this.data.next(data);
    }
    getData() {
        return this.data.asObservable();
    }
}
ElibSideBarService.ɵprov = ɵɵdefineInjectable({ factory: function ElibSideBarService_Factory() { return new ElibSideBarService(); }, token: ElibSideBarService, providedIn: "root" });
ElibSideBarService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ElibSideBarService.ctorParameters = () => [];

const browserGlobals$1 = {
    windowRef() {
        return window;
    },
    documentRef() {
        return document;
    }
};
class ElibCaptchaService {
    constructor(config) {
        this.config = config;
        this.document = browserGlobals$1.documentRef();
        this.initRecaptchaDom();
    }
    initRecaptchaDom() {
        const recaptchaScript = this.document.createElement('script');
        recaptchaScript.src = `https://www.google.com/recaptcha/api.js?render=${this.config.settings.recaptchaId}`;
        this.document.head.insertBefore(recaptchaScript, this.document.head.firstChild);
    }
    verifyRecaptcha() {
        return new Promise((resolve, reject) => {
            window.grecaptcha.ready(() => {
                window.grecaptcha.execute(this.config.settings.recaptchaId, { action: 'submit' }).then((token) => {
                    resolve();
                }).catch((err) => reject(err));
            });
        });
    }
}
ElibCaptchaService.ɵprov = ɵɵdefineInjectable({ factory: function ElibCaptchaService_Factory() { return new ElibCaptchaService(ɵɵinject(AxaAppConfig)); }, token: ElibCaptchaService, providedIn: "root" });
ElibCaptchaService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ElibCaptchaService.ctorParameters = () => [
    { type: AxaAppConfig }
];

const interceptService = [ElibHTTPListener, ElibHTTPStatus];
class ElibAppWrapperModule {
    static forRoot(config) {
        return {
            ngModule: ElibAppWrapperModule,
            providers: [
                ...interceptService,
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: ElibHTTPListener,
                    multi: true,
                },
                AxaAlertService,
                ElibModalService,
                ElibDataLayerService,
                ElibSharedService,
                ElibSideBarService,
                ElibCaptchaService,
                {
                    provide: ELIB_SHARED_CONFIG,
                    useValue: config
                },
                // { provide: APP_INITIALIZER, useFactory: initializeAxaConfig, deps: [AxaAppConfig], multi: true }
                AxaAppConfig,
                { provide: APP_INITIALIZER, useFactory: initializeAxaConfig, deps: [AxaAppConfig], multi: true },
                {
                    provide: AXA_OAUTH_ENDPOINT_KEY,
                    useFactory(c) { return c.settings.AXA_OAUTH_ENDPOINT_KEY; },
                    deps: [AxaAppConfig]
                },
                {
                    provide: AXA_OAUTH_SCOPE_KEY,
                    useFactory(c) { return c.settings.AXA_OAUTH_SCOPE_KEY; },
                    deps: [AxaAppConfig]
                },
                {
                    provide: AXA_OAUTH_CLIENTID_KEY,
                    useFactory(c) { return c.settings.AXA_OAUTH_CLIENTID_KEY; },
                    deps: [AxaAppConfig]
                },
                {
                    provide: AXA_OAUTH_CALLBACK_KEY,
                    useFactory(c) { return c.settings.AXA_OAUTH_CALLBACK_KEY; },
                    deps: [AxaAppConfig]
                },
                {
                    provide: AXA_OAUTH_TOKEN_KEY,
                    useFactory(c) { return c.settings.AXA_OAUTH_TOKEN_KEY; },
                    deps: [AxaAppConfig]
                },
                {
                    provide: AXA_OAUTH_RESPONSE_TYPE,
                    useFactory(c) { return c.settings.AXA_OAUTH_RESPONSE_TYPE; },
                    deps: [AxaAppConfig]
                },
                { provide: AXA_ERROR_CLOSE_STRING, useValue: 'Close' },
                { provide: AXA_ERROR_TITLE_STRING, useValue: 'Failure' }
            ]
        };
    }
}
ElibAppWrapperModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibAppWrapperComponent
                ],
                imports: [
                    CommonModule,
                    HttpClientModule,
                    TranslateModule,
                    AxaAlertModule,
                    AxaBusyModule,
                    ElibFooterModule,
                    ElibHeaderModule,
                    ElibModalModule,
                    ElibNavigationModule
                ],
                exports: [
                    ElibAppWrapperComponent
                ]
            },] }
];

class ElibBrokerCardComponent {
    constructor() { }
    ngOnInit() {
    }
}
ElibBrokerCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-broker-card',
                template: "<axa-card content class=\"elib-broker-card axa-card--transparent\">\r\n  <axa-card-content compact>\r\n    <h1>{{ 'ELIB_BROKER_CARD_TITLE' | translate }}</h1>\r\n    <div class=\"elib-flag-content\">\r\n      <img class=\"elib-broker-card__image elib-round-image elib-flag-content__head\" src=\"assets/BrowkersAXA_icon.svg\" alt=\"\">\r\n      <div class=\"elib-flag-content__body\">\r\n        <p [innerHTML]=\"'ELIB_BROKER_CARD_CONTENT' | translate\"></p>\r\n        <a class=\"cover-card__more-link axa-links\" axa-arrow-link>\r\n          <!-- <span>{{ 'ELIB_BROKER_CARD_ACTION' | translate }}</span>-->\r\n           \r\n          <elib-header-help [helpLinkLabel] =\"'ELIB_BROKER_CARD_ACTION'\" [showPhoneIcon]=\"'no'\"></elib-header-help>\r\n          <axa-icon name=\"rightarrow-blue\" class=\"right-icon\"></axa-icon>\r\n        </a>\r\n      </div>\r\n    </div>\r\n  </axa-card-content>\r\n</axa-card>\r\n",
                styles: [":host{display:block;margin:2rem auto 0;max-width:40rem}.elib-broker-card h1{font-family:initial;font-size:2.5em;font-weight:700;margin-bottom:1rem}.elib-broker-card h2{font-size:1.25rem;font-weight:400}.elib-broker-card .axa-links{margin-top:.5rem}.elib-broker-card p:last-of-type{margin-bottom:.5rem}.elib-broker-card .elib-flag-content{flex-wrap:wrap;justify-content:center}.elib-broker-card__image{height:5rem;margin-bottom:1rem;width:5rem}"]
            },] }
];
ElibBrokerCardComponent.ctorParameters = () => [];
ElibBrokerCardComponent.propDecorators = {
    name: [{ type: Input }]
};

class ElibBrokerCardModule {
}
ElibBrokerCardModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibBrokerCardComponent
                ],
                imports: [
                    CommonModule,
                    AxaCardModule,
                    AxaButtonModule,
                    AxaIconModule,
                    TranslateModule,
                    ElibHeaderModule
                ],
                exports: [
                    ElibBrokerCardComponent
                ]
            },] }
];

class ElibCoverCardsComponent {
    constructor() {
        this.selection = new EventEmitter();
    }
    ngOnInit() {
    }
    handleSelection(data) {
        this.selection.emit(data);
    }
}
ElibCoverCardsComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-cover-cards',
                template: "<axa-card content>\r\n  <axa-card-title>\r\n    <h1>\r\n      <span [innerHTML]=\"data.title | translate\"></span>\r\n      <small [innerHTML]=\"data.subTitle | translate\"></small>\r\n    </h1>\r\n  </axa-card-title>\r\n\r\n  <elib-cover-card *ngFor=\"let cover of data.covers\" [data]=\"cover\" [applied]=\"appliedOptions[cover.id]\" (selection)=\"handleSelection($event)\"></elib-cover-card>\r\n</axa-card>\r\n",
                encapsulation: ViewEncapsulation.None,
                styles: ["@charset \"UTF-8\";@import \"~@ng-select/ng-select/themes/default.theme.css\";.h1,.type-main-title,h1{font-size:3.2857142857rem;font-weight:900;letter-spacing:-.01em;line-height:1.13;margin-bottom:1.5rem}@media (min-width:768px){.h1,.type-main-title,h1{font-size:4.875rem;line-height:1.05;margin-bottom:1.75rem}}.type-main-title--serif{font-family:\"PT Serif\",serif;font-size:3.2857142857rem;font-weight:900;letter-spacing:.02em;line-height:1.13;margin-bottom:1.5rem}@media (min-width:768px){.type-main-title--serif{font-size:4.875rem;line-height:1.05;margin-bottom:1.75rem}}.h2,.type-page-title,h2{font-size:2.8571428571rem;font-weight:900;letter-spacing:-.01em;line-height:1.1;margin-bottom:1.1428571429rem}@media (min-width:768px){.h2,.type-page-title,h2{font-size:3.875rem;line-height:1.16;margin-bottom:1.625rem}}.type-page-title--serif{font-family:\"PT Serif\",serif;font-size:2.8571428571rem;font-weight:900;letter-spacing:.02em;line-height:1.1;margin-bottom:1.1428571429rem}@media (min-width:768px){.type-page-title--serif{font-size:3.875rem;line-height:1.16;margin-bottom:1.625rem}}.h3,.type-slice-title,h3{font-size:2.1428571429rem;font-weight:900;letter-spacing:-.01em;line-height:1.13;margin-bottom:1rem}@media (min-width:768px){.h3,.type-slice-title,h3{font-size:3rem;margin-bottom:1.125rem}}.type-slice-title--serif{font-family:\"PT Serif\",serif;font-size:2.1428571429rem;font-weight:900;letter-spacing:.02em;line-height:1.13;margin-bottom:1rem}@media (min-width:768px){.type-slice-title--serif{font-size:3rem;margin-bottom:1.125rem}}.h4,.type-small-module-title,h4{font-size:1.7142857143rem;font-weight:900;letter-spacing:-.01em;line-height:1.17;margin-bottom:1rem}@media (min-width:768px){.h4,.type-small-module-title,h4{font-size:2.25rem;margin-bottom:1rem}}.type-small-module-title--serif{font-family:\"PT Serif\",serif;font-size:1.7142857143rem;font-weight:900;letter-spacing:.02em;line-height:1.17;margin-bottom:1rem}@media (min-width:768px){.type-small-module-title--serif{font-size:2.25rem;margin-bottom:1rem}}.h5,.type-title,h5{font-size:1.4285714286rem;font-weight:700;letter-spacing:-.01em;line-height:1.5;margin-bottom:1rem}@media (min-width:768px){.h5,.type-title,h5{font-size:1.75rem;line-height:1.14;margin-bottom:1rem}}.type-title--serif{font-family:\"PT Serif\",serif;font-size:1.4285714286rem;font-weight:700;letter-spacing:.02em;line-height:1.5;margin-bottom:1rem}@media (min-width:768px){.type-title--serif{font-size:1.75rem;line-height:1.14;margin-bottom:1rem}}.h6,.type-item-highlight,h6{font-size:1.1428571429rem;font-weight:600;letter-spacing:0;line-height:1.5;margin-bottom:1rem}@media (min-width:768px){.h6,.type-item-highlight,h6{font-size:1.5rem;line-height:1.2;margin-bottom:1rem}}.lead,.type-text-intro{font-size:1.1428571429rem;font-weight:400;letter-spacing:.01em;line-height:1.5;margin-bottom:1rem}@media (min-width:768px){.lead,.type-text-intro{font-size:1.25rem;margin-bottom:1rem}}.axa-btn,.type-text{font-size:1rem;font-weight:400;letter-spacing:.01em;line-height:1.5;margin-bottom:1rem}@media (min-width:768px){.axa-btn,.type-text{font-size:1.125rem;margin-bottom:1rem}}.type-secondary-text{font-size:.8571428571rem;font-weight:400;letter-spacing:.02em;line-height:1.5;margin-bottom:.8571428571rem}@media (min-width:768px){.type-secondary-text{font-size:1rem;margin-bottom:1rem}}.type-tag{font-size:.8571428571rem;font-weight:400;letter-spacing:.02em;line-height:1.5;margin-bottom:.8571428571rem}@media (min-width:768px){.type-tag{font-size:.875rem;line-height:1.21;margin-bottom:.875rem}}.type-legal{font-size:.8571428571rem;font-weight:400;letter-spacing:.02em;line-height:1.5;margin-bottom:.8571428571rem}@media (min-width:768px){.type-legal{font-size:.8125rem;line-height:1.38;margin-bottom:.8125rem}}@-webkit-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@-webkit-keyframes fadeInHalf{0%{opacity:0}to{opacity:.5}}@keyframes fadeInHalf{0%{opacity:0}to{opacity:.5}}body,html{background:#fafafa;box-sizing:border-box;font-family:Source Sans Pro,Arial,sans-serif;font-size:16px;margin:0;overflow-x:hidden}*,:after,:before{box-sizing:inherit}.content-wrapper{margin-left:auto;margin-right:auto;max-width:100%;position:relative;width:calc(100% - 20px)}@media (min-width:576px){.content-wrapper{max-width:100%;width:536px}}@media (min-width:768px){.content-wrapper{max-width:100%;width:728px}}@media (min-width:992px){.content-wrapper{max-width:100%;width:952px}}@media (min-width:1200px){.content-wrapper{max-width:100%;width:1160px}}.container-unwrap{margin-left:calc(50% - 50vw);margin-right:calc(50% - 50vw);max-width:none;width:100vw}.axa-layout{display:flex;flex-wrap:wrap}.axa-layout__cell{flex-basis:96.6666666667px;flex-grow:1;max-width:100%}.col-1{width:96.6666666667px}.col-2{width:193.3333333333px}.col-3{width:290px}.col-4{width:386.6666666667px}.col-5{width:483.3333333333px}.col-6{width:580px}.col-7{width:676.6666666667px}.col-8{width:773.3333333333px}.col-9{width:870px}.col-10{width:966.6666666667px}.col-11{width:1063.3333333333px}.col-12{width:1160px}.col-half{width:100%/2}.col-third{width:100%/3}.col-quarter{width:100%/4}.col-fifth{width:100%/5}.col-sixth{width:100%/6}@media (min-width:576px){.col-1-sm{width:96.6666666667px}.col-2-sm{width:193.3333333333px}.col-3-sm{width:290px}.col-4-sm{width:386.6666666667px}.col-5-sm{width:483.3333333333px}.col-6-sm{width:580px}.col-7-sm{width:676.6666666667px}.col-8-sm{width:773.3333333333px}.col-9-sm{width:870px}.col-10-sm{width:966.6666666667px}.col-11-sm{width:1063.3333333333px}.col-12-sm{width:1160px}.col-half-sm{width:100%/2}.col-third-sm{width:100%/3}.col-quarter-sm{width:100%/4}.col-fifth-sm{width:100%/5}.col-sixth-sm{width:100%/6}}@media (min-width:768px){.col-1-md{width:96.6666666667px}.col-2-md{width:193.3333333333px}.col-3-md{width:290px}.col-4-md{width:386.6666666667px}.col-5-md{width:483.3333333333px}.col-6-md{width:580px}.col-7-md{width:676.6666666667px}.col-8-md{width:773.3333333333px}.col-9-md{width:870px}.col-10-md{width:966.6666666667px}.col-11-md{width:1063.3333333333px}.col-12-md{width:1160px}.col-half-md{width:100%/2}.col-third-md{width:100%/3}.col-quarter-md{width:100%/4}.col-fifth-md{width:100%/5}.col-sixth-md{width:100%/6}}@media (min-width:992px){.col-1-lg{width:96.6666666667px}.col-2-lg{width:193.3333333333px}.col-3-lg{width:290px}.col-4-lg{width:386.6666666667px}.col-5-lg{width:483.3333333333px}.col-6-lg{width:580px}.col-7-lg{width:676.6666666667px}.col-8-lg{width:773.3333333333px}.col-9-lg{width:870px}.col-10-lg{width:966.6666666667px}.col-11-lg{width:1063.3333333333px}.col-12-lg{width:1160px}.col-half-lg{width:100%/2}.col-third-lg{width:100%/3}.col-quarter-lg{width:100%/4}.col-fifth-lg{width:100%/5}.col-sixth-lg{width:100%/6}}@media (min-width:1200px){.col-1-xl{width:96.6666666667px}.col-2-xl{width:193.3333333333px}.col-3-xl{width:290px}.col-4-xl{width:386.6666666667px}.col-5-xl{width:483.3333333333px}.col-6-xl{width:580px}.col-7-xl{width:676.6666666667px}.col-8-xl{width:773.3333333333px}.col-9-xl{width:870px}.col-10-xl{width:966.6666666667px}.col-11-xl{width:1063.3333333333px}.col-12-xl{width:1160px}.col-half-xl{width:100%/2}.col-third-xl{width:100%/3}.col-quarter-xl{width:100%/4}.col-fifth-xl{width:100%/5}.col-sixth-xl{width:100%/6}}mt-0{margin-top:0}mr-0{margin-right:0}mb-0{margin-bottom:0}ml-0{margin-left:0}mt-1{margin-top:1rem}mr-1{margin-right:1rem}mb-1{margin-bottom:1rem}ml-1{margin-left:1rem}mt-2{margin-top:2rem}mr-2{margin-right:2rem}mb-2{margin-bottom:2rem}ml-2{margin-left:2rem}mt-3{margin-top:3rem}mr-3{margin-right:3rem}mb-3{margin-bottom:3rem}ml-3{margin-left:3rem}mt-4{margin-top:4rem}mr-4{margin-right:4rem}mb-4{margin-bottom:4rem}ml-4{margin-left:4rem}pt-0{padding-top:0}pr-0{padding-right:0}pb-0{padding-bottom:0}pl-0{padding-left:0}pt-1{padding-top:1rem}pr-1{padding-right:1rem}pb-1{padding-bottom:1rem}pl-1{padding-left:1rem}pt-2{padding-top:2rem}pr-2{padding-right:2rem}pb-2{padding-bottom:2rem}pl-2{padding-left:2rem}pt-3{padding-top:3rem}pr-3{padding-right:3rem}pb-3{padding-bottom:3rem}pl-3{padding-left:3rem}pt-4{padding-top:4rem}pr-4{padding-right:4rem}pb-4{padding-bottom:4rem}pl-4{padding-left:4rem}body,html{color:#333;font-family:Source Sans Pro,arial,sans-serif;font-size:14px;font-weight:400;letter-spacing:.01em;line-height:1.5}@media (min-width:768px){body,html{font-size:16px}}address,blockquote,dl,h1,h2,h3,h4,h5,h6,ol,p,pre,ul{margin:0}p{margin:0 0 1.5rem;max-width:45rem}strong{font-weight:900}abbr[data-original-title],abbr[title]{cursor:help}dl,ol,ul{line-height:2;margin-bottom:1rem}ol ol,ol ul,ul ol,ul ul{margin-bottom:0}dt{font-weight:700}dd{margin-bottom:.5rem;margin-left:0}blockquote{margin-bottom:1rem}a{color:#00008f;text-decoration:none}a:focus,a:hover{color:#00005b;text-decoration:underline}pre{margin-bottom:1rem;overflow:auto}@-webkit-keyframes animate-arrow-right{0%{opacity:1;transform:translate(0) scale(1);transform:translateZ(0) scale(1)}50%{opacity:0;transform:translate(10px) scaleX(1.3);transform:translate3d(10px,0,0) scaleX(1.3)}51%{opacity:0;transform:translate(-10px) scaleX(1.3);transform:translate3d(-10px,0,0) scaleX(1.3)}to{opacity:1;transform:translate(0) scale(1);transform:translateZ(0) scale(1)}}@keyframes animate-arrow-right{0%{opacity:1;transform:translate(0) scale(1);transform:translateZ(0) scale(1)}50%{opacity:0;transform:translate(10px) scaleX(1.3);transform:translate3d(10px,0,0) scaleX(1.3)}51%{opacity:0;transform:translate(-10px) scaleX(1.3);transform:translate3d(-10px,0,0) scaleX(1.3)}to{opacity:1;transform:translate(0) scale(1);transform:translateZ(0) scale(1)}}.axa-btn{align-items:center;background:#00008f;border:1px solid #00008f;border-bottom-color:#00005b;border-radius:0;color:#fff;cursor:pointer;display:inline-flex;font-family:Source Sans Pro,arial,sans-serif;letter-spacing:.08em;overflow:hidden;padding:calc(15px - .75em) 20px;position:relative;text-decoration:none;text-transform:uppercase;transition:all .3s;vertical-align:middle;z-index:0}.axa-btn:after{background:#00005b;content:\"\";height:100%;left:50%;opacity:0;position:absolute;top:50%;transform:translate(-50%,-50%) skew(-30deg);transition:all .3s;width:0;z-index:-1}.axa-btn:focus{outline:1px dotted #3b3fd8;outline:3px auto -webkit-focus-ring-color}.axa-btn:hover{border-color:#00005b;color:#fff;text-decoration:none}.axa-btn:hover:after{opacity:1;width:calc(100% + 2rem)}@media (min-width:768px){.axa-btn{padding:calc(20px - .75em) 20px}}.axa-btn--alt{background:#f07662;border-color:#f07662}.axa-btn--alt:after{background:#ec4d33}.axa-btn--alt:hover{border-color:#ec4d33;color:#fff}.axa-btn--neg{background:transparent;border-color:#fff}.axa-btn--neg:after{background:#fff}.axa-btn--neg:hover{border-color:#fff;color:#3b3fd8}.axa-btn--ghost{background:transparent;color:#00008f}.axa-btn--ghost.axa-btn--alt{color:#f07662}.axa-btn--ghost.axa-btn--alt:hover{color:#fff}.axa-btn--sm{font-size:.8571428571rem;font-weight:400;letter-spacing:.02em;letter-spacing:.04em;line-height:1.5;padding:calc(15px - .75em) 20px}@media (min-width:768px){.axa-btn--sm{font-size:.875rem;line-height:1.21}}.axa-btn--lg{padding:calc(20px - .75em) 20px}@media (min-width:768px){.axa-btn--lg{padding:calc(25px - .75em) 20px}}.axa-btn .axa-icon{fill:currentColor;height:16px;margin-bottom:-1px;margin-left:10px;margin-right:-10px;width:16px}.axa-btn--icon-left .axa-icon{margin-left:-10px;margin-right:10px}.axa-btn:hover .axa-icon svg{-webkit-animation:animate-arrow-right .4s cubic-bezier(.77,0,.175,1);animation:animate-arrow-right .4s cubic-bezier(.77,0,.175,1)}.axa-btn--split .axa-icon:before{border-left:1px solid;content:\"\";height:100%;opacity:.5;position:absolute;right:0;top:0;width:40px}.axa-btn--split .axa-icon{margin-left:30px}.axa-btn--split.axa-btn--sm .axa-icon{margin-left:20px;margin-right:-15px}.axa-btn--split.axa-btn--sm .axa-icon:before{width:30px}.axa-btn--split.axa-btn--lg .axa-icon{margin-left:40px;margin-right:-5px}.axa-btn--split.axa-btn--lg .axa-icon:before{width:50px}.axa-btn--split.axa-btn--icon-left .axa-icon{margin-left:-8px;margin-right:30px}.axa-btn--split.axa-btn--icon-left .axa-icon:before{border-left:none;border-right:1px solid;left:0;right:auto}.axa-btn--split.axa-btn--icon-left.axa-btn--sm .axa-icon{margin-left:-13px;margin-right:20px}.axa-btn--split.axa-btn--icon-left.axa-btn--lg .axa-icon{margin-left:-3px;margin-right:40px}.axa-btn[disabled]{background:#ccc;border-color:#ccc;color:#999;cursor:default}.axa-btn[disabled]:after{content:none}.axa-btn[disabled]:hover{background:#ccc;border-color:#ccc;color:#999;outline:none}.axa-btn[disabled]:hover .axa-icon{-webkit-animation:none;animation:none}.axa-form{background-color:transparent}.axa-form fieldset{border:0;border-top:1px solid #ccc;margin:15px 0 0;min-width:0;padding:0}@media (min-width:576px){.axa-form fieldset{margin-top:25px}}.axa-form legend{background-color:transparent;color:#5f5f5f;display:block;font-size:1.1428571429rem;font-size:1.5rem;font-weight:400;letter-spacing:.01em;line-height:1.5;margin-bottom:.5rem;margin-left:15px;max-width:100%;padding:0 15px;white-space:normal;width:auto}@media (min-width:768px){.axa-form legend{font-size:1.25rem}}@media (min-width:576px){.axa-form legend{margin-bottom:20px;margin-left:30px;padding-left:20px;padding-right:20px}}.axa-form-group{display:flex;flex-wrap:wrap;margin-bottom:1rem;max-width:350px;position:relative}.axa-form-group label{color:#333;display:inline-block;flex-basis:100%;font-size:18px;letter-spacing:.01em;line-height:1.5;margin-bottom:3px;touch-action:manipulation}@media (min-width:576px){.axa-form-group label{margin-bottom:8px}}.axa-form-control-feedback{flex-basis:100%}.axa-form-group--has-danger .axa-form-control-feedback{color:#c91432}input,select{margin:0;overflow:visible;touch-action:manipulation}[type=checkbox],[type=radio]{padding:0}.axa-form-control{background-clip:padding-box;background-color:#fff;background-image:none;border:1px solid #ccc;border-radius:0;box-shadow:inset 0 1px 1px rgba(0,0,0,.075);color:#333;display:block;flex-grow:1;font-size:18px;height:50px;letter-spacing:.01em;line-height:1.5;outline:0;padding:.625rem 20px;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;width:120px;z-index:1}.axa-form-control::-ms-expand{background-color:transparent;border:0}.axa-form-control:focus{background-color:#fff;border-color:#3032c1;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 5px rgba(48,50,193,.6);color:#3032c1;outline:none}.axa-form-control:focus::-ms-value{background-color:#fff;color:#333}.axa-form-control::-moz-placeholder{color:#7f7f7f;opacity:1}.axa-form-control::placeholder{color:#7f7f7f;opacity:1}.axa-form-control:disabled,.axa-form-control[readonly]{background-color:#ccc;opacity:1}.axa-form-control:disabled{cursor:not-allowed}.axa-form-control::-ms-expand{opacity:0}.axa-form-group--has-danger .axa-form-control{border-color:#c91432;color:#c91432}.axa-form-group--has-danger .axa-form-control:focus{box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 5px rgba(201,20,50,.6)}.clear[clearable]:after{right:62px}.clear-suffix[clearable]:after,.clear[clearable]:after{color:#000;content:\"\u2716\";cursor:pointer;position:absolute;top:50px;z-index:1}.clear-suffix[clearable]:after{right:18px}.custom-select{-moz-appearance:none;-webkit-appearance:none;background:#fff url(\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2210%22%20height%3D%227%22%3E%0D%0A%20%20%3Cpath%20fill-rule%3D%22evenodd%22%20fill%3D%22%23999%22%20d%3D%22M9.754%201.451L5.573%205.756c-.322.331-.844.331-1.166%200L.226%201.451c-.322-.332-.322-.87%200-1.202.321-.331.844-.331%201.166%200L4.99%203.954%208.588.249c.322-.331.844-.331%201.166%200%20.322.332.322.87%200%201.202z%22%2F%3E%0D%0A%3C%2Fsvg%3E\") no-repeat right 10px center;background-clip:padding-box;background-color:#fff;background-image:none;background-size:12px 8px;border:1px solid #ccc;border-radius:0;box-shadow:inset 0 1px 1px rgba(0,0,0,.075);color:#333;display:block;flex-grow:1;font-size:18px;height:50px;letter-spacing:.01em;line-height:1.5;outline:0;padding:.625rem 20px;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;width:120px}.custom-select::-ms-expand{background-color:transparent;border:0}.custom-select:focus{background-color:#fff;border-color:#3032c1;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 5px rgba(48,50,193,.6);color:#3032c1;outline:none}.custom-select:focus::-ms-value{background-color:#fff;color:#333}.custom-select::-moz-placeholder{color:#7f7f7f;opacity:1}.custom-select::placeholder{color:#7f7f7f;opacity:1}.custom-select:disabled,.custom-select[readonly]{background-color:#ccc;opacity:1}.custom-select:disabled{cursor:not-allowed}.custom-select::-ms-expand{opacity:0}.axa-form-group--has-danger .custom-select{border-color:#c91432;color:#c91432}.axa-form-group--has-danger .custom-select:focus{box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 5px rgba(201,20,50,.6)}.axa-form-field-prefix,.axa-form-field-suffix{align-items:center;background:#f5f5f5;border:1px solid #ccc;display:flex;margin-right:-1px;padding:0 1rem}.axa-form-field-prefix .axa-form-control,.axa-form-field-prefix .custom-select,.axa-form-field-suffix .axa-form-control,.axa-form-field-suffix .custom-select{margin:-1px calc(-1px - 1rem)}.axa-form-field-prefix .custom-control,.axa-form-field-suffix .custom-control{margin:0;padding:0}.axa-form-field-suffix{margin-left:-1px;margin-right:-1px}.custom-control{cursor:pointer;display:inline-flex;margin-right:1rem;min-height:1.6rem;padding-left:1.5rem;position:relative}.custom-control-input{opacity:0;position:absolute;z-index:-1}.custom-control-input:checked~.custom-control-indicator{box-shadow:none}.custom-control-input:focus~.custom-control-indicator{box-shadow:inset 0 1px 2px rgba(0,0,0,.075),0 0 5px rgba(48,50,193,.5)}.custom-control-input:active~.custom-control-indicator{background-color:#3032c1;box-shadow:none;color:#fff}.custom-control-input:disabled~.custom-control-indicator{background-color:#e5e5e5;cursor:not-allowed}.custom-control-input:disabled~.custom-control-description{color:#5f5f5f;cursor:not-allowed!important}.custom-control-indicator{-moz-user-select:none;-webkit-user-select:none;background-color:#ddd;background-position:50%;background-repeat:no-repeat;background-size:50% 50%;display:block;height:1rem;left:0;pointer-events:none;position:absolute;top:.3rem;user-select:none;width:1rem}.custom-control-input:checked~.custom-control-indicator{background-color:#494df4;color:#fff}.custom-radio.radio1{margin-right:1px;padding:0}.custom-radio.radio1 .custom-control-indicator{display:none}.custom-radio.radio1 .custom-control-description{background:#e5e5e5;border:solid #999;border-width:1px 1px 2px;color:#333;cursor:pointer;display:block;font-family:Source Sans Pro,Arial,sans-serif;font-size:13px;font-weight:600;letter-spacing:.08em;padding:4px 20px;text-transform:uppercase}@media (min-width:576px){.custom-radio.radio1 .custom-control-description{padding-bottom:8px;padding-top:9px}}.custom-radio.radio1 .custom-control-input:active:not(:disabled)~.custom-control-description,.custom-radio.radio1 .custom-control-input:checked:not(:disabled)~.custom-control-description{background:#fff;border-bottom-color:#3032c1}.custom-radio .custom-control-indicator{background-color:#fff;border-radius:50%;box-shadow:0 0 0 1px #ddd}.custom-radio .custom-control-input:checked~.custom-control-indicator{background-image:url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='%23fff'/%3E%3C/svg%3E\")}.custom-radio--image .custom-radio .custom-control-description{background:#fff;border-bottom-width:1px;border-color:#ccc;padding:1rem;transition:border-color .3s}.custom-radio--image .custom-radio img,.custom-radio--image .custom-radio svg{display:block;max-width:3.5rem}.custom-radio--image .custom-radio .custom-control-input:active:not(:disabled)~.custom-control-description,.custom-radio--image .custom-radio .custom-control-input:checked:not(:disabled)~.custom-control-description{border-color:#3032c1}.axa-form-hint{color:#7f7f7f;display:block;flex-basis:100%;font-size:80%;font-weight:400;margin-top:.25rem}.custom-checkbox{-moz-user-select:none;-webkit-user-select:none;display:block;margin-bottom:7px;user-select:none}.custom-checkbox .custom-control-indicator{background:#fff;border:1px solid #999;border-radius:0;height:16px;margin-right:10px;width:16px}.custom-checkbox .custom-control-input:checked~.custom-control-indicator{background-image:url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23fff' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3E%3C/svg%3E\")}.custom-checkbox .custom-control-input:indeterminate~.custom-control-indicator{background-color:#00008f;background-image:url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 4'%3E%3Cpath stroke='%23fff' d='M0 2h4'/%3E%3C/svg%3E\");box-shadow:none}.axa-phone-input{display:flex;flex-grow:1;flex-wrap:wrap}.axa-phone-input select{width:130px}.axa-top-content-bar{align-items:center;background:#00005b;color:#fff;display:flex;font-size:.8571428571rem;font-weight:400;justify-content:center;letter-spacing:.02em;line-height:1.5;margin-bottom:.8571428571rem;padding:.625rem 0;width:100vw;z-index:1000}@media (min-width:768px){.axa-top-content-bar{font-size:.8125rem;line-height:1.38;margin-bottom:.8125rem}}.axa-top-content-bar .axa-btn{font-size:inherit;margin:0 0 0 1.25rem}.axa-top-content-bar p{margin:0}.top-content-bar--fixed{left:0;position:fixed;top:0;z-index:1000}.axa-top-content-bar--corporate{background-color:#027180}.axa-top-content-bar--warning{background-color:#c91432}.axa-card{border:1px solid #ccc;display:block;margin-bottom:2.5rem}@media (max-width:767px){.axa-card{margin-bottom:1rem}}.axa-card__block :last-child,.axa-card__title :last-child{margin-bottom:0}.axa-card__block{background:#fafafa;border:1px solid #ccc;border-width:1px 0;display:block;margin-bottom:-1px;padding:20px 16px}@media (min-width:768px){.axa-card__block{padding:24px 30px}}.axa-card__title{background:#fafafa;display:block;padding:16px}@media (min-width:768px){.axa-card__title{padding:16px 30px}}.axa-card--active{box-shadow:0 1px 3px rgba(0,0,0,.1),0 1px 12px rgba(0,0,0,.1);position:relative;z-index:1}.axa-card--active .axa-card__title{background:#fff}@media (min-width:768px){.axa-card--wide .axa-card__block,.axa-card--wide .axa-card__title{padding:24px 60px}}.axa-card__block--compact{padding-bottom:10px;padding-top:10px}@media (min-width:768px){.axa-card__block--compact{padding-bottom:10px;padding-top:10px}}.axa-card--info{border:none;box-shadow:0 1px 3px rgba(0,0,0,.1),0 1px 12px rgba(0,0,0,.1)}.axa-card--info .axa-card__title{background:#494df4;color:#fff}.axa-card--content .axa-card__block,.axa-card--content .axa-card__title,.axa-card--info .axa-card__block{background:#fff}.axa-busy-indicator{display:none;left:50%;opacity:0;position:absolute;top:50%;transform:translate(-50%,-50%);z-index:1002}.axa-busy-indicator__backdrop{background:#fff;height:100%;left:0;opacity:0;position:absolute;top:0;width:100%;z-index:1001}.axa-busy-indicator-wrapper--fixed{position:static}.axa-busy-indicator-wrapper--fixed .axa-busy-indicator,.axa-busy-indicator-wrapper--fixed .axa-busy-indicator__backdrop{position:fixed}.axa-busy-indicator-wrapper{position:relative}.axa-busy-indicator-wrapper .axa-busy-indicator,.axa-busy-indicator-wrapper .axa-busy-indicator__backdrop{position:absolute}.axa-busy-indicator__backdrop--active{-webkit-animation:fadeInHalf .2s;animation:fadeInHalf .2s;opacity:.5}.axa-busy-indicator--active{-webkit-animation:fadeIn .2s;animation:fadeIn .2s;display:block;opacity:1}.axa-busy-indicator__caption{color:#999;text-align:center}.axa-busy-indicator__animation{-webkit-animation:rotateplane 1.1s ease-in-out infinite;animation:rotateplane 1.1s ease-in-out infinite;background-color:#00008f;height:50px;margin:10px auto;width:50px}@-webkit-keyframes rotateplane{0%{transform:perspective(120px) rotateX(0deg) rotateY(0deg)}50%{transform:perspective(120px) rotateX(-180.1deg) rotateY(0deg)}to{transform:perspective(120px) rotateX(-180deg) rotateY(-179.9deg)}}@keyframes rotateplane{0%{transform:perspective(120px) rotateX(0deg) rotateY(0deg)}50%{transform:perspective(120px) rotateX(-180.1deg) rotateY(0deg)}to{transform:perspective(120px) rotateX(-180deg) rotateY(-179.9deg)}}.axa-flag:before{background:url(/assets/flags.png) no-repeat;content:\"\";display:inline-block;height:24px;margin-right:.25rem;margin-top:-2px;vertical-align:middle;width:24px}.axa-flag--ad:before{background-position:-24px 0}.axa-flag--ae:before{background-position:-48px 0}.axa-flag--af:before{background-position:-72px 0}.axa-flag--ag:before{background-position:-96px 0}.axa-flag--ai:before{background-position:-120px 0}.axa-flag--al:before{background-position:-144px 0}.axa-flag--am:before{background-position:-168px 0}.axa-flag--an:before{background-position:-192px 0}.axa-flag--ao:before{background-position:-216px 0}.axa-flag--ar:before{background-position:-240px 0}.axa-flag--as:before{background-position:-264px 0}.axa-flag--at:before{background-position:-288px 0}.axa-flag--au:before{background-position:-312px 0}.axa-flag--aw:before{background-position:-336px 0}.axa-flag--ax:before{background-position:-360px 0}.axa-flag--az:before{background-position:0 -24px}.axa-flag--ba:before{background-position:-24px -24px}.axa-flag--bb:before{background-position:-48px -24px}.axa-flag--bd:before{background-position:-72px -24px}.axa-flag--be:before{background-position:-96px -24px}.axa-flag--bf:before{background-position:-120px -24px}.axa-flag--bg:before{background-position:-144px -24px}.axa-flag--bh:before{background-position:-168px -24px}.axa-flag--bi:before{background-position:-192px -24px}.axa-flag--bj:before{background-position:-216px -24px}.axa-flag--bl:before{background-position:-240px -24px}.axa-flag--bm:before{background-position:-264px -24px}.axa-flag--bn:before{background-position:-288px -24px}.axa-flag--bo:before{background-position:-312px -24px}.axa-flag--br:before{background-position:-336px -24px}.axa-flag--bs:before{background-position:-360px -24px}.axa-flag--bt:before{background-position:0 -48px}.axa-flag--bw:before{background-position:-24px -48px}.axa-flag--by:before{background-position:-48px -48px}.axa-flag--bz:before{background-position:-72px -48px}.axa-flag--ca:before{background-position:-96px -48px}.axa-flag--cd:before{background-position:-120px -48px}.axa-flag--cf:before{background-position:-144px -48px}.axa-flag--cg:before{background-position:-168px -48px}.axa-flag--ch:before{background-position:-192px -48px}.axa-flag--ci:before{background-position:-216px -48px}.axa-flag--ck:before{background-position:-240px -48px}.axa-flag--cl:before{background-position:-264px -48px}.axa-flag--cm:before{background-position:-288px -48px}.axa-flag--cn:before{background-position:-312px -48px}.axa-flag--co:before{background-position:-336px -48px}.axa-flag--cr:before{background-position:-360px -48px}.axa-flag--cu:before{background-position:0 -72px}.axa-flag--cv:before{background-position:-24px -72px}.axa-flag--cw:before{background-position:-48px -72px}.axa-flag--cy:before{background-position:-72px -72px}.axa-flag--cz:before{background-position:-96px -72px}.axa-flag--de:before{background-position:-120px -72px}.axa-flag--dj:before{background-position:-144px -72px}.axa-flag--dk:before{background-position:-168px -72px}.axa-flag--dm:before{background-position:-192px -72px}.axa-flag--do:before{background-position:-216px -72px}.axa-flag--dz:before{background-position:-240px -72px}.axa-flag--ec:before{background-position:-264px -72px}.axa-flag--ee:before{background-position:-288px -72px}.axa-flag--eg:before{background-position:-312px -72px}.axa-flag--eh:before{background-position:-336px -72px}.axa-flag--er:before{background-position:-360px -72px}.axa-flag--es:before{background-position:0 -96px}.axa-flag--et:before{background-position:-24px -96px}.axa-flag--eu:before{background-position:-48px -96px}.axa-flag--fi:before{background-position:-72px -96px}.axa-flag--fj:before{background-position:-96px -96px}.axa-flag--fk:before{background-position:-120px -96px}.axa-flag--fm:before{background-position:-144px -96px}.axa-flag--fo:before{background-position:-168px -96px}.axa-flag--fr:before{background-position:-192px -96px}.axa-flag--ga:before{background-position:-216px -96px}.axa-flag--gb:before{background-position:-240px -96px}.axa-flag--gd:before{background-position:-264px -96px}.axa-flag--ge:before{background-position:-288px -96px}.axa-flag--gg:before{background-position:-312px -96px}.axa-flag--gh:before{background-position:-336px -96px}.axa-flag--gi:before{background-position:-360px -96px}.axa-flag--gl:before{background-position:0 -120px}.axa-flag--gm:before{background-position:-24px -120px}.axa-flag--gn:before{background-position:-48px -120px}.axa-flag--gq:before{background-position:-72px -120px}.axa-flag--gr:before{background-position:-96px -120px}.axa-flag--gs:before{background-position:-120px -120px}.axa-flag--gt:before{background-position:-144px -120px}.axa-flag--gu:before{background-position:-168px -120px}.axa-flag--gw:before{background-position:-192px -120px}.axa-flag--gy:before{background-position:-216px -120px}.axa-flag--hk:before{background-position:-240px -120px}.axa-flag--hn:before{background-position:-264px -120px}.axa-flag--hr:before{background-position:-288px -120px}.axa-flag--ht:before{background-position:-312px -120px}.axa-flag--hu:before{background-position:-336px -120px}.axa-flag--ic:before{background-position:-360px -120px}.axa-flag--id:before{background-position:0 -144px}.axa-flag--ie:before{background-position:-24px -144px}.axa-flag--il:before{background-position:-48px -144px}.axa-flag--im:before{background-position:-72px -144px}.axa-flag--in:before{background-position:-96px -144px}.axa-flag--iq:before{background-position:-120px -144px}.axa-flag--ir:before{background-position:-144px -144px}.axa-flag--is:before{background-position:-168px -144px}.axa-flag--it:before{background-position:-192px -144px}.axa-flag--je:before{background-position:-216px -144px}.axa-flag--jm:before{background-position:-240px -144px}.axa-flag--jo:before{background-position:-264px -144px}.axa-flag--jp:before{background-position:-288px -144px}.axa-flag--ke:before{background-position:-312px -144px}.axa-flag--kg:before{background-position:-336px -144px}.axa-flag--kh:before{background-position:-360px -144px}.axa-flag--ki:before{background-position:0 -168px}.axa-flag--km:before{background-position:-24px -168px}.axa-flag--kn:before{background-position:-48px -168px}.axa-flag--kp:before{background-position:-72px -168px}.axa-flag--kr:before{background-position:-96px -168px}.axa-flag--kw:before{background-position:-120px -168px}.axa-flag--ky:before{background-position:-144px -168px}.axa-flag--kz:before{background-position:-168px -168px}.axa-flag--la:before{background-position:-192px -168px}.axa-flag--lb:before{background-position:-216px -168px}.axa-flag--lc:before{background-position:-240px -168px}.axa-flag--li:before{background-position:-264px -168px}.axa-flag--lk:before{background-position:-288px -168px}.axa-flag--lr:before{background-position:-312px -168px}.axa-flag--ls:before{background-position:-336px -168px}.axa-flag--lt:before{background-position:-360px -168px}.axa-flag--lu:before{background-position:0 -192px}.axa-flag--lv:before{background-position:-24px -192px}.axa-flag--ly:before{background-position:-48px -192px}.axa-flag--ma:before{background-position:-72px -192px}.axa-flag--mc:before{background-position:-96px -192px}.axa-flag--md:before{background-position:-120px -192px}.axa-flag--me:before{background-position:-144px -192px}.axa-flag--mf:before{background-position:-168px -192px}.axa-flag--mg:before{background-position:-192px -192px}.axa-flag--mh:before{background-position:-216px -192px}.axa-flag--mk:before{background-position:-240px -192px}.axa-flag--ml:before{background-position:-264px -192px}.axa-flag--mm:before{background-position:-288px -192px}.axa-flag--mn:before{background-position:-312px -192px}.axa-flag--mo:before{background-position:-336px -192px}.axa-flag--mp:before{background-position:-360px -192px}.axa-flag--mq:before{background-position:0 -216px}.axa-flag--mr:before{background-position:-24px -216px}.axa-flag--ms:before{background-position:-48px -216px}.axa-flag--mt:before{background-position:-72px -216px}.axa-flag--mu:before{background-position:-96px -216px}.axa-flag--mv:before{background-position:-120px -216px}.axa-flag--mw:before{background-position:-144px -216px}.axa-flag--mx:before{background-position:-168px -216px}.axa-flag--my:before{background-position:-192px -216px}.axa-flag--mz:before{background-position:-216px -216px}.axa-flag--na:before{background-position:-240px -216px}.axa-flag--nc:before{background-position:-264px -216px}.axa-flag--ne:before{background-position:-288px -216px}.axa-flag--nf:before{background-position:-312px -216px}.axa-flag--ng:before{background-position:-336px -216px}.axa-flag--ni:before{background-position:-360px -216px}.axa-flag--nl:before{background-position:0 -240px}.axa-flag--no:before{background-position:-24px -240px}.axa-flag--np:before{background-position:-48px -240px}.axa-flag--nr:before{background-position:-72px -240px}.axa-flag--nu:before{background-position:-96px -240px}.axa-flag--nz:before{background-position:-120px -240px}.axa-flag--om:before{background-position:-144px -240px}.axa-flag--pa:before{background-position:-168px -240px}.axa-flag--pe:before{background-position:-192px -240px}.axa-flag--pf:before{background-position:-216px -240px}.axa-flag--pg:before{background-position:-240px -240px}.axa-flag--ph:before{background-position:-264px -240px}.axa-flag--pk:before{background-position:-288px -240px}.axa-flag--pl:before{background-position:-312px -240px}.axa-flag--pn:before{background-position:-336px -240px}.axa-flag--pr:before{background-position:-360px -240px}.axa-flag--ps:before{background-position:0 -264px}.axa-flag--pt:before{background-position:-24px -264px}.axa-flag--pw:before{background-position:-48px -264px}.axa-flag--py:before{background-position:-72px -264px}.axa-flag--qa:before{background-position:-96px -264px}.axa-flag--ro:before{background-position:-120px -264px}.axa-flag--rs:before{background-position:-144px -264px}.axa-flag--ru:before{background-position:-168px -264px}.axa-flag--rw:before{background-position:-192px -264px}.axa-flag--sa:before{background-position:-216px -264px}.axa-flag--sb:before{background-position:-240px -264px}.axa-flag--sc:before{background-position:-264px -264px}.axa-flag--sd:before{background-position:-288px -264px}.axa-flag--se:before{background-position:-312px -264px}.axa-flag--sg:before{background-position:-336px -264px}.axa-flag--sh:before{background-position:-360px -264px}.axa-flag--si:before{background-position:0 -288px}.axa-flag--sk:before{background-position:-24px -288px}.axa-flag--sl:before{background-position:-48px -288px}.axa-flag--sm:before{background-position:-72px -288px}.axa-flag--sn:before{background-position:-96px -288px}.axa-flag--so:before{background-position:-120px -288px}.axa-flag--sr:before{background-position:-144px -288px}.axa-flag--ss:before{background-position:-168px -288px}.axa-flag--st:before{background-position:-192px -288px}.axa-flag--sv:before{background-position:-216px -288px}.axa-flag--sy:before{background-position:-240px -288px}.axa-flag--sz:before{background-position:-264px -288px}.axa-flag--tc:before{background-position:-288px -288px}.axa-flag--td:before{background-position:-312px -288px}.axa-flag--tf:before{background-position:-336px -288px}.axa-flag--tg:before{background-position:-360px -288px}.axa-flag--th:before{background-position:0 -312px}.axa-flag--tj:before{background-position:-24px -312px}.axa-flag--tk:before{background-position:-48px -312px}.axa-flag--tl:before{background-position:-72px -312px}.axa-flag--tm:before{background-position:-96px -312px}.axa-flag--tn:before{background-position:-120px -312px}.axa-flag--to:before{background-position:-144px -312px}.axa-flag--tr:before{background-position:-168px -312px}.axa-flag--tt:before{background-position:-192px -312px}.axa-flag--tv:before{background-position:-216px -312px}.axa-flag--tw:before{background-position:-240px -312px}.axa-flag--tz:before{background-position:-264px -312px}.axa-flag--ua:before{background-position:-288px -312px}.axa-flag--ug:before{background-position:-312px -312px}.axa-flag--us:before{background-position:-336px -312px}.axa-flag--uy:before{background-position:-360px -312px}.axa-flag--uz:before{background-position:0 -336px}.axa-flag--va:before{background-position:-24px -336px}.axa-flag--vc:before{background-position:-48px -336px}.axa-flag--ve:before{background-position:-72px -336px}.axa-flag--vg:before{background-position:-96px -336px}.axa-flag--vi:before{background-position:-120px -336px}.axa-flag--vn:before{background-position:-144px -336px}.axa-flag--vu:before{background-position:-168px -336px}.axa-flag--wf:before{background-position:-192px -336px}.axa-flag--ws:before{background-position:-216px -336px}.axa-flag--ye:before{background-position:-240px -336px}.axa-flag--yt:before{background-position:-264px -336px}.axa-flag--za:before{background-position:-288px -336px}.axa-flag--zm:before{background-position:-312px -336px}.axa-flag--zw:before{background-position:-336px -336px}.axa-footer{display:block}.axa-footer__main{background:#3b3fd8;color:#fff;display:flex;flex-wrap:wrap;margin-left:calc(50% - 50vw);margin-right:calc(50% - 50vw);max-width:none;padding:2rem calc(50vw - 50%);width:100vw}.axa-footer__main__quarter{flex-basis:25%}.axa-footer__main__half{flex-basis:50%}.axa-footer__main__full{flex-basis:100%}.axa-footer__main__title{font-size:1rem;font-weight:400;font-weight:700;letter-spacing:.01em;line-height:1.5;margin-bottom:1rem;text-transform:uppercase}@media (min-width:768px){.axa-footer__main__title{font-size:1.125rem;margin-bottom:1rem}}.axa-footer__main__links,.axa-footer__main__social{list-style:none;margin:0;padding:0}.axa-footer__main__links li,.axa-footer__main__social li{margin:0;padding:0}.axa-footer__main__links a,.axa-footer__main__social a{color:#fff;padding:.5rem 0}.axa-footer__main__social{align-items:center;display:flex;flex-wrap:wrap}.axa-footer__main__social a{display:block;padding:.5rem}.axa-footer__main__social a:first-child{margin-left:-.5rem}.axa-footer__main__social svg{fill:#fff;height:1rem;width:1rem}.axa-footer__bottom{align-items:center;background:#3032c1;color:#fff;display:flex;margin-left:calc(50% - 50vw);margin-right:calc(50% - 50vw);max-width:none;padding-left:calc(50vw - 50%);padding-right:calc(50vw - 50%);width:100vw}.axa-footer__main .axa-footer__bottom{border-top:1px solid hsla(0,0%,100%,.2)}.axa-footer__bottom__legal{flex-grow:1;font-size:.8571428571rem;font-weight:400;font-weight:300;letter-spacing:.02em;line-height:1.5;opacity:.5;order:1;text-align:right}@media (min-width:768px){.axa-footer__bottom__legal{font-size:.8125rem;line-height:1.38}}.axa-footer__bottom__language{margin-left:-.5rem}.axa-footer__bottom__language a{color:#fff;cursor:pointer;display:inline-block;padding:.5rem}.axa-form-steps{background:#fff;border:1px solid #ccc;border-width:1px 0;margin-bottom:24px;margin-left:calc(50% - 50vw);margin-right:calc(50% - 50vw);max-width:none;overflow:hidden;padding-bottom:2px;position:relative;width:100vw}.axa-form-steps-content[aria-expanded=false]{height:0;overflow:hidden}.axa-form-steps__wrapper{display:flex;margin-bottom:0;margin-top:0;padding:0;transition:transform .3s}.axa-form-steps__step{color:#999;display:flex;flex-direction:column;font-size:1.1428571429rem;font-weight:400;font-weight:700;justify-content:center;letter-spacing:.01em;line-height:1.5;min-width:100%;padding:10px 60px;position:relative;z-index:1}@media (min-width:768px){.axa-form-steps__step{font-size:1.25rem}}.axa-form-steps--pricing{padding-left:90px}.axa-form-steps--pricing__icon{height:24px;left:60px;margin-top:-12px;position:absolute;top:50%;width:24px}.axa-form-steps--pricing__icon svg{fill:#999}.axa-form-steps__step__label{font-size:.8571428571rem;font-weight:400;letter-spacing:.02em;line-height:1.5}@media (min-width:768px){.axa-form-steps__step__label{font-size:.875rem;line-height:1.21}}.axa-form-steps__step--active{color:#333}.axa-form-steps__step--done{background:#f5f5f5;color:#999}.axa-form-steps__step--done .axa-form-steps__step__progress{background-color:#ccc;width:100%}.axa-form-steps__step__progress{background-color:#f07662;height:3px;left:0;position:absolute;top:100%;transition:width .3s;width:0}.axa-form-steps__next,.axa-form-steps__previous{align-items:center;background:#fff;border:none;display:block;display:flex;height:100%;justify-content:center;left:0;margin:0;padding:0;position:absolute;top:0;transition:all .3s;width:50px;z-index:2}.axa-form-steps__next:focus,.axa-form-steps__previous:focus{outline:none}.axa-form-steps__next svg,.axa-form-steps__previous svg{fill:#999;height:30px;transition:fill .3s;width:30px}.axa-form-steps__next[disabled],.axa-form-steps__previous[disabled]{background:#f4f4f4}.axa-form-steps__next[disabled] svg,.axa-form-steps__previous[disabled] svg{fill:#ccc}.axa-form-steps__previous{border-right:1px solid #ccc}.axa-form-steps__next{border-left:1px solid #ccc;left:auto;right:0}@media (min-width:768px){.axa-form-steps{overflow:visible;padding-bottom:0}.axa-form-steps__wrapper{margin-left:auto;margin-right:auto;max-width:100%;position:relative;transform:none!important;width:calc(100% - 20px)}}@media (min-width:768px) and (min-width:768px){.axa-form-steps__wrapper{max-width:100%;width:720px}}@media (min-width:768px) and (min-width:992px){.axa-form-steps__wrapper{max-width:100%;width:960px}}@media (min-width:768px) and (min-width:1200px){.axa-form-steps__wrapper{max-width:100%;width:1140px}}@media (min-width:768px){.axa-form-steps__step{border:1px solid #ccc;border-width:0 1px 1px 0;flex-grow:1;margin-bottom:-1px;min-width:0;padding:15px 30px}.axa-form-steps__step:first-child{border-left-width:1px}}@media (min-width:768px){.axa-form-steps--pricing{align-self:center;background:#fff;border:1px solid #ccc;border-radius:50%;flex-grow:0;flex-shrink:1;height:26px;margin-left:-13px;margin-right:-13px;padding:0;position:relative;transition:border-color .3s,background-color .3s;width:26px;z-index:2}.axa-form-steps--pricing .axa-form-steps__step__content,.axa-form-steps--pricing .axa-form-steps__step__label{display:none}.axa-form-steps--pricing.axa-form-steps__step--active{background-color:#3b3fd8;border:1px solid #3b3fd8}.axa-form-steps--pricing.axa-form-steps__step--done{background-color:#fff;border:1px solid #3b3fd8}}@media (min-width:768px){.axa-form-steps--pricing__icon{align-items:center;display:flex;flex-grow:1;height:auto;justify-content:center;margin-top:0;position:static;width:auto}.axa-form-steps--pricing__icon svg{fill:#ccc;height:16px;transition:fill .3s;width:16px}.axa-form-steps__step--active .axa-form-steps--pricing__icon svg{fill:#fff}.axa-form-steps__step--done .axa-form-steps--pricing__icon svg{fill:#3b3fd8}}@media (min-width:768px){.axa-form-steps__step__progress{height:6px}}@media (min-width:768px){.axa-form-steps__next,.axa-form-steps__previous{display:none}}@media (max-width:991px){body{padding-top:88px}}.axa-header{display:block}@media (max-width:991px){.axa-header{bottom:0;max-width:480px;overflow-x:hidden;overflow-y:auto;pointer-events:none;position:fixed;right:0;top:0;width:calc(100vw - 64px);z-index:999}}.axa-header__main__logo,.axa-header__meta,.axa-header__nav,.axa-header__toggle,.axa-header__tools{pointer-events:auto}.axa-header__toggle{display:none;z-index:1001}@media (max-width:991px){.axa-header__toggle{display:block;fill:#00008f;position:fixed;right:24px;top:20px}}.axa-header__toggle--bg{background:rgba(0,0,0,.5);bottom:100%;left:0;opacity:0;position:fixed;right:0;top:0;transition:opacity .3s,bottom 0s .3s;z-index:-1}.axa-header__toggle__input:checked~.axa-header__toggle--bg{bottom:0;opacity:1;transition:opacity .3s,bottom 0s}.axa-header__toggle__input{display:none}.axa-header__toggle__close,.axa-header__toggle__open{height:40px;position:absolute;right:0;transition:opacity .1s .05s,transform .3s;width:40px}.axa-header__toggle__close{opacity:0}.axa-header__toggle__input:checked~.axa-header__toggle .axa-header__toggle__close{opacity:1;transform:rotateY(180deg)}.axa-header__toggle__input:checked~.axa-header__toggle .axa-header__toggle__open{opacity:0;transform:rotateY(180deg)}@media (max-width:991px){.axa-header__toggle__input:not(:checked)~.axa-header__wrapper .axa-header__meta,.axa-header__toggle__input:not(:checked)~.axa-header__wrapper .axa-header__nav{transform:translate3d(100%,0,0)}}.axa-header__wrapper{display:flex;flex-direction:column;font-size:13px;margin:0}.axa-header__wrapper a{display:block;line-height:1;padding:10px 16px;text-decoration:none;text-transform:uppercase}@media (max-width:991px){.axa-header__wrapper{min-height:100%;padding-top:70px;transition:transform .3s}}@media (min-width:992px){.axa-header__wrapper{background:#fff;border-top:2px solid #00008f;box-shadow:0 1px 3px rgba(0,0,0,.1),0 1px 12px rgba(0,0,0,.1);margin-bottom:24px;margin-left:calc(50% - 50vw);margin-right:calc(50% - 50vw);max-width:none;position:static;width:100vw}}.axa-header__main{display:flex;flex-direction:column;margin-left:auto;margin-right:auto;max-width:100%;position:relative;width:calc(100% - 20px);width:100%}@media (min-width:768px){.axa-header__main{max-width:100%;width:720px}}@media (min-width:992px){.axa-header__main{max-width:100%;width:960px}}@media (min-width:1200px){.axa-header__main{max-width:100%;width:1140px}}@media (max-width:991px){.axa-header__main{flex-grow:1}}@media (min-width:992px){.axa-header__main{align-items:center;flex-direction:row;min-height:70px}}.axa-header__main__logo{background:#fff;left:0;top:0}.axa-header__main__logo svg{height:55px;margin-left:1rem}@media (max-width:991px){.axa-header__main__logo{border-top:2px solid #00008f;box-shadow:1px 0 3px rgba(0,0,0,.1),1px 0 12px rgba(0,0,0,.1);min-height:70px;position:fixed;right:0;z-index:1000}}@media (min-width:992px){.axa-header__main__logo svg{margin-left:0}}.axa-header__meta{background:none;display:flex;font-size:12px}@media (max-width:991px){.axa-header__meta{background:#fff;flex-direction:column;flex-grow:1;order:10;transition:transform .3s}}@media (min-width:992px){.axa-header__meta{background:#fafafa}}.axa-header__meta__container{display:flex;height:100%}@media (max-width:991px){.axa-header__meta__container{flex-direction:column;flex-grow:1}}@media (min-width:992px){.axa-header__meta__container{align-items:center;flex-direction:row;height:auto;margin-left:auto;margin-right:auto;max-width:100%;position:relative;width:calc(100% - 20px)}}@media (min-width:992px) and (min-width:768px){.axa-header__meta__container{max-width:100%;width:720px}}@media (min-width:992px) and (min-width:992px){.axa-header__meta__container{max-width:100%;width:960px}}@media (min-width:992px) and (min-width:1200px){.axa-header__meta__container{max-width:100%;width:1140px}}.axa-header__meta__domain{display:flex}@media (max-width:991px){.axa-header__meta__domain{flex-direction:column;flex-grow:1;width:100%}}@media (min-width:992px){.axa-header__meta__domain{align-items:center;margin-left:-1rem}}.axa-header__meta__helper{display:flex}.axa-header__meta__helper .axa-btn{font-size:inherit;line-height:1;margin:0 16px;padding:10px 16px}@media (max-width:991px){.axa-header__meta__helper{flex-direction:column;width:100%}}@media (min-width:992px){.axa-header__meta__helper{align-items:center;flex-grow:1;justify-content:flex-end;margin-right:-1rem}}@media (max-width:991px){.axa-header__meta__helper__link{display:flex}.axa-header__meta__helper__link .axa-btn{display:flex;flex-grow:1;justify-content:center;margin:1rem 24px;padding:calc(20px - .75em) 20px}}.axa-header__meta__domain__link a:not(.axa-btn),.axa-header__meta__helper__link a:not(.axa-btn){color:#999;width:100%}@media (max-width:991px){.axa-header__meta__domain__link a:not(.axa-btn),.axa-header__meta__helper__link a:not(.axa-btn){border:1px solid #e5e5e5;border-width:1px 0;margin-top:-1px;padding:1.25rem 24px;width:100%}.axa-header__meta__domain__link a:not(.axa-btn).active,.axa-header__meta__helper__link a:not(.axa-btn).active{box-shadow:inset 0 -1px 0 0 #00008f;color:#333;text-shadow:0 0 .001rem currentColor}.axa-header__meta__domain__link a:not(.axa-btn):hover,.axa-header__meta__helper__link a:not(.axa-btn):hover{color:#333;text-shadow:0 0 .001rem currentColor}}@media (min-width:992px){.axa-header__meta__domain__link a:not(.axa-btn),.axa-header__meta__helper__link a:not(.axa-btn){width:auto}.axa-header__meta__domain__link a:not(.axa-btn).active,.axa-header__meta__domain__link a:not(.axa-btn):hover,.axa-header__meta__helper__link a:not(.axa-btn).active,.axa-header__meta__helper__link a:not(.axa-btn):hover{background-color:#fff}}.axa-header__nav{display:flex}@media (max-width:991px){.axa-header__nav{background:#fff;flex-direction:column;flex-grow:1;transition:transform .3s}}@media (min-width:992px){.axa-header__nav{align-items:center;flex-grow:1;justify-content:flex-end;margin-right:-1rem;padding-right:8px}}@media (max-width:991px){.axa-header__nav__link{width:100%}}@media (max-width:991px){.axa-header__nav__link--button{display:flex;order:-1;padding:24px;width:100%}}.axa-header__nav__link .axa-btn{display:flex;flex-grow:1;font-size:14px;justify-content:center}@media (max-width:991px){.axa-header__nav__link .axa-btn{margin:0;padding:calc(20px - .75em) 20px}}@media (min-width:992px){.axa-header__nav__link .axa-btn{margin:0 8px 4px}}.axa-header__nav__link a:not(.axa-btn){display:block;letter-spacing:.08rem;padding:10px 16px;transition:all .3s}@media (max-width:991px){.axa-header__nav__link a:not(.axa-btn){border:1px solid #e5e5e5;border-width:1px 0;margin-top:-1px;padding:20px 24px;width:100%}}@media (min-width:992px){.axa-header__nav__link a:not(.axa-btn){border:none;margin:0;min-height:70px;padding:26px 1rem}}@media (max-width:991px){.axa-header__nav__link a:not(.axa-btn):hover{box-shadow:inset 0 -1px 0 0 #f07662;text-shadow:0 0 .001rem currentColor}}@media (min-width:992px){.axa-header__nav__link a:not(.axa-btn):hover{box-shadow:inset 0 -4px 0 0 #f07662}}.axa-header__nav__link a.active:not(.axa-btn){box-shadow:inset 0 -2px 0 0 #f07662;text-shadow:0 0 .001rem currentColor}@media (min-width:992px){.axa-header__nav__link a.active:not(.axa-btn){box-shadow:inset 0 -4px 0 0 #f07662}}@media (max-width:991px){.axa-header__tools{position:fixed;right:80px;top:20px;z-index:1001}}.axa-header__search{display:block;margin-left:16px}.axa-header__search__wrapper{display:flex}.axa-header__search__input{border:1px solid transparent;border-right-color:#ccc;color:transparent;font-size:16px;height:42px;margin-top:-21px;padding:0;position:absolute;right:44px;top:50%;transition:border-color .3s,width .3s,color .3s,padding .3s;width:0}.axa-header__search__input::-webkit-input-placeholder{color:#aaa}.axa-header__search__input::-moz-placeholder{color:#aaa}.axa-header__search__input:-ms-input-placeholder{color:#aaa}.axa-header__search__input:-moz-placeholder{color:#aaa}@media (max-width:991px){.axa-header__search__input{border-color:transparent}}.axa-header__search:hover .axa-header__search__input,.axa-header__search__input:focus{border-color:#ccc;color:#333;outline:none;padding:0 1rem;width:calc(100% - 120px)}@media (max-width:991px){.axa-header__search:hover .axa-header__search__input,.axa-header__search__input:focus{width:calc(100vw - 210px)}}.axa-header__search .axa-header__search__input:focus{border-color:#3b3fd8}.axa-header__search:hover .axa-header__search__btn svg,.axa-header__search__input:focus+.axa-header__search__btn svg{fill:#3b3fd8}.axa-header__search__btn{background:transparent;border:none;cursor:pointer;margin-left:16px;padding:0}.axa-header__search__btn:focus{outline:none}.axa-header__search__btn svg{fill:#ccc;height:28px;transition:fill .3s;width:28px}@media (max-width:991px){.axa-header__search__btn{margin-top:4px}.axa-header__search__btn svg{height:32px;width:32px}}.axa-icon{align-items:center;display:flex}.axa-icon svg,svg.axa-icon{align-self:center;height:1em;max-height:100%;max-width:100%;width:1em}.axa-link{align-items:center;color:#00008f;cursor:pointer;display:inline-flex;font-size:1.125rem;text-decoration:none;text-transform:uppercase}.axa-link:hover{color:#00005b;text-decoration:none}.axa-link svg{fill:currentColor;height:1em;width:1em}.axa-link svg:first-child{margin-right:10px}.axa-link svg:last-child{margin-left:10px}.axa-link-blue-arrow:hover>svg,.axa-link-red-arrow:hover>svg{-webkit-animation:animate-arrow-right .4s cubic-bezier(.77,0,.175,1);animation:animate-arrow-right .4s cubic-bezier(.77,0,.175,1)}.axa-link-red-arrow,.axa-link-red-icon{color:#f07662}.axa-link-red-arrow:hover,.axa-link-red-icon:hover{color:#ec4d33}.axa-links{list-style-type:none;margin:0;padding:0}.axa-table-wrapper{display:block;margin-bottom:2rem;max-width:100%;overflow-x:auto;overflow-y:hidden}@media (min-width:768px){.axa-table-wrapper{background:#fff;border:1px solid #ccc;padding:0 1rem}}.axa-table{border-collapse:collapse;margin-bottom:-1px;width:100%}.axa-table thead{color:#7f7f7f;font-weight:400;text-align:left}.axa-table tbody{text-align:left}.axa-table tfoot td,.axa-table tfoot th{border-bottom:none}.axa-table td,.axa-table th{border-bottom:1px solid #e5e5e5;font-weight:400;padding:1rem .5rem}@media (max-width:575px){.axa-table--flex-xs{background:transparent;border:none;padding:0}.axa-table--flex-xs tbody,.axa-table--flex-xs tfoot,.axa-table--flex-xs thead{display:block}.axa-table--flex-xs td,.axa-table--flex-xs th{border:none}.axa-table--flex-xs tr{border:1px solid #e5e5e5;display:flex;flex-wrap:wrap;margin-bottom:.5rem}}@media (max-width:767px){.axa-table--flex-sm{background:transparent;border:none;padding:0}.axa-table--flex-sm tbody,.axa-table--flex-sm tfoot,.axa-table--flex-sm thead{display:block}.axa-table--flex-sm td,.axa-table--flex-sm th{border:none}.axa-table--flex-sm tr{border:1px solid #e5e5e5;display:flex;flex-wrap:wrap;margin-bottom:.5rem}}@media (max-width:991px){.axa-table--flex-md{background:transparent;border:none;padding:0}.axa-table--flex-md tbody,.axa-table--flex-md tfoot,.axa-table--flex-md thead{display:block}.axa-table--flex-md td,.axa-table--flex-md th{border:none}.axa-table--flex-md tr{border:1px solid #e5e5e5;display:flex;flex-wrap:wrap;margin-bottom:.5rem}}@media (max-width:1199px){.axa-table--flex-lg{background:transparent;border:none;padding:0}.axa-table--flex-lg tbody,.axa-table--flex-lg tfoot,.axa-table--flex-lg thead{display:block}.axa-table--flex-lg td,.axa-table--flex-lg th{border:none}.axa-table--flex-lg tr{border:1px solid #e5e5e5;display:flex;flex-wrap:wrap;margin-bottom:.5rem}}.axa-table--flex-xl{background:transparent;border:none;padding:0}.axa-table--flex-xl tbody,.axa-table--flex-xl tfoot,.axa-table--flex-xl thead{display:block}.axa-table--flex-xl td,.axa-table--flex-xl th{border:none}.axa-table--flex-xl tr{border:1px solid #e5e5e5;display:flex;flex-wrap:wrap;margin-bottom:.5rem}.table-of-contents{border-left:2px solid #3054ae;display:block;margin-bottom:2rem;margin-top:2rem;padding-left:25px}.table-of-contents__heading{color:#ccc;display:block;font-size:1rem;font-weight:400;font-weight:700;letter-spacing:.01em;line-height:1.5;margin-bottom:1rem;padding-bottom:10px}@media (min-width:768px){.table-of-contents__heading{font-size:1.125rem;margin-bottom:1rem}}.table-of-contents__menu{display:block;list-style-type:none;margin:0;padding:0}.table-of-contents__item{display:block;padding-bottom:10px}.table-of-contents__link{color:#3054ae;display:inline;font-size:1.1428571429rem;font-weight:600;font-weight:400;letter-spacing:0;line-height:1.5;margin-bottom:1rem;text-decoration:none}@media (min-width:768px){.table-of-contents__link{font-size:1.5rem;line-height:1.2;margin-bottom:1rem}}.axa-tab{border:1px solid #ccc;box-shadow:0 1px 2px 0 #e5e5e5}.axa-tab-list{color:#00005b;display:flex;height:60px}.axa-tab-list__tab{align-items:center;background:#fafafa;cursor:pointer;display:flex;flex:1;font-weight:400;justify-content:center}.axa-tab-list__tab[aria-selected=false]{border-bottom:1px solid #ccc;border-left:1px solid #ccc;border-right:1px solid #ccc}.axa-tab-list__tab[aria-selected=true]{background:#fff;font-weight:500}.axa-tab-panel{background:#fff;font-weight:400}.axa-tab-list__tab-alt{align-items:center;cursor:pointer;display:flex;flex:1;font-weight:400;justify-content:center}.axa-tab-list__tab-alt[aria-selected=false]{border-bottom:1px solid #ccc}.axa-tab-list__tab-alt[aria-selected=true]{border-bottom:5px solid #00005b;font-weight:500}.axa-tab-panel-alt{font-weight:400}.axa-expansion-panel{box-shadow:0 1px 3px rgba(0,0,0,.1),0 1px 12px rgba(0,0,0,.1);display:block;margin:0;transition:margin 225ms cubic-bezier(.4,0,.2,1)}.axa-expansion-panel-header{align-items:center;border:1px solid #ccc;display:flex;flex-direction:row;padding:0 24px}.axa-expansion-panel-header:focus,.axa-expansion-panel-header:hover{outline:none}.axa-expansion-panel-header.mat-expanded:focus,.axa-expansion-panel-header.mat-expanded:hover{background:inherit}.axa-expansion-panel-header:not([aria-disabled=true]){background:#fff;cursor:pointer}.axa-expansion-panel-content{display:flex;flex-direction:column;overflow:hidden}.axa-expansion-panel-content.axa-expanded{overflow:visible}.axa-expansion-panel-body{padding:0 24px 16px}.axa-expansion-panel-spacing{margin:16px 0}.axa-accordion>.axa-expansion-panel-spacing:first-child,.axa-accordion>:first-child:not(.axa-expansion-panel) .axa-expansion-panel-spacing{margin-top:0}.axa-accordion>.axa-expansion-panel-spacing:last-child,.axa-accordion>:last-child:not(.axa-expansion-panel) .axa-expansion-panel-spacing{margin-bottom:0}.custom-radio.radio1{-webkit-tap-highlight-color:rgba(0,0,0,0)!important;-webkit-tap-highlight-color:transparent!important}.custom-radio.radio1 .custom-control-description{background-color:#f5f5f5;border:1px solid #ccc;box-sizing:border-box;color:#828282;font-family:Source Sans Pro;font-size:14px;line-height:16px;min-height:51px;text-align:center}label.custom-control,label.custom-control:focus{-webkit-tap-highlight-color:rgba(255,255,255,0)!important;-webkit-tap-highlight-color:transparent!important}@media (max-width:767px){body{padding-top:0!important}}@media (min-width:768px) and (max-width:991px){body{padding-top:71px!important}}@media (max-width:991px){.axa-card{box-shadow:none}}@media (max-width:991px){.axa-card .axa-card__title{background:transparent!important;padding-bottom:1rem!important;padding-top:12px!important;text-align:center}}.axa-card h1{font-family:initial;font-size:2.5em;font-weight:700;margin-bottom:1rem}.axa-card h1 small{color:#999;display:block;font-family:Source Sans Pro,arial,sans-serif;font-size:1.2rem;font-weight:400;letter-spacing:.1;margin-bottom:.4em;margin-top:.5rem;text-transform:uppercase}elib-cover-card{display:block}.cover-card{align-items:center;box-shadow:0 0 12px 0 rgba(0,0,0,.2);display:flex;flex-direction:column;position:relative;transition:box-shadow .3s}@media (max-width:991px){.cover-card{border:none;margin-bottom:1rem}}@media (min-width:992px){.cover-card{background:transparent;border-top:1px solid #ccc!important;box-shadow:none;display:grid;font-size:.875rem;grid-column-gap:1.5rem;grid-template:\"main1 aside1\" \"main2 aside2\" \"main3 aside3\" \"main4 aside4\" \"main5 aside5\";grid-template-columns:auto 10rem;grid-template-rows:auto}}.elib-modal__dialog__body .cover-card{box-shadow:none}.cover-card--active{box-shadow:0 0 12px 0 rgba(0,0,0,.2),inset 0 0 0 3px #00adc6}.cover-card--active .cover-card__tick{opacity:1}.cover-card__tick{background:#fff;border-radius:50%;fill:#00adc6;height:24px;opacity:0;position:absolute;right:-11px;top:-11px;transition:opacity .3s;width:24px;z-index:1}.cover-card__icon{align-self:center;grid-row-end:span aside5;grid-row-start:aside2;margin-bottom:1rem;width:6rem}@media (min-width:992px){.cover-card__icon{align-self:flex-start;justify-self:center}}.cover-card__heading{font-size:1.1428571429rem;font-size:1.375rem;font-weight:600;grid-area:main1;letter-spacing:0;line-height:1.5;margin-bottom:0}@media (min-width:768px){.cover-card__heading{font-size:1.5rem;line-height:1.2;margin-bottom:1rem}}.cover-card__price{font-size:2.5rem;font-weight:900;grid-area:aside1;margin-bottom:1rem}@media (min-width:992px){.cover-card__price{justify-self:flex-end}}.cover-card__content{grid-area:main3;margin-bottom:1rem}.cover-card__more-link{align-items:center;align-self:flex-start;display:flex;font-weight:600;grid-area:main4;margin-bottom:1rem;text-transform:uppercase}.cover-card__more-link axa-icon{margin-left:.5rem}.cover-card__more-link svg{height:24px;width:24px}.cover-card__remove-link{align-items:center;color:#ff1721;cursor:pointer;display:flex;grid-area:main5}.cover-card__remove-link:hover{color:#ff1721}.cover-card__remove-link axa-icon{margin-right:.5rem}.cover-card__remove-link svg{fill:#ff1721;height:24px;width:24px}.cover-card__action{display:flex;font-size:1rem;grid-area:main5;justify-content:center;width:100%}.cover-card__subtitle{font-size:1rem;grid-area:main2;margin-bottom:.5rem}@media (min-width:992px){.cover-card__heading{-ms-grid-column:1;-ms-grid-row:1}.cover-card__price{-ms-grid-column:3;-ms-grid-row:1}.cover-card__content{-ms-grid-column:1;-ms-grid-row:3}.cover-card__more-link{-ms-grid-column:1;-ms-grid-row:4}.cover-card__action,.cover-card__remove-link{-ms-grid-column:1;-ms-grid-row:5}.cover-card__subtitle{-ms-grid-column:1;-ms-grid-row:2}}.cover-card-hidden{display:none}"]
            },] }
];
ElibCoverCardsComponent.ctorParameters = () => [];
ElibCoverCardsComponent.propDecorators = {
    data: [{ type: Input }],
    appliedOptions: [{ type: Input }],
    selection: [{ type: Output }]
};

class ElibCoverCardComponent {
    constructor(modalService) {
        this.modalService = modalService;
        this.selection = new EventEmitter();
    }
    ngOnInit() {
    }
    handleSelection(value, id) {
        this.selection.emit({ value, id });
    }
    showDetails() {
        this.modalService.showModal({
            title: this.data.modalTitle,
            content: this.modal.nativeElement.innerHTML,
            primaryActionLabel: 'ELIB_MODAL_CONFIRM',
            primaryAction: () => {
                this.modalService.hideModal();
            },
            secondaryActionLabel: 'ELIB_MODAL_CLOSE',
            plainMode: true
        });
    }
}
ElibCoverCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-cover-card',
                template: "<axa-card-content class=\"cover-card\" [class.cover-card--active]=\"applied\" compact >\r\n  <svg class=\"cover-card__tick\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-1.959 17l-4.5-4.319 1.395-1.435 3.08 2.937 7.021-7.183 1.422 1.409-8.418 8.591z\"></path></svg>\r\n  <img class=\"cover-card__icon\" [src]=\"data.icon\" alt=\"\" />\r\n  <h2 class=\"cover-card__heading\" [innerHTML]=\"data.title | translate\"></h2>\r\n  <div class=\"cover-card__price\" [innerHTML]=\"data.price | price\"></div>\r\n  <div class=\"cover-card__content\" [innerHTML]=\"data.description | translate\"></div>\r\n  <a class=\"cover-card__more-link axa-links\" axa-arrow-link (click)=\"showDetails()\" *ngIf=\"data.modalTitle\">\r\n    <span [innerHTML]=\"'ELIB_COVER_CARD_MORE_LINK' | translate\"></span>\r\n    <axa-icon name=\"rightarrow-blue\"></axa-icon>\r\n  </a>\r\n  <a class=\"cover-card__remove-link\" *ngIf=\"applied\" (click)=\"handleSelection(false, data.id)\">\r\n    <axa-icon name=\"trash-icon\"></axa-icon>\r\n    <span [innerHTML]=\"'ELIB_COVER_CARD_REMOVE' | translate\"></span>\r\n  </a>\r\n  <button class=\"cover-card__action\" axa-button *ngIf=\"!applied\" (click)=\"handleSelection(true, data.id)\" [innerHTML]=\"'ELIB_COVER_CARD_ADD' | translate\"></button>\r\n</axa-card-content>\r\n\r\n<div class=\"cover-card-hidden\">\r\n  <div #modal>\r\n    <div class=\"cover-card\">\r\n      <img class=\"cover-card__icon\" [src]=\"data.icon\" alt=\"\" />\r\n      <h2 class=\"cover-card__heading\" [innerHTML]=\"data.modalHeading | translate\"></h2>\r\n      <div class=\"cover-card__content\" [innerHTML]=\"data.modalDescription | translate\"></div>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                styles: [""]
            },] }
];
ElibCoverCardComponent.ctorParameters = () => [
    { type: ElibModalService }
];
ElibCoverCardComponent.propDecorators = {
    data: [{ type: Input }],
    applied: [{ type: Input }],
    selection: [{ type: Output }],
    modal: [{ type: ViewChild, args: ['modal', { static: true },] }]
};

class ElibCoverCardBrokerComponent {
    constructor(modalService) {
        this.modalService = modalService;
        this.handleLeadToBroker = new EventEmitter();
        this.disablePageNext = new EventEmitter();
    }
    ngOnInit() {
        this.nhfOptions = this.data.map((o, i) => {
            return new ElibFieldConfig({
                name: `nhf_check_${i}`,
                type: ElibFieldTypes.checkbox,
                label: o,
                value: !!this.preloadedData[`nhf_check_${i}`]
            });
        });
    }
    handleSelection() {
        this.handleLeadToBroker.emit(true);
    }
    isNHF() {
        const filteredarr = this.data.filter((o, i) => { var _a; return !!((_a = this.form.get(this.nhfOptions[i].name)) === null || _a === void 0 ? void 0 : _a.value); });
        this.disablePageNext.emit(filteredarr.length > 0);
        return filteredarr.length > 0;
    }
    showDetails() {
        this.modalService.showModal({
            title: this.modalData.modalTitle,
            content: this.modal.nativeElement.innerHTML,
            primaryActionLabel: 'ELIB_MODAL_CONFIRM',
            primaryAction: () => {
                this.modalService.hideModal();
            },
            secondaryActionLabel: 'ELIB_MODAL_CLOSE',
            plainMode: true
        });
    }
}
ElibCoverCardBrokerComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-cover-card-broker',
                template: "<axa-card content>\r\n  <axa-card-title>\r\n    <h1>\r\n      <span [innerHTML]=\"'ELIB_COVER_CARD_BROKER_TITLE' | translate\"></span>\r\n      <small [innerHTML]=\"'ELIB_COVER_CARD_BROKER_SUBTITLE' | translate\"></small>\r\n    </h1>\r\n  </axa-card-title>\r\n\r\n  <axa-card-content class=\"cover-card\" compact >\r\n    <img class=\"cover-card__icon\" src=\"assets/icons/illustration-broker.svg\" alt=\"\" />\r\n    <div class=\"cover-card__content\" [innerHTML]=\"'ELIB_COVER_CARD_BROKER_CONTENT' | translate\"></div>\r\n    <h3 class=\"cover-card__subtitle\" [innerHTML]=\"'ELIB_COVER_CARD_BROKER_CONTENT_SUBTITLE' | translate\"></h3>\r\n    <ul class=\"cover-card__options-list\">\r\n      <li *ngFor=\"let cover of data; let i = index;\"> <elib-field-checkbox [form]=\"form\" [config]=\"nhfOptions[i]\"></elib-field-checkbox></li> <!-- -->\r\n    </ul>\r\n    <a class=\"cover-card__more-link axa-links\" axa-arrow-link (click)=\"showDetails()\">\r\n      <span [innerHTML]=\"'ELIB_COVER_CARD_MORE_LINK' | translate\"></span>\r\n      <axa-icon name=\"rightarrow-blue\"></axa-icon>\r\n    </a>\r\n\r\n    <button class=\"cover-card__action\" axa-button [disabled]=\"!isNHF()\" (click)=\"handleSelection()\" [innerHTML]=\"'ELIB_COVER_CARD_BROKER_SELECT' | translate\"></button>\r\n\r\n  </axa-card-content>\r\n  \r\n</axa-card>\r\n\r\n\r\n\r\n<div class=\"cover-card-hidden\">\r\n  <div #modal>\r\n    <div class=\"cover-card\">\r\n      <img class=\"cover-card__icon\" [src]=\"modalData.icon\" alt=\"\" />\r\n      <h2 class=\"cover-card__heading\" [innerHTML]=\"modalData.modalHeading | translate\"></h2>\r\n      <div class=\"cover-card__content\" [innerHTML]=\"modalData.modalDescription | translate\"></div>\r\n    </div>\r\n  </div>\r\n</div>",
                styles: [".cover-card{align-items:flex-start}.cover-card__icon{grid-row-start:aside1}.cover-card__content{grid-area:main1}.cover-card__subtitle{grid-area:main2}.cover-card__options-list{grid-area:main3;list-style:none;padding:0}.cover-card__options-list li{align-items:center;display:flex}.cover-card__options-list img{margin-right:.5rem}"]
            },] }
];
ElibCoverCardBrokerComponent.ctorParameters = () => [
    { type: ElibModalService }
];
ElibCoverCardBrokerComponent.propDecorators = {
    data: [{ type: Input }],
    modalData: [{ type: Input }],
    form: [{ type: Input }],
    preloadedData: [{ type: Input }],
    handleLeadToBroker: [{ type: Output }],
    modal: [{ type: ViewChild, args: ['modal', { static: true },] }],
    disablePageNext: [{ type: Output }]
};

class ElibCoverCardVpBrokerComponent {
    constructor(modalService) {
        this.modalService = modalService;
    }
    ngOnInit() {
    }
    showDetails() {
        this.modalService.showModal({
            title: 'ELIB_VP_BROKER_TITLE_PU',
            content: this.modal.nativeElement.innerHTML,
            primaryActionLabel: 'ELIB_GLOBAL_CLOSE_PU'
        });
    }
    handleSelection() {
    }
}
ElibCoverCardVpBrokerComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-cover-card-vp-broker',
                template: "<h1>\r\n  <span [innerHTML]=\"'ELIB_VP_BROKER_CARD_TITLE' | translate\"></span>\r\n</h1>\r\n<p [innerHTML]=\"'ELIB_VP_BROKER_CARD_TITLE_INTRO' | translate\"></p>\r\n\r\n<img class=\"cover-card__icon\" src=\"assets/icons/illustration-broker.svg\" alt=\"\" />\r\n<div class=\"cover-card__content\" [innerHTML]=\"'ELIB_VP_BROKER_INTRO' | translate\"></div>\r\n<h3 class=\"cover-card__subtitle\" [innerHTML]=\"'ELIB_VP_BROKER_TITLE' | translate\"></h3>\r\n<ul class=\"cover-card__options-list\">\r\n  <li *ngFor=\"let cover of data\"><img src=\"assets/icons/check.svg\" alt=\"\">{{ cover | translate }}</li>\r\n</ul>\r\n<a class=\"cover-card__more-link axa-links\" axa-arrow-link (click)=\"showDetails()\">\r\n  <span [innerHTML]=\"'ELIB_VP_BROKER_MI' | translate\"></span>\r\n  <!-- <axa-icon name=\"rightarrow-blue\"></axa-icon> -->\r\n</a>\r\n<!-- <a class=\"cover-card__action\" axa-button ghost (click)=\"handleSelection()\" [innerHTML]=\"'ELIB_COVER_CARD_BROKER_SELECT' | translate\"></a> -->\r\n\r\n\r\n<div class=\"hidden-div\">\r\n  <div #modal>\r\n      <p  [innerHTML]=\"'ELIB_VP_BROKER_BODY_PU' | translate\"></p>\r\n  </div>\r\n</div>",
                styles: [".cover-card{align-items:flex-start}.cover-card__icon{grid-row-start:aside1}.cover-card__content{grid-area:main1}.cover-card__subtitle{grid-area:main2}.cover-card__options-list{grid-area:main3;list-style:none;padding:0}.cover-card__options-list li{align-items:center;display:flex}.cover-card__options-list img{margin-right:.5rem}.hidden-div{display:none}::ng-deep elib-cover-card-vp-broker img.cover-card__icon{float:right!important;width:30%!important}"]
            },] }
];
ElibCoverCardVpBrokerComponent.ctorParameters = () => [
    { type: ElibModalService }
];
ElibCoverCardVpBrokerComponent.propDecorators = {
    data: [{ type: Input }],
    modal: [{ type: ViewChild, args: ['modal', { static: true },] }]
};

class ElibFieldAddressComponent {
    constructor(translateClient) {
        this.translateClient = translateClient;
        this.changeEvent = new EventEmitter();
        this.keyUpEvent = new EventEmitter();
        this.blurEvent = new EventEmitter();
        this.clickEvent = new EventEmitter();
        this.selectionEvent = new EventEmitter();
    }
    ngOnInit() { }
    getZipConfig() {
        const name = `${this.config.name}_zip`;
        return new ElibFieldConfig({
            name,
            type: ElibFieldTypes.numberPositiveInteger,
            mandatory: true,
            label: 'ELIB_ADDRESS_POSTCODE',
            placeholder: 'ELIB_ADDRESS_POSTCODE_PH',
            value: this.config.value[name] ? this.config.value[name] : undefined,
            maxlength: 4
        });
    }
    getCityConfig() {
        const name = `${this.config.name}_city`;
        return new ElibFieldConfig({
            name,
            type: ElibFieldTypes.numberInteger,
            mandatory: true,
            label: 'ELIB_ADDRESS_CITY',
            placeholder: 'ELIB_ADDRESS_CITY_PH',
            value: this.config.value[name] ? this.config.value[name] : undefined,
            maxlength: 35
        });
    }
    getStreetConfig() {
        const name = `${this.config.name}_street`;
        return new ElibFieldConfig({
            name,
            type: ElibFieldTypes.numberInteger,
            mandatory: true,
            label: 'ELIB_ADDRESS_STREET',
            placeholder: 'ELIB_ADDRESS_STREET_PH',
            value: this.config.value[name] ? this.config.value[name] : undefined,
            maxlength: 33
        });
    }
    getNumberConfig() {
        const name = `${this.config.name}_number`;
        return new ElibFieldConfig({
            name,
            type: ElibFieldTypes.numberInteger,
            mandatory: true,
            label: 'ELIB_ADDRESS_HOUSENUMBER',
            placeholder: 'ELIB_ADDRESS_HOUSENUMBER_PH',
            value: this.config.value[name] ? this.config.value[name] : undefined,
            maxlength: 4
        });
    }
    getBoxConfig() {
        const name = `${this.config.name}_box`;
        return new ElibFieldConfig({
            name,
            type: ElibFieldTypes.numberInteger,
            mandatory: false,
            label: 'ELIB_ADDRESS_BOX',
            placeholder: 'ELIB_ADDRESS_BOX_PH',
            value: this.config.value[name] ? this.config.value[name] : undefined,
            maxlength: 3
        });
    }
    handleBlur(nameOfFormControl, data) {
        this.blurEvent.emit({ nameOfFormControl, data: this.form.get(`${this.config.name}_${nameOfFormControl}`).value });
    }
    handleChange(nameOfFormControl, data) {
        this.changeEvent.emit({ nameOfFormControl, data: this.form.get(`${this.config.name}_${nameOfFormControl}`).value });
    }
    handleKeyUp(nameOfFormControl, data) {
        this.keyUpEvent.emit({ nameOfFormControl, data: this.form.get(`${this.config.name}_${nameOfFormControl}`).value });
    }
    handleClick(nameOfFormControl, data) {
        this.clickEvent.emit({ nameOfFormControl, data: this.form.get(`${this.config.name}_${nameOfFormControl}`).value });
    }
    handleSelectionEvent(data, nameOfFormControl) {
        this.selectionEvent.emit({ nameOfFormControl, data });
    }
}
ElibFieldAddressComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-address',
                template: "\r\n  <elib-field-wrapper\r\n    [prefix]=\"config.prefix\"\r\n    [suffix]=\"config.suffix\"\r\n    [hint]=\"config.hint\"\r\n    [help]=\"config.help\"\r\n    class=\"address\">\r\n      <elib-field-text class=\"elib-field-address__zip\" [config]=\"getZipConfig()\" [form]=\"form\"\r\n        (blurEvent)=\"handleBlur('zip', $event)\"\r\n        (keyUpEvent)=\"handleKeyUp('zip', $event)\"\r\n        (changeEvent)=\"handleChange('zip', $event)\"\r\n        (clickEvent)=\"handleClick('zip', $event)\"></elib-field-text>\r\n\r\n      <elib-field-city-autocomplete\r\n        [form]=\"form\"\r\n        [config]=\"getCityConfig()\"\r\n        [autocompleteDataForCity]=\"autocompleteDataForCity\"\r\n        (blurEvent)=\"handleBlur('city', $event)\"\r\n        (keyUpEvent)=\"handleKeyUp('city', $event)\"\r\n        (changeEvent)=\"handleChange('city', $event)\"\r\n        (clickEvent)=\"handleClick('city', $event)\"\r\n        (selectionEvent)=\"handleSelectionEvent($event, 'city')\"></elib-field-city-autocomplete>\r\n\r\n      <elib-field-street-autocomplete\r\n        [config]=\"getStreetConfig()\" [form]=\"form\"\r\n        [autocompleteDataForStreet]=\"autocompleteDataForStreet\"\r\n        (blurEvent)=\"handleBlur('street', $event)\"\r\n        (keyUpEvent)=\"handleKeyUp('street', $event)\"\r\n        (changeEvent)=\"handleChange('street', $event)\"\r\n        (clickEvent)=\"handleClick('street', $event)\"\r\n        ></elib-field-street-autocomplete>\r\n\r\n      <div class=\"elib-field-address__numbers\">\r\n        <elib-field-text class=\"elib-field-address__number\" [config]=\"getNumberConfig()\" [form]=\"form\"\r\n          (blurEvent)=\"handleBlur('number', $event)\"\r\n          (keyUpEvent)=\"handleKeyUp('number', $event)\"\r\n          (changeEvent)=\"handleChange('number', $event)\"\r\n          (clickEvent)=\"handleClick('number', $event)\"></elib-field-text>\r\n\r\n        <elib-field-text class=\"elib-field-address__box\" [config]=\"getBoxConfig()\" [form]=\"form\"\r\n          (blurEvent)=\"handleBlur('box', $event)\"\r\n          (keyUpEvent)=\"handleKeyUp('box', $event)\"\r\n          (changeEvent)=\"handleChange('box', $event)\"\r\n          (clickEvent)=\"handleClick('box', $event)\"></elib-field-text>\r\n      </div>\r\n\r\n  </elib-field-wrapper>\r\n\r\n",
                styles: [""]
            },] }
];
ElibFieldAddressComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibFieldAddressComponent.propDecorators = {
    form: [{ type: Input }],
    config: [{ type: Input }],
    autocompleteDataForCity: [{ type: Input }],
    autocompleteDataForStreet: [{ type: Input }],
    changeEvent: [{ type: Output }],
    keyUpEvent: [{ type: Output }],
    blurEvent: [{ type: Output }],
    clickEvent: [{ type: Output }],
    selectionEvent: [{ type: Output }]
};

class ElibFieldComponent {
    constructor(translateClient) {
        this.translateClient = translateClient;
        this.changeEvent = new EventEmitter();
        this.keyUpEvent = new EventEmitter();
        this.blurEvent = new EventEmitter();
        this.clickEvent = new EventEmitter();
        this.validatorsList = [];
        this.standardMandatory = true;
    }
    get showError() {
        const control = this.form.controls[this.config.name];
        return (control.dirty || control.touched) && control.invalid;
    }
    getConfigValue() {
        return this.config.value;
    }
    getValue() {
        return this.form.get(this.config.name).value;
    }
    ngOnInit() {
        // Set mandatory validator
        if (this.config.mandatory && this.standardMandatory) {
            this.validatorsList.push(required);
        }
        this.initField();
        // Check if there are additional validators (minLength, maxLength, ...) to add to the others
        if (this.config.additionalValidators && this.config.additionalValidators.length > 0) {
            this.validatorsList = this.validatorsList.concat(this.config.additionalValidators);
        }
        // Create the control and add it to the form
        this.form.addControl(this.config.name, new FormControl({
            value: this.getConfigValue(),
            disabled: this.config.disabled
        }, this.validatorsList));
    }
    initField() { }
    getErrorMessage() {
        const ctrl = this.form.controls[this.config.name];
        if (ctrl.touched
            && !ctrl.valid
            && ctrl.errors
            && Object.keys(ctrl.errors).length > 0) {
            const t = this.translateClient.get(Object.keys(ctrl.errors)[0]);
            return t ? Object.keys(ctrl.errors)[0] : `error.${Object.keys(ctrl.errors)[0]}`;
        }
        else {
            return '';
        }
    }
    handleChange(e) {
        this.changeEvent.emit(e);
    }
    handleKeyUp(e) {
        this.keyUpEvent.emit(e);
    }
    handleBlur(e) {
        this.blurEvent.emit(e);
    }
    handleClick(e) {
        this.clickEvent.emit(e);
    }
    ngOnDestroy() {
        this.form.removeControl(this.config.name);
    }
}
ElibFieldComponent.decorators = [
    { type: Component, args: [{
                template: ''
            },] }
];
ElibFieldComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibFieldComponent.propDecorators = {
    form: [{ type: Input }],
    config: [{ type: Input }],
    changeEvent: [{ type: Output }],
    keyUpEvent: [{ type: Output }],
    blurEvent: [{ type: Output }],
    clickEvent: [{ type: Output }]
};

class ElibFieldCheckboxComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
        this.$isToggle = false;
    }
    set isToggle(value) {
        this.$isToggle = typeof value !== 'undefined' && value;
    }
    get isToggle() {
        return this.$isToggle;
    }
    ngOnInit() { super.ngOnInit(); }
}
ElibFieldCheckboxComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-checkbox',
                template: "<elib-field-wrapper\r\n  class=\"currency\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <div [formGroup]=\"form\">\r\n    <axa-checkbox [formControlName]=\"config.name\" class=\"form-checkbox-field__content\" [class.form-checkbox-field--toggle]=\"isToggle\">\r\n      <div *ngIf=\"isToggle\" class=\"toggle-group\">\r\n        <span class=\"form-checkbox-field--toggle__indicator\"></span>\r\n        <span data-label=\"\" class=\"form-checkbox-field--toggle__label-on\">{{ 'ELIB_YES' | translate }}</span>\r\n        <span data-label=\"\" class=\"form-checkbox-field--toggle__label-off\">{{ 'ELIB_NO' | translate }}</span>\r\n      </div>\r\n    </axa-checkbox>\r\n    <label class=\"form-label\" *ngIf=\"config.label && !config.labelTranslationParam\" [innerHTML]=\"config.label | translate\"></label>\r\n    <label class=\"form-label\" *ngIf=\"config.label && config.labelTranslationParam\" [innerHTML]=\"config.label | translate:config.labelTranslationParam\"></label>\r\n    <axa-error *ngIf=\"showError\">{{ getErrorMessage() | translate }}</axa-error>\r\n    <elib-field-tooltip *ngIf=\"config.help\" [content]=\"config.help | translate\"></elib-field-tooltip>\r\n  </div>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldCheckboxComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibFieldCheckboxComponent.propDecorators = {
    grow: [{ type: Input }],
    isToggle: [{ type: Input }]
};

class ElibFieldCurrencyComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
    }
    ngOnInit() { super.ngOnInit(); }
}
ElibFieldCurrencyComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-currency',
                template: "<elib-field-wrapper\r\n  class=\"currency\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <input\r\n      axaInput\r\n      type=\"number\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n      [formControlName]=\"config.name\" />\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldCurrencyComponent.ctorParameters = () => [
    { type: TranslateService }
];

class ElibFieldDateComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
        this.numericKeys = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        this.movementKeys = ['ArrowLeft', 'ArrowRight'];
        this.deleteKeys = ['Backspace', 'Delete'];
        this.allowedKeys = [...this.numericKeys, ...this.movementKeys, ...this.deleteKeys, 'Tab'];
    }
    ngOnInit() { super.ngOnInit(); }
    initField() {
        this.validatorsList.push(validDate);
    }
    isZoneFull(pos, val) {
        // Check if a zone delimited by slashes is already full
        return ((pos < 3 && val.slice(2, 3) === '/') || (pos > 2 && pos < 6 && val.slice(5, 6) === '/'));
    }
    clearInRange(fld, val, start, end) {
        // Slice string on the selected range and insert text
        this.form.controls[this.config.name].setValue([val.slice(0, start), val.slice(end)].join(''));
        // Maintain cursor position
        fld.setSelectionRange(start, start);
    }
    parseEventKey(e) {
        switch (e.inputType) {
            case 'insertText': {
                return e.data;
            }
            case 'deleteContentBackward': {
                return 'Backspace';
            }
            case 'deleteContentForward': {
                return 'Delete';
            }
        }
    }
    getEventData(e) {
        const fld = e.target;
        const key = e.key;
        const initialValue = fld.value;
        const pos = this.selectionStartPos(fld);
        const posEnd = fld.selectionEnd;
        const isSlash = (key === '/');
        const isNumeric = this.numericKeys.indexOf(key) > -1;
        const isBackSpace = (key === 'Backspace');
        const isDel = (key === 'Delete');
        const isTab = (key === 'Tab');
        const isNotSlash = [isNumeric, isBackSpace, isDel].includes(true);
        const hasSelection = pos !== posEnd;
        return {
            e,
            fld,
            key,
            initialValue,
            pos,
            posEnd,
            isSlash,
            isNumeric,
            isBackSpace,
            isDel,
            isTab,
            isNotSlash,
            hasSelection
        };
    }
    preventEventDefault(eData) {
        const excludedKeys = this.allowedKeys;
        if (!excludedKeys.includes(eData.key)) {
            eData.e.preventDefault();
        }
    }
    // If the user inserts a slash but there's only one number, add a zero before
    addZeroAsPrefix(eData) {
        if (eData.isSlash && eData.pos === 1) {
            eData.fld.value = `0${eData.initialValue}/`;
        }
    }
    // If the user inserts a slash but there's only 4 characters, add a zero before the 4th character
    addZeroAtFourth(eData) {
        const tmpVal = eData.fld.value;
        if (eData.isSlash && eData.pos === 4) {
            eData.fld.value = [tmpVal.slice(0, 3), '0', tmpVal.slice(3, 4), '/'].join('');
        }
        return tmpVal;
    }
    preventDefaultIfBackspace(eData) {
        if ((eData.isSlash || eData.fld.value.length === 10) && !eData.isBackSpace && !eData.isTab) {
            eData.e.preventDefault();
            return true;
        }
        return false;
    }
    // If a range is selected, any input will remove the selection
    clearSelectionIfNotSlash(eData) {
        if (eData.hasSelection && eData.isNotSlash) {
            this.clearInRange(eData.fld, eData.initialValue, this.getPos(eData.pos), this.getPosEnd(eData.posEnd));
        }
    }
    handleKeyDown(e) {
        const eData = this.getEventData(e);
        const fld = e.target;
        const key = eData.key;
        const pos = this.selectionStartPos(fld);
        const isNumeric = this.numericKeys.indexOf(key) > -1;
        const isBackSpace = (key === 'Backspace');
        const isDel = (key === 'Delete');
        this.preventEventDefault(eData);
        this.addZeroAsPrefix(eData);
        this.clearSelectionIfNotSlash(eData);
        let tmpVal = this.addZeroAtFourth(eData);
        if (this.preventDefaultIfBackspace(eData)) {
            return;
        }
        const val = fld.value;
        const zoneIsFull = this.isZoneFull(pos, val);
        const shouldInsertSlashBefore = this.posTwoFive(pos);
        const isBackDeleteSlash = this.posThreeSixNBackspace(isBackSpace, pos);
        const isForwardDeleteSlash = this.delNPosTwoFive(isDel, pos);
        const shouldInsertSlash = this.numericOneFour(pos, isNumeric);
        // In some cases, the slash may have been deleted (by range-select).
        // If something is entered where a slash should be, insert one
        if (this.shouldbeSlash(shouldInsertSlashBefore, isNumeric, zoneIsFull)) {
            this.form.controls[this.config.name].setValue(`${fld.value}/${key}`);
            e.preventDefault();
            return;
        }
        // Backspace was hit and there was a slash in the way
        if (isBackDeleteSlash) {
            // Remove the slash AND the character before
            this.clearInRange(fld, fld.value, pos - 2, pos);
            e.preventDefault();
            return;
        }
        // Del was hit and a slash was in the way
        if (isForwardDeleteSlash) {
            // Remove the character after
            this.clearInRange(fld, fld.value, pos + 1, pos + 2);
            e.preventDefault();
            return;
        }
        // If we're at position 1 or 4 a slash should be inserted
        if (shouldInsertSlash) {
            tmpVal = [fld.value.slice(0, pos), key, fld.value.slice(pos)].join('');
            if (this.isZoneFull(pos, tmpVal)) {
                this.form.controls[this.config.name].setValue(tmpVal);
                e.preventDefault();
                return;
            }
            fld.value = [val.slice(0, pos), `${key}/`, val.slice(pos)].join('');
            e.preventDefault();
        }
    }
    selectionStartPos(fld) {
        return fld.selectionStart || 0;
    }
    getPosEnd(posEnd) {
        return posEnd || 0;
    }
    getPos(pos) {
        return pos || 0;
    }
    isBackspaceorMoving(isBackSpace, isMoving) {
        return isBackSpace || isMoving;
    }
    shouldbeSlash(shouldInsertSlashBefore, isNumeric, zoneIsFull) {
        return shouldInsertSlashBefore && isNumeric && !zoneIsFull;
    }
    numericOneFour(pos, isNumeric) {
        return ((pos === 1 || pos === 4) && isNumeric);
    }
    delNPosTwoFive(isDel, pos) {
        return (isDel && this.posTwoFive(pos));
    }
    posThreeSixNBackspace(isBackSpace, pos) {
        return (isBackSpace && (pos === 3 || pos === 6));
    }
    posTwoFive(pos) {
        return (pos === 2 || pos === 5);
    }
}
ElibFieldDateComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-date',
                template: "<elib-field-wrapper\r\n  class=\"date\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <input\r\n      axaInput\r\n      type=\"text\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n      [formControlName]=\"config.name\"\r\n      (keydown)=\"handleKeyDown($event)\"\r\n      (blur)=\"handleBlur($event)\"\r\n      (change)=\"handleChange($event)\"/>\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldDateComponent.ctorParameters = () => [
    { type: TranslateService }
];

class ElibFieldDropdownComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
    }
    ngOnInit() { super.ngOnInit(); }
    ngOnChanges(changes) {
        if (!changes || !changes.options) {
            return;
        }
        this.listOfOptions = changes.options.currentValue;
    }
    handleChange(e) {
        const target = e.target;
        this.changeEvent.emit(parseInt(target.value.split(': ')[1], 10));
    }
}
ElibFieldDropdownComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-dropdown',
                template: "<elib-field-wrapper\r\n  class=\"dropdown\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <select axaSelect [formControlName]=\"config.name\" class=\"custom-select\" (change)=\"handleChange($event)\">\r\n      <option *ngIf=\"!config.value\" [ngValue]=\"null\" selected disabled>{{'ELIB_FIELD_DROPDOWN_PLACEHOLDER' | translate}}</option>\r\n      <option *ngIf=\"!config.mandatory\" [ngValue]=\"\"></option>\r\n      <option *ngFor=\"let option of listOfOptions\" [ngValue]=\"option.value\">{{option.label === '' ? '---' : option.label | translate}}</option>\r\n    </select>\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldDropdownComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibFieldDropdownComponent.propDecorators = {
    options: [{ type: Input }]
};

class ElibFieldIncrementalNumberComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
        this.min = null;
        this.max = null;
    }
    ngOnInit() {
        super.ngOnInit();
        // this.form.get(this.config.name).setValue(this.config.value);
    }
    initField() {
        this.errorMessageParameters = {
            minLength: '',
            maxLength: ''
        };
        if (this.config.type === ElibFieldTypes.numberPositiveInteger && this.min === null) {
            this.min = 1;
        }
    }
    increaseDisabled() {
        return Number(this.getValue()) >= Number(this.max);
    }
    increase() {
        const value = Number(this.getValue());
        if (value !== this.max) {
            this.form.get(this.config.name).setValue(value + 1);
        }
    }
    decreaseDisabled() {
        return Number(this.getValue()) <= Number(this.min);
    }
    decrease() {
        const value = Number(this.getValue());
        if (value !== this.max) {
            this.form.get(this.config.name).setValue(value - 1);
        }
    }
    numberOnly(event) {
        event.preventDefault();
        let pattern = new RegExp(/^\d{0,2}$/g);
        let val = this.form.get(this.config.name).value;
        if (pattern.test(event.key)) {
            if (Number(`${val}${event.key}`) > Number(this.max) || Number(`${val}${event.key}`) < Number(this.min)) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }
    }
}
ElibFieldIncrementalNumberComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-incremental-number',
                template: "<elib-field-wrapper\r\n  class=\"number\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <button type=\"button\" (click)=\"decrease()\" [disabled]=\"decreaseDisabled()\">\r\n      <axa-icon name=\"minus-icon\" class=\"axa-minus-icon\"></axa-icon>\r\n    </button>\r\n    <input\r\n      axaInput\r\n      type=\"text\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n      [formControlName]=\"config.name\"\r\n      (keydown)=\"numberOnly($event)\" />\r\n    <button type=\"button\" (click)=\"increase()\" [disabled]=\"increaseDisabled()\">\r\n      <axa-icon name=\"plus-icon\" class=\"axa-plus-icon\"></axa-icon>\r\n    </button>\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: ["button{background-color:#f5f5f5;border:1px solid #ccc;box-sizing:border-box;color:#00008f;cursor:pointer;font-size:14px;line-height:16px;padding:0 1em;text-align:center;transition:border-bottom-color .3s,background-color .2s}button:hover{border-bottom-color:#00008f}button:active{background-color:#fff}button ::ng-deep .axa-icon{height:13px;width:13px}input{margin:0 10px;max-width:7rem;text-align:center}"]
            },] }
];
ElibFieldIncrementalNumberComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibFieldIncrementalNumberComponent.propDecorators = {
    min: [{ type: Input }],
    max: [{ type: Input }]
};

class ElibFieldMailComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
    }
    ngOnInit() { super.ngOnInit(); }
    initField() {
        this.validatorsList.push(validEmail);
    }
}
ElibFieldMailComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-mail',
                template: "<elib-field-wrapper\r\n  class=\"mail\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <input\r\n      axaInput\r\n      type=\"text\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n      [formControlName]=\"config.name\" />\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldMailComponent.ctorParameters = () => [
    { type: TranslateService }
];

class ElibFieldNumberComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
        this.min = null;
    }
    ngOnInit() { super.ngOnInit(); }
    initField() {
        this.errorMessageParameters = {
            minLength: '',
            maxLength: ''
        };
        if (this.config.type === ElibFieldTypes.numberPositiveInteger) {
            this.min = 0;
        }
    }
    handleKeyUp(e) {
        const formControl = this.form.controls[this.config.name];
        if (formControl.valid) {
            this.keyUpEvent.emit(true);
        }
    }
}
ElibFieldNumberComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-number',
                template: "<elib-field-wrapper\r\n  class=\"number\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <input\r\n      axaInput\r\n      type=\"number\"\r\n      [min]=\"min\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n      [formControlName]=\"config.name\"\r\n      [max]=\"config.maxlength\"\r\n      (blur)=\"handleBlur($event)\" \r\n      (keyup)=\"handleKeyUp($event)\" />\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: ["input::-webkit-inner-spin-button,input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}input[type=number]{-moz-appearance:textfield}"]
            },] }
];
ElibFieldNumberComponent.ctorParameters = () => [
    { type: TranslateService }
];

class ElibFieldPhoneComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
        this.standardMandatory = false;
        this.default = 'BE';
    }
    getConfigValue() {
        return this.config.value ? this.config.value : '+32';
    }
    ngOnInit() { super.ngOnInit(); }
    initField() {
        this.errorMessageParameters = {
            minLength: '',
            maxLength: ''
        };
        if (this.config.mandatory) {
            this.validatorsList.push(phoneRequired);
        }
        this.validatorsList.push(validPhone);
    }
}
ElibFieldPhoneComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-phone',
                template: "<elib-field-wrapper\r\n  class=\"phone\"\r\n  [label]=\"config.label\"\r\n  [showError]=\"showError\"\r\n  [formGroup]=\"form\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <axa-phone-input\r\n      [favorites]=\"['NL','BE','FR']\"\r\n      [formControlName]=\"config.name\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n    ></axa-phone-input>\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldPhoneComponent.ctorParameters = () => [
    { type: TranslateService }
];

class ElibFieldRadioComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
        this.style = '1';
    }
    ngOnInit() { super.ngOnInit(); }
    initField() {
        if (!this.radioStyle) {
            this.radioStyle = '2';
        }
        else if (this.radioStyle === '1') {
            this.radioStyle = '1';
        }
    }
    getClassName() {
        const baseClass = 'axa-form-row axa-form-group axa-form-group--radio elib-field-radio';
        return this.grow === '' || this.grow ? `${baseClass} axa-form-group--radio--grow` : baseClass;
    }
}
ElibFieldRadioComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-radio',
                template: "<elib-field-wrapper\r\n  class=\"currency\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <div [class]=\"getClassName()\" [formGroup]=\"form\">\r\n    <label class=\"form-label\" *ngIf=\"config.label\">{{config.label | translate}}</label>\r\n    <axa-radio-group class=\"axa-form-group__field\" [name]=\"config.name\" [formControlName]=\"config.name\" [class.form-radio-field--2]=\"style === '2'\">\r\n      <ng-container>\r\n        <axa-radio-button tabindex=\"0\" *ngFor=\"let option of options\" [style]=\"style\" value=\"{{option.value}}\" (click)=\"handleClick(option.value)\">\r\n          <axa-icon *ngIf=\"option.icon\" [name]=\"option.icon\"></axa-icon>\r\n          <span *ngIf=\"option.labelTranslationParam\" [innerHTML]=\"option.label | translate:option.labelTranslationParam\"></span>\r\n          <span *ngIf=\"!option.labelTranslationParam\" [innerHTML]=\"option.label | translate\"></span>\r\n          <elib-field-tooltip *ngIf=\"option.help\" [content]=\"option.help | translate\"></elib-field-tooltip>\r\n        </axa-radio-button>\r\n      </ng-container>\r\n    </axa-radio-group>\r\n    <axa-error *ngIf=\"showError\">{{ getErrorMessage() | translate }}</axa-error>\r\n  </div>\r\n</elib-field-wrapper>\r\n",
                encapsulation: ViewEncapsulation.None,
                styles: [".axa-form-group--radio axa-radio-group{display:flex}.axa-form-group--radio axa-radio-group .custom-control-description{align-items:center;display:flex!important;flex-grow:1;justify-content:center;text-align:center;transition:all .3s}.axa-form-group--radio axa-radio-group .custom-control-description .axa-icon{height:2.5rem;width:100%}.axa-form-group--radio--grow axa-radio-group{display:flex;flex-grow:1;flex-wrap:wrap;max-width:none}.axa-form-group--radio--grow axa-radio-button{flex-basis:33%;flex-grow:1}.axa-form-group--radio axa-radio-group{margin:-.25rem}.axa-form-group--radio axa-radio-button{display:flex;padding:.25rem}.axa-form-group--radio .custom-radio.radio1{display:flex;flex-grow:1}.axa-form-group--radio .custom-radio.radio1:focus{outline:none}.axa-form-group--radio .custom-control:hover .custom-control-input:not(:disabled)~.custom-control-description{border-bottom-color:#3032c1}.axa-form-group--radio .custom-control-input{opacity:0;position:absolute;z-index:-1}.axa-form-group--radio input[type=radio]{box-sizing:border-box;padding:0}.axa-form-group--radio .axa-form-group label{color:#333;display:inline-block;flex-basis:100%;font-size:18px;letter-spacing:.01em;line-height:1.5;margin-bottom:.5rem;touch-action:manipulation}.axa-form-group--radio .axa-form-group__field{position:relative}@media (max-width:991px){.axa-form-group--radio .axa-form-group__field{display:flex}}.axa-form-group--radio .form-radio-field--2{display:block}"]
            },] }
];
ElibFieldRadioComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibFieldRadioComponent.propDecorators = {
    options: [{ type: Input }],
    radioStyle: [{ type: Input }],
    grow: [{ type: Input }],
    style: [{ type: Input }]
};

class ElibFieldTextComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
    }
    ngOnInit() { super.ngOnInit(); }
    initField() {
        // Set validator based on the type of the field
        switch (this.config.type) {
            case ElibFieldTypes.textWithoutNumbers:
                this.regExToAccept = '^[a-zA-ZàâäôéèëêïîçùûüÿæœÀÂÄÔÉÈËÊÏÎŸÇÙÛÜÆŒ,.\\-\\s]$';
                this.validatorsList.push(Validators.pattern(/^[a-zA-ZàâäôéèëêïîçùûüÿæœÀÂÄÔÉÈËÊÏÎŸÇÙÛÜÆŒ,.\-\s]+$/));
                break;
            case ElibFieldTypes.numberPositiveInteger:
                this.regExToAccept = '^[0-9]+$';
                this.validatorsList.push(Validators.pattern(/^([0-9]\d*|0)$/));
                break;
            case ElibFieldTypes.numberPositiveFloat:
                this.regExToAccept = '^[0-9.]+$';
                this.validatorsList.push(Validators.pattern(/^(0|[1-9]\d{0,9})(\.\d{0,3})?$/));
                break;
            default:
                this.regExToAccept = '.';
                this.validatorsList.push(Validators.pattern(/./));
                break;
        }
    }
    handleKeyUp(e) {
        const formControl = this.form.controls[this.config.name];
        if (formControl.valid) {
            this.keyUpEvent.emit(true);
        }
    }
}
ElibFieldTextComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-text',
                template: "<elib-field-wrapper\r\n  class=\"text\"\r\n  [label]=\"config.label\"\r\n  [showError]=\"showError\"\r\n  [formGroup]=\"form\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <input\r\n      axaInput\r\n      type=\"text\"\r\n      [appAcceptInput]=\"regExToAccept\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n      [maxlength]=\"config.maxlength\"\r\n      [formControlName]=\"config.name\"\r\n      (blur)=\"handleBlur($event)\"\r\n      (keyup)=\"handleKeyUp($event)\"\r\n      (change)=\"handleChange($event)\" />\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldTextComponent.ctorParameters = () => [
    { type: TranslateService }
];

class ElibFieldTooltipComponent {
    constructor() {
        this.toggled = false;
    }
    handleBlur() {
        this.toggled = false;
    }
    handleClick(e) {
        e.preventDefault();
        e.stopPropagation();
        this.toggled = !this.toggled;
    }
}
ElibFieldTooltipComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-tooltip',
                template: "<div class=\"elib-field-tooltip\" [class.elib-field-tooltip--active]=\"toggled\">\r\n  <a href=\"#\" class=\"elib-field-tooltip__icon\" tabIndex=\"-1\" (blur)=\"handleBlur()\" (click)=\"handleClick($event)\">\r\n    <axa-icon name=\"info\"></axa-icon>\r\n  </a>\r\n  <div class=\"elib-field-tooltip__content\" [innerHTML]=\"content | translate\"></div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                styles: [".elib-field-tooltip{align-self:center;display:inline-flex;flex-direction:column;pointer-events:none;position:relative;vertical-align:middle;width:100%;z-index:1}.elib-field-tooltip--active{z-index:2}.axa-form-row .elib-field-tooltip{height:100%;left:0;position:absolute;top:0;width:100%}.elib-field-tooltip__icon{-moz-appearance:none;-webkit-appearance:none;appearance:none;left:100%;margin-left:.5rem;margin-top:-1.5rem;pointer-events:all;position:absolute}.elib-field-tooltip__icon:active,.elib-field-tooltip__icon:focus{outline:none}.axa-form-row .elib-field-tooltip__icon{margin-top:0}.custom-control-description .elib-field-tooltip__icon{margin-top:-.5rem;top:50%}.elib-field-tooltip__icon .axa-icon{height:1rem!important;width:1rem!important}.elib-field-tooltip__content{background:#3032c1;border-radius:2px;color:#fff;font-size:14px;font-weight:400;line-height:1.2;margin-top:.5rem;opacity:0;padding:1rem;position:absolute;right:-2rem;transition:opacity .3s;width:calc(100% + 2rem)}.elib-field-tooltip__content:after{border-bottom:6px solid #3032c1;border-left:6px solid transparent;border-right:6px solid transparent;bottom:100%;content:\"\";position:absolute;right:.625rem}.elib-field-tooltip--active .elib-field-tooltip__content{opacity:1;pointer-events:all}.axa-form-row .elib-field-tooltip__content{margin-top:2rem}.custom-control-description .elib-field-tooltip__content{margin-top:1.5rem;top:50%}.elib-field-tooltip__content ol,.elib-field-tooltip__content p,.elib-field-tooltip__content ul{font-size:inherit}.elib-field-tooltip__content ol,.elib-field-tooltip__content ul{padding-left:1.25rem}.elib-field-tooltip__content :last-child{margin-bottom:0}.elib-field-tooltip__content svg{display:none}"]
            },] }
];
ElibFieldTooltipComponent.ctorParameters = () => [];
ElibFieldTooltipComponent.propDecorators = {
    content: [{ type: Input }]
};

class ElibFieldWrapperComponent {
    constructor() { }
    getClass() {
        const customClass = this.class ? ` elib-field-${this.class}` : '';
        return `axa-form-row${customClass}`;
    }
}
ElibFieldWrapperComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-wrapper',
                template: "<div [class]=\"getClass()\">\r\n  <div class=\"axa-form-row__input\">\r\n    <axa-prefix *ngIf=\"prefix\">{{ prefix | translate }}</axa-prefix>\r\n    <ng-content></ng-content>\r\n    <axa-suffix *ngIf=\"suffix\">{{ suffix | translate }}</axa-suffix>\r\n  </div>\r\n\r\n  <axa-error>{{ error | translate }}</axa-error>\r\n  <axa-hint *ngIf=\"hint\">{{ hint | translate }}</axa-hint>\r\n  <elib-field-tooltip *ngIf=\"help\" [content]=\"help | translate\"></elib-field-tooltip>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                styles: [""]
            },] }
];
ElibFieldWrapperComponent.ctorParameters = () => [];
ElibFieldWrapperComponent.propDecorators = {
    class: [{ type: Input }],
    prefix: [{ type: Input }],
    suffix: [{ type: Input }],
    error: [{ type: Input }],
    hint: [{ type: Input }],
    help: [{ type: Input }]
};

class ElibFieldCityAutocompleteComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
        this.selectionEvent = new EventEmitter();
        this.streets = [];
    }
    ngOnInit() { super.ngOnInit(); }
    initField() {
        // Set validator based on the type of the field
        switch (this.config.type) {
            case ElibFieldTypes.textWithoutNumbers:
                this.regExToAccept = '^[a-zA-ZàâäôéèëêïîçùûüÿæœÀÂÄÔÉÈËÊÏÎŸÇÙÛÜÆŒ,.\\-\\s]$';
                this.validatorsList.push(Validators.pattern(/^[a-zA-ZàâäôéèëêïîçùûüÿæœÀÂÄÔÉÈËÊÏÎŸÇÙÛÜÆŒ,.\-\s]+$/));
                break;
            case ElibFieldTypes.numberPositiveInteger:
                this.regExToAccept = '^[0-9]+$';
                this.validatorsList.push(Validators.pattern(/^([0-9]\d*|0)$/));
                break;
            case ElibFieldTypes.numberPositiveFloat:
                this.regExToAccept = '^[0-9.]+$';
                this.validatorsList.push(Validators.pattern(/^(0|[1-9]\d{0,9})(\.\d{0,3})?$/));
                break;
            default:
                this.regExToAccept = '.';
                this.validatorsList.push(Validators.pattern(/./));
                break;
        }
    }
    handleKeyUp(e) {
        const formControl = this.form.controls[this.config.name];
        if (formControl.valid) {
            this.keyUpEvent.emit(true);
        }
    }
    ngOnChanges(changes) {
        const name = `${this.config.name.split('_')[0]}_zip`;
        if (changes.autocompleteDataForCity && changes.autocompleteDataForCity.currentValue) {
            this.autocompleteDataForCity = changes.autocompleteDataForCity.currentValue;
            if (this.form.get(name)) {
                this.filteredStreets = of([]);
                this.filteredStreets = this.form.get(name).valueChanges.pipe(startWith(''), map(value => this._filter(value)));
            }
        }
    }
    _filter(value) {
        const filterValue = this._normalizeValue(value);
        return this.autocompleteDataForCity.filter(street => this._normalizeValue(street).includes(filterValue));
    }
    _normalizeValue(value) {
        return value ? value.toString().toLowerCase().replace(/\s/g, '') : '';
    }
    extractStreet(val) {
        return (val.indexOf('(') !== -1 && val.indexOf(')') !== -1) ? val.split(' ')[0] : val;
    }
    extractZIP(val) {
        return (val.indexOf('(') !== -1 && val.indexOf(')') !== -1) ? val.split(' ')[1].substr(1).slice(0, -1) : val;
    }
    handleSelection(rawCity) {
        this.selectionEvent.emit(this.extractZIP(rawCity));
    }
}
ElibFieldCityAutocompleteComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-city-autocomplete',
                template: "<elib-field-wrapper\r\n  class=\"text\"\r\n  [label]=\"config.label\"\r\n  [showError]=\"showError\"\r\n  [formGroup]=\"form\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <input\r\n      axaInput\r\n      type=\"text\"\r\n      [appAcceptInput]=\"regExToAccept\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n      [maxlength]=\"config.maxlength\"\r\n      [formControlName]=\"config.name\"\r\n      (blur)=\"handleBlur($event)\"\r\n      (keyup)=\"handleKeyUp($event)\"\r\n      (change)=\"handleChange($event)\" \r\n      [matAutocomplete]=\"auto\"/>\r\n      <mat-autocomplete #auto=\"matAutocomplete\">\r\n        <mat-option *ngFor=\"let street of filteredStreets | async\" [value]=\"extractStreet(street)\" (onSelectionChange)=\"handleSelection(street)\">\r\n          {{street}}\r\n        </mat-option>\r\n      </mat-autocomplete>\r\n\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldCityAutocompleteComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibFieldCityAutocompleteComponent.propDecorators = {
    autocompleteDataForCity: [{ type: Input }],
    selectionEvent: [{ type: Output }]
};

class ElibFieldStreetAutocompleteComponent extends ElibFieldComponent {
    constructor(translateClient) {
        super(translateClient);
        this.translateClient = translateClient;
        this.streets = [];
    }
    ngOnInit() { super.ngOnInit(); }
    initField() {
        // Set validator based on the type of the field
        switch (this.config.type) {
            case ElibFieldTypes.textWithoutNumbers:
                this.regExToAccept = '^[a-zA-ZàâäôéèëêïîçùûüÿæœÀÂÄÔÉÈËÊÏÎŸÇÙÛÜÆŒ,.\\-\\s]$';
                this.validatorsList.push(Validators.pattern(/^[a-zA-ZàâäôéèëêïîçùûüÿæœÀÂÄÔÉÈËÊÏÎŸÇÙÛÜÆŒ,.\-\s]+$/));
                break;
            case ElibFieldTypes.numberPositiveInteger:
                this.regExToAccept = '^[0-9]+$';
                this.validatorsList.push(Validators.pattern(/^([0-9]\d*|0)$/));
                break;
            case ElibFieldTypes.numberPositiveFloat:
                this.regExToAccept = '^[0-9.]+$';
                this.validatorsList.push(Validators.pattern(/^(0|[1-9]\d{0,9})(\.\d{0,3})?$/));
                break;
            default:
                this.regExToAccept = '.';
                this.validatorsList.push(Validators.pattern(/./));
                break;
        }
    }
    handleKeyUp(e) {
        const formControl = this.form.controls[this.config.name];
        if (formControl.valid) {
            this.keyUpEvent.emit(true);
        }
    }
    ngOnChanges(changes) {
        const name = `${this.config.name.split('_')[0]}_street`;
        if (changes.autocompleteDataForStreet && changes.autocompleteDataForStreet.currentValue) {
            this.autocompleteDataForStreet = changes.autocompleteDataForStreet.currentValue;
            if (this.form.get(name)) {
                this.filteredStreets = of([]);
                this.filteredStreets = this.form.get(name).valueChanges.pipe(startWith(''), map(value => this._filter(value)));
            }
        }
    }
    _filter(value) {
        const filterValue = this._normalizeValue(value);
        return this.autocompleteDataForStreet.filter(street => this._normalizeValue(street).includes(filterValue));
    }
    _normalizeValue(value) {
        return value ? value.toString().toLowerCase().replace(/\s/g, '') : '';
    }
    extractStreet(val) {
        return (val.indexOf('(') !== -1 && val.indexOf(')') !== -1) ? val.split(' ')[0] : val;
    }
}
ElibFieldStreetAutocompleteComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-field-street-autocomplete',
                template: "<elib-field-wrapper\r\n  class=\"text\"\r\n  [label]=\"config.label\"\r\n  [showError]=\"showError\"\r\n  [formGroup]=\"form\"\r\n  [prefix]=\"config.prefix\"\r\n  [suffix]=\"config.suffix\"\r\n  [error]=\"getErrorMessage()\"\r\n  [hint]=\"config.hint\"\r\n  [help]=\"config.help\">\r\n  <axa-form-field [label]=\"config.label | translate\" [showError]=\"showError\" [formGroup]=\"form\">\r\n    <input\r\n      axaInput\r\n      type=\"text\"\r\n      [appAcceptInput]=\"regExToAccept\"\r\n      [placeholder]=\"config.placeholder | translate\"\r\n      [maxlength]=\"config.maxlength\"\r\n      [formControlName]=\"config.name\"\r\n      (blur)=\"handleBlur($event)\"\r\n      (keyup)=\"handleKeyUp($event)\"\r\n      (change)=\"handleChange($event)\" \r\n      [matAutocomplete]=\"auto\"/>\r\n      <mat-autocomplete #auto=\"matAutocomplete\">\r\n        <mat-option *ngFor=\"let street of filteredStreets | async\" [value]=\"extractStreet(street)\" >\r\n          {{street}}\r\n        </mat-option>\r\n      </mat-autocomplete>\r\n\r\n  </axa-form-field>\r\n</elib-field-wrapper>\r\n",
                styles: [""]
            },] }
];
ElibFieldStreetAutocompleteComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibFieldStreetAutocompleteComponent.propDecorators = {
    autocompleteDataForStreet: [{ type: Input }]
};

class ElibFieldsModule {
}
ElibFieldsModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibFieldAddressComponent,
                    ElibFieldCheckboxComponent,
                    ElibFieldCurrencyComponent,
                    ElibFieldDateComponent,
                    ElibFieldDropdownComponent,
                    ElibFieldIncrementalNumberComponent,
                    ElibFieldMailComponent,
                    ElibFieldNumberComponent,
                    ElibFieldPhoneComponent,
                    ElibFieldRadioComponent,
                    ElibFieldTextComponent,
                    ElibFieldTooltipComponent,
                    ElibFieldWrapperComponent,
                    ElibFieldComponent,
                    ElibFieldCityAutocompleteComponent,
                    ElibFieldStreetAutocompleteComponent
                ],
                imports: [
                    TranslateModule,
                    CommonModule,
                    MatAutocompleteModule,
                    MatInputModule,
                    FormsModule,
                    ReactiveFormsModule,
                    AxaIconModule,
                    AxaButtonModule,
                    AxaFormFieldModule,
                    AxaInputModule,
                    AxaPhoneInputModule,
                    AxaRadioButtonModule,
                    AxaDateComboPickerModule,
                    AxaSelectModule,
                    AxaCheckboxModule
                ],
                schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
                exports: [
                    FormsModule,
                    MatAutocompleteModule,
                    ReactiveFormsModule,
                    ElibFieldAddressComponent,
                    ElibFieldCheckboxComponent,
                    ElibFieldCurrencyComponent,
                    ElibFieldDateComponent,
                    ElibFieldDropdownComponent,
                    ElibFieldIncrementalNumberComponent,
                    ElibFieldMailComponent,
                    ElibFieldNumberComponent,
                    ElibFieldPhoneComponent,
                    ElibFieldRadioComponent,
                    ElibFieldTextComponent,
                    ElibFieldTooltipComponent,
                    ElibFieldCityAutocompleteComponent,
                    ElibFieldStreetAutocompleteComponent
                ]
            },] }
];

class ElibCoverCardsModule {
}
ElibCoverCardsModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibCoverCardsComponent,
                    ElibCoverCardComponent,
                    ElibCoverCardBrokerComponent,
                    ElibCoverCardVpBrokerComponent
                ],
                imports: [
                    CommonModule,
                    AxaCardModule,
                    AxaIconModule,
                    AxaButtonModule,
                    TranslateModule,
                    ElibPipesModule,
                    ElibFieldsModule
                ],
                exports: [
                    ElibCoverCardsComponent,
                    ElibCoverCardComponent,
                    ElibCoverCardBrokerComponent,
                    ElibCoverCardVpBrokerComponent
                ]
            },] }
];

const elibComposeStreetAddress = (street, streetNr, postalBoxText = '', boxNr = '') => {
    let addressStreetNr = '';
    let addressBoxNr = boxNr;
    if (streetNr) {
        addressStreetNr = streetNr;
    }
    if (addressBoxNr !== '') {
        addressBoxNr = ` ${postalBoxText} ${addressBoxNr}`;
    }
    return `${street} ${addressStreetNr}${addressBoxNr}`.trim();
};
const elibComposeCityAddress = (postalCode, city) => {
    return `${postalCode} ${city}`;
};
const elibComposeFullAddress = (street, streetNr, postalBoxText = '', boxNr = '', postalCode, city, oneLine = true) => {
    const separator = oneLine ? ', ' : ',<br />';
    const fullStreet = elibComposeStreetAddress(street, streetNr, postalBoxText, boxNr);
    const fullCity = elibComposeCityAddress(postalCode, city);
    return `${fullStreet}${separator}${fullCity}`;
};
const elibGenerateGuid = () => {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return `${s4()}${s4()}-${s4()}-${s4()}-${s4()}-${s4()}${s4()}${s4()}`;
};
const elibGuidGetKey = (guid) => {
    return `_${guid.replace(/-/g, '_')}_`;
};
const elibGuidGetFromKey = (key) => {
    return key.substr(1, key.length - 2).replace(/_/g, '-');
};
const elibGuidCombine = (label, key) => {
    return `${label}.${key.includes('_') ? key : elibGuidGetKey(key)}`;
};
const composeStreetAddress = (street, streetNr, postalBoxText = '', boxNr = '') => {
    let addressStreetNr = '';
    let addressBoxNr = boxNr;
    if (streetNr) {
        addressStreetNr = streetNr;
    }
    if (addressBoxNr !== '') {
        addressBoxNr = ` ${postalBoxText} ${addressBoxNr}`;
    }
    return `${street} ${addressStreetNr}${addressBoxNr}`.trim();
};
const composeCityAddress = (postalCode, city) => {
    return `${postalCode} ${city}`;
};
const composeFullAddress = (street, streetNr, postalBoxText = '', boxNr = '', postalCode, city, oneLine = true) => {
    const separator = oneLine ? ', ' : ',<br />';
    const fullStreet = composeStreetAddress(street, streetNr, postalBoxText, boxNr);
    const fullCity = composeCityAddress(postalCode, city);
    return `${fullStreet}${separator}${fullCity}`;
};

const findProducerNumber = (data) => {
    let i = 0;
    const accountsListLength = data.comptes_list ? data.comptes_list.length : 0;
    for (i; i < accountsListLength; i++) {
        if (data.comptes_list[i].producer_account_number) {
            return data.comptes_list[i].producer_account_number;
        }
    }
};
const parseBrokerDataFromApiModel = (data) => {
    return {
        id: data.associate_id,
        name: data.name,
        street: data.postal_address_list[0] ? data.postal_address_list[0].street_name : '',
        nr: data.postal_address_list[0] ? data.postal_address_list[0].street_number : '',
        zip: data.postal_address_list[0] ? data.postal_address_list[0].postal_code : '',
        city: data.postal_address_list[0] ? data.postal_address_list[0].town_name : '',
        email: data.email_list[0] ? data.email_list[0].email_address : '',
        emailLead: data.email_list[0] ? data.email_list[0].email_address : '',
        phone: data.phone_list[0] ? data.phone_list[0].phone_number : '',
        fax: '',
        website: data.url_list[0] ? data.url_list[0].url_address : '',
        cbfa: data.cbfa_number,
        insuranceFederationCode: data.insurance_federation_code,
        mainNetworkCode: data.main_network_code,
        producerNumber: findProducerNumber(data),
        hasBrocomLogo: (data === null || data === void 0 ? void 0 : data.has_brocom_logo) || false
    };
};
const ɵ0$1 = parseBrokerDataFromApiModel;
const parseBrokerDataFromDltModel = (data) => {
    return {
        id: data.ID,
        name: data.NAME,
        street: data.STREET,
        nr: data.STREET_NUMBER,
        zip: data.POSTAL_CODE,
        city: data.CITY,
        email: data.EMAIL,
        emailLead: data.EMAIL_LEAD,
        phone: data.TELEPHONE,
        fax: data.FAX,
        website: data.WEBSITE,
        cbfa: data.CBFA_NUMBER,
        insuranceFederationCode: data.INSURANCE_FEDERATION_CODE,
        mainNetworkCode: data.MAIN_NETWORK_CODE,
        producerNumber: data.PRODUCER_NUMBER,
        hasBrocomLogo: data.HAS_BROCOM_LOGO
    };
};
const ɵ1 = parseBrokerDataFromDltModel;
const parseBrokerData = (data) => {
    if (data.id) {
        return data;
    }
    if (data.comptes_list) {
        return parseBrokerDataFromApiModel(data);
    }
    return parseBrokerDataFromDltModel(data);
};
const mergeBrokerData = (apiData, dltData) => {
    if (apiData.producerNumber) {
        return Object.assign(dltData, { producerNumber: apiData.producerNumber, hasBrocomLogo: apiData.hasBrocomLogo });
    }
    return dltData;
};

class ElibPosCardComponent {
    constructor() {
    }
    set posData(data) {
        this.parsedData = parseBrokerData(data);
    }
    get posData() {
        return this.parsedData;
    }
    ngOnInit() { }
    getAddress() {
        return composeFullAddress(this.parsedData.street, this.parsedData.nr, '', '', this.parsedData.zip, this.parsedData.city, false);
    }
    handleClick(e) {
        this.actionHandler(this.parsedData);
    }
}
ElibPosCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-pos-card',
                template: "<div class=\"pos-card\" *ngIf=\"parsedData\">\r\n  <h3 *ngIf=\"title\" class=\"pos-card__heading\">{{title}}</h3>\r\n\r\n  <div class=\"pos-card__details\">\r\n    <p class=\"pos-card__details__name\">{{posData.name}}</p>\r\n    <div class=\"pos_address\">\r\n      <axa-icon name=\"location-icon\" class=\"axa-location-icon\"></axa-icon>\r\n      <p class=\"pos-card__details__address\" [innerHTML]=\"getAddress()\"></p>\r\n    </div>\r\n    \r\n    <div class=\"pos_contact\">\r\n      <div>\r\n        <axa-icon name=\"mail-icon\" class=\"axa-mail-icon\"></axa-icon>\r\n        <p *ngIf=\"posData.email\" class=\"pos-card__details__email\" [innerHTML]=\"posData.email\"></p>\r\n      </div>\r\n      <div>\r\n        <axa-icon name=\"phone-icon\" class=\"axa-phone-icon\"></axa-icon>\r\n        <p *ngIf=\"posData.phone\" class=\"pos-card__details__phone\" [innerHTML]=\"posData.phone\"></p>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div *ngIf=\"actionHandler\" class=\"pos-card__actions\">\r\n    <button type=\"button\" axa-button ghost small (click)=\"handleClick($event)\">{{actionLabel | translate}}</button>\r\n  </div>\r\n</div>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush,
                styles: [".pos-card{align-items:flex-end;background:#fff;border:1px solid #ccc;box-shadow:0 0 12px 0 rgba(0,0,0,.2);display:flex;flex-wrap:wrap;margin:1rem 0;overflow:hidden;padding:1rem;width:100%}.pos-card__heading{flex-basis:100%;font-family:\"PT Serif\",serif;font-size:24px;margin-bottom:3rem;margin-top:1rem}.pos-card__details{flex-grow:1}.pos-card__details :last-child{margin-bottom:0}.pos-card__details__name{font-weight:900}.pos-card__actions button,.pos-card__details__address{margin-bottom:0}.axa-location-icon{background:transparent url(assets/icons/location.svg) no-repeat 50%}.axa-mail-icon{background:transparent url(assets/icons/mail.svg) no-repeat 50%}.axa-mail-icon,.axa-phone-icon{float:left;height:24px;width:24px}.axa-phone-icon{background:transparent url(assets/icons/phone.svg) no-repeat 50%}.pos-card__details{margin-bottom:1rem;width:100%!important}.pos_address{display:flex;float:left}.pos_contact{float:right}.pos-card__details__email{margin-bottom:0!important}.pos-card__details__email,.pos-card__details__phone{float:left;font-weight:600;padding-left:.4rem}.pos-card__actions{width:100%!important}.pos-card__actions button{align-items:center;background:#fff;border:1px solid #00008f;border-bottom-color:#00005b;border-radius:0;color:#00008f;cursor:pointer;display:inline-flex;float:right;font-family:Source Sans Pro,arial,sans-serif;letter-spacing:.08em;overflow:hidden;padding:calc(15px - .75em) 20px;position:relative;text-decoration:none;text-transform:uppercase;transition:all .3s;vertical-align:middle;z-index:0}.pos-card__details__address{float:right;padding-left:.4rem}"]
            },] }
];
ElibPosCardComponent.ctorParameters = () => [];
ElibPosCardComponent.propDecorators = {
    posData: [{ type: Input, args: ['posData',] }],
    title: [{ type: Input }],
    actionLabel: [{ type: Input }],
    actionHandler: [{ type: Input }]
};

///<reference types="@types/googlemaps" />
let loaded = false;
const elibLoadGoogleMapsJs = (key, init) => {
    if (loaded) {
        init();
        return;
    }
    const ref = window.document.getElementsByTagName('script')[0];
    const script = window.document.createElement('script');
    window.initMap = init;
    script.src = `https://maps.googleapis.com/maps/api/js?key=${key}&callback=initMap`;
    script.async = true;
    ref.parentNode.insertBefore(script, ref);
    loaded = true;
};
const elibGetLatLngFromAddress = (address, handleGeocodingResults) => {
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address }, handleGeocodingResults);
};
const elibComposeGmapsAddress = (lang, street = '', streetNumber = '', zip = '', city = '') => {
    const country = (lang === 'fr') ? 'Belgique' : 'België';
    const validZip = (zip !== '') ? zip : '1000';
    const validCity = (city !== '') ? city : (lang === 'fr') ? 'Bruxelles' : 'Brussels';
    let p1 = `${street} ${streetNumber}`;
    let separator = ', ';
    if (p1.length < 2) {
        p1 = '';
        separator = '';
    }
    return `${p1}${separator}${validZip} ${validCity} ${country}`;
};

class ElibDltCardService {
}

class ElibBrokerSelectionCardComponent {
    constructor(cdRef, sharedService, modalService, service, translateClient) {
        this.cdRef = cdRef;
        this.sharedService = sharedService;
        this.modalService = modalService;
        this.service = service;
        this.translateClient = translateClient;
        this.unsubscribe = new Subject();
        this.ready = false;
    }
    ngOnInit() {
        this.zip = this.InAddress.zip;
        this.city = this.InAddress.city;
        this.street = this.InAddress.street;
        this.number = this.InAddress.number;
        this.lang = this.sharedService.getDataByAttribute(this.storageKeys.Language).toLowerCase();
        this.dltUrl = this.config.dlt_url;
        this.address = elibComposeGmapsAddress(this.lang, this.street, this.number, this.zip, this.city);
        this.cityAddress = elibComposeGmapsAddress(this.lang, '', '', this.zip, this.city);
        elibLoadGoogleMapsJs(this.config.maps_key, this.initMap.bind(this));
        window.addEventListener('message', this.handleDltMessage.bind(this));
        this.iframeURL = this.getDltUrl();
        this.translateClient.onLangChange.subscribe((d) => {
            this.lang = d.lang;
            this.iframeURL = this.getDltUrl();
        });
    }
    initMap() {
        elibGetLatLngFromAddress(this.address, this.handleGeocodingResults.bind(this));
    }
    getDltUrl() {
        return `${this.dltUrl}/?lang=${this.lang}&list=101&list2=100&showinitial=3&lat=${this.lat}&lng=${this.lng}&showDesktopMap=${'true'}&showMobileMap=${'false'}&address=${this.address}`;
    }
    handleGeocodingResults(results, status) {
        if (status === google.maps.GeocoderStatus.OK) {
            const result = results[0];
            const geometry = result.geometry;
            if (geometry.viewport) {
                const loc = geometry.location;
                this.lng = loc.lng();
                this.lat = loc.lat();
            }
        }
        else if (this.address !== this.cityAddress) {
            this.address = this.cityAddress;
            elibGetLatLngFromAddress(this.cityAddress, this.handleGeocodingResults.bind(this));
            return;
        }
        else {
            this.lng = '4.3524138';
            this.lat = '50.8467316';
            this.address = (this.lang === 'nl') ? elibComposeGmapsAddress('Grote Markt', '', '1000', 'Brussel') : elibComposeGmapsAddress('Grand Place', '', '1000', 'Bruxelles');
        }
        this.ready = true;
        this.cdRef.detectChanges();
    }
    handleDltMessage(e) {
        let data;
        try {
            data = JSON.parse(e.data);
        }
        catch (_a) {
            data = e.data;
        }
        if (typeof data !== 'undefined' && typeof data.ID !== 'undefined' && typeof data.CBFA_NUMBER !== 'undefined') {
            this.handleDltChoice(data);
        }
    }
    handleDltChoice(data) {
        // producer number returned from the dlt is incorrect
        const pos = parseBrokerData(data);
        if (data.ID) {
            this.service.getPointOfSale({
                language: this.lang,
                reference_id: pos.id,
                reference_type_code: '3'
            }).pipe(takeUntil(this.unsubscribe)).subscribe((d) => {
                if (!d.point_of_sale) {
                    this.handlePosSelectionError();
                    return;
                }
                this.choiceCallback(this.parsePointOfSale(pos, d.point_of_sale));
            }, error => {
                throw error;
            });
        }
        else {
            this.handlePosSelectionError();
        }
    }
    parsePointOfSale(dltData, data) {
        const apiData = parseBrokerData(data);
        return mergeBrokerData(apiData, dltData);
    }
    handlePosSelectionError() {
        this.modalService.showModal({
            title: 'ELIB_ERROR_DLT_TITLE',
            content: 'ELIB_ERROR_DLT_BODY'
        });
    }
    ngOnDestroy() {
        window.removeEventListener('message', this.handleDltMessage.bind(this), false);
    }
}
ElibBrokerSelectionCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-broker-selection-card',
                template: "<div class=\"dlt\" *ngIf=\"ready\">\r\n  <iframe class=\"dlt__iframe\" title=\"dltiframe\" [src]=\"iframeURL | elibSafeUrl\"></iframe>\r\n</div>\r\n",
                styles: [".dlt{border:1px solid #ccc;display:flex;margin:2rem -2rem;padding-right:1px;width:calc(100% + 4rem)}.dlt .dlt__iframe{border:none;height:100%;width:100%}"]
            },] }
];
ElibBrokerSelectionCardComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: ElibSharedService },
    { type: ElibModalService },
    { type: ElibDltCardService },
    { type: TranslateService }
];
ElibBrokerSelectionCardComponent.propDecorators = {
    choiceCallback: [{ type: Input }],
    config: [{ type: Input }],
    InAddress: [{ type: Input }],
    storageKeys: [{ type: Input }]
};

class ElibDltCardComponent {
    constructor(cdRef, sharedService) {
        this.cdRef = cdRef;
        this.sharedService = sharedService;
        this.unsubscribe = new Subject();
        this.simulationNext = new EventEmitter();
    }
    ngOnInit() {
        this.preloadedData = this.sharedService.getDataByAttribute(this.storageKeys.preloadedData);
        const hasPreloadedValue = this.preloadedData && Object.keys(this.preloadedData).length > 0;
        this.preloadedData = hasPreloadedValue ? this.preloadedData : null;
        if (!hasPreloadedValue) {
            this.prospectPos = this.sharedService.getDataByAttribute(this.storageKeys.checkProspectResponse).point_of_sales || null;
        }
        if (this.hasExistingBroker()) {
            this.savePosSelection(this.prospectPos[0]);
        }
    }
    ngAfterViewChecked() {
        this.detectChanges();
    }
    detectChanges() {
        if (!this.cdRef['destroyed']) {
            this.cdRef.detectChanges();
        }
    }
    hasSelectedBroker() {
        return (this.preloadedData !== null && typeof this.preloadedData !== 'undefined') && Object.keys(this.preloadedData).length !== 0;
    }
    hasExistingBrokers() {
        return Array.isArray(this.prospectPos) && this.prospectPos.length > 1;
    }
    hasExistingBroker() {
        return Array.isArray(this.prospectPos) && this.prospectPos.length === 1;
    }
    savePosSelection(data) {
        const parsedData = parseBrokerData(data);
        this.sharedService.setData({ fieldData: parsedData });
        // this.preloadedData = parsedData;
        // this.detectChanges();
        this.handleGlobalNext(data);
    }
    removePosSelection() {
        this.sharedService.setData({ fieldData: null });
        this.preloadedData = null;
        this.detectChanges();
    }
    handleGlobalNext(data) {
        this.detectChanges();
        this.simulationNext.emit(data);
    }
    clearExistingBrokers() {
        this.prospectPos = null;
        this.detectChanges();
    }
    handleDltChoice(data) {
        this.savePosSelection(data);
    }
}
ElibDltCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-dlt-card',
                template: "\r\n<ng-template [ngIf]=\"hasSelectedBroker() || hasExistingBrokers()\" [ngIfElse]=\"nobroker\">\r\n    <span  [innerHTML]=\"'ELIB_BROKER_INTRO' | translate\"></span>\r\n</ng-template>\r\n\r\n<ng-template #nobroker>\r\n    <span [innerHTML]=\"'ELIB_NO_BROKER_INTRO' | translate\" ></span>\r\n</ng-template>\r\n\r\n<ng-template [ngIf]=\"hasSelectedBroker()\">\r\n  <elib-pos-card  [@inOutAnimation] [posData]=\"preloadedData\" [actionHandler]=\"handleGlobalNext.bind(this)\" actionLabel=\"ELIB_GLOBAL_NEXT\"></elib-pos-card>\r\n  <a class=\"cover-card__more-link axa-links\" axa-arrow-link (click)=\"removePosSelection()\">\r\n    <span [innerHTML]=\"'ELIB_CHANGE_BROKER' | translate\"></span>\r\n  </a>\r\n</ng-template>\r\n\r\n<div *ngIf=\"hasExistingBrokers() && !hasSelectedBroker()\" [@inOutAnimation] class=\"prospect-brokers\">\r\n  <elib-pos-card *ngFor=\"let pos of prospectPos\" [posData]=\"pos\" [actionHandler]=\"savePosSelection.bind(this)\" actionLabel=\"ELIB_CHOOSE_BROKER\"></elib-pos-card>\r\n  <a class=\"cover-card__more-link axa-links\" axa-arrow-link (click)=\"clearExistingBrokers()\">\r\n    <span [innerHTML]=\"'ELIB_CHANGE_BROKER' | translate\"></span>\r\n  </a>\r\n</div>\r\n\r\n<elib-broker-selection-card [class.hidden]=\"hasSelectedBroker() || hasExistingBrokers()\" [config]=\"config\" [InAddress]=\"address\" [storageKeys]=\"storageKeys\" [choiceCallback]=\"handleDltChoice.bind(this)\"></elib-broker-selection-card>\r\n",
                changeDetection: ChangeDetectionStrategy.OnPush,
                animations: [
                    trigger('inOutAnimation', [
                        transition(':enter', [
                            style({ maxHeight: '0', opacity: 0 }),
                            animate('.3s ease-out', style({ maxHeight: '20rem', opacity: 1 }))
                        ]),
                        transition(':leave', [
                            style({ maxHeight: '20rem', opacity: 1 }),
                            animate('.3s ease-in', style({ maxHeight: '0', opacity: 0 }))
                        ])
                    ]),
                ],
                styles: ["elib-pos-card{display:flex;width:100%}elib-broker-selection-card{display:flex;height:42rem;opacity:1;transition:all .3s}elib-broker-selection-card.hidden{height:0;opacity:0}.center{display:block;margin:0 auto}::ng-deep .cover-card__more-link span{font-size:.9rem!important;font-weight:600!important;text-transform:uppercase!important}::ng-deep elib-dlt-card span{font-family:initial!important;font-size:2em!important;font-weight:700!important}"]
            },] }
];
ElibDltCardComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: ElibSharedService }
];
ElibDltCardComponent.propDecorators = {
    config: [{ type: Input }],
    address: [{ type: Input }],
    form: [{ type: Input }],
    storageKeys: [{ type: Input }],
    simulationNext: [{ type: Output }]
};

class ElibBrokerDetailsCardComponent {
    constructor() {
        this.editEvent = new EventEmitter();
    }
    set posData(data) {
        this.parsedData = parseBrokerData(data);
    }
    get posData() {
        return this.parsedData;
    }
    ngOnInit() { }
    getAddress() {
        return composeFullAddress(this.parsedData.street, this.parsedData.nr, '', '', this.parsedData.zip, this.parsedData.city, false);
    }
    handleEditClick() {
        this.editEvent.emit();
    }
}
ElibBrokerDetailsCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-broker-details-card',
                template: "<div class=\"pos-card\" *ngIf=\"parsedData\">\r\n  <div class=\"pos_section\">\r\n    <div class=\"pos_section_title\">\r\n      <h2 class=\"elib-overview-datalist__group__title\" *ngIf=\"title\" [innerHTML]=\"title | translate\"></h2>\r\n    </div>\r\n    <div class=\"pos_section_icon\">\r\n      <!-- <axa-icon name=\"phone-icon\" class=\"axa-phone-icon\"></axa-icon> -->\r\n      <axa-icon class=\"elib-overview-datalist__item__edit__icon\" name=\"edit-icon\" (click)=\"handleEditClick()\" ></axa-icon>\r\n      <p class=\"\" [innerHTML]=\"'ELIB_GLOBAL_CHANGE' | translate\"></p>\r\n    </div>\r\n  </div>\r\n  <div class=\"pos-name\">\r\n    <axa-icon name=\"brocom-logo\" class=\"axa-brocom-logo\" *ngIf=\"posData.hasBrocomLogo\"></axa-icon>\r\n    <p class=\"pos-card__details__name\">{{posData.name}}</p>\r\n  </div>\r\n\r\n  <div class=\"pos-card__details\">\r\n    <div class=\"pos_address\">\r\n      <axa-icon name=\"location-icon\" class=\"axa-location-icon\"></axa-icon>\r\n      <p class=\"pos-card__details__address\" [innerHTML]=\"getAddress()\"></p>\r\n    </div>\r\n    <div class=\"pos_contact\">\r\n      <div>\r\n        <axa-icon name=\"mail-icon\" class=\"axa-mail-icon\"></axa-icon>\r\n        <p *ngIf=\"posData.email\" class=\"pos-card__details__email\" [innerHTML]=\"posData.email\"></p>\r\n      </div>\r\n      <div>\r\n        <axa-icon name=\"phone-icon\" class=\"axa-phone-icon\"></axa-icon>\r\n        <p *ngIf=\"posData.phone\" class=\"pos-card__details__phone\" [innerHTML]=\"posData.phone\"></p>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>",
                styles: [".pos-card{align-items:flex-end;background:#fff;border:1px solid #ccc;box-shadow:0 0 12px 0 rgba(0,0,0,.2);display:flex;flex-wrap:wrap;margin:1rem 0;overflow:hidden;padding:24px 40px!important;width:100%}.pos-card__heading{flex-basis:100%;font-family:\"PT Serif\",serif;font-size:24px;margin-bottom:3rem;margin-top:1rem}.pos-card__details{flex-grow:1}.pos-card__details :last-child{margin-bottom:0}.pos-card__details__name{font-weight:900}.pos-card__actions button,.pos-card__details__address{margin-bottom:0}.axa-brocom-logo{background:transparent url(assets/icons/brocom.svg) no-repeat 50%}.axa-location-icon{background:transparent url(assets/icons/location.svg) no-repeat 50%}.axa-mail-icon{background:transparent url(assets/icons/mail.svg) no-repeat 50%}.axa-mail-icon,.axa-phone-icon{float:left;height:24px;width:24px}.axa-phone-icon{background:transparent url(assets/icons/phone.svg) no-repeat 50%}.pos-card__details{margin-bottom:1rem;width:100%!important}.pos-name,.pos_address{display:flex;float:left}.pos_contact{float:right}.pos-card__details__email{margin-bottom:0!important}.pos-card__details__email,.pos-card__details__phone{float:left;font-weight:600;padding-left:.4rem}.pos-card__actions{width:100%!important}.pos-card__actions button{align-items:center;background:#fff;border:1px solid #00008f;border-bottom-color:#00005b;border-radius:0;color:#00008f;cursor:pointer;display:inline-flex;float:right;font-family:Source Sans Pro,arial,sans-serif;letter-spacing:.08em;overflow:hidden;padding:calc(15px - .75em) 20px;position:relative;text-decoration:none;text-transform:uppercase;transition:all .3s;vertical-align:middle;z-index:0}.pos-card__details__address{float:right;padding-left:.4rem}.elib-overview-datalist__group__title{font-family:Roboto,Helvetica Neue,sans-serif;font-size:1.25rem;margin-bottom:1rem;margin-top:2rem;text-transform:uppercase}.pos_section{width:100%}.pos_section_title{display:flex;float:left}.pos_section_icon{float:right}.pos_section_icon p{color:#00008f;display:inline-block;font-size:.9rem;font-weight:600;text-transform:uppercase}.pos_section_icon .axa-icon{position:relative;right:5px;top:6px}.pos_section_title h2{margin-top:.5rem!important}"]
            },] }
];
ElibBrokerDetailsCardComponent.ctorParameters = () => [];
ElibBrokerDetailsCardComponent.propDecorators = {
    posData: [{ type: Input, args: ['posData',] }],
    title: [{ type: Input }],
    editEvent: [{ type: Output }]
};

class ElibDltCardModule {
    static forRoot(config) {
        return {
            ngModule: ElibDltCardModule,
            providers: [
                config.DltCardService
            ]
        };
    }
    static forChild(config) {
        return {
            ngModule: ElibDltCardModule,
            providers: [
                { provide: ElibDltCardService, useValue: config.DltCardService }
            ]
        };
    }
}
ElibDltCardModule.decorators = [
    { type: NgModule, args: [{
                declarations: [ElibPosCardComponent, ElibBrokerSelectionCardComponent, ElibDltCardComponent, ElibBrokerDetailsCardComponent],
                imports: [
                    CommonModule,
                    AxaCardModule,
                    AxaIconModule,
                    TranslateModule,
                    ElibPipesModule
                ],
                exports: [ElibDltCardComponent, ElibBrokerDetailsCardComponent]
            },] }
];

const elibGenerateUrlParam = (name, value) => {
    return typeof value !== 'undefined' ? `&${name}=${encodeURI(value)}` : '';
};
const elibGenerateUrlKeyPair = (index, key, value) => {
    const v = `${value}`;
    return typeof value !== 'undefined' ? `&K${index}=${encodeURI(key)}&P${index}=${encodeURI(v)}` : '';
};
const elibFormatDashedDate = (d) => {
    if (d) {
        const dobParts = d.split('/').map(Number);
        return `${dobParts[2]}-${dobParts[1]}-${dobParts[0]}`;
    }
    return;
};
const elibGetCurrentUrl = () => {
    const url = window.location.href;
    const currentUrl = url ? url.split('?') : null;
    const params = currentUrl[1] ? currentUrl[1].split('&') : null;
    let finalUrl = currentUrl[0];
    if (params && params.length >= 2) {
        finalUrl = `${currentUrl[0]}?${params[0]}&${params[1]}`;
    }
    return finalUrl;
};

class ElibIngenicoService {
}

const elibIngenicoIsSuccess = (params) => {
    return [5, 50, 51, 52, 55, 56, 57, 59, 9, 91, 92, 95, 99].includes(Number(params.STATUS));
};

class ElibIngenicoComponent {
    constructor(aRoute, router, service, cdRef) {
        this.aRoute = aRoute;
        this.router = router;
        this.service = service;
        this.cdRef = cdRef;
        this.unsubscribe = new Subject();
    }
    ngOnInit() {
        this.aRoute.queryParams.subscribe((params) => {
            if (this.canGoToThankyou(params)) {
                this.router.navigate([this.successRoute], { queryParamsHandling: 'preserve' });
            }
            else {
                this.constructIngenicoParameters(elibGetCurrentUrl());
            }
        });
        this.aRoute.queryParams.subscribe((params) => {
            if (elibIngenicoIsSuccess(params)) {
                if (this.successCallback && this.successCallback.then) {
                    this.successCallback.then(() => {
                        this.router.navigate([this.successRoute], { queryParamsHandling: 'preserve' });
                    });
                }
                else {
                    this.router.navigate([this.successRoute], { queryParamsHandling: 'preserve' });
                }
            }
        });
    }
    canGoToThankyou(params) {
        return [
            ...[5, 50, 51, 52, 55, 56, 57, 59],
            ...[9, 91, 92, 95, 99]
        ].includes(Number(params['STATUS']));
    }
    constructIngenicoParameters(url) {
        this.service.createPaymentRequest(url).pipe(takeUntil(this.unsubscribe))
            .subscribe(response => {
            this.bindHiddenFields(response);
        }, err => { });
        this.cdRef.detectChanges();
    }
    bindHiddenFields(objResponse) {
        if (objResponse.parameters.length > 0) {
            this.params = objResponse.parameters.reduce((map, obj) => {
                map[obj.key] = obj.value;
                return map;
            }, {});
        }
    }
    submit() {
        this.form.nativeElement.submit();
    }
    ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
}
ElibIngenicoComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-ingenico',
                template: "<form class=\"axa-form\" #ingenicoForm ngNoForm method=\"post\" name=\"redirect\" action={{url}}>\r\n  <div *ngIf=\"params\">\r\n    <input type=\"hidden\" name=\"AMOUNT\" [value]=\"params.AMOUNT\">\r\n    <input type=\"hidden\" name=\"BGCOLOR\" value=\"#fff\">\r\n    <input type=\"hidden\" name=\"BUTTONBGCOLOR\" value=\"#3a88d6\">\r\n    <input type=\"hidden\" name=\"BUTTONTXTCOLOR\" value=\"#fff\">\r\n    <input type=\"hidden\" name=\"CN\" [value]=\"params.CN\">\r\n    <input type=\"hidden\" name=\"CURRENCY\" value=\"EUR\">\r\n    <input type=\"hidden\" name=\"EMAIL\" [value]=\"params.EMAIL\">\r\n    <input type=\"hidden\" name=\"FONTTYPE\" value=\"arial\">\r\n    <input type=\"hidden\" name=\"LANGUAGE\" [value]=\"params.LANGUAGE\">\r\n    <input type=\"hidden\" name=\"LOGO\" value=\"https://start2bank.axa.be/images/ogone/insurance_fr_small.jpg\">\r\n    <input type=\"hidden\" name=\"ORDERID\" [value]=\"params.ORDERID\">\r\n    <input type=\"hidden\" name=\"OWNERADDRESS\" [value]=\"params.OWNERADDRESS\">\r\n    <input type=\"hidden\" name=\"OWNERCTY\" value=\"150\">\r\n    <input type=\"hidden\" name=\"OWNERTELNO\" [value]=\"params.OWNERTELNO\">\r\n    <input type=\"hidden\" name=\"OWNERTOWN\" [value]=\"params.OWNERTOWN\">\r\n    <input type=\"hidden\" name=\"OWNERZIP\" [value]=\"params.OWNERZIP\">\r\n    <input type=\"hidden\" name=\"PARAMPLUS\" [value]=\"params.PARAMPLUS\">\r\n    <input type=\"hidden\" name=\"PSPID\" [value]=\"params.PSPID\">\r\n    <input type=\"hidden\" name=\"TBLBGCOLOR\" value=\"#e6eff5\">\r\n    <input type=\"hidden\" name=\"TBLTXTCOLOR\" value=\"#333\">\r\n    <input type=\"hidden\" name=\"TXTCOLOR\" value=\"#333\">\r\n    <input type=\"hidden\" name=\"SHASIGN\" [value]=\"params.SHASIGN\">\r\n  </div>\r\n</form>\r\n",
                styles: [""]
            },] }
];
ElibIngenicoComponent.ctorParameters = () => [
    { type: ActivatedRoute },
    { type: Router },
    { type: ElibIngenicoService },
    { type: ChangeDetectorRef }
];
ElibIngenicoComponent.propDecorators = {
    url: [{ type: Input }],
    successRoute: [{ type: Input }],
    successCallback: [{ type: Input }],
    createPaymentRequestMethod: [{ type: Input }],
    form: [{ type: ViewChild, args: ['ingenicoForm', { static: true },] }]
};

class ElibIngenicoModule {
    static forRoot(config) {
        return {
            ngModule: ElibIngenicoModule,
            providers: [
                config.IngenicoService
            ]
        };
    }
    static forChild(config) {
        return {
            ngModule: ElibIngenicoModule,
            providers: [
                { provide: ElibIngenicoService, useValue: config.IngenicoService }
            ]
        };
    }
}
ElibIngenicoModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibIngenicoComponent
                ],
                imports: [
                    CommonModule,
                    RouterModule
                ],
                exports: [
                    ElibIngenicoComponent
                ]
            },] }
];

;

class ElibOverviewDatalistComponent {
    constructor() { }
}
ElibOverviewDatalistComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-overview-datalist',
                template: "<section class=\"elib-overview-datalist\">\r\n  <axa-card content>\r\n    <axa-card-content>\r\n      <h1 class=\"elib-overview-datalist__title\">{{ title | translate }}</h1>\r\n      <ng-content></ng-content>\r\n    </axa-card-content>\r\n  </axa-card>\r\n</section>\r\n",
                styles: [".elib-overview-datalist__title{font-family:Roboto,Helvetica Neue,sans-serif;font-size:1.25rem;margin-bottom:1.5rem;text-transform:uppercase}"]
            },] }
];
ElibOverviewDatalistComponent.ctorParameters = () => [];
ElibOverviewDatalistComponent.propDecorators = {
    title: [{ type: Input }]
};

class ElibOverviewGroupComponent {
    constructor() { }
}
ElibOverviewGroupComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-overview-group',
                template: "<div class=\"elib-overview-datalist__group\">\r\n  <h2 class=\"elib-overview-datalist__group__title\" *ngIf=\"title\">{{ title | translate }}</h2>\r\n  <ul class=\"elib-overview-datalist__group__list\">\r\n    <ng-content></ng-content>\r\n  </ul>\r\n</div>\r\n",
                styles: [".elib-overview-datalist__group__list{list-style:none;padding:0}.elib-overview-datalist__group__title{font-size:1rem;font-weight:700;margin-bottom:1rem;margin-top:2rem;text-transform:none}"]
            },] }
];
ElibOverviewGroupComponent.ctorParameters = () => [];
ElibOverviewGroupComponent.propDecorators = {
    title: [{ type: Input }]
};

class ElibOverviewItemComponent {
    constructor(el) {
        this.el = el;
        this.$nonEditable = false;
        this.editEvent = new EventEmitter();
    }
    set nonEditable(value) {
        this.$nonEditable = typeof value !== 'undefined' && value !== false;
    }
    get nonEditable() {
        return this.$nonEditable;
    }
    ngOnInit() {
        const nativeEl = this.el.nativeElement;
        const parentEl = nativeEl.parentElement;
        while (nativeEl.firstChild) {
            parentEl.insertBefore(nativeEl.firstChild, nativeEl);
        }
        parentEl.removeChild(nativeEl);
    }
    handleEditClick() {
        this.editEvent.emit();
    }
}
ElibOverviewItemComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-overview-item',
                template: "<li class=\"elib-overview-datalist__item\">\r\n  <div class=\"elib-overview-datalist__item__name\">\r\n    <ng-content select=\"[elib-overview-item-name]\"></ng-content>\r\n  </div>\r\n  <div class=\"elib-overview-datalist__item__value\">\r\n    <ng-content select=\"[elib-overview-item-value]\"></ng-content>\r\n  </div>\r\n  <div class=\"elib-overview-datalist__item__edit\">\r\n    <axa-icon class=\"elib-overview-datalist__item__edit__icon\" name=\"edit-icon\" (click)=\"handleEditClick()\" *ngIf=\"!nonEditable\"></axa-icon>\r\n  </div>\r\n</li>\r\n",
                styles: [".elib-overview-datalist__item{border-bottom:1px solid #efefef;color:#777;display:flex;padding:.25rem 0}.elib-overview-datalist__item:last-child{border-bottom:none}.elib-overview-datalist__item__name{flex-grow:1;margin-right:1rem}.elib-overview-datalist__item__value{text-align:right}.elib-overview-datalist__item__edit{flex-basis:2rem;text-align:right}.elib-overview-datalist__item__edit__icon{display:inline-block;height:15px;margin:8px 0 0;vertical-align:top;width:15px}"]
            },] }
];
ElibOverviewItemComponent.ctorParameters = () => [
    { type: ElementRef }
];
ElibOverviewItemComponent.propDecorators = {
    nonEditable: [{ type: Input }],
    editEvent: [{ type: Output }]
};

class ElibOverviewPriceComponent {
    // @ViewChild('modal', { static: true }) modal: ElementRef;
    constructor(service, modalService) {
        this.service = service;
        this.modalService = modalService;
        this.submitPromoEvent = new EventEmitter();
        this.editOptionsEvent = new EventEmitter();
        this.$showPromo = false;
    }
    set showPromo(value) {
        this.$showPromo = typeof value !== 'undefined' && value !== false;
    }
    get showPromo() {
        return this.$showPromo;
    }
    ngOnInit() {
        this.service.getData().subscribe((data) => {
            this.covers = data.covers;
            this.options = data.options;
            this.packName = data.packName;
            this.getPrice();
        });
    }
    getPrice() {
        let optionsPrice = 0;
        let coversPrice = 0;
        this.covers.forEach((cover) => {
            coversPrice += cover.price ? cover.price : 0;
        });
        this.options.forEach((option) => {
            optionsPrice += option.price ? option.price : 0;
        });
        this.coversPrice = coversPrice;
        this.optionsPrice = optionsPrice;
        this.price = coversPrice + optionsPrice;
    }
    handlePromoClick(value) {
        this.submitPromoEvent.emit(value);
    }
    handleEditOptions() {
        this.editOptionsEvent.emit();
    }
    openMeerDetails() {
        var _a, _b;
        this.modalService.showModal({
            title: ((_a = this.popupData) === null || _a === void 0 ? void 0 : _a.titleLabel) || '',
            content: ((_b = this.popupData) === null || _b === void 0 ? void 0 : _b.contentLabel) || '',
            primaryActionLabel: 'ELIB_MODAL_CONFIRM',
            primaryAction: () => {
                this.modalService.hideModal();
            },
            secondaryActionLabel: 'ELIB_MODAL_CLOSE',
            plainMode: true
        });
    }
}
ElibOverviewPriceComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-overview-price',
                template: "<section class=\"elib-overview-price\">\r\n  <axa-card content>\r\n    <axa-card-content>\r\n      <h1 class=\"elib-overview-price__title\">{{ 'ELIB_OVERVIEW_PRICE_TITLE' | translate }}</h1>\r\n      <div class=\"elib-overview-price__message\">\r\n        {{ 'ELIB_OVERVIEW_PRICE_MESSAGE' | translate }}\r\n        \r\n        <div *ngIf=\"popupData\">\r\n          <a class=\"cover-card__more-link axa-links\" axa-arrow-link (click)=\"openMeerDetails()\" >\r\n            <span [innerHTML]=\"popupData?.linkLabel | translate\"></span>\r\n            <axa-icon name=\"rightarrow-blue\"></axa-icon>\r\n          </a>\r\n        </div>\r\n        \r\n      </div>\r\n      <h2 class=\"elib-overview-price__subtitle\">{{ 'ELIB_OVERVIEW_PRICE_SUBTITLE' | translate }}</h2>\r\n      <ul class=\"elib-overview-price__coversList\">\r\n        <li *ngFor=\"let cover of covers\" class=\"elib-overview-price__coversList__cover\" [class.elib-overview-price__coversList__cover--highlight]=\"cover.highlight\">\r\n          <span class=\"elib-overview-price__coversList__cover__heading\">{{ cover.name | translate }}</span>\r\n          <span class=\"elib-overview-price__coversList__cover__price\" *ngIf=\"cover.price\" [innerHTML]=\"cover.price | price\"></span>\r\n        </li>\r\n      </ul>\r\n      <ul class=\"elib-overview-price__optionsList\" *ngIf=\"options\">\r\n        <li class=\"elib-overview-price__optionsList__title\">\r\n          <span class=\"elib-overview-price__optionsList__title__text\">{{ 'ELIB_OVERVIEW_PRICE_OPTIONS__TITLE' | translate }} <axa-icon class=\"elib-overview-price__optionsList__title__edit\" name=\"edit-icon\" (click)=\"handleEditOptions()\"></axa-icon></span>\r\n          <span class=\"elib-overview-price__optionsList__title__price\" *ngIf=\"optionsPrice\" [innerHTML]=\"optionsPrice | price\"></span>\r\n        </li>\r\n        <li *ngFor=\"let option of options\" class=\"elib-overview-price__optionsList__option\">\r\n          <span class=\"elib-overview-price__optionsList__option__heading\">{{ option.name | translate }}</span>\r\n          <span class=\"elib-overview-price__optionsList__option__price\" *ngIf=\"option.price\" [innerHTML]=\"option.price | price\"></span>\r\n        </li>\r\n        <li *ngIf=\"options.length === 0\">\r\n          {{ 'ETRAVEL_P2_SC2_TOTAL_NO_SELECTED_OPTIONAL_COVERAGE' | translate }}\r\n        </li>\r\n      </ul>\r\n      <div class=\"elib-overview-price__total\">\r\n        <span class=\"elib-overview-price__total__label\">{{ 'ELIB_OVERVIEW_PRICE_TOTAL__TITLE' | translate }}<span class=\"elib-global-taxes_label\">{{'ELIB_GLOBAL_TAXES'  | translate}}</span></span>\r\n        <span class=\"elib-overview-price__total__value\" [innerHTML]=\"price | price\"></span>\r\n      </div>\r\n    </axa-card-content>\r\n  </axa-card>\r\n</section>\r\n\r\n\r\n<!-- \r\n<div class=\"cover-card-hidden\" >\r\n  <div #modal>\r\n    <div class=\"cover-card\">\r\n      <div class=\"cover-card__content\" [innerHTML]=\"popupData.contentLabel | translate\" ></div>\r\n    </div>\r\n  </div>\r\n</div> -->",
                styles: [".elib-overview-price__title{font-family:initial;font-size:2.5em;font-weight:700;margin-bottom:1.5rem}.elib-overview-price__subtitle{font-family:Roboto,Helvetica Neue,sans-serif;font-size:1rem;font-weight:700;margin-bottom:.5rem;text-transform:uppercase}.elib-overview-price__coversList,.elib-overview-price__optionsList{list-style:none;padding:0}.elib-overview-price__coversList,.elib-overview-price__optionsList__title{font-weight:700}.elib-overview-price__coversList{border-bottom:1px solid #ccc;padding-bottom:1rem}.elib-overview-price__coversList__cover,.elib-overview-price__optionsList__option,.elib-overview-price__optionsList__title,.elib-overview-price__total{display:flex}.elib-overview-price__coversList__cover__heading,.elib-overview-price__optionsList__option__heading,.elib-overview-price__optionsList__title__text,.elib-overview-price__total__label{flex-grow:1}.elib-overview-price__coversList__cover__price,.elib-overview-price__optionsList__title__price{color:#00aec6}.elib-overview-price__optionsList__title__text{align-items:center;display:flex}.elib-overview-price__optionsList__title__edit{height:1rem;margin-left:1rem;width:1rem}.elib-overview-price__total{background:#ddd;font-size:1.25rem;font-weight:700;margin:1rem -40px;padding:1rem 40px}.elib-overview-price__message{background:#ddd;border-left:3px solid #00aec6;font-size:14px;margin:1rem 0 2rem;padding:1rem}.elib-global-taxes_label{font-size:.8rem;padding:.3rem}"]
            },] }
];
ElibOverviewPriceComponent.ctorParameters = () => [
    { type: ElibSideBarService },
    { type: ElibModalService }
];
ElibOverviewPriceComponent.propDecorators = {
    popupData: [{ type: Input }],
    showPromo: [{ type: Input }],
    submitPromoEvent: [{ type: Output }],
    editOptionsEvent: [{ type: Output }]
};

class ElibOverviewModule {
}
ElibOverviewModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibOverviewDatalistComponent,
                    ElibOverviewGroupComponent,
                    ElibOverviewItemComponent,
                    ElibOverviewPriceComponent
                ],
                imports: [
                    CommonModule,
                    AxaCardModule,
                    AxaIconModule,
                    TranslateModule,
                    ElibPipesModule
                ],
                exports: [
                    ElibOverviewDatalistComponent,
                    ElibOverviewGroupComponent,
                    ElibOverviewItemComponent,
                    ElibOverviewPriceComponent
                ]
            },] }
];

class ElibPacksComponent {
    constructor() {
        this.desktopPacksData = [];
        this.mobilePacksData = [];
        this.guid = elibGenerateGuid();
        this.selectPack = new EventEmitter();
    }
    set packsData(value) {
        if (typeof value === 'undefined') {
            return;
        }
        this.generateDesktopPacksData(value);
        this.generateMobilePacksData(value);
    }
    getJointLabel(prefix, suffix) {
        if (typeof prefix === 'undefined') {
            return suffix;
        }
        if (typeof suffix === 'undefined') {
            return prefix;
        }
        return [prefix, suffix].join('&nbsp;:&nbsp;');
    }
    generateDesktopPacksData(data) {
        let rowIndex = 1;
        this.desktopPacksDataHeader = this.generateDesktopPacksDataRow(data[0]);
        this.desktopPacksData = [];
        for (rowIndex; rowIndex < data.length; rowIndex += 1) {
            this.desktopPacksData.push(this.generateDesktopPacksDataRow(data[rowIndex]));
        }
    }
    generateDesktopPacksDataRow(data) {
        return {
            heading: {
                label: data.label,
                content: data.content,
                section: !data.columns || !data.columns.length
            },
            columns: data.columns
        };
    }
    generateMobilePacksData(data) {
        let colIndex = 0;
        let rowIndex = 1;
        this.mobilePacksData = [];
        for (colIndex; colIndex < data[0].columns.length; colIndex += 1) {
            this.mobilePacksData[colIndex] = [];
            for (rowIndex = 1; rowIndex < data.length; rowIndex += 1) {
                this.mobilePacksData[colIndex].push(this.generateMobilePacksDataRow(data[rowIndex], colIndex));
            }
        }
    }
    generateMobilePacksDataRow(data, index) {
        var _a, _b;
        if (!data.columns) {
            return {
                label: [data.label],
                content: [data.content],
                section: true
            };
        }
        return {
            label: [data.label, (_a = data.columns[index]) === null || _a === void 0 ? void 0 : _a.label],
            content: [data.content, (_b = data.columns[index]) === null || _b === void 0 ? void 0 : _b.content],
            included: data.columns[index].included,
            action: data.columns[index].action,
            packId: data.columns[index].packId,
            icon: data.columns[index].icon,
            price: data.columns[index].price
        };
    }
    handlePackSelect(e) {
        this.selectPack.emit(e);
    }
}
ElibPacksComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-packs',
                template: "<!-- Desktop markup - Table structure -->\r\n<table class=\"elib-packs elib-packs--desktop\" *ngIf=\"desktopPacksData && desktopPacksDataHeader\">\r\n  <thead>\r\n    <tr>\r\n      <td></td>\r\n      <td class=\"elib-packs__row__column\" *ngFor=\"let col of desktopPacksDataHeader.columns\">\r\n        <elib-packs-cover [data]=\"col\"></elib-packs-cover>\r\n      </td>\r\n    </tr>\r\n  </thead>\r\n  <tbody>\r\n    <tr *ngFor=\"let row of desktopPacksData; let i = index\">\r\n      <th class=\"elib-packs__row__heading\" [class.elib-pack-section]=\"row.heading.section\"><elib-packs-row-header [data]=\"row.heading\" [guid]=\"guid\" [rowId]=\"i\"></elib-packs-row-header></th>\r\n      <td class=\"elib-packs__row__column\" *ngFor=\"let col of row.columns\">\r\n        <elib-packs-cell [data]=\"col\" [guid]=\"guid\" [rowId]=\"i\" (selectPack)=\"handlePackSelect($event)\"></elib-packs-cell>\r\n      </td>\r\n      <td class=\"elib-packs__row__column\" [class.elib-pack-section]=\"row.heading.section\" *ngIf=\"!row.columns\" [colspan]=\"desktopPacksDataHeader.columns.length\"></td>\r\n    </tr>\r\n  </tbody>\r\n</table>\r\n\r\n<!-- Mobile markup - Columns structure -->\r\n<div class=\"elib-packs elib-packs--mobile\" *ngIf=\"mobilePacksData\">\r\n  <div class=\"elib-packs__pack\" *ngFor=\"let pack of mobilePacksData; let i = index\">\r\n    <div class=\"elib-packs__pack__header\">\r\n      <elib-packs-cover [data]=\"desktopPacksDataHeader.columns[i]\"></elib-packs-cover>\r\n    </div>\r\n    <ng-container *ngFor=\"let row of pack; let j = index\">\r\n      <div class=\"elib-packs__pack__row\" [class.elib-pack-section]=\"row.section\">\r\n        <elib-packs-row-mobile [data]=\"row\" [guid]=\"guid\" [rowId]=\"j\" (selectPack)=\"handlePackSelect($event)\"></elib-packs-row-mobile>\r\n      </div>\r\n    </ng-container>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"elib-legal\" [innerHTML]=\"'ELIB_PACKS_TAXES' | translate\"></div>\r\n<div class=\"elib-legal\" [innerHTML]=\"'ELIB_PACKS_LIMITATIONS' | translate\"></div>\r\n",
                styles: [":host{align-items:center;display:flex;flex-direction:column;margin-bottom:2rem}.elib-packs{border-spacing:0;filter:drop-shadow(2px 4px 10px rgba(0,0,0,.1));margin:1rem 2rem;width:auto}.elib-packs.elib-packs--mobile{background:#fff;display:flex;padding:1rem}.elib-packs.elib-packs--mobile ::ng-deep .mat-expansion-indicator{left:auto;right:-.5rem}@media (min-width:992px){.elib-packs.elib-packs--mobile{display:none}}.elib-packs.elib-packs--desktop{display:none}@media (min-width:992px){.elib-packs.elib-packs--desktop{display:table}}.elib-packs thead{border-right:1px solid #ccc;transition:.3s}.elib-packs tbody{border:1px solid #ccc;transition:.3s}.elib-packs th{font-weight:400}.elib-packs .elib-pack-section{background:#ccc!important;color:#333;font-weight:700;position:relative;text-transform:uppercase}.elib-packs ::ng-deep .mat-expansion-panel-header{margin:0 -24px;padding:0 24px;text-align:left}.elib-packs ::ng-deep .mat-expansion-panel-body{padding:0!important;text-align:left!important}.elib-packs__row__column,.elib-packs__row__heading{background:#fff;border-bottom:1px solid #eee;border-right:1px dotted #ccc;max-width:20rem;padding:.8rem 1rem .8rem 2rem;text-align:left;vertical-align:top}.elib-packs__row__column{max-width:30rem;padding:.8rem 1.5rem}.elib-packs__row__column ::ng-deep .mat-expansion-panel-header-title{display:inline}.elib-packs__row__column:last-child{border-right:none}tbody tr:last-child .elib-packs__row__column{border-bottom:0}.elib-packs__pack{display:flex;flex-direction:column;margin:0 auto}.elib-packs__pack__row{align-items:center;display:flex;margin:.5rem 0;padding-left:1rem}.elib-packs__pack__row button{justify-content:center;margin:1rem 0;width:100%}.axa-btn{font-size:.9em;padding:1em 4em}::ng-deep .elib-pack__icon{border-radius:50%;display:inline-block;height:1.1rem;position:relative;width:1.1rem}::ng-deep .elib-pack__icon:after{background:transparent url(assets/icons/pack-available.svg) no-repeat 50%;background-size:contain;content:\"\";display:block;height:.8rem;left:50%;position:absolute;top:50%;transform:translate(-50%,-50%);width:.8rem}::ng-deep .elib-pack__icon--unavailable:after{background-image:url(assets/icons/pack-unavailable.svg)}::ng-deep .elib-pack__icon--option:after{background-image:url(assets/icons/pack-option.svg)}::ng-deep .elib-pack__icon--nooption:after{background-image:url(assets/icons/pack-nooption.svg)}::ng-deep .elib-packs__pack__row button{justify-content:center;margin:1rem 0;width:100%}.elib-packs--mobile .elib-packs__pack__row{padding:0 1rem}.elib-packs--mobile ::ng-deep .mat-expansion-panel-content,.elib-packs--mobile ::ng-deep .mat-expansion-panel-header-title{padding-left:30px}.elib-packs--mobile ::ng-deep .elib-packs__pack__row__indicator{margin-left:-30px}.elib-packs--mobile ::ng-deep .elib-accordion-block-as-label{padding-left:30px}.elib-packs--mobile ::ng-deep .elib-pack-section.elib-pack-section{background:transparent!important}.elib-packs--mobile ::ng-deep .elib-pack-section.elib-pack-section .elib-accordion-block-as-label{padding-left:0}elib-packs-row-mobile{width:100%}"]
            },] }
];
ElibPacksComponent.propDecorators = {
    packsData: [{ type: Input }],
    selectPack: [{ type: Output }]
};

class ElibPacksCellComponent {
    constructor(translateService) {
        this.translateService = translateService;
        this.selectPack = new EventEmitter();
    }
    set setHasColumns(attribute) { this.hasColumns = attribute === '' || attribute; }
    set setMobile(attribute) { this.mobile = attribute === '' || attribute; }
    set setIsHeader(attribute) { this.isHeader = attribute === '' || attribute; }
    getId() { return `${this.guid}${this.rowId}`; }
    getColumnAccordionData() {
        const header = this.getLabel();
        const content = this.data.content ? this.translateService.instant(this.data.content) : null;
        return {
            id: this.getId(),
            header,
            content,
            expanded: false,
            static: false
        };
    }
    getLabel() {
        let l = '';
        if (this.data.label) {
            l = this.translateService.instant(this.data.label);
        }
        else {
            l = '';
        }
        const indicatorLabel = this.getIndicatorLabel();
        return indicatorLabel === '' ? l : `<span class="elib-packs__pack__row__indicator">${indicatorLabel}</span>${l}`;
    }
    getIndicatorLabel() {
        if (this.data.included === 'YES') {
            return '<span class="elib-pack__icon elib-pack__icon--available"></span>';
        }
        if (this.data.included === 'NO') {
            return '<span class="elib-pack__icon elib-pack__icon--unavailable"></span>';
        }
        if (this.data.included === 'OPTION') {
            return '<span class="elib-pack__icon elib-pack__icon--option"></span>';
        }
        if (this.data.included === 'NOOPTION') {
            return '<span class="elib-pack__icon elib-pack__icon--nooption"></span>';
        }
        return '';
    }
    hasLabel() {
        return !!(typeof this.data !== 'undefined' && (this.data.label || this.data.included));
    }
    hasContent() {
        return typeof this.data !== 'undefined' && (typeof this.data.content !== 'undefined' && this.data.content !== '');
    }
    shouldShowAccordion() {
        return !this.shouldShowAction() && this.hasLabel() && this.hasContent();
    }
    shouldShowLabel() {
        return this.hasLabel() && !this.hasContent();
    }
    shouldShowAction() {
        return !!this.data.action;
    }
    handlePackSelect(e) {
        this.selectPack.emit(this.data.packId);
    }
}
ElibPacksCellComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-packs-cell',
                template: "<elib-accordion-block\r\n  *ngIf=\"shouldShowAccordion()\"\r\n  [accordionData]=\"getColumnAccordionData()\"\r\n  class=\"elib-accordion-block\"\r\n  [hideToggle]=\"true\"\r\n></elib-accordion-block>\r\n\r\n<span\r\n  class=\"elib-accordion-block-as-label\"\r\n  *ngIf=\"shouldShowLabel()\"\r\n  [innerHTML]=\"getLabel()\">\r\n</span>\r\n\r\n<button\r\n  *ngIf=\"shouldShowAction()\"\r\n  axa-button\r\n  alt\r\n  type=\"submit\"\r\n  (click)=\"handlePackSelect()\">\r\n  {{ data.action | translate }}\r\n</button>\r\n",
                styles: [":host{padding-right:1rem;width:100%}@media (min-width:992px){:host{padding-right:0}}.elib-accordion-block-as-label{display:flex}::ng-deep .elib-packs__pack__row__indicator{align-items:center;display:inline-flex;height:20px;margin-right:10px;vertical-align:middle;width:20px}button{display:block;margin:0 auto;max-width:100%;width:11rem}"]
            },] }
];
ElibPacksCellComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibPacksCellComponent.propDecorators = {
    data: [{ type: Input }],
    guid: [{ type: Input }],
    rowId: [{ type: Input }],
    setHasColumns: [{ type: Input, args: ['hasColumns',] }],
    setMobile: [{ type: Input, args: ['mobile',] }],
    setIsHeader: [{ type: Input, args: ['isHeader',] }],
    selectPack: [{ type: Output }]
};

class ElibPacksCoverComponent {
    constructor() { }
    getIconSrc() {
        return `assets/icons/${this.data.icon}.svg`;
    }
}
ElibPacksCoverComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-packs-cover',
                template: "<div class=\"elib-packs-cover\">\r\n  <div class=\"elib-packs-cover__icon\"><img [src]=\"getIconSrc()\" /></div>\r\n  <div class=\"elib-packs-cover__label\">{{data?.label | translate}}</div>\r\n  <div class=\"elib-packs-cover__price\"><div [innerHTML]=\"data?.price | price\"></div><sup>(1)</sup></div>\r\n</div>\r\n",
                styles: [".elib-packs-cover{align-items:center;display:flex;flex-direction:column}.elib-packs-cover__icon{margin:1rem 0 .5rem}.elib-packs-cover__icon img{height:8rem;margin:0 auto}.elib-packs-cover__label{font-weight:800;margin:0}.elib-packs-cover__price{display:flex;font-size:2rem;font-weight:800;margin:0 0 1rem}.elib-packs-cover__price sup{font-size:1rem}"]
            },] }
];
ElibPacksCoverComponent.ctorParameters = () => [];
ElibPacksCoverComponent.propDecorators = {
    data: [{ type: Input }]
};

class ElibPacksRowHeaderComponent {
    constructor(translateService) {
        this.translateService = translateService;
    }
    getId() { return `${this.guid}${this.rowId}`; }
    getColumnAccordionData() {
        const header = this.getLabel();
        const content = this.data.content ? this.translateService.instant(this.data.content) : null;
        return {
            id: this.getId(),
            header,
            content,
            expanded: false,
            static: false
        };
    }
    getLabel() {
        if (this.data.label) {
            return this.translateService.instant(this.data.label);
        }
        return '';
    }
    hasLabel() {
        return !!(typeof this.data !== 'undefined' && this.data.label);
    }
    hasContent() {
        return typeof this.data !== 'undefined' && (typeof this.data.content !== 'undefined' && this.data.content !== '');
    }
    shouldShowAccordion() {
        return this.hasLabel() && this.hasContent();
    }
    shouldShowLabel() {
        return (this.hasLabel() && !this.hasContent());
    }
}
ElibPacksRowHeaderComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-packs-row-header',
                template: "<elib-accordion-block\r\n  *ngIf=\"shouldShowAccordion()\"\r\n  [accordionData]=\"getColumnAccordionData()\"\r\n  class=\"elib-accordion-block\"\r\n  [hideToggle]=\"hideToggle\"\r\n></elib-accordion-block>\r\n\r\n<span\r\n  *ngIf=\"shouldShowLabel()\"\r\n  [innerHTML]=\"getLabel()\">\r\n</span>\r\n",
                styles: [""]
            },] }
];
ElibPacksRowHeaderComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibPacksRowHeaderComponent.propDecorators = {
    data: [{ type: Input }],
    guid: [{ type: Input }],
    rowId: [{ type: Input }]
};

class ElibPacksRowMobileComponent {
    constructor(translateService) {
        this.translateService = translateService;
        this.selectPack = new EventEmitter();
    }
    getId() { return `${this.guid}${this.rowId}`; }
    getJointLabel(prefix, suffix) {
        const prefixTranslation = prefix ? this.translateService.instant(prefix) : null;
        const suffixTranslation = suffix ? this.translateService.instant(suffix) : null;
        if (!prefixTranslation) {
            return suffixTranslation;
        }
        if (!suffixTranslation) {
            return prefixTranslation;
        }
        return [prefixTranslation, suffixTranslation].join('&nbsp;:&nbsp;');
    }
    getLabel() {
        const l = this.getJointLabel(this.data.label[0], this.data.label[1]);
        const indicatorLabel = this.getIndicatorLabel();
        return indicatorLabel === '' ? l : `<span class="elib-packs__pack__row__indicator">${indicatorLabel}</span>${l}`;
    }
    getIndicatorLabel() {
        if (this.data.included === 'YES') {
            return '<span class="elib-pack__icon elib-pack__icon--available"></span>';
        }
        if (this.data.included === 'NO') {
            return '<span class="elib-pack__icon elib-pack__icon--unavailable"></span>';
        }
        if (this.data.included === 'OPTION') {
            return '<span class="elib-pack__icon elib-pack__icon--option"></span>';
        }
        if (this.data.included === 'NOOPTION') {
            return '<span class="elib-pack__icon elib-pack__icon--nooption"></span>';
        }
        return '';
    }
    getContent() {
        const content = [];
        for (const item of this.data.content) {
            if (item) {
                content.push(this.translateService.instant(item));
            }
        }
        return content.join('<br />');
    }
    getAccordionData() {
        const header = this.getLabel();
        const content = this.getContent();
        return {
            id: this.getId(),
            header,
            content,
            expanded: false,
            static: false
        };
    }
    hasContent() {
        return typeof this.data.content[0] !== 'undefined' || typeof this.data.content[1] !== 'undefined';
    }
    shouldShowAccordion() {
        return this.hasContent() && !this.shouldShowAction();
    }
    shouldShowLabel() {
        return !this.hasContent() && !this.shouldShowAction();
    }
    shouldShowAction() {
        return !!this.data.action;
    }
    handlePackSelect(e) {
        this.selectPack.emit(e);
    }
}
ElibPacksRowMobileComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-packs-row-mobile',
                template: "<elib-accordion-block\r\n  *ngIf=\"shouldShowAccordion()\"\r\n  [accordionData]=\"getAccordionData()\"\r\n  class=\"elib-accordion-block\"\r\n  [hideToggle]=\"false\"\r\n></elib-accordion-block>\r\n\r\n<span\r\n  class=\"elib-accordion-block-as-label\"\r\n  *ngIf=\"shouldShowLabel()\"\r\n  [innerHTML]=\"getLabel()\">\r\n</span>\r\n\r\n<button\r\n  *ngIf=\"shouldShowAction()\"\r\n  axa-button\r\n  alt\r\n  type=\"submit\"\r\n  (click)=\"handlePackSelect(data.packId)\">\r\n  {{ data.action | translate }}\r\n</button>\r\n",
                styles: [""]
            },] }
];
ElibPacksRowMobileComponent.ctorParameters = () => [
    { type: TranslateService }
];
ElibPacksRowMobileComponent.propDecorators = {
    data: [{ type: Input }],
    guid: [{ type: Input }],
    rowId: [{ type: Input }],
    selectPack: [{ type: Output }]
};

class ElibPacksModule {
    static forRoot() {
        return {
            ngModule: ElibAccordionBlockModule,
            providers: [
                ElibAccordionBlockService
            ]
        };
    }
    static forChild() {
        return {
            ngModule: ElibAccordionBlockModule,
            providers: [
                ElibAccordionBlockService
            ]
        };
    }
}
ElibPacksModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibPacksComponent,
                    ElibPacksCellComponent,
                    ElibPacksCoverComponent,
                    ElibPacksRowHeaderComponent,
                    ElibPacksRowMobileComponent
                ],
                imports: [
                    CommonModule,
                    AxaHeaderModule,
                    AxaIconModule,
                    TranslateModule,
                    ElibAccordionBlockModule,
                    ElibPipesModule,
                    AxaButtonModule
                ],
                exports: [
                    ElibPacksComponent
                ]
            },] }
];

/*export interface ElibPacksMobileRow {
  label: string;
  content: string;
  included?: string;
  action?: string;
  packId?: string;
}

export interface ElibPacksMobileColumn extends Array<ElibPacksMobileRow> {}

export interface ElibPacksHeaderData extends Array<ElibPacksHeaderColumnData> {}*/

class ElibPrevLinkComponent {
    constructor(router) {
        this.router = router;
    }
    handlePrevClick() {
        this.router.navigate([this.prevRoute], { queryParamsHandling: 'preserve' });
    }
}
ElibPrevLinkComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-prev-link',
                template: "<a axa-arrow-link class=\"elib-prev-link\" (click)=\"handlePrevClick()\">\r\n  <axa-icon name=\"icon-arrow-left\" class=\"axa-left-icon\"></axa-icon>\r\n  {{ 'ELIB_PREV_LINK' | translate }}\r\n</a>\r\n",
                styles: [":host{display:block;font-size:.85rem;margin:0 2rem}.elib-prev-link{color:#f07662;cursor:pointer;font-size:12px;font-weight:600;letter-spacing:1px;line-height:18px;text-transform:uppercase}a{align-items:center;display:flex}::ng-deep .axa-left-icon{fill:currentColor;height:1.3em;margin-right:.5rem;width:1.3em}::ng-deep .axa-left-icon svg{height:auto!important;width:auto!important}"]
            },] }
];
ElibPrevLinkComponent.ctorParameters = () => [
    { type: Router }
];
ElibPrevLinkComponent.propDecorators = {
    prevRoute: [{ type: Input }]
};

class ElibPrevLinkModule {
}
ElibPrevLinkModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibPrevLinkComponent
                ],
                imports: [
                    CommonModule,
                    AxaIconModule,
                    TranslateModule
                ],
                exports: [
                    ElibPrevLinkComponent
                ]
            },] }
];

class ElibSidebarComponent {
    constructor(service, eref, renderer) {
        this.service = service;
        this.eref = eref;
        this.renderer = renderer;
        this.toggled = false;
        this.editEvent = new EventEmitter();
        this.removeEvent = new EventEmitter();
    }
    clickout(e) {
        if (!this.eref.nativeElement.contains(e.target)) {
            this.toggled = false;
        }
    }
    ngOnInit() {
        this.renderer.addClass(document.body, 'elib-has-sidebar');
        this.service.getData().subscribe((data) => {
            this.covers = data.covers;
            this.options = data.options;
            this.packName = data.packName;
            this.getPrice();
        });
    }
    ngOnDestroy() {
        this.renderer.removeClass(document.body, 'elib-has-sidebar');
    }
    getPrice() {
        let optionsPrice = 0;
        let coversPrice = 0;
        this.covers.forEach((cover) => {
            coversPrice += cover.price ? cover.price : 0;
        });
        this.options.forEach((option) => {
            optionsPrice += option.price ? option.price : 0;
        });
        this.coversPrice = coversPrice;
        this.optionsPrice = optionsPrice;
        this.price = coversPrice + optionsPrice;
    }
    handleEdit(id) {
        this.editEvent.emit(id);
    }
    handleRemove(id) {
        this.removeEvent.emit(id);
    }
    handleToggle() {
        this.toggled = !this.toggled;
    }
}
ElibSidebarComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-sidebar',
                template: "<div class=\"elib-sidebar__host\">\r\n  <div class=\"elib-sidebar__wrapper\" [class.toggled]=\"toggled\">\r\n    <axa-card active>\r\n      <axa-card-title class=\"elib-sidebar__title\" (click)=\"handleToggle()\">\r\n        <svg class=\"elib-sidebar__title__icon\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 511.999 511.999\">\r\n          <path d=\"M214.685,402.828c-24.829,0-45.029,20.2-45.029,45.029c0,24.829,20.2,45.029,45.029,45.029s45.029-20.2,45.029-45.029 C259.713,423.028,239.513,402.828,214.685,402.828z M214.685,467.742c-10.966,0-19.887-8.922-19.887-19.887 c0-10.966,8.922-19.887,19.887-19.887s19.887,8.922,19.887,19.887C234.572,458.822,225.65,467.742,214.685,467.742z\"/>\r\n          <path d=\"M372.63,402.828c-24.829,0-45.029,20.2-45.029,45.029c0,24.829,20.2,45.029,45.029,45.029s45.029-20.2,45.029-45.029 C417.658,423.028,397.458,402.828,372.63,402.828z M372.63,467.742c-10.966,0-19.887-8.922-19.887-19.887 c0-10.966,8.922-19.887,19.887-19.887c10.966,0,19.887,8.922,19.887,19.887C392.517,458.822,383.595,467.742,372.63,467.742z\"/>\r\n          <path d=\"M383.716,165.755H203.567c-6.943,0-12.571,5.628-12.571,12.571c0,6.943,5.629,12.571,12.571,12.571h180.149 c6.943,0,12.571-5.628,12.571-12.571C396.287,171.382,390.659,165.755,383.716,165.755z\"/>\r\n          <path d=\"M373.911,231.035H213.373c-6.943,0-12.571,5.628-12.571,12.571s5.628,12.571,12.571,12.571h160.537 c6.943,0,12.571-5.628,12.571-12.571C386.481,236.664,380.853,231.035,373.911,231.035z\"/>\r\n          <path d=\"M506.341,109.744c-4.794-5.884-11.898-9.258-19.489-9.258H95.278L87.37,62.097c-1.651-8.008-7.113-14.732-14.614-17.989 l-55.177-23.95c-6.37-2.767-13.773,0.156-16.536,6.524c-2.766,6.37,0.157,13.774,6.524,16.537L62.745,67.17l60.826,295.261 c2.396,11.628,12.752,20.068,24.625,20.068h301.166c6.943,0,12.571-5.628,12.571-12.571c0-6.943-5.628-12.571-12.571-12.571 H148.197l-7.399-35.916H451.69c11.872,0,22.229-8.44,24.624-20.068l35.163-170.675 C513.008,123.266,511.136,115.627,506.341,109.744z M451.69,296.301H135.619l-35.161-170.674l386.393,0.001L451.69,296.301z\"/>\r\n        </svg>\r\n        <h1 class=\"elib-sidebar__title__heading\">{{ 'ELIB_SIDEBAR_TITLE' | translate }}</h1>\r\n        <div class=\"elib-sidebar__title__price\" [innerHTML]=\"price | price\"></div>\r\n      </axa-card-title>\r\n      <axa-card-content compact class=\"elib-sidebar__covers\">\r\n        <ul class=\"elib-sidebar__list elib-sidebar__covers__list\">\r\n          <li class=\"elib-sidebar__list__item elib-sidebar__list__title\">\r\n            <span class=\"elib-sidebar__list__item__heading\">{{ packName | translate }}</span>\r\n            <span class=\"elib-sidebar__list__item__price\" *ngIf=\"coversPrice\" [innerHTML]=\"coversPrice | price\">{{ coversPrice | price }}</span>\r\n          </li>\r\n          <li *ngFor=\"let cover of covers\" class=\"elib-sidebar__list__item elib-sidebar__covers__list__cover\" [class.elib-sidebar__covers__list__cover--highlight]=\"cover.highlight\">\r\n            <span class=\"elib-sidebar__list__item__heading\">{{ cover.name | translate }}</span>\r\n            <span class=\"elib-sidebar__list__item__price\" *ngIf=\"cover.price\" [innerHTML]=\"cover.price | price\"></span>\r\n            <axa-icon class=\"elib-sidebar__list__item__edit\" name=\"edit-icon\" *ngIf=\"cover.editId\" (click)=\"handleEdit(cover.editId)\"></axa-icon>\r\n            <axa-icon class=\"elib-sidebar__list__item__remove\" name=\"cancel-icon\" *ngIf=\"cover.removeId\" (click)=\"handleRemove(cover.removeId)\"></axa-icon>\r\n          </li>\r\n        </ul>\r\n      </axa-card-content>\r\n      <axa-card-content compact class=\"elib-sidebar__options\" *ngIf=\"options.length\">\r\n        <ul class=\"elib-sidebar__list elib-sidebar__options__list\">\r\n          <li class=\"elib-sidebar__list__item elib-sidebar__list__title\">\r\n            <span class=\"elib-sidebar__list__item__heading\">{{ 'ELIB_SIDEBAR_OPTIONS_TITLE' | translate }}</span>\r\n            <span class=\"elib-sidebar__list__item__price\" *ngIf=\"optionsPrice\" [innerHTML]=\"optionsPrice | price\"></span>\r\n          </li>\r\n          <li *ngFor=\"let option of options\" class=\"elib-sidebar__list__item elib-sidebar__options__list__option\">\r\n            <span class=\"elib-sidebar__list__item__heading\">{{ option.name | translate }}</span>\r\n            <span class=\"elib-sidebar__list__item__price\" *ngIf=\"option.price\" [innerHTML]=\"option.price | price\"></span>\r\n            <axa-icon class=\"elib-sidebar__list__item__edit\" name=\"edit-icon\" *ngIf=\"option.editId\" (click)=\"handleEdit(option.editId)\"></axa-icon>\r\n            <axa-icon class=\"elib-sidebar__list__item__remove\" name=\"cancel-icon\" *ngIf=\"option.removeId\" (click)=\"handleRemove(option.removeId)\"></axa-icon>\r\n          </li>\r\n        </ul>\r\n      </axa-card-content>\r\n\r\n      <axa-card-content compact class=\"elib-sidebar__options\" *ngIf=\"options.length === 0\" >\r\n        <ul class=\"elib-sidebar__list elib-sidebar__options__list\">\r\n          <li class=\"elib-sidebar__list__item elib-sidebar__list__title\">\r\n            <span class=\"elib-sidebar__list__item__heading\">{{ 'ELIB_SIDEBAR_OPTIONS_TITLE' | translate }}</span>\r\n          </li>\r\n          <li class=\"elib-sidebar__list__item elib-sidebar__options__list__option\">\r\n            <span class=\"elib-sidebar__list__item__heading\">{{ 'ETRAVEL_P2_SC2_TOTAL_NO_SELECTED_OPTIONAL_COVERAGE' | translate }}</span>\r\n          </li>\r\n        </ul>\r\n      </axa-card-content>\r\n    </axa-card>\r\n  </div>\r\n</div>\r\n\r\n<ng-content></ng-content>\r\n",
                styles: [".elib-sidebar__host{display:block}@media (max-width:991px){.elib-sidebar__host{left:0;position:fixed;top:100%;width:100%;z-index:800}}@media (max-width:991px){::ng-deep .elib-has-sidebar{padding-bottom:75px}}.axa-card__block,.axa-card__title{padding:24px 20px!important}.elib-sidebar__wrapper{display:flex;flex-direction:column;left:0;position:sticky;top:0;transition:transform .3s;width:100%;will-change:transform}@media (max-width:991px){.elib-sidebar__wrapper{background:#fff;padding-bottom:0;position:static;transform:translateY(-75px)}.elib-sidebar__wrapper.toggled{transform:translateY(-100%)}}.elib-sidebar__title{align-items:center;background:#00aec6!important;color:#fff;display:flex}@media (max-width:991px){.elib-sidebar__title{padding-bottom:12px!important;padding-top:12px!important}}.elib-sidebar__title__icon{fill:#fff;height:3rem;margin-right:1rem;width:3rem}@media (max-width:991px){.elib-sidebar__title__icon{height:2.5rem;width:2.5rem}}.elib-sidebar__title__heading,.elib-sidebar__title__price{font-family:\"PT Serif\",serif;font-size:2rem;font-weight:700;letter-spacing:.02em;line-height:2;margin:0}@media (max-width:991px){.elib-sidebar__title__heading,.elib-sidebar__title__price{font-size:1.8rem;line-height:1.8}}.elib-sidebar__title__heading{flex-grow:1;text-align:left}.elib-sidebar__title__price{font-size:1.75rem}.elib-sidebar__covers__heading,.elib-sidebar__options__heading{font-size:1rem;font-weight:700;letter-spacing:.02em;line-height:2;margin:0;text-transform:uppercase}.elib-sidebar__list{list-style:none;padding:0}.elib-sidebar__list__item{display:flex}.elib-sidebar__list__item__edit,.elib-sidebar__list__item__remove{align-self:center;cursor:pointer;height:1rem;margin-left:-1rem;width:1rem}.elib-sidebar__list__item__heading{flex-grow:1}.elib-sidebar__list__item__price{padding-right:2rem}.elib-sidebar__list__title .elib-sidebar__list__item__heading{flex-grow:1;font-weight:700}.elib-sidebar__list__title .elib-sidebar__list__item__price{color:#00aec6;font-weight:700}::ng-deep .axa-card{margin-bottom:2rem!important}@media (max-width:991px){::ng-deep .axa-card{margin-bottom:0!important}}::ng-deep .btn-zone{margin:0 -1rem!important}::ng-deep .btn-zone__button{max-width:none!important}"]
            },] }
];
ElibSidebarComponent.ctorParameters = () => [
    { type: ElibSideBarService },
    { type: ElementRef },
    { type: Renderer2 }
];
ElibSidebarComponent.propDecorators = {
    editEvent: [{ type: Output }],
    removeEvent: [{ type: Output }],
    clickout: [{ type: HostListener, args: ['document:click', ['$event'],] }]
};

class ElibSidebarModule {
}
ElibSidebarModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibSidebarComponent
                ],
                imports: [
                    CommonModule,
                    AxaCardModule,
                    AxaIconModule,
                    TranslateModule,
                    ElibPipesModule
                ],
                exports: [
                    ElibSidebarComponent
                ]
            },] }
];

class ElibTooltipComponent {
    constructor() {
        this.toggled = false;
    }
    ngOnInit() {
    }
    handleBlur() {
        this.toggled = false;
    }
    handleClick(e) {
        e.preventDefault();
        e.stopPropagation();
        this.toggled = !this.toggled;
    }
    getClassName() {
        const cls = 'elib-tooltip__icon';
        return this.toggled ? `${cls} elib-tooltip__icon--toggled` : cls;
    }
}
ElibTooltipComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-tooltip',
                template: "<a href=\"#\" [class]=\"getClassName()\" tabIndex=\"-1\" (blur)=\"handleBlur()\" (click)=\"handleClick($event)\">\r\n  <axa-icon name=\"info\"></axa-icon>\r\n</a>\r\n<div class=\"elib-tooltip__content\" [innerHTML]=\"content | translate\"></div>\r\n",
                styles: [":host{position:relative}.axa-icon,:host{display:inline-block}.axa-icon{height:1.25rem;width:1.25rem}.elib-tooltip__content{background:#3032c1;border-radius:5px;bottom:1.75rem;color:#fff;left:50%;opacity:0;padding:.5rem;position:absolute;transform:translateX(-50%);transition:opacity .3s;visibility:hidden;width:20rem}.elib-tooltip__content:after{border:5px solid transparent;border-bottom-color:#3032c1;content:\"\";left:49%;pointer-events:none;position:absolute;top:100%;transform:rotate(180deg)}.elib-tooltip__icon--toggled+.elib-tooltip__content{opacity:1;visibility:visible}"]
            },] }
];
ElibTooltipComponent.ctorParameters = () => [];
ElibTooltipComponent.propDecorators = {
    content: [{ type: Input }]
};

class ElibTooltipModule {
}
ElibTooltipModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibTooltipComponent
                ],
                imports: [
                    TranslateModule,
                    AxaIconModule
                ],
                exports: [
                    ElibTooltipComponent
                ]
            },] }
];

class ElibPageThankYouComponent {
    constructor() { }
    ngOnInit() {
    }
}
ElibPageThankYouComponent.decorators = [
    { type: Component, args: [{
                selector: 'elib-page-thank-you',
                template: "<div class=\"elib-page elib-page-thank-you\">\r\n  <svg class=\"elib-page-thank-you__icon\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\"  viewBox=\"0 0 25 25\">\r\n    <g transform=\"translate(0 -1028.4)\">\r\n      <path d=\"m22 12c0 5.523-4.477 10-10 10-5.5228 0-10-4.477-10-10 0-5.5228 4.4772-10 10-10 5.523 0 10 4.4772 10 10z\" transform=\"translate(0 1029.4)\" fill=\"#27ae60\"/>\r\n      <path d=\"m22 12c0 5.523-4.477 10-10 10-5.5228 0-10-4.477-10-10 0-5.5228 4.4772-10 10-10 5.523 0 10 4.4772 10 10z\" transform=\"translate(0 1028.4)\" fill=\"#2ecc71\"/>\r\n      <path d=\"m16 1037.4-6 6-2.5-2.5-2.125 2.1 2.5 2.5 2 2 0.125 0.1 8.125-8.1-2.125-2.1z\" fill=\"#27ae60\"/>\r\n      <path d=\"m16 1036.4-6 6-2.5-2.5-2.125 2.1 2.5 2.5 2 2 0.125 0.1 8.125-8.1-2.125-2.1z\" fill=\"#ecf0f1\"/>\r\n    </g>\r\n  </svg>\r\n\r\n  <h1 class=\"elib-page__title elib-page-thank-you__title\">\r\n    <span [innerHTML]=\"'ELIB_PAGE_THANK_YOU_TITLE' | translate\"></span>\r\n    <span class=\"elib-page__title__sub elib-page-thank-you__title__sub\" [innerHTML]=\"'ELIB_PAGE_THANK_YOU_SUBTITLE' | translate\"></span>\r\n  </h1>\r\n\r\n  <ng-content select=\"[elib-page-thank-you-section1]\"></ng-content>\r\n\r\n  <div class=\"elib-ekomi\" *ngIf=\"ekomiData\">\r\n    <h2 [innerHTML]=\"ekomiData.title | translate\"></h2>\r\n    <p [innerHTML]=\"ekomiData.text | translate\"></p>\r\n\r\n    <div class=\"elib-ekomi__stars\">\r\n      <svg class=\"elib-ekomi__stars__star\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 32 32\" xml:space=\"preserve\">\r\n        <path d=\"M 32,10 H 20 L 16,0 12,10 H 0 L 8,20 4,32 16,25 28,32 24,20 32,10 z M 16,22.406 8.125,27 10.75,19.125 5.5,12.562 h 7.875 L 16,6 18.625,12.562 H 26.5 L 21.25,19.124 23.875,27 16,22.406 z\" />\r\n      </svg>\r\n      <svg class=\"elib-ekomi__stars__star\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 32 32\" xml:space=\"preserve\">\r\n        <path d=\"M 32,10 H 20 L 16,0 12,10 H 0 L 8,20 4,32 16,25 28,32 24,20 32,10 z M 16,22.406 8.125,27 10.75,19.125 5.5,12.562 h 7.875 L 16,6 18.625,12.562 H 26.5 L 21.25,19.124 23.875,27 16,22.406 z\" />\r\n      </svg>\r\n      <svg class=\"elib-ekomi__stars__star\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 32 32\" xml:space=\"preserve\">\r\n        <path d=\"M 32,10 H 20 L 16,0 12,10 H 0 L 8,20 4,32 16,25 28,32 24,20 32,10 z M 16,22.406 8.125,27 10.75,19.125 5.5,12.562 h 7.875 L 16,6 18.625,12.562 H 26.5 L 21.25,19.124 23.875,27 16,22.406 z\" />\r\n      </svg>\r\n      <svg class=\"elib-ekomi__stars__star\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 32 32\" xml:space=\"preserve\">\r\n        <path d=\"M 32,10 H 20 L 16,0 12,10 H 0 L 8,20 4,32 16,25 28,32 24,20 32,10 z M 16,22.406 8.125,27 10.75,19.125 5.5,12.562 h 7.875 L 16,6 18.625,12.562 H 26.5 L 21.25,19.124 23.875,27 16,22.406 z\" />\r\n      </svg>\r\n      <svg class=\"elib-ekomi__stars__star\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 32 32\" xml:space=\"preserve\">\r\n        <path d=\"M 32,10 H 20 L 16,0 12,10 H 0 L 8,20 4,32 16,25 28,32 24,20 32,10 z M 16,22.406 8.125,27 10.75,19.125 5.5,12.562 h 7.875 L 16,6 18.625,12.562 H 26.5 L 21.25,19.124 23.875,27 16,22.406 z\" />\r\n      </svg>\r\n    </div>\r\n  </div>\r\n\r\n  <div *ngIf=\"promo\" class=\"elib-promo\">\r\n    <div class=\"elib-promo__banner\">\r\n      <img *ngIf=\"promo.image\" [src]=\"promo.image\" />\r\n      <h2 *ngIf=\"promo.heading\" [innerHTML]=\"promo.heading | translate\"></h2>\r\n    </div>\r\n    <h3 *ngIf=\"promo.subheading\" [innerHTML]=\"promo.subheading | translate\"></h3>\r\n    <ng-content select=\"[elib-promo-content]\"></ng-content>\r\n    <a *ngIf=\"promo.button\" [href]=\"promo.button.link | translate\" (click)=\"promo.button.handleClick\" axa-button alt>\r\n      {{ promo.button.label | translate }}<axa-icon style=\"width:24px;height:24px\" name=\"rightarrow-blue\"></axa-icon>\r\n    </a>\r\n    <p class=\"elib-promo__notes\" [innerHTML]=\"promo.notes | translate\"></p>\r\n  </div>\r\n</div>\r\n",
                styles: [".elib-page-thank-you{align-items:center;display:flex;flex-direction:column;text-align:center}.elib-page-thank-you__icon{height:4rem;margin:1rem;width:4rem}.elib-ekomi{width:100%}.elib-ekomi:before{background:#ccc;content:\"\";display:block;height:1px;margin:1rem -2rem 2rem;width:calc(100% + 4rem)}@media (min-width:992px){.elib-ekomi:before{margin:1rem -3rem 2rem;width:calc(100% + 6rem)}}.elib-ekomi__stars{display:flex;justify-content:center}.elib-ekomi__stars__star{fill:#ccc;height:2rem;margin:.5rem;width:2rem}.elib-promo{margin:2rem 0;text-align:left;width:100%}.elib-promo__banner{margin-bottom:3rem;position:relative}.elib-promo__banner img{margin:0 -2rem;width:calc(100% + 4rem)}@media (min-width:992px){.elib-promo__banner img{margin:0 -3rem;width:calc(100% + 6rem)}}.elib-promo__banner h2{background:#fff;bottom:-2rem;box-shadow:0 4px 8px 0 rgba(0,0,0,.3);display:block;font-family:initial;max-width:75%;padding:1rem;position:absolute}.elib-promo__banner h2,.elib-promo h3{font-size:2rem;font-weight:700}.elib-promo .axa-btn{margin-top:2rem}.elib-promo__notes{color:#999;font-size:80%;margin:.5em 0}.elib-page{margin:2rem}@media (min-width:992px){.elib-page{border:1px solid #ccc;box-shadow:0 4px 8px 0 rgba(0,0,0,.3);margin:0 auto;padding:3rem;transition:.3s;width:630px}}.elib-page__title{font-family:initial;font-size:2.5rem;font-weight:700}.elib-page__title__sub{display:block;font-family:roboto;font-size:1rem;font-weight:400;margin-top:1rem;text-transform:uppercase}"]
            },] }
];
ElibPageThankYouComponent.ctorParameters = () => [];
ElibPageThankYouComponent.propDecorators = {
    promo: [{ type: Input }],
    ekomiData: [{ type: Input }]
};

class ElibPageThankYouModule {
}
ElibPageThankYouModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ElibPageThankYouComponent
                ],
                imports: [
                    CommonModule,
                    TranslateModule,
                    AxaCardModule,
                    AxaButtonModule
                ],
                exports: [
                    ElibPageThankYouComponent
                ]
            },] }
];

const elibCompareObjects = (a, b) => {
    const s = (o) => Object.entries(o).sort().map(i => {
        if (i[1] instanceof Object) {
            i[1] = s(i[1]);
        }
        return i;
    });
    return JSON.stringify(s(a)) === JSON.stringify(s(b));
};

class ElibMissingTranslationHandler {
    handle(params) {
        return params.key;
    }
}

const elibValidation = validation;

/**
 * Generated bundle index. Do not edit.
 */

export { ELIB_SHARED_CONFIG, ElibAccordionBlockComponent, ElibAccordionBlockModule, ElibAlertService, ElibAmountPipe, ElibAppWrapperComponent, ElibAppWrapperModule, ElibBrokerCardComponent, ElibBrokerCardModule, ElibBrokerDetailsCardComponent, ElibCaptchaService, ElibCommonModule, ElibCoverCardBrokerComponent, ElibCoverCardComponent, ElibCoverCardVpBrokerComponent, ElibCoverCardsComponent, ElibCoverCardsModule, ElibDataLayerService, ElibDateOperationsService, ElibDltCardComponent, ElibDltCardModule, ElibDltCardService, ElibFieldAddressComponent, ElibFieldCheckboxComponent, ElibFieldCityAutocompleteComponent, ElibFieldConfig, ElibFieldCurrencyComponent, ElibFieldDateComponent, ElibFieldDropdownComponent, ElibFieldIncrementalNumberComponent, ElibFieldMailComponent, ElibFieldNumberComponent, ElibFieldPhoneComponent, ElibFieldRadioComponent, ElibFieldStreetAutocompleteComponent, ElibFieldTextComponent, ElibFieldTooltipComponent, ElibFieldTypes, ElibFieldsModule, ElibFooterComponent, ElibFooterModule, ElibHTTPListener, ElibHTTPStatus, ElibHeaderComponent, ElibHeaderCovidBannerComponent, ElibHeaderHelpComponent, ElibHeaderModule, ElibIngenicoComponent, ElibIngenicoModule, ElibIngenicoService, ElibMissingTranslationHandler, ElibModalComponent, ElibModalModule, ElibModalService, ElibNavigationComponent, ElibNavigationModule, ElibOverviewDatalistComponent, ElibOverviewGroupComponent, ElibOverviewItemComponent, ElibOverviewModule, ElibOverviewPriceComponent, ElibPacksComponent, ElibPacksModule, ElibPageThankYouComponent, ElibPageThankYouModule, ElibPipesModule, ElibPrevLinkComponent, ElibPrevLinkModule, ElibPricePipe, ElibSafeUrlPipe, ElibSharedService, ElibSideBarService, ElibSidebarComponent, ElibSidebarModule, ElibStorageService, ElibTooltipComponent, ElibTooltipModule, composeCityAddress, composeFullAddress, composeStreetAddress, eLibAmountTransform, elibCompareObjects, elibComposeCityAddress, elibComposeFullAddress, elibComposeGmapsAddress, elibComposeStreetAddress, elibFormatDashedDate, elibGenerateGuid, elibGenerateUrlKeyPair, elibGenerateUrlParam, elibGetCurrentUrl, elibGetLatLngFromAddress, elibGuidCombine, elibGuidGetFromKey, elibGuidGetKey, elibIngenicoIsSuccess, elibLoadGoogleMapsJs, elibPatternDate, elibPatternEmail, elibPatternPhone, elibPatternPhoneMobile, elibPatternPositiveFloat, elibPatternPositiveInteger, elibPatternTextWithoutNumbers, elibToFixed, elibValidation, findProducerNumber, futureDateNotAllowed, mergeBrokerData, parseBrokerData, phoneRequired, required, validAge, validDate, validEmail, validPhone, validateMaxAge, validateMinAge, ɵ0$1 as ɵ0, ɵ1, ElibAccordionBlockService as ɵa, AxaAlertModule as ɵb, AxaAlertManager as ɵc, AxaAlertService as ɵd, ElibLanguageSelectorComponent as ɵe, ElibFieldComponent as ɵf, ElibFieldWrapperComponent as ɵg, ElibPosCardComponent as ɵh, ElibBrokerSelectionCardComponent as ɵi, ElibPacksCellComponent as ɵj, ElibPacksCoverComponent as ɵk, ElibPacksRowHeaderComponent as ɵl, ElibPacksRowMobileComponent as ɵm };
//# sourceMappingURL=elib-common.js.map
